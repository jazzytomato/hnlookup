// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.config');
goog.require('cljs.core');
oops.config.get_initial_runtime_config = (function oops$config$get_initial_runtime_config(){
return cljs.core.PersistentHashMap.fromArrays([cljs.core.cst$kw$warning_DASH_reporting,cljs.core.cst$kw$empty_DASH_selector_DASH_access,cljs.core.cst$kw$error_DASH_reporting,cljs.core.cst$kw$expected_DASH_function_DASH_value,cljs.core.cst$kw$child_DASH_factory,cljs.core.cst$kw$invalid_DASH_selector,cljs.core.cst$kw$throw_DASH_errors_DASH_from_DASH_macro_DASH_call_DASH_sites,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.cst$kw$missing_DASH_object_DASH_key],[cljs.core.cst$kw$console,cljs.core.cst$kw$warn,cljs.core.cst$kw$throw,cljs.core.cst$kw$error,cljs.core.cst$kw$js_DASH_obj,cljs.core.cst$kw$error,true,cljs.core.cst$kw$error,cljs.core.cst$kw$error]);
});
oops.config._STAR_runtime_config_STAR_ = oops.config.get_initial_runtime_config();
oops.config.set_current_runtime_config_BANG_ = (function oops$config$set_current_runtime_config_BANG_(new_config){

oops.config._STAR_runtime_config_STAR_ = new_config;

return new_config;
});
oops.config.get_current_runtime_config = (function oops$config$get_current_runtime_config(){
return oops.config._STAR_runtime_config_STAR_;
});
oops.config.update_current_runtime_config_BANG_ = (function oops$config$update_current_runtime_config_BANG_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___13352 = arguments.length;
var i__8119__auto___13353 = (0);
while(true){
if((i__8119__auto___13353 < len__8118__auto___13352)){
args__8125__auto__.push((arguments[i__8119__auto___13353]));

var G__13354 = (i__8119__auto___13353 + (1));
i__8119__auto___13353 = G__13354;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (f_or_map,args){
if(cljs.core.map_QMARK_(f_or_map)){
return oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic(cljs.core.merge,cljs.core.array_seq([f_or_map], 0));
} else {
return oops.config.set_current_runtime_config_BANG_(cljs.core.apply.cljs$core$IFn$_invoke$arity$3(f_or_map,oops.config.get_current_runtime_config(),args));
}
});

oops.config.update_current_runtime_config_BANG_.cljs$lang$maxFixedArity = (1);

oops.config.update_current_runtime_config_BANG_.cljs$lang$applyTo = (function (seq13350){
var G__13351 = cljs.core.first(seq13350);
var seq13350__$1 = cljs.core.next(seq13350);
return oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__13351,seq13350__$1);
});

oops.config.get_config_key = (function oops$config$get_config_key(var_args){
var args__8125__auto__ = [];
var len__8118__auto___13362 = arguments.length;
var i__8119__auto___13363 = (0);
while(true){
if((i__8119__auto___13363 < len__8118__auto___13362)){
args__8125__auto__.push((arguments[i__8119__auto___13363]));

var G__13364 = (i__8119__auto___13363 + (1));
i__8119__auto___13363 = G__13364;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic = (function (key,p__13357){
var vec__13358 = p__13357;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__13358,(0),null);
var G__13361 = (function (){var or__6939__auto__ = config;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return oops.config.get_current_runtime_config();
}
})();
return (key.cljs$core$IFn$_invoke$arity$1 ? key.cljs$core$IFn$_invoke$arity$1(G__13361) : key.call(null,G__13361));
});

oops.config.get_config_key.cljs$lang$maxFixedArity = (1);

oops.config.get_config_key.cljs$lang$applyTo = (function (seq13355){
var G__13356 = cljs.core.first(seq13355);
var seq13355__$1 = cljs.core.next(seq13355);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(G__13356,seq13355__$1);
});

oops.config.has_config_key_QMARK_ = (function oops$config$has_config_key_QMARK_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___13371 = arguments.length;
var i__8119__auto___13372 = (0);
while(true){
if((i__8119__auto___13372 < len__8118__auto___13371)){
args__8125__auto__.push((arguments[i__8119__auto___13372]));

var G__13373 = (i__8119__auto___13372 + (1));
i__8119__auto___13372 = G__13373;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return oops.config.has_config_key_QMARK_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

oops.config.has_config_key_QMARK_.cljs$core$IFn$_invoke$arity$variadic = (function (key,p__13367){
var vec__13368 = p__13367;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__13368,(0),null);
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$oops$config_SLASH_not_DASH_found,cljs.core.get.cljs$core$IFn$_invoke$arity$3((function (){var or__6939__auto__ = config;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return oops.config.get_current_runtime_config();
}
})(),key,cljs.core.cst$kw$oops$config_SLASH_not_DASH_found));
});

oops.config.has_config_key_QMARK_.cljs$lang$maxFixedArity = (1);

oops.config.has_config_key_QMARK_.cljs$lang$applyTo = (function (seq13365){
var G__13366 = cljs.core.first(seq13365);
var seq13365__$1 = cljs.core.next(seq13365);
return oops.config.has_config_key_QMARK_.cljs$core$IFn$_invoke$arity$variadic(G__13366,seq13365__$1);
});

oops.config.get_error_reporting = (function oops$config$get_error_reporting(var_args){
var args__8125__auto__ = [];
var len__8118__auto___13379 = arguments.length;
var i__8119__auto___13380 = (0);
while(true){
if((i__8119__auto___13380 < len__8118__auto___13379)){
args__8125__auto__.push((arguments[i__8119__auto___13380]));

var G__13381 = (i__8119__auto___13380 + (1));
i__8119__auto___13380 = G__13381;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_error_reporting.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_error_reporting.cljs$core$IFn$_invoke$arity$variadic = (function (p__13375){
var vec__13376 = p__13375;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__13376,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$error_DASH_reporting,cljs.core.array_seq([config], 0));
});

oops.config.get_error_reporting.cljs$lang$maxFixedArity = (0);

oops.config.get_error_reporting.cljs$lang$applyTo = (function (seq13374){
return oops.config.get_error_reporting.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq13374));
});

oops.config.get_warning_reporting = (function oops$config$get_warning_reporting(var_args){
var args__8125__auto__ = [];
var len__8118__auto___13387 = arguments.length;
var i__8119__auto___13388 = (0);
while(true){
if((i__8119__auto___13388 < len__8118__auto___13387)){
args__8125__auto__.push((arguments[i__8119__auto___13388]));

var G__13389 = (i__8119__auto___13388 + (1));
i__8119__auto___13388 = G__13389;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_warning_reporting.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_warning_reporting.cljs$core$IFn$_invoke$arity$variadic = (function (p__13383){
var vec__13384 = p__13383;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__13384,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$warning_DASH_reporting,cljs.core.array_seq([config], 0));
});

oops.config.get_warning_reporting.cljs$lang$maxFixedArity = (0);

oops.config.get_warning_reporting.cljs$lang$applyTo = (function (seq13382){
return oops.config.get_warning_reporting.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq13382));
});

oops.config.get_suppress_reporting = (function oops$config$get_suppress_reporting(var_args){
var args__8125__auto__ = [];
var len__8118__auto___13395 = arguments.length;
var i__8119__auto___13396 = (0);
while(true){
if((i__8119__auto___13396 < len__8118__auto___13395)){
args__8125__auto__.push((arguments[i__8119__auto___13396]));

var G__13397 = (i__8119__auto___13396 + (1));
i__8119__auto___13396 = G__13397;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_suppress_reporting.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_suppress_reporting.cljs$core$IFn$_invoke$arity$variadic = (function (p__13391){
var vec__13392 = p__13391;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__13392,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$suppress_DASH_reporting,cljs.core.array_seq([config], 0));
});

oops.config.get_suppress_reporting.cljs$lang$maxFixedArity = (0);

oops.config.get_suppress_reporting.cljs$lang$applyTo = (function (seq13390){
return oops.config.get_suppress_reporting.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq13390));
});

oops.config.get_child_factory = (function oops$config$get_child_factory(var_args){
var args__8125__auto__ = [];
var len__8118__auto___13403 = arguments.length;
var i__8119__auto___13404 = (0);
while(true){
if((i__8119__auto___13404 < len__8118__auto___13403)){
args__8125__auto__.push((arguments[i__8119__auto___13404]));

var G__13405 = (i__8119__auto___13404 + (1));
i__8119__auto___13404 = G__13405;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_child_factory.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_child_factory.cljs$core$IFn$_invoke$arity$variadic = (function (p__13399){
var vec__13400 = p__13399;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__13400,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$child_DASH_factory,cljs.core.array_seq([config], 0));
});

oops.config.get_child_factory.cljs$lang$maxFixedArity = (0);

oops.config.get_child_factory.cljs$lang$applyTo = (function (seq13398){
return oops.config.get_child_factory.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq13398));
});

oops.config.set_child_factory_BANG_ = (function oops$config$set_child_factory_BANG_(new_factory_fn){
return oops.config.update_current_runtime_config_BANG_(new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$child_DASH_factory,new_factory_fn], null));
});
oops.config.throw_errors_from_macro_call_sites_QMARK_ = (function oops$config$throw_errors_from_macro_call_sites_QMARK_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___13411 = arguments.length;
var i__8119__auto___13412 = (0);
while(true){
if((i__8119__auto___13412 < len__8118__auto___13411)){
args__8125__auto__.push((arguments[i__8119__auto___13412]));

var G__13413 = (i__8119__auto___13412 + (1));
i__8119__auto___13412 = G__13413;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$core$IFn$_invoke$arity$variadic = (function (p__13407){
var vec__13408 = p__13407;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__13408,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$throw_DASH_errors_DASH_from_DASH_macro_DASH_call_DASH_sites,cljs.core.array_seq([config], 0)) === true;
});

oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$lang$maxFixedArity = (0);

oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$lang$applyTo = (function (seq13406){
return oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq13406));
});


// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.helpers');
goog.require('cljs.core');
oops.helpers.is_prototype_QMARK_ = (function oops$helpers$is_prototype_QMARK_(o){
return (o.constructor.prototype === o);
});
oops.helpers.get_constructor = (function oops$helpers$get_constructor(o){
return (o["constructor"]);
});
oops.helpers.cljs_type_QMARK_ = (function oops$helpers$cljs_type_QMARK_(f){
var and__6927__auto__ = goog.isObject(f);
if(cljs.core.truth_(and__6927__auto__)){
var and__6927__auto____$1 = cljs.core.not(oops.helpers.is_prototype_QMARK_(f));
if(and__6927__auto____$1){
return (f["cljs$lang$type"]);
} else {
return and__6927__auto____$1;
}
} else {
return and__6927__auto__;
}
});
oops.helpers.cljs_instance_QMARK_ = (function oops$helpers$cljs_instance_QMARK_(value){
var and__6927__auto__ = goog.isObject(value);
if(cljs.core.truth_(and__6927__auto__)){
return oops.helpers.cljs_type_QMARK_(oops.helpers.get_constructor(value));
} else {
return and__6927__auto__;
}
});
oops.helpers.to_native_array = (function oops$helpers$to_native_array(coll){
if(cljs.core.array_QMARK_(coll)){
return coll;
} else {
var arr = [];
var items = cljs.core.seq(coll);
while(true){
if(!((items == null))){
var item = cljs.core._first(items);
arr.push(item);

var G__18086 = cljs.core.next(items);
items = G__18086;
continue;
} else {
return arr;
}
break;
}
}
});
oops.helpers.repurpose_error = (function oops$helpers$repurpose_error(error,msg,info){


error.message = msg;

var x18088 = error;
x18088.cljs$core$IPrintWithWriter$ = true;

x18088.cljs$core$IPrintWithWriter$_pr_writer$arity$3 = ((function (x18088){
return (function (_obj,writer,opts){
var _obj__$1 = this;
cljs.core._write(writer,msg);

if(cljs.core.some_QMARK_(info)){
cljs.core._write(writer," ");

return cljs.core.pr_writer(info,writer,opts);
} else {
return null;
}
});})(x18088))
;

return x18088;
});

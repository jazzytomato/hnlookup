// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.messages');
goog.require('cljs.core');
oops.messages.post_process_error_message = (function oops$messages$post_process_error_message(msg){
return [cljs.core.str("Oops, "),cljs.core.str(msg)].join('');
});
if(typeof oops.messages.runtime_message !== 'undefined'){
} else {
oops.messages.runtime_message = (function (){var method_table__7962__auto__ = (function (){var G__18186 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__18186) : cljs.core.atom.call(null,G__18186));
})();
var prefer_table__7963__auto__ = (function (){var G__18187 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__18187) : cljs.core.atom.call(null,G__18187));
})();
var method_cache__7964__auto__ = (function (){var G__18188 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__18188) : cljs.core.atom.call(null,G__18188));
})();
var cached_hierarchy__7965__auto__ = (function (){var G__18189 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__18189) : cljs.core.atom.call(null,G__18189));
})();
var hierarchy__7966__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$3(cljs.core.PersistentArrayMap.EMPTY,cljs.core.cst$kw$hierarchy,cljs.core.get_global_hierarchy());
return (new cljs.core.MultiFn(cljs.core.symbol.cljs$core$IFn$_invoke$arity$2("oops.messages","runtime-message"),((function (method_table__7962__auto__,prefer_table__7963__auto__,method_cache__7964__auto__,cached_hierarchy__7965__auto__,hierarchy__7966__auto__){
return (function() { 
var G__18190__delegate = function (type,_){
return type;
};
var G__18190 = function (type,var_args){
var _ = null;
if (arguments.length > 1) {
var G__18191__i = 0, G__18191__a = new Array(arguments.length -  1);
while (G__18191__i < G__18191__a.length) {G__18191__a[G__18191__i] = arguments[G__18191__i + 1]; ++G__18191__i;}
  _ = new cljs.core.IndexedSeq(G__18191__a,0);
} 
return G__18190__delegate.call(this,type,_);};
G__18190.cljs$lang$maxFixedArity = 1;
G__18190.cljs$lang$applyTo = (function (arglist__18192){
var type = cljs.core.first(arglist__18192);
var _ = cljs.core.rest(arglist__18192);
return G__18190__delegate(type,_);
});
G__18190.cljs$core$IFn$_invoke$arity$variadic = G__18190__delegate;
return G__18190;
})()
;})(method_table__7962__auto__,prefer_table__7963__auto__,method_cache__7964__auto__,cached_hierarchy__7965__auto__,hierarchy__7966__auto__))
,cljs.core.cst$kw$default,hierarchy__7966__auto__,method_table__7962__auto__,prefer_table__7963__auto__,method_cache__7964__auto__,cached_hierarchy__7965__auto__));
})();
}
oops.messages.runtime_message.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,(function (_type,info){
var map__18193 = info;
var map__18193__$1 = ((((!((map__18193 == null)))?((((map__18193.cljs$lang$protocol_mask$partition0$ & (64))) || (map__18193.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__18193):map__18193);
var flavor = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__18193__$1,cljs.core.cst$kw$flavor);
var path = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__18193__$1,cljs.core.cst$kw$path);
return oops.messages.post_process_error_message([cljs.core.str("Unexpected object value ("),cljs.core.str(flavor),cljs.core.str(")"),cljs.core.str(((!(cljs.core.empty_QMARK_(path)))?[cljs.core.str(" on key path '"),cljs.core.str(path),cljs.core.str("'")].join(''):null))].join(''));
}));
oops.messages.runtime_message.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$expected_DASH_function_DASH_value,(function (_type,info){
var map__18195 = info;
var map__18195__$1 = ((((!((map__18195 == null)))?((((map__18195.cljs$lang$protocol_mask$partition0$ & (64))) || (map__18195.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__18195):map__18195);
var soft_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__18195__$1,cljs.core.cst$kw$soft_QMARK_);
var path = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__18195__$1,cljs.core.cst$kw$path);
var fn = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__18195__$1,cljs.core.cst$kw$fn);
return oops.messages.post_process_error_message([cljs.core.str("Expected a function"),cljs.core.str((cljs.core.truth_(soft_QMARK_)?[cljs.core.str(" or nil")].join(''):null)),cljs.core.str(((!(cljs.core.empty_QMARK_(path)))?[cljs.core.str(" on key path '"),cljs.core.str(path),cljs.core.str("'")].join(''):null)),cljs.core.str(", got <"),cljs.core.str(goog.typeOf(fn)),cljs.core.str("> instead")].join(''));
}));
oops.messages.runtime_message.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$missing_DASH_object_DASH_key,(function (_type,info){
var map__18197 = info;
var map__18197__$1 = ((((!((map__18197 == null)))?((((map__18197.cljs$lang$protocol_mask$partition0$ & (64))) || (map__18197.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__18197):map__18197);
var key = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__18197__$1,cljs.core.cst$kw$key);
var path = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__18197__$1,cljs.core.cst$kw$path);
return oops.messages.post_process_error_message([cljs.core.str("Missing expected object key '"),cljs.core.str(key),cljs.core.str("'"),cljs.core.str(((!((cljs.core.empty_QMARK_(path)) || (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(path,key))))?[cljs.core.str(" on key path '"),cljs.core.str(path),cljs.core.str("'")].join(''):null))].join(''));
}));
oops.messages.runtime_message.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$invalid_DASH_selector,(function (_type){
return oops.messages.post_process_error_message("Invalid selector");
}));
oops.messages.runtime_message.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$empty_DASH_selector_DASH_access,(function (_type){
return oops.messages.post_process_error_message([cljs.core.str("Accessing target object with empty selector")].join(''));
}));

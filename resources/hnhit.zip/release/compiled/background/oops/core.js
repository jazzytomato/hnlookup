// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.core');
goog.require('cljs.core');
goog.require('cljs.spec');
goog.require('goog.object');
goog.require('oops.sdefs');
goog.require('oops.state');
goog.require('oops.config');
goog.require('oops.messages');
goog.require('oops.helpers');
goog.require('oops.schema');
oops.core.report_runtime_error = (function oops$core$report_runtime_error(msg,data){
if(oops.state.was_error_reported_QMARK_()){
return null;
} else {
oops.state.mark_error_reported_BANG_();

var G__19958 = oops.config.get_error_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__19958)){
throw oops.state.prepare_error_from_call_site(msg,(function (){var data__19812__auto__ = data;
var or__6939__auto__ = (function (){var temp__6726__auto__ = (window["devtools"]);
if(cljs.core.truth_(temp__6726__auto__)){
var devtools__19813__auto__ = temp__6726__auto__;
var temp__6726__auto____$1 = (devtools__19813__auto__["toolbox"]);
if(cljs.core.truth_(temp__6726__auto____$1)){
var toolbox__19814__auto__ = temp__6726__auto____$1;
var temp__6726__auto____$2 = (toolbox__19814__auto__["envelope"]);
if(cljs.core.truth_(temp__6726__auto____$2)){
var envelope__19815__auto__ = temp__6726__auto____$2;
if(cljs.core.fn_QMARK_(envelope__19815__auto__)){
return (envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2 ? envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2(data__19812__auto__,"details") : envelope__19815__auto__.call(null,data__19812__auto__,"details"));
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
})();
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return data__19812__auto__;
}
})());
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__19958)){
return oops.state.get_console_reporter().call(null,(console["error"]),msg,(function (){var data__19812__auto__ = data;
var or__6939__auto__ = (function (){var temp__6726__auto__ = (window["devtools"]);
if(cljs.core.truth_(temp__6726__auto__)){
var devtools__19813__auto__ = temp__6726__auto__;
var temp__6726__auto____$1 = (devtools__19813__auto__["toolbox"]);
if(cljs.core.truth_(temp__6726__auto____$1)){
var toolbox__19814__auto__ = temp__6726__auto____$1;
var temp__6726__auto____$2 = (toolbox__19814__auto__["envelope"]);
if(cljs.core.truth_(temp__6726__auto____$2)){
var envelope__19815__auto__ = temp__6726__auto____$2;
if(cljs.core.fn_QMARK_(envelope__19815__auto__)){
return (envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2 ? envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2(data__19812__auto__,"details") : envelope__19815__auto__.call(null,data__19812__auto__,"details"));
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
})();
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return data__19812__auto__;
}
})());
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__19958)){
return null;
} else {
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(oops.config.get_error_reporting())].join('')));

}
}
}
}
});
oops.core.report_runtime_warning = (function oops$core$report_runtime_warning(msg,data){
var G__19960 = oops.config.get_warning_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__19960)){
throw oops.state.prepare_error_from_call_site(msg,(function (){var data__19812__auto__ = data;
var or__6939__auto__ = (function (){var temp__6726__auto__ = (window["devtools"]);
if(cljs.core.truth_(temp__6726__auto__)){
var devtools__19813__auto__ = temp__6726__auto__;
var temp__6726__auto____$1 = (devtools__19813__auto__["toolbox"]);
if(cljs.core.truth_(temp__6726__auto____$1)){
var toolbox__19814__auto__ = temp__6726__auto____$1;
var temp__6726__auto____$2 = (toolbox__19814__auto__["envelope"]);
if(cljs.core.truth_(temp__6726__auto____$2)){
var envelope__19815__auto__ = temp__6726__auto____$2;
if(cljs.core.fn_QMARK_(envelope__19815__auto__)){
return (envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2 ? envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2(data__19812__auto__,"details") : envelope__19815__auto__.call(null,data__19812__auto__,"details"));
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
})();
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return data__19812__auto__;
}
})());
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__19960)){
return oops.state.get_console_reporter().call(null,(console["warn"]),msg,(function (){var data__19812__auto__ = data;
var or__6939__auto__ = (function (){var temp__6726__auto__ = (window["devtools"]);
if(cljs.core.truth_(temp__6726__auto__)){
var devtools__19813__auto__ = temp__6726__auto__;
var temp__6726__auto____$1 = (devtools__19813__auto__["toolbox"]);
if(cljs.core.truth_(temp__6726__auto____$1)){
var toolbox__19814__auto__ = temp__6726__auto____$1;
var temp__6726__auto____$2 = (toolbox__19814__auto__["envelope"]);
if(cljs.core.truth_(temp__6726__auto____$2)){
var envelope__19815__auto__ = temp__6726__auto____$2;
if(cljs.core.fn_QMARK_(envelope__19815__auto__)){
return (envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2 ? envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2(data__19812__auto__,"details") : envelope__19815__auto__.call(null,data__19812__auto__,"details"));
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
})();
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return data__19812__auto__;
}
})());
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__19960)){
return null;
} else {
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(oops.config.get_warning_reporting())].join('')));

}
}
}
});
oops.core.report_if_needed_dynamically = (function oops$core$report_if_needed_dynamically(var_args){
var args__8125__auto__ = [];
var len__8118__auto___19967 = arguments.length;
var i__8119__auto___19968 = (0);
while(true){
if((i__8119__auto___19968 < len__8118__auto___19967)){
args__8125__auto__.push((arguments[i__8119__auto___19968]));

var G__19969 = (i__8119__auto___19968 + (1));
i__8119__auto___19968 = G__19969;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic = (function (msg_id,p__19963){
var vec__19964 = p__19963;
var info = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__19964,(0),null);
return null;
});

oops.core.report_if_needed_dynamically.cljs$lang$maxFixedArity = (1);

oops.core.report_if_needed_dynamically.cljs$lang$applyTo = (function (seq19961){
var G__19962 = cljs.core.first(seq19961);
var seq19961__$1 = cljs.core.next(seq19961);
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(G__19962,seq19961__$1);
});

oops.core.punch_key_dynamically_BANG_ = (function oops$core$punch_key_dynamically_BANG_(obj,key){
var child_factory_19976 = oops.config.get_child_factory();
var child_factory_19976__$1 = (function (){var G__19977 = (((child_factory_19976 instanceof cljs.core.Keyword))?child_factory_19976.fqn:null);
switch (G__19977) {
case "js-obj":
return ((function (G__19977,child_factory_19976){
return (function (){
return {};
});
;})(G__19977,child_factory_19976))

break;
case "js-array":
return ((function (G__19977,child_factory_19976){
return (function (){
return [];
});
;})(G__19977,child_factory_19976))

break;
default:
return child_factory_19976;

}
})();

var child_obj_19975 = (child_factory_19976__$1.cljs$core$IFn$_invoke$arity$2 ? child_factory_19976__$1.cljs$core$IFn$_invoke$arity$2(obj,key) : child_factory_19976__$1.call(null,obj,key));
goog.object.set(obj,key,child_obj_19975);

return child_obj_19975;
});
oops.core.validate_object_access_dynamically = (function oops$core$validate_object_access_dynamically(obj,mode,key,check_key_QMARK_){
if(cljs.core.truth_((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((void 0 === obj)))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"undefined",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((obj == null)))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"nil",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(goog.isBoolean(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"boolean",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(goog.isNumber(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"number",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(goog.isString(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"string",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):((cljs.core.not(goog.isObject(obj)))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"non-object",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(goog.isDateLike(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"date-like",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(oops.helpers.cljs_type_QMARK_(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs type",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(oops.helpers.cljs_instance_QMARK_(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs instance",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):true
))))))))))){
oops.state.add_key_to_current_path_BANG_(key);

oops.state.set_last_access_modifier_BANG_(mode);

if(cljs.core.truth_(check_key_QMARK_)){
if((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && (cljs.core.not(goog.object.containsKey(obj,key)))){
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$missing_DASH_object_DASH_key,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0));
} else {
return true;
}
} else {
return true;
}
} else {
return null;
}
});
oops.core.validate_fn_call_dynamically = (function oops$core$validate_fn_call_dynamically(fn,mode){
if((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1))) && ((fn == null))){
return true;
} else {
if(cljs.core.truth_(goog.isFunction(fn))){
return true;
} else {
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$expected_DASH_function_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$soft_QMARK_,cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1)),cljs.core.cst$kw$fn,fn,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0));

}
}
});
oops.core.build_path_dynamically = (function oops$core$build_path_dynamically(selector){
if((typeof selector === 'string') || ((selector instanceof cljs.core.Keyword))){
var selector_path_19983 = [];
oops.schema.coerce_key_dynamically_BANG_(selector,selector_path_19983);

return selector_path_19983;
} else {
var selector_path_19984 = [];
oops.schema.collect_coerced_keys_into_array_BANG_(selector,selector_path_19984);

return selector_path_19984;

}
});
oops.core.get_key_dynamically = (function oops$core$get_key_dynamically(obj,key,mode){
return goog.object.get(obj,key);
});
oops.core.set_key_dynamically = (function oops$core$set_key_dynamically(obj,key,val,mode){
return goog.object.set(obj,key,val);
});
oops.core.get_selector_dynamically = (function oops$core$get_selector_dynamically(obj,selector){
var path_19995 = (function (){var path_19994 = oops.core.build_path_dynamically(selector);

return path_19994;
})();
var len_19996 = path_19995.length;
var i_19997 = (0);
var obj_19998 = obj;
while(true){
if((i_19997 < len_19996)){
var mode_19999 = (path_19995[i_19997]);
var key_20000 = (path_19995[(i_19997 + (1))]);
var next_obj_20001 = oops.core.get_key_dynamically(obj_19998,key_20000,mode_19999);
var G__20002 = mode_19999;
switch (G__20002) {
case (0):
var G__20004 = (i_19997 + (2));
var G__20005 = next_obj_20001;
i_19997 = G__20004;
obj_19998 = G__20005;
continue;

break;
case (1):
if(!((next_obj_20001 == null))){
var G__20006 = (i_19997 + (2));
var G__20007 = next_obj_20001;
i_19997 = G__20006;
obj_19998 = G__20007;
continue;
} else {
return null;
}

break;
case (2):
if(!((next_obj_20001 == null))){
var G__20008 = (i_19997 + (2));
var G__20009 = next_obj_20001;
i_19997 = G__20008;
obj_19998 = G__20009;
continue;
} else {
var G__20010 = (i_19997 + (2));
var G__20011 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_19998,key_20000) : oops.core.punch_key_dynamically_BANG_.call(null,obj_19998,key_20000));
i_19997 = G__20010;
obj_19998 = G__20011;
continue;
}

break;
default:
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(mode_19999)].join('')));

}
} else {
return obj_19998;
}
break;
}
});
oops.core.set_selector_dynamically = (function oops$core$set_selector_dynamically(obj,selector,val){
var path_20028 = (function (){var path_20027 = oops.core.build_path_dynamically(selector);

return path_20027;
})();
var len_20031 = path_20028.length;
var parent_obj_path_20032 = path_20028.slice((0),(len_20031 - (2)));
var key_20029 = (path_20028[(len_20031 - (1))]);
var mode_20030 = (path_20028[(len_20031 - (2))]);
var parent_obj_20033 = (function (){var path_20034 = parent_obj_path_20032;
var len_20035 = path_20034.length;
var i_20036 = (0);
var obj_20037 = obj;
while(true){
if((i_20036 < len_20035)){
var mode_20038 = (path_20034[i_20036]);
var key_20039 = (path_20034[(i_20036 + (1))]);
var next_obj_20040 = oops.core.get_key_dynamically(obj_20037,key_20039,mode_20038);
var G__20041 = mode_20038;
switch (G__20041) {
case (0):
var G__20043 = (i_20036 + (2));
var G__20044 = next_obj_20040;
i_20036 = G__20043;
obj_20037 = G__20044;
continue;

break;
case (1):
if(!((next_obj_20040 == null))){
var G__20045 = (i_20036 + (2));
var G__20046 = next_obj_20040;
i_20036 = G__20045;
obj_20037 = G__20046;
continue;
} else {
return null;
}

break;
case (2):
if(!((next_obj_20040 == null))){
var G__20047 = (i_20036 + (2));
var G__20048 = next_obj_20040;
i_20036 = G__20047;
obj_20037 = G__20048;
continue;
} else {
var G__20049 = (i_20036 + (2));
var G__20050 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_20037,key_20039) : oops.core.punch_key_dynamically_BANG_.call(null,obj_20037,key_20039));
i_20036 = G__20049;
obj_20037 = G__20050;
continue;
}

break;
default:
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(mode_20038)].join('')));

}
} else {
return obj_20037;
}
break;
}
})();
return oops.core.set_key_dynamically(parent_obj_20033,key_20029,val,mode_20030);
});

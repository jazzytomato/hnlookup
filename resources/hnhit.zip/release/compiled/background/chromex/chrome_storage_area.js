// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_storage_area');
goog.require('cljs.core');
goog.require('chromex.support');
goog.require('oops.core');
goog.require('chromex.protocols');

/**
* @constructor
 * @implements {chromex.protocols.IChromeStorageArea}
*/
chromex.chrome_storage_area.ChromeStorageArea = (function (native_chrome_storage_area,channel_factory,callback_factory){
this.native_chrome_storage_area = native_chrome_storage_area;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
})
chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$IChromeStorageArea$ = true;

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$IChromeStorageArea$get_native_storage_area$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_storage_area;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$IChromeStorageArea$get$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return chromex.protocols.get.cljs$core$IFn$_invoke$arity$2(this$__$1,null);
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$IChromeStorageArea$get$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_20280_20295 = self__.native_chrome_storage_area;
var fn_20281_20296 = (function (){var next_obj_20282 = goog.object.get(target_obj_20280_20295,"get");
return next_obj_20282;
})();
if(!((fn_20281_20296 == null))){
fn_20281_20296.call(target_obj_20280_20295,keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$IChromeStorageArea$get_bytes_in_use$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return chromex.protocols.get_bytes_in_use.cljs$core$IFn$_invoke$arity$2(this$__$1,null);
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$IChromeStorageArea$get_bytes_in_use$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_20283_20297 = self__.native_chrome_storage_area;
var fn_20284_20298 = (function (){var next_obj_20285 = goog.object.get(target_obj_20283_20297,"getBytesInUse");
return next_obj_20285;
})();
if(!((fn_20284_20298 == null))){
fn_20284_20298.call(target_obj_20283_20297,keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$IChromeStorageArea$set$arity$2 = (function (_this,items){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_20286_20299 = self__.native_chrome_storage_area;
var fn_20287_20300 = (function (){var next_obj_20288 = goog.object.get(target_obj_20286_20299,"set");
return next_obj_20288;
})();
if(!((fn_20287_20300 == null))){
fn_20287_20300.call(target_obj_20286_20299,items,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$IChromeStorageArea$remove$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_20289_20301 = self__.native_chrome_storage_area;
var fn_20290_20302 = (function (){var next_obj_20291 = goog.object.get(target_obj_20289_20301,"remove");
return next_obj_20291;
})();
if(!((fn_20290_20302 == null))){
fn_20290_20302.call(target_obj_20289_20301,keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$IChromeStorageArea$clear$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_20292_20303 = self__.native_chrome_storage_area;
var fn_20293_20304 = (function (){var next_obj_20294 = goog.object.get(target_obj_20292_20303,"clear");
return next_obj_20294;
})();
if(!((fn_20293_20304 == null))){
fn_20293_20304.call(target_obj_20292_20303,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$native_DASH_chrome_DASH_storage_DASH_area,cljs.core.cst$sym$channel_DASH_factory,cljs.core.cst$sym$callback_DASH_factory], null);
});

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$type = true;

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$ctorStr = "chromex.chrome-storage-area/ChromeStorageArea";

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"chromex.chrome-storage-area/ChromeStorageArea");
});

chromex.chrome_storage_area.__GT_ChromeStorageArea = (function chromex$chrome_storage_area$__GT_ChromeStorageArea(native_chrome_storage_area,channel_factory,callback_factory){
return (new chromex.chrome_storage_area.ChromeStorageArea(native_chrome_storage_area,channel_factory,callback_factory));
});

chromex.chrome_storage_area.make_chrome_storage_area = (function chromex$chrome_storage_area$make_chrome_storage_area(config,native_chrome_storage_area){

return (new chromex.chrome_storage_area.ChromeStorageArea(native_chrome_storage_area,(function (){var config__13456__auto__ = config;
var handler_key__13457__auto__ = cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_channel_DASH_factory;
var handler__13458__auto__ = (handler_key__13457__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13457__auto__.cljs$core$IFn$_invoke$arity$1(config__13456__auto__) : handler_key__13457__auto__.call(null,config__13456__auto__));

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__13458__auto__,config__13456__auto__);
})(),(function (){var config__13456__auto__ = config;
var handler_key__13457__auto__ = cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_fn_DASH_factory;
var handler__13458__auto__ = (handler_key__13457__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13457__auto__.cljs$core$IFn$_invoke$arity$1(config__13456__auto__) : handler_key__13457__auto__.call(null,config__13456__auto__));

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__13458__auto__,config__13456__auto__);
})()));
});

// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.version');
goog.require('cljs.core');
chromex.version.current_version = "0.5.1";
chromex.version.get_current_version = (function chromex$version$get_current_version(){
return chromex.version.current_version;
});

// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.tabs');
goog.require('cljs.core');
goog.require('chromex.core');
chromex.ext.tabs.tab_id_none_STAR_ = (function chromex$ext$tabs$tab_id_none_STAR_(config){
var result_22007 = (function (){var final_args_array_22008 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.tabs.TAB_ID_NONE");
var ns_22009 = (function (){var target_obj_22011 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22012 = goog.object.get(target_obj_22011,"chrome");
var next_obj_22013 = goog.object.get(next_obj_22012,"tabs");
return next_obj_22013;
})();


var target_22010 = (function (){var target_obj_22014 = ns_22009;
var next_obj_22015 = goog.object.get(target_obj_22014,"TAB_ID_NONE");
if(!((next_obj_22015 == null))){
return next_obj_22015;
} else {
return null;
}
})();
return target_22010;
})();
return result_22007;
});
chromex.ext.tabs.get_STAR_ = (function chromex$ext$tabs$get_STAR_(config,tab_id){
var callback_chan_22033 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22035_22050 = (function (){var omit_test_22040 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22040,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22040;
}
})();
var marshalled_callback_22036_22051 = ((function (marshalled_tab_id_22035_22050,callback_chan_22033){
return (function (cb_tab_22041){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22042 = config__13447__auto__;
var G__22043 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get,cljs.core.cst$kw$name,"get",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22044 = callback_chan_22033;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22042,G__22043,G__22044) : handler__13449__auto__.call(null,G__22042,G__22043,G__22044));
})().call(null,cb_tab_22041);
});})(marshalled_tab_id_22035_22050,callback_chan_22033))
;
var result_22034_22052 = (function (){var final_args_array_22037 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22035_22050,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22036_22051,"callback",null], null)], null),"chrome.tabs.get");
var ns_22038 = (function (){var target_obj_22045 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22046 = goog.object.get(target_obj_22045,"chrome");
var next_obj_22047 = goog.object.get(next_obj_22046,"tabs");
return next_obj_22047;
})();
var config__13480__auto___22053 = config;
var api_check_fn__13481__auto___22054 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22053);

(api_check_fn__13481__auto___22054.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22054.cljs$core$IFn$_invoke$arity$3("chrome.tabs.get",ns_22038,"get") : api_check_fn__13481__auto___22054.call(null,"chrome.tabs.get",ns_22038,"get"));


var target_22039 = (function (){var target_obj_22048 = ns_22038;
var next_obj_22049 = goog.object.get(target_obj_22048,"get");
if(!((next_obj_22049 == null))){
return next_obj_22049;
} else {
return null;
}
})();
return target_22039.apply(ns_22038,final_args_array_22037);
})();

return callback_chan_22033;
});
chromex.ext.tabs.get_current_STAR_ = (function chromex$ext$tabs$get_current_STAR_(config){
var callback_chan_22070 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_22072_22085 = ((function (callback_chan_22070){
return (function (cb_tab_22076){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22077 = config__13447__auto__;
var G__22078 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_current,cljs.core.cst$kw$name,"getCurrent",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22079 = callback_chan_22070;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22077,G__22078,G__22079) : handler__13449__auto__.call(null,G__22077,G__22078,G__22079));
})().call(null,cb_tab_22076);
});})(callback_chan_22070))
;
var result_22071_22086 = (function (){var final_args_array_22073 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22072_22085,"callback",null], null)], null),"chrome.tabs.getCurrent");
var ns_22074 = (function (){var target_obj_22080 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22081 = goog.object.get(target_obj_22080,"chrome");
var next_obj_22082 = goog.object.get(next_obj_22081,"tabs");
return next_obj_22082;
})();
var config__13480__auto___22087 = config;
var api_check_fn__13481__auto___22088 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22087);

(api_check_fn__13481__auto___22088.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22088.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getCurrent",ns_22074,"getCurrent") : api_check_fn__13481__auto___22088.call(null,"chrome.tabs.getCurrent",ns_22074,"getCurrent"));


var target_22075 = (function (){var target_obj_22083 = ns_22074;
var next_obj_22084 = goog.object.get(target_obj_22083,"getCurrent");
if(!((next_obj_22084 == null))){
return next_obj_22084;
} else {
return null;
}
})();
return target_22075.apply(ns_22074,final_args_array_22073);
})();

return callback_chan_22070;
});
chromex.ext.tabs.connect_STAR_ = (function chromex$ext$tabs$connect_STAR_(config,tab_id,connect_info){
var marshalled_tab_id_22103 = (function (){var omit_test_22108 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22108,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22108;
}
})();
var marshalled_connect_info_22104 = (function (){var omit_test_22109 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_22109,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22109;
}
})();
var result_22102 = (function (){var final_args_array_22105 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22103,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_22104,"connect-info",true], null)], null),"chrome.tabs.connect");
var ns_22106 = (function (){var target_obj_22110 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22111 = goog.object.get(target_obj_22110,"chrome");
var next_obj_22112 = goog.object.get(next_obj_22111,"tabs");
return next_obj_22112;
})();
var config__13480__auto___22115 = config;
var api_check_fn__13481__auto___22116 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22115);

(api_check_fn__13481__auto___22116.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22116.cljs$core$IFn$_invoke$arity$3("chrome.tabs.connect",ns_22106,"connect") : api_check_fn__13481__auto___22116.call(null,"chrome.tabs.connect",ns_22106,"connect"));


var target_22107 = (function (){var target_obj_22113 = ns_22106;
var next_obj_22114 = goog.object.get(target_obj_22113,"connect");
if(!((next_obj_22114 == null))){
return next_obj_22114;
} else {
return null;
}
})();
return target_22107.apply(ns_22106,final_args_array_22105);
})();
return chromex.marshalling.from_native_chrome_port(config,result_22102);
});
chromex.ext.tabs.send_request_STAR_ = (function chromex$ext$tabs$send_request_STAR_(config,tab_id,request){
var callback_chan_22136 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22138_22155 = (function (){var omit_test_22144 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22144,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22144;
}
})();
var marshalled_request_22139_22156 = (function (){var omit_test_22145 = request;
if(cljs.core.keyword_identical_QMARK_(omit_test_22145,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22145;
}
})();
var marshalled_response_callback_22140_22157 = ((function (marshalled_tab_id_22138_22155,marshalled_request_22139_22156,callback_chan_22136){
return (function (cb_response_22146){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22147 = config__13447__auto__;
var G__22148 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_send_DASH_request,cljs.core.cst$kw$name,"sendRequest",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'runtime.sendMessage'.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"request",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22149 = callback_chan_22136;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22147,G__22148,G__22149) : handler__13449__auto__.call(null,G__22147,G__22148,G__22149));
})().call(null,cb_response_22146);
});})(marshalled_tab_id_22138_22155,marshalled_request_22139_22156,callback_chan_22136))
;
var result_22137_22158 = (function (){var final_args_array_22141 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22138_22155,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_request_22139_22156,"request",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_22140_22157,"response-callback",true], null)], null),"chrome.tabs.sendRequest");
var ns_22142 = (function (){var target_obj_22150 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22151 = goog.object.get(target_obj_22150,"chrome");
var next_obj_22152 = goog.object.get(next_obj_22151,"tabs");
return next_obj_22152;
})();
var config__13480__auto___22159 = config;
var api_check_fn__13481__auto___22160 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22159);

(api_check_fn__13481__auto___22160.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22160.cljs$core$IFn$_invoke$arity$3("chrome.tabs.sendRequest",ns_22142,"sendRequest") : api_check_fn__13481__auto___22160.call(null,"chrome.tabs.sendRequest",ns_22142,"sendRequest"));


var target_22143 = (function (){var target_obj_22153 = ns_22142;
var next_obj_22154 = goog.object.get(target_obj_22153,"sendRequest");
if(!((next_obj_22154 == null))){
return next_obj_22154;
} else {
return null;
}
})();
return target_22143.apply(ns_22142,final_args_array_22141);
})();

return callback_chan_22136;
});
chromex.ext.tabs.send_message_STAR_ = (function chromex$ext$tabs$send_message_STAR_(config,tab_id,message,options){
var callback_chan_22182 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22184_22203 = (function (){var omit_test_22191 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22191,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22191;
}
})();
var marshalled_message_22185_22204 = (function (){var omit_test_22192 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_22192,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22192;
}
})();
var marshalled_options_22186_22205 = (function (){var omit_test_22193 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_22193,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22193;
}
})();
var marshalled_response_callback_22187_22206 = ((function (marshalled_tab_id_22184_22203,marshalled_message_22185_22204,marshalled_options_22186_22205,callback_chan_22182){
return (function (cb_response_22194){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22195 = config__13447__auto__;
var G__22196 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$since,"20",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22197 = callback_chan_22182;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22195,G__22196,G__22197) : handler__13449__auto__.call(null,G__22195,G__22196,G__22197));
})().call(null,cb_response_22194);
});})(marshalled_tab_id_22184_22203,marshalled_message_22185_22204,marshalled_options_22186_22205,callback_chan_22182))
;
var result_22183_22207 = (function (){var final_args_array_22188 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22184_22203,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_22185_22204,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_22186_22205,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_22187_22206,"response-callback",true], null)], null),"chrome.tabs.sendMessage");
var ns_22189 = (function (){var target_obj_22198 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22199 = goog.object.get(target_obj_22198,"chrome");
var next_obj_22200 = goog.object.get(next_obj_22199,"tabs");
return next_obj_22200;
})();
var config__13480__auto___22208 = config;
var api_check_fn__13481__auto___22209 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22208);

(api_check_fn__13481__auto___22209.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22209.cljs$core$IFn$_invoke$arity$3("chrome.tabs.sendMessage",ns_22189,"sendMessage") : api_check_fn__13481__auto___22209.call(null,"chrome.tabs.sendMessage",ns_22189,"sendMessage"));


var target_22190 = (function (){var target_obj_22201 = ns_22189;
var next_obj_22202 = goog.object.get(target_obj_22201,"sendMessage");
if(!((next_obj_22202 == null))){
return next_obj_22202;
} else {
return null;
}
})();
return target_22190.apply(ns_22189,final_args_array_22188);
})();

return callback_chan_22182;
});
chromex.ext.tabs.get_selected_STAR_ = (function chromex$ext$tabs$get_selected_STAR_(config,window_id){
var callback_chan_22227 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_window_id_22229_22244 = (function (){var omit_test_22234 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22234,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22234;
}
})();
var marshalled_callback_22230_22245 = ((function (marshalled_window_id_22229_22244,callback_chan_22227){
return (function (cb_tab_22235){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22236 = config__13447__auto__;
var G__22237 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_selected,cljs.core.cst$kw$name,"getSelected",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'tabs.query' {active: true}.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22238 = callback_chan_22227;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22236,G__22237,G__22238) : handler__13449__auto__.call(null,G__22236,G__22237,G__22238));
})().call(null,cb_tab_22235);
});})(marshalled_window_id_22229_22244,callback_chan_22227))
;
var result_22228_22246 = (function (){var final_args_array_22231 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_22229_22244,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22230_22245,"callback",null], null)], null),"chrome.tabs.getSelected");
var ns_22232 = (function (){var target_obj_22239 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22240 = goog.object.get(target_obj_22239,"chrome");
var next_obj_22241 = goog.object.get(next_obj_22240,"tabs");
return next_obj_22241;
})();
var config__13480__auto___22247 = config;
var api_check_fn__13481__auto___22248 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22247);

(api_check_fn__13481__auto___22248.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22248.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getSelected",ns_22232,"getSelected") : api_check_fn__13481__auto___22248.call(null,"chrome.tabs.getSelected",ns_22232,"getSelected"));


var target_22233 = (function (){var target_obj_22242 = ns_22232;
var next_obj_22243 = goog.object.get(target_obj_22242,"getSelected");
if(!((next_obj_22243 == null))){
return next_obj_22243;
} else {
return null;
}
})();
return target_22233.apply(ns_22232,final_args_array_22231);
})();

return callback_chan_22227;
});
chromex.ext.tabs.get_all_in_window_STAR_ = (function chromex$ext$tabs$get_all_in_window_STAR_(config,window_id){
var callback_chan_22266 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_window_id_22268_22283 = (function (){var omit_test_22273 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22273,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22273;
}
})();
var marshalled_callback_22269_22284 = ((function (marshalled_window_id_22268_22283,callback_chan_22266){
return (function (cb_tabs_22274){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22275 = config__13447__auto__;
var G__22276 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_all_DASH_in_DASH_window,cljs.core.cst$kw$name,"getAllInWindow",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'tabs.query' {windowId: windowId}.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tabs",cljs.core.cst$kw$type,"[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22277 = callback_chan_22266;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22275,G__22276,G__22277) : handler__13449__auto__.call(null,G__22275,G__22276,G__22277));
})().call(null,cb_tabs_22274);
});})(marshalled_window_id_22268_22283,callback_chan_22266))
;
var result_22267_22285 = (function (){var final_args_array_22270 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_22268_22283,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22269_22284,"callback",null], null)], null),"chrome.tabs.getAllInWindow");
var ns_22271 = (function (){var target_obj_22278 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22279 = goog.object.get(target_obj_22278,"chrome");
var next_obj_22280 = goog.object.get(next_obj_22279,"tabs");
return next_obj_22280;
})();
var config__13480__auto___22286 = config;
var api_check_fn__13481__auto___22287 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22286);

(api_check_fn__13481__auto___22287.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22287.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getAllInWindow",ns_22271,"getAllInWindow") : api_check_fn__13481__auto___22287.call(null,"chrome.tabs.getAllInWindow",ns_22271,"getAllInWindow"));


var target_22272 = (function (){var target_obj_22281 = ns_22271;
var next_obj_22282 = goog.object.get(target_obj_22281,"getAllInWindow");
if(!((next_obj_22282 == null))){
return next_obj_22282;
} else {
return null;
}
})();
return target_22272.apply(ns_22271,final_args_array_22270);
})();

return callback_chan_22266;
});
chromex.ext.tabs.create_STAR_ = (function chromex$ext$tabs$create_STAR_(config,create_properties){
var callback_chan_22305 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_create_properties_22307_22322 = (function (){var omit_test_22312 = create_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_22312,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22312;
}
})();
var marshalled_callback_22308_22323 = ((function (marshalled_create_properties_22307_22322,callback_chan_22305){
return (function (cb_tab_22313){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22314 = config__13447__auto__;
var G__22315 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_create,cljs.core.cst$kw$name,"create",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"create-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22316 = callback_chan_22305;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22314,G__22315,G__22316) : handler__13449__auto__.call(null,G__22314,G__22315,G__22316));
})().call(null,cb_tab_22313);
});})(marshalled_create_properties_22307_22322,callback_chan_22305))
;
var result_22306_22324 = (function (){var final_args_array_22309 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_create_properties_22307_22322,"create-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22308_22323,"callback",true], null)], null),"chrome.tabs.create");
var ns_22310 = (function (){var target_obj_22317 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22318 = goog.object.get(target_obj_22317,"chrome");
var next_obj_22319 = goog.object.get(next_obj_22318,"tabs");
return next_obj_22319;
})();
var config__13480__auto___22325 = config;
var api_check_fn__13481__auto___22326 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22325);

(api_check_fn__13481__auto___22326.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22326.cljs$core$IFn$_invoke$arity$3("chrome.tabs.create",ns_22310,"create") : api_check_fn__13481__auto___22326.call(null,"chrome.tabs.create",ns_22310,"create"));


var target_22311 = (function (){var target_obj_22320 = ns_22310;
var next_obj_22321 = goog.object.get(target_obj_22320,"create");
if(!((next_obj_22321 == null))){
return next_obj_22321;
} else {
return null;
}
})();
return target_22311.apply(ns_22310,final_args_array_22309);
})();

return callback_chan_22305;
});
chromex.ext.tabs.duplicate_STAR_ = (function chromex$ext$tabs$duplicate_STAR_(config,tab_id){
var callback_chan_22344 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22346_22361 = (function (){var omit_test_22351 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22351,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22351;
}
})();
var marshalled_callback_22347_22362 = ((function (marshalled_tab_id_22346_22361,callback_chan_22344){
return (function (cb_tab_22352){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22353 = config__13447__auto__;
var G__22354 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_duplicate,cljs.core.cst$kw$name,"duplicate",cljs.core.cst$kw$since,"23",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22355 = callback_chan_22344;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22353,G__22354,G__22355) : handler__13449__auto__.call(null,G__22353,G__22354,G__22355));
})().call(null,cb_tab_22352);
});})(marshalled_tab_id_22346_22361,callback_chan_22344))
;
var result_22345_22363 = (function (){var final_args_array_22348 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22346_22361,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22347_22362,"callback",true], null)], null),"chrome.tabs.duplicate");
var ns_22349 = (function (){var target_obj_22356 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22357 = goog.object.get(target_obj_22356,"chrome");
var next_obj_22358 = goog.object.get(next_obj_22357,"tabs");
return next_obj_22358;
})();
var config__13480__auto___22364 = config;
var api_check_fn__13481__auto___22365 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22364);

(api_check_fn__13481__auto___22365.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22365.cljs$core$IFn$_invoke$arity$3("chrome.tabs.duplicate",ns_22349,"duplicate") : api_check_fn__13481__auto___22365.call(null,"chrome.tabs.duplicate",ns_22349,"duplicate"));


var target_22350 = (function (){var target_obj_22359 = ns_22349;
var next_obj_22360 = goog.object.get(target_obj_22359,"duplicate");
if(!((next_obj_22360 == null))){
return next_obj_22360;
} else {
return null;
}
})();
return target_22350.apply(ns_22349,final_args_array_22348);
})();

return callback_chan_22344;
});
chromex.ext.tabs.query_STAR_ = (function chromex$ext$tabs$query_STAR_(config,query_info){
var callback_chan_22383 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_query_info_22385_22400 = (function (){var omit_test_22390 = query_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_22390,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22390;
}
})();
var marshalled_callback_22386_22401 = ((function (marshalled_query_info_22385_22400,callback_chan_22383){
return (function (cb_result_22391){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22392 = config__13447__auto__;
var G__22393 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_query,cljs.core.cst$kw$name,"query",cljs.core.cst$kw$since,"16",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"query-info",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22394 = callback_chan_22383;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22392,G__22393,G__22394) : handler__13449__auto__.call(null,G__22392,G__22393,G__22394));
})().call(null,cb_result_22391);
});})(marshalled_query_info_22385_22400,callback_chan_22383))
;
var result_22384_22402 = (function (){var final_args_array_22387 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_query_info_22385_22400,"query-info",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22386_22401,"callback",null], null)], null),"chrome.tabs.query");
var ns_22388 = (function (){var target_obj_22395 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22396 = goog.object.get(target_obj_22395,"chrome");
var next_obj_22397 = goog.object.get(next_obj_22396,"tabs");
return next_obj_22397;
})();
var config__13480__auto___22403 = config;
var api_check_fn__13481__auto___22404 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22403);

(api_check_fn__13481__auto___22404.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22404.cljs$core$IFn$_invoke$arity$3("chrome.tabs.query",ns_22388,"query") : api_check_fn__13481__auto___22404.call(null,"chrome.tabs.query",ns_22388,"query"));


var target_22389 = (function (){var target_obj_22398 = ns_22388;
var next_obj_22399 = goog.object.get(target_obj_22398,"query");
if(!((next_obj_22399 == null))){
return next_obj_22399;
} else {
return null;
}
})();
return target_22389.apply(ns_22388,final_args_array_22387);
})();

return callback_chan_22383;
});
chromex.ext.tabs.highlight_STAR_ = (function chromex$ext$tabs$highlight_STAR_(config,highlight_info){
var callback_chan_22422 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_highlight_info_22424_22439 = (function (){var omit_test_22429 = highlight_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_22429,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22429;
}
})();
var marshalled_callback_22425_22440 = ((function (marshalled_highlight_info_22424_22439,callback_chan_22422){
return (function (cb_window_22430){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22431 = config__13447__auto__;
var G__22432 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_highlight,cljs.core.cst$kw$name,"highlight",cljs.core.cst$kw$since,"16",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"highlight-info",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"window",cljs.core.cst$kw$type,"windows.Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22433 = callback_chan_22422;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22431,G__22432,G__22433) : handler__13449__auto__.call(null,G__22431,G__22432,G__22433));
})().call(null,cb_window_22430);
});})(marshalled_highlight_info_22424_22439,callback_chan_22422))
;
var result_22423_22441 = (function (){var final_args_array_22426 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_highlight_info_22424_22439,"highlight-info",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22425_22440,"callback",true], null)], null),"chrome.tabs.highlight");
var ns_22427 = (function (){var target_obj_22434 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22435 = goog.object.get(target_obj_22434,"chrome");
var next_obj_22436 = goog.object.get(next_obj_22435,"tabs");
return next_obj_22436;
})();
var config__13480__auto___22442 = config;
var api_check_fn__13481__auto___22443 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22442);

(api_check_fn__13481__auto___22443.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22443.cljs$core$IFn$_invoke$arity$3("chrome.tabs.highlight",ns_22427,"highlight") : api_check_fn__13481__auto___22443.call(null,"chrome.tabs.highlight",ns_22427,"highlight"));


var target_22428 = (function (){var target_obj_22437 = ns_22427;
var next_obj_22438 = goog.object.get(target_obj_22437,"highlight");
if(!((next_obj_22438 == null))){
return next_obj_22438;
} else {
return null;
}
})();
return target_22428.apply(ns_22427,final_args_array_22426);
})();

return callback_chan_22422;
});
chromex.ext.tabs.update_STAR_ = (function chromex$ext$tabs$update_STAR_(config,tab_id,update_properties){
var callback_chan_22463 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22465_22482 = (function (){var omit_test_22471 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22471,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22471;
}
})();
var marshalled_update_properties_22466_22483 = (function (){var omit_test_22472 = update_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_22472,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22472;
}
})();
var marshalled_callback_22467_22484 = ((function (marshalled_tab_id_22465_22482,marshalled_update_properties_22466_22483,callback_chan_22463){
return (function (cb_tab_22473){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22474 = config__13447__auto__;
var G__22475 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_update,cljs.core.cst$kw$name,"update",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"update-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22476 = callback_chan_22463;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22474,G__22475,G__22476) : handler__13449__auto__.call(null,G__22474,G__22475,G__22476));
})().call(null,cb_tab_22473);
});})(marshalled_tab_id_22465_22482,marshalled_update_properties_22466_22483,callback_chan_22463))
;
var result_22464_22485 = (function (){var final_args_array_22468 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22465_22482,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_update_properties_22466_22483,"update-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22467_22484,"callback",true], null)], null),"chrome.tabs.update");
var ns_22469 = (function (){var target_obj_22477 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22478 = goog.object.get(target_obj_22477,"chrome");
var next_obj_22479 = goog.object.get(next_obj_22478,"tabs");
return next_obj_22479;
})();
var config__13480__auto___22486 = config;
var api_check_fn__13481__auto___22487 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22486);

(api_check_fn__13481__auto___22487.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22487.cljs$core$IFn$_invoke$arity$3("chrome.tabs.update",ns_22469,"update") : api_check_fn__13481__auto___22487.call(null,"chrome.tabs.update",ns_22469,"update"));


var target_22470 = (function (){var target_obj_22480 = ns_22469;
var next_obj_22481 = goog.object.get(target_obj_22480,"update");
if(!((next_obj_22481 == null))){
return next_obj_22481;
} else {
return null;
}
})();
return target_22470.apply(ns_22469,final_args_array_22468);
})();

return callback_chan_22463;
});
chromex.ext.tabs.move_STAR_ = (function chromex$ext$tabs$move_STAR_(config,tab_ids,move_properties){
var callback_chan_22507 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_ids_22509_22526 = (function (){var omit_test_22515 = tab_ids;
if(cljs.core.keyword_identical_QMARK_(omit_test_22515,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22515;
}
})();
var marshalled_move_properties_22510_22527 = (function (){var omit_test_22516 = move_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_22516,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22516;
}
})();
var marshalled_callback_22511_22528 = ((function (marshalled_tab_ids_22509_22526,marshalled_move_properties_22510_22527,callback_chan_22507){
return (function (cb_tabs_22517){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22518 = config__13447__auto__;
var G__22519 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_move,cljs.core.cst$kw$name,"move",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-ids",cljs.core.cst$kw$type,"integer-or-[array-of-integers]"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"move-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tabs",cljs.core.cst$kw$type,"tabs.Tab-or-[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22520 = callback_chan_22507;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22518,G__22519,G__22520) : handler__13449__auto__.call(null,G__22518,G__22519,G__22520));
})().call(null,cb_tabs_22517);
});})(marshalled_tab_ids_22509_22526,marshalled_move_properties_22510_22527,callback_chan_22507))
;
var result_22508_22529 = (function (){var final_args_array_22512 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_ids_22509_22526,"tab-ids",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_move_properties_22510_22527,"move-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22511_22528,"callback",true], null)], null),"chrome.tabs.move");
var ns_22513 = (function (){var target_obj_22521 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22522 = goog.object.get(target_obj_22521,"chrome");
var next_obj_22523 = goog.object.get(next_obj_22522,"tabs");
return next_obj_22523;
})();
var config__13480__auto___22530 = config;
var api_check_fn__13481__auto___22531 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22530);

(api_check_fn__13481__auto___22531.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22531.cljs$core$IFn$_invoke$arity$3("chrome.tabs.move",ns_22513,"move") : api_check_fn__13481__auto___22531.call(null,"chrome.tabs.move",ns_22513,"move"));


var target_22514 = (function (){var target_obj_22524 = ns_22513;
var next_obj_22525 = goog.object.get(target_obj_22524,"move");
if(!((next_obj_22525 == null))){
return next_obj_22525;
} else {
return null;
}
})();
return target_22514.apply(ns_22513,final_args_array_22512);
})();

return callback_chan_22507;
});
chromex.ext.tabs.reload_STAR_ = (function chromex$ext$tabs$reload_STAR_(config,tab_id,reload_properties){
var callback_chan_22550 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22552_22568 = (function (){var omit_test_22558 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22558,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22558;
}
})();
var marshalled_reload_properties_22553_22569 = (function (){var omit_test_22559 = reload_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_22559,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22559;
}
})();
var marshalled_callback_22554_22570 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22560 = config__13447__auto__;
var G__22561 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_reload,cljs.core.cst$kw$name,"reload",cljs.core.cst$kw$since,"16",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"reload-properties",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22562 = callback_chan_22550;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22560,G__22561,G__22562) : handler__13449__auto__.call(null,G__22560,G__22561,G__22562));
})();
var result_22551_22571 = (function (){var final_args_array_22555 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22552_22568,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_reload_properties_22553_22569,"reload-properties",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22554_22570,"callback",true], null)], null),"chrome.tabs.reload");
var ns_22556 = (function (){var target_obj_22563 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22564 = goog.object.get(target_obj_22563,"chrome");
var next_obj_22565 = goog.object.get(next_obj_22564,"tabs");
return next_obj_22565;
})();
var config__13480__auto___22572 = config;
var api_check_fn__13481__auto___22573 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22572);

(api_check_fn__13481__auto___22573.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22573.cljs$core$IFn$_invoke$arity$3("chrome.tabs.reload",ns_22556,"reload") : api_check_fn__13481__auto___22573.call(null,"chrome.tabs.reload",ns_22556,"reload"));


var target_22557 = (function (){var target_obj_22566 = ns_22556;
var next_obj_22567 = goog.object.get(target_obj_22566,"reload");
if(!((next_obj_22567 == null))){
return next_obj_22567;
} else {
return null;
}
})();
return target_22557.apply(ns_22556,final_args_array_22555);
})();

return callback_chan_22550;
});
chromex.ext.tabs.remove_STAR_ = (function chromex$ext$tabs$remove_STAR_(config,tab_ids){
var callback_chan_22590 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_ids_22592_22606 = (function (){var omit_test_22597 = tab_ids;
if(cljs.core.keyword_identical_QMARK_(omit_test_22597,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22597;
}
})();
var marshalled_callback_22593_22607 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22598 = config__13447__auto__;
var G__22599 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_remove,cljs.core.cst$kw$name,"remove",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-ids",cljs.core.cst$kw$type,"integer-or-[array-of-integers]"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22600 = callback_chan_22590;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22598,G__22599,G__22600) : handler__13449__auto__.call(null,G__22598,G__22599,G__22600));
})();
var result_22591_22608 = (function (){var final_args_array_22594 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_ids_22592_22606,"tab-ids",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22593_22607,"callback",true], null)], null),"chrome.tabs.remove");
var ns_22595 = (function (){var target_obj_22601 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22602 = goog.object.get(target_obj_22601,"chrome");
var next_obj_22603 = goog.object.get(next_obj_22602,"tabs");
return next_obj_22603;
})();
var config__13480__auto___22609 = config;
var api_check_fn__13481__auto___22610 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22609);

(api_check_fn__13481__auto___22610.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22610.cljs$core$IFn$_invoke$arity$3("chrome.tabs.remove",ns_22595,"remove") : api_check_fn__13481__auto___22610.call(null,"chrome.tabs.remove",ns_22595,"remove"));


var target_22596 = (function (){var target_obj_22604 = ns_22595;
var next_obj_22605 = goog.object.get(target_obj_22604,"remove");
if(!((next_obj_22605 == null))){
return next_obj_22605;
} else {
return null;
}
})();
return target_22596.apply(ns_22595,final_args_array_22594);
})();

return callback_chan_22590;
});
chromex.ext.tabs.detect_language_STAR_ = (function chromex$ext$tabs$detect_language_STAR_(config,tab_id){
var callback_chan_22628 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22630_22645 = (function (){var omit_test_22635 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22635,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22635;
}
})();
var marshalled_callback_22631_22646 = ((function (marshalled_tab_id_22630_22645,callback_chan_22628){
return (function (cb_language_22636){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22637 = config__13447__auto__;
var G__22638 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_detect_DASH_language,cljs.core.cst$kw$name,"detectLanguage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"language",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22639 = callback_chan_22628;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22637,G__22638,G__22639) : handler__13449__auto__.call(null,G__22637,G__22638,G__22639));
})().call(null,cb_language_22636);
});})(marshalled_tab_id_22630_22645,callback_chan_22628))
;
var result_22629_22647 = (function (){var final_args_array_22632 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22630_22645,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22631_22646,"callback",null], null)], null),"chrome.tabs.detectLanguage");
var ns_22633 = (function (){var target_obj_22640 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22641 = goog.object.get(target_obj_22640,"chrome");
var next_obj_22642 = goog.object.get(next_obj_22641,"tabs");
return next_obj_22642;
})();
var config__13480__auto___22648 = config;
var api_check_fn__13481__auto___22649 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22648);

(api_check_fn__13481__auto___22649.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22649.cljs$core$IFn$_invoke$arity$3("chrome.tabs.detectLanguage",ns_22633,"detectLanguage") : api_check_fn__13481__auto___22649.call(null,"chrome.tabs.detectLanguage",ns_22633,"detectLanguage"));


var target_22634 = (function (){var target_obj_22643 = ns_22633;
var next_obj_22644 = goog.object.get(target_obj_22643,"detectLanguage");
if(!((next_obj_22644 == null))){
return next_obj_22644;
} else {
return null;
}
})();
return target_22634.apply(ns_22633,final_args_array_22632);
})();

return callback_chan_22628;
});
chromex.ext.tabs.capture_visible_tab_STAR_ = (function chromex$ext$tabs$capture_visible_tab_STAR_(config,window_id,options){
var callback_chan_22669 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_window_id_22671_22688 = (function (){var omit_test_22677 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22677,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22677;
}
})();
var marshalled_options_22672_22689 = (function (){var omit_test_22678 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_22678,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22678;
}
})();
var marshalled_callback_22673_22690 = ((function (marshalled_window_id_22671_22688,marshalled_options_22672_22689,callback_chan_22669){
return (function (cb_data_url_22679){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22680 = config__13447__auto__;
var G__22681 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_capture_DASH_visible_DASH_tab,cljs.core.cst$kw$name,"captureVisibleTab",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"data-url",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22682 = callback_chan_22669;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22680,G__22681,G__22682) : handler__13449__auto__.call(null,G__22680,G__22681,G__22682));
})().call(null,cb_data_url_22679);
});})(marshalled_window_id_22671_22688,marshalled_options_22672_22689,callback_chan_22669))
;
var result_22670_22691 = (function (){var final_args_array_22674 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_22671_22688,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_22672_22689,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22673_22690,"callback",null], null)], null),"chrome.tabs.captureVisibleTab");
var ns_22675 = (function (){var target_obj_22683 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22684 = goog.object.get(target_obj_22683,"chrome");
var next_obj_22685 = goog.object.get(next_obj_22684,"tabs");
return next_obj_22685;
})();
var config__13480__auto___22692 = config;
var api_check_fn__13481__auto___22693 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22692);

(api_check_fn__13481__auto___22693.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22693.cljs$core$IFn$_invoke$arity$3("chrome.tabs.captureVisibleTab",ns_22675,"captureVisibleTab") : api_check_fn__13481__auto___22693.call(null,"chrome.tabs.captureVisibleTab",ns_22675,"captureVisibleTab"));


var target_22676 = (function (){var target_obj_22686 = ns_22675;
var next_obj_22687 = goog.object.get(target_obj_22686,"captureVisibleTab");
if(!((next_obj_22687 == null))){
return next_obj_22687;
} else {
return null;
}
})();
return target_22676.apply(ns_22675,final_args_array_22674);
})();

return callback_chan_22669;
});
chromex.ext.tabs.execute_script_STAR_ = (function chromex$ext$tabs$execute_script_STAR_(config,tab_id,details){
var callback_chan_22713 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22715_22732 = (function (){var omit_test_22721 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22721,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22721;
}
})();
var marshalled_details_22716_22733 = (function (){var omit_test_22722 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_22722,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22722;
}
})();
var marshalled_callback_22717_22734 = ((function (marshalled_tab_id_22715_22732,marshalled_details_22716_22733,callback_chan_22713){
return (function (cb_result_22723){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22724 = config__13447__auto__;
var G__22725 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_execute_DASH_script,cljs.core.cst$kw$name,"executeScript",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"[array-of-anys]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22726 = callback_chan_22713;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22724,G__22725,G__22726) : handler__13449__auto__.call(null,G__22724,G__22725,G__22726));
})().call(null,cb_result_22723);
});})(marshalled_tab_id_22715_22732,marshalled_details_22716_22733,callback_chan_22713))
;
var result_22714_22735 = (function (){var final_args_array_22718 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22715_22732,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_22716_22733,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22717_22734,"callback",true], null)], null),"chrome.tabs.executeScript");
var ns_22719 = (function (){var target_obj_22727 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22728 = goog.object.get(target_obj_22727,"chrome");
var next_obj_22729 = goog.object.get(next_obj_22728,"tabs");
return next_obj_22729;
})();
var config__13480__auto___22736 = config;
var api_check_fn__13481__auto___22737 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22736);

(api_check_fn__13481__auto___22737.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22737.cljs$core$IFn$_invoke$arity$3("chrome.tabs.executeScript",ns_22719,"executeScript") : api_check_fn__13481__auto___22737.call(null,"chrome.tabs.executeScript",ns_22719,"executeScript"));


var target_22720 = (function (){var target_obj_22730 = ns_22719;
var next_obj_22731 = goog.object.get(target_obj_22730,"executeScript");
if(!((next_obj_22731 == null))){
return next_obj_22731;
} else {
return null;
}
})();
return target_22720.apply(ns_22719,final_args_array_22718);
})();

return callback_chan_22713;
});
chromex.ext.tabs.insert_css_STAR_ = (function chromex$ext$tabs$insert_css_STAR_(config,tab_id,details){
var callback_chan_22756 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22758_22774 = (function (){var omit_test_22764 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22764,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22764;
}
})();
var marshalled_details_22759_22775 = (function (){var omit_test_22765 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_22765,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22765;
}
})();
var marshalled_callback_22760_22776 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22766 = config__13447__auto__;
var G__22767 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_insert_DASH_css,cljs.core.cst$kw$name,"insertCSS",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22768 = callback_chan_22756;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22766,G__22767,G__22768) : handler__13449__auto__.call(null,G__22766,G__22767,G__22768));
})();
var result_22757_22777 = (function (){var final_args_array_22761 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22758_22774,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_22759_22775,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22760_22776,"callback",true], null)], null),"chrome.tabs.insertCSS");
var ns_22762 = (function (){var target_obj_22769 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22770 = goog.object.get(target_obj_22769,"chrome");
var next_obj_22771 = goog.object.get(next_obj_22770,"tabs");
return next_obj_22771;
})();
var config__13480__auto___22778 = config;
var api_check_fn__13481__auto___22779 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22778);

(api_check_fn__13481__auto___22779.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22779.cljs$core$IFn$_invoke$arity$3("chrome.tabs.insertCSS",ns_22762,"insertCSS") : api_check_fn__13481__auto___22779.call(null,"chrome.tabs.insertCSS",ns_22762,"insertCSS"));


var target_22763 = (function (){var target_obj_22772 = ns_22762;
var next_obj_22773 = goog.object.get(target_obj_22772,"insertCSS");
if(!((next_obj_22773 == null))){
return next_obj_22773;
} else {
return null;
}
})();
return target_22763.apply(ns_22762,final_args_array_22761);
})();

return callback_chan_22756;
});
chromex.ext.tabs.set_zoom_STAR_ = (function chromex$ext$tabs$set_zoom_STAR_(config,tab_id,zoom_factor){
var callback_chan_22798 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22800_22816 = (function (){var omit_test_22806 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22806,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22806;
}
})();
var marshalled_zoom_factor_22801_22817 = (function (){var omit_test_22807 = zoom_factor;
if(cljs.core.keyword_identical_QMARK_(omit_test_22807,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22807;
}
})();
var marshalled_callback_22802_22818 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22808 = config__13447__auto__;
var G__22809 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_set_DASH_zoom,cljs.core.cst$kw$name,"setZoom",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-factor",cljs.core.cst$kw$type,"double"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22810 = callback_chan_22798;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22808,G__22809,G__22810) : handler__13449__auto__.call(null,G__22808,G__22809,G__22810));
})();
var result_22799_22819 = (function (){var final_args_array_22803 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22800_22816,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_zoom_factor_22801_22817,"zoom-factor",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22802_22818,"callback",true], null)], null),"chrome.tabs.setZoom");
var ns_22804 = (function (){var target_obj_22811 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22812 = goog.object.get(target_obj_22811,"chrome");
var next_obj_22813 = goog.object.get(next_obj_22812,"tabs");
return next_obj_22813;
})();
var config__13480__auto___22820 = config;
var api_check_fn__13481__auto___22821 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22820);

(api_check_fn__13481__auto___22821.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22821.cljs$core$IFn$_invoke$arity$3("chrome.tabs.setZoom",ns_22804,"setZoom") : api_check_fn__13481__auto___22821.call(null,"chrome.tabs.setZoom",ns_22804,"setZoom"));


var target_22805 = (function (){var target_obj_22814 = ns_22804;
var next_obj_22815 = goog.object.get(target_obj_22814,"setZoom");
if(!((next_obj_22815 == null))){
return next_obj_22815;
} else {
return null;
}
})();
return target_22805.apply(ns_22804,final_args_array_22803);
})();

return callback_chan_22798;
});
chromex.ext.tabs.get_zoom_STAR_ = (function chromex$ext$tabs$get_zoom_STAR_(config,tab_id){
var callback_chan_22839 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22841_22856 = (function (){var omit_test_22846 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22846,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22846;
}
})();
var marshalled_callback_22842_22857 = ((function (marshalled_tab_id_22841_22856,callback_chan_22839){
return (function (cb_zoom_factor_22847){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22848 = config__13447__auto__;
var G__22849 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_zoom,cljs.core.cst$kw$name,"getZoom",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-factor",cljs.core.cst$kw$type,"double"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22850 = callback_chan_22839;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22848,G__22849,G__22850) : handler__13449__auto__.call(null,G__22848,G__22849,G__22850));
})().call(null,cb_zoom_factor_22847);
});})(marshalled_tab_id_22841_22856,callback_chan_22839))
;
var result_22840_22858 = (function (){var final_args_array_22843 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22841_22856,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22842_22857,"callback",null], null)], null),"chrome.tabs.getZoom");
var ns_22844 = (function (){var target_obj_22851 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22852 = goog.object.get(target_obj_22851,"chrome");
var next_obj_22853 = goog.object.get(next_obj_22852,"tabs");
return next_obj_22853;
})();
var config__13480__auto___22859 = config;
var api_check_fn__13481__auto___22860 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22859);

(api_check_fn__13481__auto___22860.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22860.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getZoom",ns_22844,"getZoom") : api_check_fn__13481__auto___22860.call(null,"chrome.tabs.getZoom",ns_22844,"getZoom"));


var target_22845 = (function (){var target_obj_22854 = ns_22844;
var next_obj_22855 = goog.object.get(target_obj_22854,"getZoom");
if(!((next_obj_22855 == null))){
return next_obj_22855;
} else {
return null;
}
})();
return target_22845.apply(ns_22844,final_args_array_22843);
})();

return callback_chan_22839;
});
chromex.ext.tabs.set_zoom_settings_STAR_ = (function chromex$ext$tabs$set_zoom_settings_STAR_(config,tab_id,zoom_settings){
var callback_chan_22879 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22881_22897 = (function (){var omit_test_22887 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22887,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22887;
}
})();
var marshalled_zoom_settings_22882_22898 = (function (){var omit_test_22888 = zoom_settings;
if(cljs.core.keyword_identical_QMARK_(omit_test_22888,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22888;
}
})();
var marshalled_callback_22883_22899 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22889 = config__13447__auto__;
var G__22890 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_set_DASH_zoom_DASH_settings,cljs.core.cst$kw$name,"setZoomSettings",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-settings",cljs.core.cst$kw$type,"tabs.ZoomSettings"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22891 = callback_chan_22879;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22889,G__22890,G__22891) : handler__13449__auto__.call(null,G__22889,G__22890,G__22891));
})();
var result_22880_22900 = (function (){var final_args_array_22884 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22881_22897,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_zoom_settings_22882_22898,"zoom-settings",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22883_22899,"callback",true], null)], null),"chrome.tabs.setZoomSettings");
var ns_22885 = (function (){var target_obj_22892 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22893 = goog.object.get(target_obj_22892,"chrome");
var next_obj_22894 = goog.object.get(next_obj_22893,"tabs");
return next_obj_22894;
})();
var config__13480__auto___22901 = config;
var api_check_fn__13481__auto___22902 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22901);

(api_check_fn__13481__auto___22902.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22902.cljs$core$IFn$_invoke$arity$3("chrome.tabs.setZoomSettings",ns_22885,"setZoomSettings") : api_check_fn__13481__auto___22902.call(null,"chrome.tabs.setZoomSettings",ns_22885,"setZoomSettings"));


var target_22886 = (function (){var target_obj_22895 = ns_22885;
var next_obj_22896 = goog.object.get(target_obj_22895,"setZoomSettings");
if(!((next_obj_22896 == null))){
return next_obj_22896;
} else {
return null;
}
})();
return target_22886.apply(ns_22885,final_args_array_22884);
})();

return callback_chan_22879;
});
chromex.ext.tabs.get_zoom_settings_STAR_ = (function chromex$ext$tabs$get_zoom_settings_STAR_(config,tab_id){
var callback_chan_22920 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22922_22937 = (function (){var omit_test_22927 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22927,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22927;
}
})();
var marshalled_callback_22923_22938 = ((function (marshalled_tab_id_22922_22937,callback_chan_22920){
return (function (cb_zoom_settings_22928){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22929 = config__13447__auto__;
var G__22930 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_zoom_DASH_settings,cljs.core.cst$kw$name,"getZoomSettings",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-settings",cljs.core.cst$kw$type,"tabs.ZoomSettings"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22931 = callback_chan_22920;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22929,G__22930,G__22931) : handler__13449__auto__.call(null,G__22929,G__22930,G__22931));
})().call(null,cb_zoom_settings_22928);
});})(marshalled_tab_id_22922_22937,callback_chan_22920))
;
var result_22921_22939 = (function (){var final_args_array_22924 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22922_22937,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22923_22938,"callback",null], null)], null),"chrome.tabs.getZoomSettings");
var ns_22925 = (function (){var target_obj_22932 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22933 = goog.object.get(target_obj_22932,"chrome");
var next_obj_22934 = goog.object.get(next_obj_22933,"tabs");
return next_obj_22934;
})();
var config__13480__auto___22940 = config;
var api_check_fn__13481__auto___22941 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22940);

(api_check_fn__13481__auto___22941.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22941.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getZoomSettings",ns_22925,"getZoomSettings") : api_check_fn__13481__auto___22941.call(null,"chrome.tabs.getZoomSettings",ns_22925,"getZoomSettings"));


var target_22926 = (function (){var target_obj_22935 = ns_22925;
var next_obj_22936 = goog.object.get(target_obj_22935,"getZoomSettings");
if(!((next_obj_22936 == null))){
return next_obj_22936;
} else {
return null;
}
})();
return target_22926.apply(ns_22925,final_args_array_22924);
})();

return callback_chan_22920;
});
chromex.ext.tabs.discard_STAR_ = (function chromex$ext$tabs$discard_STAR_(config,tab_id){
var callback_chan_22959 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_22961_22976 = (function (){var omit_test_22966 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_22966,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_22966;
}
})();
var marshalled_callback_22962_22977 = ((function (marshalled_tab_id_22961_22976,callback_chan_22959){
return (function (cb_tab_22967){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22968 = config__13447__auto__;
var G__22969 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_discard,cljs.core.cst$kw$name,"discard",cljs.core.cst$kw$since,"54",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__22970 = callback_chan_22959;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22968,G__22969,G__22970) : handler__13449__auto__.call(null,G__22968,G__22969,G__22970));
})().call(null,cb_tab_22967);
});})(marshalled_tab_id_22961_22976,callback_chan_22959))
;
var result_22960_22978 = (function (){var final_args_array_22963 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_22961_22976,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_22962_22977,"callback",true], null)], null),"chrome.tabs.discard");
var ns_22964 = (function (){var target_obj_22971 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22972 = goog.object.get(target_obj_22971,"chrome");
var next_obj_22973 = goog.object.get(next_obj_22972,"tabs");
return next_obj_22973;
})();
var config__13480__auto___22979 = config;
var api_check_fn__13481__auto___22980 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___22979);

(api_check_fn__13481__auto___22980.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___22980.cljs$core$IFn$_invoke$arity$3("chrome.tabs.discard",ns_22964,"discard") : api_check_fn__13481__auto___22980.call(null,"chrome.tabs.discard",ns_22964,"discard"));


var target_22965 = (function (){var target_obj_22974 = ns_22964;
var next_obj_22975 = goog.object.get(target_obj_22974,"discard");
if(!((next_obj_22975 == null))){
return next_obj_22975;
} else {
return null;
}
})();
return target_22965.apply(ns_22964,final_args_array_22963);
})();

return callback_chan_22959;
});
chromex.ext.tabs.on_created_STAR_ = (function chromex$ext$tabs$on_created_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___22997 = arguments.length;
var i__8119__auto___22998 = (0);
while(true){
if((i__8119__auto___22998 < len__8118__auto___22997)){
args__8125__auto__.push((arguments[i__8119__auto___22998]));

var G__22999 = (i__8119__auto___22998 + (1));
i__8119__auto___22998 = G__22999;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_22984 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__22989 = config__13447__auto__;
var G__22990 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_created;
var G__22991 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__22989,G__22990,G__22991) : handler__13449__auto__.call(null,G__22989,G__22990,G__22991));
})();
var handler_fn_22985 = ((function (event_fn_22984){
return (function (cb_tab_22987){
return (event_fn_22984.cljs$core$IFn$_invoke$arity$1 ? event_fn_22984.cljs$core$IFn$_invoke$arity$1(cb_tab_22987) : event_fn_22984.call(null,cb_tab_22987));
});})(event_fn_22984))
;
var logging_fn__20428__auto__ = ((function (event_fn_22984,handler_fn_22985){
return (function (cb_param_tab_22988){

return handler_fn_22985(cb_param_tab_22988);
});})(event_fn_22984,handler_fn_22985))
;
var ns_obj_22986 = (function (){var target_obj_22992 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_22993 = goog.object.get(target_obj_22992,"chrome");
var next_obj_22994 = goog.object.get(next_obj_22993,"tabs");
return next_obj_22994;
})();
var config__13480__auto___23000 = config;
var api_check_fn__13481__auto___23001 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23000);

(api_check_fn__13481__auto___23001.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23001.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onCreated",ns_obj_22986,"onCreated") : api_check_fn__13481__auto___23001.call(null,"chrome.tabs.onCreated",ns_obj_22986,"onCreated"));

var event_obj__20429__auto__ = (function (){var target_obj_22995 = ns_obj_22986;
var next_obj_22996 = goog.object.get(target_obj_22995,"onCreated");
return next_obj_22996;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_created_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_created_STAR_.cljs$lang$applyTo = (function (seq22981){
var G__22982 = cljs.core.first(seq22981);
var seq22981__$1 = cljs.core.next(seq22981);
var G__22983 = cljs.core.first(seq22981__$1);
var seq22981__$2 = cljs.core.next(seq22981__$1);
return chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__22982,G__22983,seq22981__$2);
});

chromex.ext.tabs.on_updated_STAR_ = (function chromex$ext$tabs$on_updated_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23022 = arguments.length;
var i__8119__auto___23023 = (0);
while(true){
if((i__8119__auto___23023 < len__8118__auto___23022)){
args__8125__auto__.push((arguments[i__8119__auto___23023]));

var G__23024 = (i__8119__auto___23023 + (1));
i__8119__auto___23023 = G__23024;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23005 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23014 = config__13447__auto__;
var G__23015 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_updated;
var G__23016 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23014,G__23015,G__23016) : handler__13449__auto__.call(null,G__23014,G__23015,G__23016));
})();
var handler_fn_23006 = ((function (event_fn_23005){
return (function (cb_tab_id_23008,cb_change_info_23009,cb_tab_23010){
return (event_fn_23005.cljs$core$IFn$_invoke$arity$3 ? event_fn_23005.cljs$core$IFn$_invoke$arity$3(cb_tab_id_23008,cb_change_info_23009,cb_tab_23010) : event_fn_23005.call(null,cb_tab_id_23008,cb_change_info_23009,cb_tab_23010));
});})(event_fn_23005))
;
var logging_fn__20428__auto__ = ((function (event_fn_23005,handler_fn_23006){
return (function (cb_param_tab_id_23011,cb_param_change_info_23012,cb_param_tab_23013){

return handler_fn_23006(cb_param_tab_id_23011,cb_param_change_info_23012,cb_param_tab_23013);
});})(event_fn_23005,handler_fn_23006))
;
var ns_obj_23007 = (function (){var target_obj_23017 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23018 = goog.object.get(target_obj_23017,"chrome");
var next_obj_23019 = goog.object.get(next_obj_23018,"tabs");
return next_obj_23019;
})();
var config__13480__auto___23025 = config;
var api_check_fn__13481__auto___23026 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23025);

(api_check_fn__13481__auto___23026.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23026.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onUpdated",ns_obj_23007,"onUpdated") : api_check_fn__13481__auto___23026.call(null,"chrome.tabs.onUpdated",ns_obj_23007,"onUpdated"));

var event_obj__20429__auto__ = (function (){var target_obj_23020 = ns_obj_23007;
var next_obj_23021 = goog.object.get(target_obj_23020,"onUpdated");
return next_obj_23021;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_updated_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_updated_STAR_.cljs$lang$applyTo = (function (seq23002){
var G__23003 = cljs.core.first(seq23002);
var seq23002__$1 = cljs.core.next(seq23002);
var G__23004 = cljs.core.first(seq23002__$1);
var seq23002__$2 = cljs.core.next(seq23002__$1);
return chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23003,G__23004,seq23002__$2);
});

chromex.ext.tabs.on_moved_STAR_ = (function chromex$ext$tabs$on_moved_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23045 = arguments.length;
var i__8119__auto___23046 = (0);
while(true){
if((i__8119__auto___23046 < len__8118__auto___23045)){
args__8125__auto__.push((arguments[i__8119__auto___23046]));

var G__23047 = (i__8119__auto___23046 + (1));
i__8119__auto___23046 = G__23047;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23030 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23037 = config__13447__auto__;
var G__23038 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_moved;
var G__23039 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23037,G__23038,G__23039) : handler__13449__auto__.call(null,G__23037,G__23038,G__23039));
})();
var handler_fn_23031 = ((function (event_fn_23030){
return (function (cb_tab_id_23033,cb_move_info_23034){
return (event_fn_23030.cljs$core$IFn$_invoke$arity$2 ? event_fn_23030.cljs$core$IFn$_invoke$arity$2(cb_tab_id_23033,cb_move_info_23034) : event_fn_23030.call(null,cb_tab_id_23033,cb_move_info_23034));
});})(event_fn_23030))
;
var logging_fn__20428__auto__ = ((function (event_fn_23030,handler_fn_23031){
return (function (cb_param_tab_id_23035,cb_param_move_info_23036){

return handler_fn_23031(cb_param_tab_id_23035,cb_param_move_info_23036);
});})(event_fn_23030,handler_fn_23031))
;
var ns_obj_23032 = (function (){var target_obj_23040 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23041 = goog.object.get(target_obj_23040,"chrome");
var next_obj_23042 = goog.object.get(next_obj_23041,"tabs");
return next_obj_23042;
})();
var config__13480__auto___23048 = config;
var api_check_fn__13481__auto___23049 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23048);

(api_check_fn__13481__auto___23049.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23049.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onMoved",ns_obj_23032,"onMoved") : api_check_fn__13481__auto___23049.call(null,"chrome.tabs.onMoved",ns_obj_23032,"onMoved"));

var event_obj__20429__auto__ = (function (){var target_obj_23043 = ns_obj_23032;
var next_obj_23044 = goog.object.get(target_obj_23043,"onMoved");
return next_obj_23044;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_moved_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_moved_STAR_.cljs$lang$applyTo = (function (seq23027){
var G__23028 = cljs.core.first(seq23027);
var seq23027__$1 = cljs.core.next(seq23027);
var G__23029 = cljs.core.first(seq23027__$1);
var seq23027__$2 = cljs.core.next(seq23027__$1);
return chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23028,G__23029,seq23027__$2);
});

chromex.ext.tabs.on_selection_changed_STAR_ = (function chromex$ext$tabs$on_selection_changed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23068 = arguments.length;
var i__8119__auto___23069 = (0);
while(true){
if((i__8119__auto___23069 < len__8118__auto___23068)){
args__8125__auto__.push((arguments[i__8119__auto___23069]));

var G__23070 = (i__8119__auto___23069 + (1));
i__8119__auto___23069 = G__23070;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23053 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23060 = config__13447__auto__;
var G__23061 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_selection_DASH_changed;
var G__23062 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23060,G__23061,G__23062) : handler__13449__auto__.call(null,G__23060,G__23061,G__23062));
})();
var handler_fn_23054 = ((function (event_fn_23053){
return (function (cb_tab_id_23056,cb_select_info_23057){
return (event_fn_23053.cljs$core$IFn$_invoke$arity$2 ? event_fn_23053.cljs$core$IFn$_invoke$arity$2(cb_tab_id_23056,cb_select_info_23057) : event_fn_23053.call(null,cb_tab_id_23056,cb_select_info_23057));
});})(event_fn_23053))
;
var logging_fn__20428__auto__ = ((function (event_fn_23053,handler_fn_23054){
return (function (cb_param_tab_id_23058,cb_param_select_info_23059){

return handler_fn_23054(cb_param_tab_id_23058,cb_param_select_info_23059);
});})(event_fn_23053,handler_fn_23054))
;
var ns_obj_23055 = (function (){var target_obj_23063 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23064 = goog.object.get(target_obj_23063,"chrome");
var next_obj_23065 = goog.object.get(next_obj_23064,"tabs");
return next_obj_23065;
})();
var config__13480__auto___23071 = config;
var api_check_fn__13481__auto___23072 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23071);

(api_check_fn__13481__auto___23072.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23072.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onSelectionChanged",ns_obj_23055,"onSelectionChanged") : api_check_fn__13481__auto___23072.call(null,"chrome.tabs.onSelectionChanged",ns_obj_23055,"onSelectionChanged"));

var event_obj__20429__auto__ = (function (){var target_obj_23066 = ns_obj_23055;
var next_obj_23067 = goog.object.get(target_obj_23066,"onSelectionChanged");
return next_obj_23067;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_selection_changed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_selection_changed_STAR_.cljs$lang$applyTo = (function (seq23050){
var G__23051 = cljs.core.first(seq23050);
var seq23050__$1 = cljs.core.next(seq23050);
var G__23052 = cljs.core.first(seq23050__$1);
var seq23050__$2 = cljs.core.next(seq23050__$1);
return chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23051,G__23052,seq23050__$2);
});

chromex.ext.tabs.on_active_changed_STAR_ = (function chromex$ext$tabs$on_active_changed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23091 = arguments.length;
var i__8119__auto___23092 = (0);
while(true){
if((i__8119__auto___23092 < len__8118__auto___23091)){
args__8125__auto__.push((arguments[i__8119__auto___23092]));

var G__23093 = (i__8119__auto___23092 + (1));
i__8119__auto___23092 = G__23093;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23076 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23083 = config__13447__auto__;
var G__23084 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_active_DASH_changed;
var G__23085 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23083,G__23084,G__23085) : handler__13449__auto__.call(null,G__23083,G__23084,G__23085));
})();
var handler_fn_23077 = ((function (event_fn_23076){
return (function (cb_tab_id_23079,cb_select_info_23080){
return (event_fn_23076.cljs$core$IFn$_invoke$arity$2 ? event_fn_23076.cljs$core$IFn$_invoke$arity$2(cb_tab_id_23079,cb_select_info_23080) : event_fn_23076.call(null,cb_tab_id_23079,cb_select_info_23080));
});})(event_fn_23076))
;
var logging_fn__20428__auto__ = ((function (event_fn_23076,handler_fn_23077){
return (function (cb_param_tab_id_23081,cb_param_select_info_23082){

return handler_fn_23077(cb_param_tab_id_23081,cb_param_select_info_23082);
});})(event_fn_23076,handler_fn_23077))
;
var ns_obj_23078 = (function (){var target_obj_23086 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23087 = goog.object.get(target_obj_23086,"chrome");
var next_obj_23088 = goog.object.get(next_obj_23087,"tabs");
return next_obj_23088;
})();
var config__13480__auto___23094 = config;
var api_check_fn__13481__auto___23095 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23094);

(api_check_fn__13481__auto___23095.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23095.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onActiveChanged",ns_obj_23078,"onActiveChanged") : api_check_fn__13481__auto___23095.call(null,"chrome.tabs.onActiveChanged",ns_obj_23078,"onActiveChanged"));

var event_obj__20429__auto__ = (function (){var target_obj_23089 = ns_obj_23078;
var next_obj_23090 = goog.object.get(target_obj_23089,"onActiveChanged");
return next_obj_23090;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_active_changed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_active_changed_STAR_.cljs$lang$applyTo = (function (seq23073){
var G__23074 = cljs.core.first(seq23073);
var seq23073__$1 = cljs.core.next(seq23073);
var G__23075 = cljs.core.first(seq23073__$1);
var seq23073__$2 = cljs.core.next(seq23073__$1);
return chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23074,G__23075,seq23073__$2);
});

chromex.ext.tabs.on_activated_STAR_ = (function chromex$ext$tabs$on_activated_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23112 = arguments.length;
var i__8119__auto___23113 = (0);
while(true){
if((i__8119__auto___23113 < len__8118__auto___23112)){
args__8125__auto__.push((arguments[i__8119__auto___23113]));

var G__23114 = (i__8119__auto___23113 + (1));
i__8119__auto___23113 = G__23114;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23099 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23104 = config__13447__auto__;
var G__23105 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_activated;
var G__23106 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23104,G__23105,G__23106) : handler__13449__auto__.call(null,G__23104,G__23105,G__23106));
})();
var handler_fn_23100 = ((function (event_fn_23099){
return (function (cb_active_info_23102){
return (event_fn_23099.cljs$core$IFn$_invoke$arity$1 ? event_fn_23099.cljs$core$IFn$_invoke$arity$1(cb_active_info_23102) : event_fn_23099.call(null,cb_active_info_23102));
});})(event_fn_23099))
;
var logging_fn__20428__auto__ = ((function (event_fn_23099,handler_fn_23100){
return (function (cb_param_active_info_23103){

return handler_fn_23100(cb_param_active_info_23103);
});})(event_fn_23099,handler_fn_23100))
;
var ns_obj_23101 = (function (){var target_obj_23107 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23108 = goog.object.get(target_obj_23107,"chrome");
var next_obj_23109 = goog.object.get(next_obj_23108,"tabs");
return next_obj_23109;
})();
var config__13480__auto___23115 = config;
var api_check_fn__13481__auto___23116 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23115);

(api_check_fn__13481__auto___23116.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23116.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onActivated",ns_obj_23101,"onActivated") : api_check_fn__13481__auto___23116.call(null,"chrome.tabs.onActivated",ns_obj_23101,"onActivated"));

var event_obj__20429__auto__ = (function (){var target_obj_23110 = ns_obj_23101;
var next_obj_23111 = goog.object.get(target_obj_23110,"onActivated");
return next_obj_23111;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_activated_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_activated_STAR_.cljs$lang$applyTo = (function (seq23096){
var G__23097 = cljs.core.first(seq23096);
var seq23096__$1 = cljs.core.next(seq23096);
var G__23098 = cljs.core.first(seq23096__$1);
var seq23096__$2 = cljs.core.next(seq23096__$1);
return chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23097,G__23098,seq23096__$2);
});

chromex.ext.tabs.on_highlight_changed_STAR_ = (function chromex$ext$tabs$on_highlight_changed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23133 = arguments.length;
var i__8119__auto___23134 = (0);
while(true){
if((i__8119__auto___23134 < len__8118__auto___23133)){
args__8125__auto__.push((arguments[i__8119__auto___23134]));

var G__23135 = (i__8119__auto___23134 + (1));
i__8119__auto___23134 = G__23135;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23120 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23125 = config__13447__auto__;
var G__23126 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_highlight_DASH_changed;
var G__23127 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23125,G__23126,G__23127) : handler__13449__auto__.call(null,G__23125,G__23126,G__23127));
})();
var handler_fn_23121 = ((function (event_fn_23120){
return (function (cb_select_info_23123){
return (event_fn_23120.cljs$core$IFn$_invoke$arity$1 ? event_fn_23120.cljs$core$IFn$_invoke$arity$1(cb_select_info_23123) : event_fn_23120.call(null,cb_select_info_23123));
});})(event_fn_23120))
;
var logging_fn__20428__auto__ = ((function (event_fn_23120,handler_fn_23121){
return (function (cb_param_select_info_23124){

return handler_fn_23121(cb_param_select_info_23124);
});})(event_fn_23120,handler_fn_23121))
;
var ns_obj_23122 = (function (){var target_obj_23128 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23129 = goog.object.get(target_obj_23128,"chrome");
var next_obj_23130 = goog.object.get(next_obj_23129,"tabs");
return next_obj_23130;
})();
var config__13480__auto___23136 = config;
var api_check_fn__13481__auto___23137 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23136);

(api_check_fn__13481__auto___23137.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23137.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onHighlightChanged",ns_obj_23122,"onHighlightChanged") : api_check_fn__13481__auto___23137.call(null,"chrome.tabs.onHighlightChanged",ns_obj_23122,"onHighlightChanged"));

var event_obj__20429__auto__ = (function (){var target_obj_23131 = ns_obj_23122;
var next_obj_23132 = goog.object.get(target_obj_23131,"onHighlightChanged");
return next_obj_23132;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_highlight_changed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_highlight_changed_STAR_.cljs$lang$applyTo = (function (seq23117){
var G__23118 = cljs.core.first(seq23117);
var seq23117__$1 = cljs.core.next(seq23117);
var G__23119 = cljs.core.first(seq23117__$1);
var seq23117__$2 = cljs.core.next(seq23117__$1);
return chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23118,G__23119,seq23117__$2);
});

chromex.ext.tabs.on_highlighted_STAR_ = (function chromex$ext$tabs$on_highlighted_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23154 = arguments.length;
var i__8119__auto___23155 = (0);
while(true){
if((i__8119__auto___23155 < len__8118__auto___23154)){
args__8125__auto__.push((arguments[i__8119__auto___23155]));

var G__23156 = (i__8119__auto___23155 + (1));
i__8119__auto___23155 = G__23156;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23141 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23146 = config__13447__auto__;
var G__23147 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_highlighted;
var G__23148 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23146,G__23147,G__23148) : handler__13449__auto__.call(null,G__23146,G__23147,G__23148));
})();
var handler_fn_23142 = ((function (event_fn_23141){
return (function (cb_highlight_info_23144){
return (event_fn_23141.cljs$core$IFn$_invoke$arity$1 ? event_fn_23141.cljs$core$IFn$_invoke$arity$1(cb_highlight_info_23144) : event_fn_23141.call(null,cb_highlight_info_23144));
});})(event_fn_23141))
;
var logging_fn__20428__auto__ = ((function (event_fn_23141,handler_fn_23142){
return (function (cb_param_highlight_info_23145){

return handler_fn_23142(cb_param_highlight_info_23145);
});})(event_fn_23141,handler_fn_23142))
;
var ns_obj_23143 = (function (){var target_obj_23149 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23150 = goog.object.get(target_obj_23149,"chrome");
var next_obj_23151 = goog.object.get(next_obj_23150,"tabs");
return next_obj_23151;
})();
var config__13480__auto___23157 = config;
var api_check_fn__13481__auto___23158 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23157);

(api_check_fn__13481__auto___23158.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23158.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onHighlighted",ns_obj_23143,"onHighlighted") : api_check_fn__13481__auto___23158.call(null,"chrome.tabs.onHighlighted",ns_obj_23143,"onHighlighted"));

var event_obj__20429__auto__ = (function (){var target_obj_23152 = ns_obj_23143;
var next_obj_23153 = goog.object.get(target_obj_23152,"onHighlighted");
return next_obj_23153;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_highlighted_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_highlighted_STAR_.cljs$lang$applyTo = (function (seq23138){
var G__23139 = cljs.core.first(seq23138);
var seq23138__$1 = cljs.core.next(seq23138);
var G__23140 = cljs.core.first(seq23138__$1);
var seq23138__$2 = cljs.core.next(seq23138__$1);
return chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23139,G__23140,seq23138__$2);
});

chromex.ext.tabs.on_detached_STAR_ = (function chromex$ext$tabs$on_detached_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23177 = arguments.length;
var i__8119__auto___23178 = (0);
while(true){
if((i__8119__auto___23178 < len__8118__auto___23177)){
args__8125__auto__.push((arguments[i__8119__auto___23178]));

var G__23179 = (i__8119__auto___23178 + (1));
i__8119__auto___23178 = G__23179;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23162 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23169 = config__13447__auto__;
var G__23170 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_detached;
var G__23171 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23169,G__23170,G__23171) : handler__13449__auto__.call(null,G__23169,G__23170,G__23171));
})();
var handler_fn_23163 = ((function (event_fn_23162){
return (function (cb_tab_id_23165,cb_detach_info_23166){
return (event_fn_23162.cljs$core$IFn$_invoke$arity$2 ? event_fn_23162.cljs$core$IFn$_invoke$arity$2(cb_tab_id_23165,cb_detach_info_23166) : event_fn_23162.call(null,cb_tab_id_23165,cb_detach_info_23166));
});})(event_fn_23162))
;
var logging_fn__20428__auto__ = ((function (event_fn_23162,handler_fn_23163){
return (function (cb_param_tab_id_23167,cb_param_detach_info_23168){

return handler_fn_23163(cb_param_tab_id_23167,cb_param_detach_info_23168);
});})(event_fn_23162,handler_fn_23163))
;
var ns_obj_23164 = (function (){var target_obj_23172 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23173 = goog.object.get(target_obj_23172,"chrome");
var next_obj_23174 = goog.object.get(next_obj_23173,"tabs");
return next_obj_23174;
})();
var config__13480__auto___23180 = config;
var api_check_fn__13481__auto___23181 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23180);

(api_check_fn__13481__auto___23181.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23181.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onDetached",ns_obj_23164,"onDetached") : api_check_fn__13481__auto___23181.call(null,"chrome.tabs.onDetached",ns_obj_23164,"onDetached"));

var event_obj__20429__auto__ = (function (){var target_obj_23175 = ns_obj_23164;
var next_obj_23176 = goog.object.get(target_obj_23175,"onDetached");
return next_obj_23176;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_detached_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_detached_STAR_.cljs$lang$applyTo = (function (seq23159){
var G__23160 = cljs.core.first(seq23159);
var seq23159__$1 = cljs.core.next(seq23159);
var G__23161 = cljs.core.first(seq23159__$1);
var seq23159__$2 = cljs.core.next(seq23159__$1);
return chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23160,G__23161,seq23159__$2);
});

chromex.ext.tabs.on_attached_STAR_ = (function chromex$ext$tabs$on_attached_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23200 = arguments.length;
var i__8119__auto___23201 = (0);
while(true){
if((i__8119__auto___23201 < len__8118__auto___23200)){
args__8125__auto__.push((arguments[i__8119__auto___23201]));

var G__23202 = (i__8119__auto___23201 + (1));
i__8119__auto___23201 = G__23202;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23185 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23192 = config__13447__auto__;
var G__23193 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_attached;
var G__23194 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23192,G__23193,G__23194) : handler__13449__auto__.call(null,G__23192,G__23193,G__23194));
})();
var handler_fn_23186 = ((function (event_fn_23185){
return (function (cb_tab_id_23188,cb_attach_info_23189){
return (event_fn_23185.cljs$core$IFn$_invoke$arity$2 ? event_fn_23185.cljs$core$IFn$_invoke$arity$2(cb_tab_id_23188,cb_attach_info_23189) : event_fn_23185.call(null,cb_tab_id_23188,cb_attach_info_23189));
});})(event_fn_23185))
;
var logging_fn__20428__auto__ = ((function (event_fn_23185,handler_fn_23186){
return (function (cb_param_tab_id_23190,cb_param_attach_info_23191){

return handler_fn_23186(cb_param_tab_id_23190,cb_param_attach_info_23191);
});})(event_fn_23185,handler_fn_23186))
;
var ns_obj_23187 = (function (){var target_obj_23195 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23196 = goog.object.get(target_obj_23195,"chrome");
var next_obj_23197 = goog.object.get(next_obj_23196,"tabs");
return next_obj_23197;
})();
var config__13480__auto___23203 = config;
var api_check_fn__13481__auto___23204 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23203);

(api_check_fn__13481__auto___23204.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23204.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onAttached",ns_obj_23187,"onAttached") : api_check_fn__13481__auto___23204.call(null,"chrome.tabs.onAttached",ns_obj_23187,"onAttached"));

var event_obj__20429__auto__ = (function (){var target_obj_23198 = ns_obj_23187;
var next_obj_23199 = goog.object.get(target_obj_23198,"onAttached");
return next_obj_23199;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_attached_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_attached_STAR_.cljs$lang$applyTo = (function (seq23182){
var G__23183 = cljs.core.first(seq23182);
var seq23182__$1 = cljs.core.next(seq23182);
var G__23184 = cljs.core.first(seq23182__$1);
var seq23182__$2 = cljs.core.next(seq23182__$1);
return chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23183,G__23184,seq23182__$2);
});

chromex.ext.tabs.on_removed_STAR_ = (function chromex$ext$tabs$on_removed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23223 = arguments.length;
var i__8119__auto___23224 = (0);
while(true){
if((i__8119__auto___23224 < len__8118__auto___23223)){
args__8125__auto__.push((arguments[i__8119__auto___23224]));

var G__23225 = (i__8119__auto___23224 + (1));
i__8119__auto___23224 = G__23225;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23208 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23215 = config__13447__auto__;
var G__23216 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_removed;
var G__23217 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23215,G__23216,G__23217) : handler__13449__auto__.call(null,G__23215,G__23216,G__23217));
})();
var handler_fn_23209 = ((function (event_fn_23208){
return (function (cb_tab_id_23211,cb_remove_info_23212){
return (event_fn_23208.cljs$core$IFn$_invoke$arity$2 ? event_fn_23208.cljs$core$IFn$_invoke$arity$2(cb_tab_id_23211,cb_remove_info_23212) : event_fn_23208.call(null,cb_tab_id_23211,cb_remove_info_23212));
});})(event_fn_23208))
;
var logging_fn__20428__auto__ = ((function (event_fn_23208,handler_fn_23209){
return (function (cb_param_tab_id_23213,cb_param_remove_info_23214){

return handler_fn_23209(cb_param_tab_id_23213,cb_param_remove_info_23214);
});})(event_fn_23208,handler_fn_23209))
;
var ns_obj_23210 = (function (){var target_obj_23218 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23219 = goog.object.get(target_obj_23218,"chrome");
var next_obj_23220 = goog.object.get(next_obj_23219,"tabs");
return next_obj_23220;
})();
var config__13480__auto___23226 = config;
var api_check_fn__13481__auto___23227 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23226);

(api_check_fn__13481__auto___23227.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23227.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onRemoved",ns_obj_23210,"onRemoved") : api_check_fn__13481__auto___23227.call(null,"chrome.tabs.onRemoved",ns_obj_23210,"onRemoved"));

var event_obj__20429__auto__ = (function (){var target_obj_23221 = ns_obj_23210;
var next_obj_23222 = goog.object.get(target_obj_23221,"onRemoved");
return next_obj_23222;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_removed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_removed_STAR_.cljs$lang$applyTo = (function (seq23205){
var G__23206 = cljs.core.first(seq23205);
var seq23205__$1 = cljs.core.next(seq23205);
var G__23207 = cljs.core.first(seq23205__$1);
var seq23205__$2 = cljs.core.next(seq23205__$1);
return chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23206,G__23207,seq23205__$2);
});

chromex.ext.tabs.on_replaced_STAR_ = (function chromex$ext$tabs$on_replaced_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23246 = arguments.length;
var i__8119__auto___23247 = (0);
while(true){
if((i__8119__auto___23247 < len__8118__auto___23246)){
args__8125__auto__.push((arguments[i__8119__auto___23247]));

var G__23248 = (i__8119__auto___23247 + (1));
i__8119__auto___23247 = G__23248;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23231 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23238 = config__13447__auto__;
var G__23239 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_replaced;
var G__23240 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23238,G__23239,G__23240) : handler__13449__auto__.call(null,G__23238,G__23239,G__23240));
})();
var handler_fn_23232 = ((function (event_fn_23231){
return (function (cb_added_tab_id_23234,cb_removed_tab_id_23235){
return (event_fn_23231.cljs$core$IFn$_invoke$arity$2 ? event_fn_23231.cljs$core$IFn$_invoke$arity$2(cb_added_tab_id_23234,cb_removed_tab_id_23235) : event_fn_23231.call(null,cb_added_tab_id_23234,cb_removed_tab_id_23235));
});})(event_fn_23231))
;
var logging_fn__20428__auto__ = ((function (event_fn_23231,handler_fn_23232){
return (function (cb_param_added_tab_id_23236,cb_param_removed_tab_id_23237){

return handler_fn_23232(cb_param_added_tab_id_23236,cb_param_removed_tab_id_23237);
});})(event_fn_23231,handler_fn_23232))
;
var ns_obj_23233 = (function (){var target_obj_23241 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23242 = goog.object.get(target_obj_23241,"chrome");
var next_obj_23243 = goog.object.get(next_obj_23242,"tabs");
return next_obj_23243;
})();
var config__13480__auto___23249 = config;
var api_check_fn__13481__auto___23250 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23249);

(api_check_fn__13481__auto___23250.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23250.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onReplaced",ns_obj_23233,"onReplaced") : api_check_fn__13481__auto___23250.call(null,"chrome.tabs.onReplaced",ns_obj_23233,"onReplaced"));

var event_obj__20429__auto__ = (function (){var target_obj_23244 = ns_obj_23233;
var next_obj_23245 = goog.object.get(target_obj_23244,"onReplaced");
return next_obj_23245;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_replaced_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_replaced_STAR_.cljs$lang$applyTo = (function (seq23228){
var G__23229 = cljs.core.first(seq23228);
var seq23228__$1 = cljs.core.next(seq23228);
var G__23230 = cljs.core.first(seq23228__$1);
var seq23228__$2 = cljs.core.next(seq23228__$1);
return chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23229,G__23230,seq23228__$2);
});

chromex.ext.tabs.on_zoom_change_STAR_ = (function chromex$ext$tabs$on_zoom_change_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___23267 = arguments.length;
var i__8119__auto___23268 = (0);
while(true){
if((i__8119__auto___23268 < len__8118__auto___23267)){
args__8125__auto__.push((arguments[i__8119__auto___23268]));

var G__23269 = (i__8119__auto___23268 + (1));
i__8119__auto___23268 = G__23269;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_23254 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__23259 = config__13447__auto__;
var G__23260 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_zoom_DASH_change;
var G__23261 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__23259,G__23260,G__23261) : handler__13449__auto__.call(null,G__23259,G__23260,G__23261));
})();
var handler_fn_23255 = ((function (event_fn_23254){
return (function (cb_zoom_change_info_23257){
return (event_fn_23254.cljs$core$IFn$_invoke$arity$1 ? event_fn_23254.cljs$core$IFn$_invoke$arity$1(cb_zoom_change_info_23257) : event_fn_23254.call(null,cb_zoom_change_info_23257));
});})(event_fn_23254))
;
var logging_fn__20428__auto__ = ((function (event_fn_23254,handler_fn_23255){
return (function (cb_param_zoom_change_info_23258){

return handler_fn_23255(cb_param_zoom_change_info_23258);
});})(event_fn_23254,handler_fn_23255))
;
var ns_obj_23256 = (function (){var target_obj_23262 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_23263 = goog.object.get(target_obj_23262,"chrome");
var next_obj_23264 = goog.object.get(next_obj_23263,"tabs");
return next_obj_23264;
})();
var config__13480__auto___23270 = config;
var api_check_fn__13481__auto___23271 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___23270);

(api_check_fn__13481__auto___23271.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___23271.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onZoomChange",ns_obj_23256,"onZoomChange") : api_check_fn__13481__auto___23271.call(null,"chrome.tabs.onZoomChange",ns_obj_23256,"onZoomChange"));

var event_obj__20429__auto__ = (function (){var target_obj_23265 = ns_obj_23256;
var next_obj_23266 = goog.object.get(target_obj_23265,"onZoomChange");
return next_obj_23266;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_zoom_change_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_zoom_change_STAR_.cljs$lang$applyTo = (function (seq23251){
var G__23252 = cljs.core.first(seq23251);
var seq23251__$1 = cljs.core.next(seq23251);
var G__23253 = cljs.core.first(seq23251__$1);
var seq23251__$2 = cljs.core.next(seq23251__$1);
return chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__23252,G__23253,seq23251__$2);
});


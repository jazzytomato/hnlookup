// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.runtime');
goog.require('cljs.core');
goog.require('chromex.core');
chromex.ext.runtime.last_error_STAR_ = (function chromex$ext$runtime$last_error_STAR_(config){
var result_20641 = (function (){var final_args_array_20642 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.lastError");
var ns_20643 = (function (){var target_obj_20645 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20646 = goog.object.get(target_obj_20645,"chrome");
var next_obj_20647 = goog.object.get(next_obj_20646,"runtime");
return next_obj_20647;
})();


var target_20644 = (function (){var target_obj_20648 = ns_20643;
var next_obj_20649 = goog.object.get(target_obj_20648,"lastError");
if(!((next_obj_20649 == null))){
return next_obj_20649;
} else {
return null;
}
})();
return target_20644;
})();
return result_20641;
});
chromex.ext.runtime.id_STAR_ = (function chromex$ext$runtime$id_STAR_(config){
var result_20659 = (function (){var final_args_array_20660 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.id");
var ns_20661 = (function (){var target_obj_20663 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20664 = goog.object.get(target_obj_20663,"chrome");
var next_obj_20665 = goog.object.get(next_obj_20664,"runtime");
return next_obj_20665;
})();


var target_20662 = (function (){var target_obj_20666 = ns_20661;
var next_obj_20667 = goog.object.get(target_obj_20666,"id");
if(!((next_obj_20667 == null))){
return next_obj_20667;
} else {
return null;
}
})();
return target_20662;
})();
return result_20659;
});
chromex.ext.runtime.get_background_page_STAR_ = (function chromex$ext$runtime$get_background_page_STAR_(config){
var callback_chan_20683 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_20685_20698 = ((function (callback_chan_20683){
return (function (cb_background_page_20689){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__20690 = config__13447__auto__;
var G__20691 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_background_DASH_page,cljs.core.cst$kw$name,"getBackgroundPage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"background-page",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__20692 = callback_chan_20683;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__20690,G__20691,G__20692) : handler__13449__auto__.call(null,G__20690,G__20691,G__20692));
})().call(null,cb_background_page_20689);
});})(callback_chan_20683))
;
var result_20684_20699 = (function (){var final_args_array_20686 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_20685_20698,"callback",null], null)], null),"chrome.runtime.getBackgroundPage");
var ns_20687 = (function (){var target_obj_20693 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20694 = goog.object.get(target_obj_20693,"chrome");
var next_obj_20695 = goog.object.get(next_obj_20694,"runtime");
return next_obj_20695;
})();
var config__13480__auto___20700 = config;
var api_check_fn__13481__auto___20701 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___20700);

(api_check_fn__13481__auto___20701.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___20701.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getBackgroundPage",ns_20687,"getBackgroundPage") : api_check_fn__13481__auto___20701.call(null,"chrome.runtime.getBackgroundPage",ns_20687,"getBackgroundPage"));


var target_20688 = (function (){var target_obj_20696 = ns_20687;
var next_obj_20697 = goog.object.get(target_obj_20696,"getBackgroundPage");
if(!((next_obj_20697 == null))){
return next_obj_20697;
} else {
return null;
}
})();
return target_20688.apply(ns_20687,final_args_array_20686);
})();

return callback_chan_20683;
});
chromex.ext.runtime.open_options_page_STAR_ = (function chromex$ext$runtime$open_options_page_STAR_(config){
var callback_chan_20716 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_20718_20730 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__20722 = config__13447__auto__;
var G__20723 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_open_DASH_options_DASH_page,cljs.core.cst$kw$name,"openOptionsPage",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__20724 = callback_chan_20716;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__20722,G__20723,G__20724) : handler__13449__auto__.call(null,G__20722,G__20723,G__20724));
})();
var result_20717_20731 = (function (){var final_args_array_20719 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_20718_20730,"callback",true], null)], null),"chrome.runtime.openOptionsPage");
var ns_20720 = (function (){var target_obj_20725 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20726 = goog.object.get(target_obj_20725,"chrome");
var next_obj_20727 = goog.object.get(next_obj_20726,"runtime");
return next_obj_20727;
})();
var config__13480__auto___20732 = config;
var api_check_fn__13481__auto___20733 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___20732);

(api_check_fn__13481__auto___20733.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___20733.cljs$core$IFn$_invoke$arity$3("chrome.runtime.openOptionsPage",ns_20720,"openOptionsPage") : api_check_fn__13481__auto___20733.call(null,"chrome.runtime.openOptionsPage",ns_20720,"openOptionsPage"));


var target_20721 = (function (){var target_obj_20728 = ns_20720;
var next_obj_20729 = goog.object.get(target_obj_20728,"openOptionsPage");
if(!((next_obj_20729 == null))){
return next_obj_20729;
} else {
return null;
}
})();
return target_20721.apply(ns_20720,final_args_array_20719);
})();

return callback_chan_20716;
});
chromex.ext.runtime.get_manifest_STAR_ = (function chromex$ext$runtime$get_manifest_STAR_(config){
var result_20743 = (function (){var final_args_array_20744 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.getManifest");
var ns_20745 = (function (){var target_obj_20747 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20748 = goog.object.get(target_obj_20747,"chrome");
var next_obj_20749 = goog.object.get(next_obj_20748,"runtime");
return next_obj_20749;
})();
var config__13480__auto___20752 = config;
var api_check_fn__13481__auto___20753 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___20752);

(api_check_fn__13481__auto___20753.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___20753.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getManifest",ns_20745,"getManifest") : api_check_fn__13481__auto___20753.call(null,"chrome.runtime.getManifest",ns_20745,"getManifest"));


var target_20746 = (function (){var target_obj_20750 = ns_20745;
var next_obj_20751 = goog.object.get(target_obj_20750,"getManifest");
if(!((next_obj_20751 == null))){
return next_obj_20751;
} else {
return null;
}
})();
return target_20746.apply(ns_20745,final_args_array_20744);
})();
return result_20743;
});
chromex.ext.runtime.get_url_STAR_ = (function chromex$ext$runtime$get_url_STAR_(config,path){
var marshalled_path_20766 = (function (){var omit_test_20770 = path;
if(cljs.core.keyword_identical_QMARK_(omit_test_20770,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_20770;
}
})();
var result_20765 = (function (){var final_args_array_20767 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_path_20766,"path",null], null)], null),"chrome.runtime.getURL");
var ns_20768 = (function (){var target_obj_20771 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20772 = goog.object.get(target_obj_20771,"chrome");
var next_obj_20773 = goog.object.get(next_obj_20772,"runtime");
return next_obj_20773;
})();
var config__13480__auto___20776 = config;
var api_check_fn__13481__auto___20777 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___20776);

(api_check_fn__13481__auto___20777.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___20777.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getURL",ns_20768,"getURL") : api_check_fn__13481__auto___20777.call(null,"chrome.runtime.getURL",ns_20768,"getURL"));


var target_20769 = (function (){var target_obj_20774 = ns_20768;
var next_obj_20775 = goog.object.get(target_obj_20774,"getURL");
if(!((next_obj_20775 == null))){
return next_obj_20775;
} else {
return null;
}
})();
return target_20769.apply(ns_20768,final_args_array_20767);
})();
return result_20765;
});
chromex.ext.runtime.set_uninstall_url_STAR_ = (function chromex$ext$runtime$set_uninstall_url_STAR_(config,url){
var callback_chan_20794 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_url_20796_20810 = (function (){var omit_test_20801 = url;
if(cljs.core.keyword_identical_QMARK_(omit_test_20801,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_20801;
}
})();
var marshalled_callback_20797_20811 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__20802 = config__13447__auto__;
var G__20803 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_set_DASH_uninstall_DASH_url,cljs.core.cst$kw$name,"setUninstallURL",cljs.core.cst$kw$since,"41",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"url",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__20804 = callback_chan_20794;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__20802,G__20803,G__20804) : handler__13449__auto__.call(null,G__20802,G__20803,G__20804));
})();
var result_20795_20812 = (function (){var final_args_array_20798 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_url_20796_20810,"url",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_20797_20811,"callback",true], null)], null),"chrome.runtime.setUninstallURL");
var ns_20799 = (function (){var target_obj_20805 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20806 = goog.object.get(target_obj_20805,"chrome");
var next_obj_20807 = goog.object.get(next_obj_20806,"runtime");
return next_obj_20807;
})();
var config__13480__auto___20813 = config;
var api_check_fn__13481__auto___20814 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___20813);

(api_check_fn__13481__auto___20814.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___20814.cljs$core$IFn$_invoke$arity$3("chrome.runtime.setUninstallURL",ns_20799,"setUninstallURL") : api_check_fn__13481__auto___20814.call(null,"chrome.runtime.setUninstallURL",ns_20799,"setUninstallURL"));


var target_20800 = (function (){var target_obj_20808 = ns_20799;
var next_obj_20809 = goog.object.get(target_obj_20808,"setUninstallURL");
if(!((next_obj_20809 == null))){
return next_obj_20809;
} else {
return null;
}
})();
return target_20800.apply(ns_20799,final_args_array_20798);
})();

return callback_chan_20794;
});
chromex.ext.runtime.reload_STAR_ = (function chromex$ext$runtime$reload_STAR_(config){
var result_20824 = (function (){var final_args_array_20825 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.reload");
var ns_20826 = (function (){var target_obj_20828 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20829 = goog.object.get(target_obj_20828,"chrome");
var next_obj_20830 = goog.object.get(next_obj_20829,"runtime");
return next_obj_20830;
})();
var config__13480__auto___20833 = config;
var api_check_fn__13481__auto___20834 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___20833);

(api_check_fn__13481__auto___20834.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___20834.cljs$core$IFn$_invoke$arity$3("chrome.runtime.reload",ns_20826,"reload") : api_check_fn__13481__auto___20834.call(null,"chrome.runtime.reload",ns_20826,"reload"));


var target_20827 = (function (){var target_obj_20831 = ns_20826;
var next_obj_20832 = goog.object.get(target_obj_20831,"reload");
if(!((next_obj_20832 == null))){
return next_obj_20832;
} else {
return null;
}
})();
return target_20827.apply(ns_20826,final_args_array_20825);
})();
return result_20824;
});
chromex.ext.runtime.request_update_check_STAR_ = (function chromex$ext$runtime$request_update_check_STAR_(config){
var callback_chan_20851 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_20853_20867 = ((function (callback_chan_20851){
return (function (cb_status_20857,cb_details_20858){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__20859 = config__13447__auto__;
var G__20860 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_request_DASH_update_DASH_check,cljs.core.cst$kw$name,"requestUpdateCheck",cljs.core.cst$kw$since,"25",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"status",cljs.core.cst$kw$type,"runtime.RequestUpdateCheckStatus"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__20861 = callback_chan_20851;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__20859,G__20860,G__20861) : handler__13449__auto__.call(null,G__20859,G__20860,G__20861));
})().call(null,cb_status_20857,cb_details_20858);
});})(callback_chan_20851))
;
var result_20852_20868 = (function (){var final_args_array_20854 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_20853_20867,"callback",null], null)], null),"chrome.runtime.requestUpdateCheck");
var ns_20855 = (function (){var target_obj_20862 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20863 = goog.object.get(target_obj_20862,"chrome");
var next_obj_20864 = goog.object.get(next_obj_20863,"runtime");
return next_obj_20864;
})();
var config__13480__auto___20869 = config;
var api_check_fn__13481__auto___20870 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___20869);

(api_check_fn__13481__auto___20870.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___20870.cljs$core$IFn$_invoke$arity$3("chrome.runtime.requestUpdateCheck",ns_20855,"requestUpdateCheck") : api_check_fn__13481__auto___20870.call(null,"chrome.runtime.requestUpdateCheck",ns_20855,"requestUpdateCheck"));


var target_20856 = (function (){var target_obj_20865 = ns_20855;
var next_obj_20866 = goog.object.get(target_obj_20865,"requestUpdateCheck");
if(!((next_obj_20866 == null))){
return next_obj_20866;
} else {
return null;
}
})();
return target_20856.apply(ns_20855,final_args_array_20854);
})();

return callback_chan_20851;
});
chromex.ext.runtime.restart_STAR_ = (function chromex$ext$runtime$restart_STAR_(config){
var result_20880 = (function (){var final_args_array_20881 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.restart");
var ns_20882 = (function (){var target_obj_20884 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20885 = goog.object.get(target_obj_20884,"chrome");
var next_obj_20886 = goog.object.get(next_obj_20885,"runtime");
return next_obj_20886;
})();
var config__13480__auto___20889 = config;
var api_check_fn__13481__auto___20890 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___20889);

(api_check_fn__13481__auto___20890.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___20890.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restart",ns_20882,"restart") : api_check_fn__13481__auto___20890.call(null,"chrome.runtime.restart",ns_20882,"restart"));


var target_20883 = (function (){var target_obj_20887 = ns_20882;
var next_obj_20888 = goog.object.get(target_obj_20887,"restart");
if(!((next_obj_20888 == null))){
return next_obj_20888;
} else {
return null;
}
})();
return target_20883.apply(ns_20882,final_args_array_20881);
})();
return result_20880;
});
chromex.ext.runtime.restart_after_delay_STAR_ = (function chromex$ext$runtime$restart_after_delay_STAR_(config,seconds){
var callback_chan_20907 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_seconds_20909_20923 = (function (){var omit_test_20914 = seconds;
if(cljs.core.keyword_identical_QMARK_(omit_test_20914,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_20914;
}
})();
var marshalled_callback_20910_20924 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__20915 = config__13447__auto__;
var G__20916 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_restart_DASH_after_DASH_delay,cljs.core.cst$kw$name,"restartAfterDelay",cljs.core.cst$kw$since,"53",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"seconds",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__20917 = callback_chan_20907;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__20915,G__20916,G__20917) : handler__13449__auto__.call(null,G__20915,G__20916,G__20917));
})();
var result_20908_20925 = (function (){var final_args_array_20911 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_seconds_20909_20923,"seconds",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_20910_20924,"callback",true], null)], null),"chrome.runtime.restartAfterDelay");
var ns_20912 = (function (){var target_obj_20918 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20919 = goog.object.get(target_obj_20918,"chrome");
var next_obj_20920 = goog.object.get(next_obj_20919,"runtime");
return next_obj_20920;
})();
var config__13480__auto___20926 = config;
var api_check_fn__13481__auto___20927 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___20926);

(api_check_fn__13481__auto___20927.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___20927.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restartAfterDelay",ns_20912,"restartAfterDelay") : api_check_fn__13481__auto___20927.call(null,"chrome.runtime.restartAfterDelay",ns_20912,"restartAfterDelay"));


var target_20913 = (function (){var target_obj_20921 = ns_20912;
var next_obj_20922 = goog.object.get(target_obj_20921,"restartAfterDelay");
if(!((next_obj_20922 == null))){
return next_obj_20922;
} else {
return null;
}
})();
return target_20913.apply(ns_20912,final_args_array_20911);
})();

return callback_chan_20907;
});
chromex.ext.runtime.connect_STAR_ = (function chromex$ext$runtime$connect_STAR_(config,extension_id,connect_info){
var marshalled_extension_id_20942 = (function (){var omit_test_20947 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_20947,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_20947;
}
})();
var marshalled_connect_info_20943 = (function (){var omit_test_20948 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_20948,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_20948;
}
})();
var result_20941 = (function (){var final_args_array_20944 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_20942,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_20943,"connect-info",true], null)], null),"chrome.runtime.connect");
var ns_20945 = (function (){var target_obj_20949 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20950 = goog.object.get(target_obj_20949,"chrome");
var next_obj_20951 = goog.object.get(next_obj_20950,"runtime");
return next_obj_20951;
})();
var config__13480__auto___20954 = config;
var api_check_fn__13481__auto___20955 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___20954);

(api_check_fn__13481__auto___20955.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___20955.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connect",ns_20945,"connect") : api_check_fn__13481__auto___20955.call(null,"chrome.runtime.connect",ns_20945,"connect"));


var target_20946 = (function (){var target_obj_20952 = ns_20945;
var next_obj_20953 = goog.object.get(target_obj_20952,"connect");
if(!((next_obj_20953 == null))){
return next_obj_20953;
} else {
return null;
}
})();
return target_20946.apply(ns_20945,final_args_array_20944);
})();
return chromex.marshalling.from_native_chrome_port(config,result_20941);
});
chromex.ext.runtime.connect_native_STAR_ = (function chromex$ext$runtime$connect_native_STAR_(config,application){
var marshalled_application_20968 = (function (){var omit_test_20972 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_20972,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_20972;
}
})();
var result_20967 = (function (){var final_args_array_20969 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_20968,"application",null], null)], null),"chrome.runtime.connectNative");
var ns_20970 = (function (){var target_obj_20973 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_20974 = goog.object.get(target_obj_20973,"chrome");
var next_obj_20975 = goog.object.get(next_obj_20974,"runtime");
return next_obj_20975;
})();
var config__13480__auto___20978 = config;
var api_check_fn__13481__auto___20979 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___20978);

(api_check_fn__13481__auto___20979.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___20979.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connectNative",ns_20970,"connectNative") : api_check_fn__13481__auto___20979.call(null,"chrome.runtime.connectNative",ns_20970,"connectNative"));


var target_20971 = (function (){var target_obj_20976 = ns_20970;
var next_obj_20977 = goog.object.get(target_obj_20976,"connectNative");
if(!((next_obj_20977 == null))){
return next_obj_20977;
} else {
return null;
}
})();
return target_20971.apply(ns_20970,final_args_array_20969);
})();
return chromex.marshalling.from_native_chrome_port(config,result_20967);
});
chromex.ext.runtime.send_message_STAR_ = (function chromex$ext$runtime$send_message_STAR_(config,extension_id,message,options){
var callback_chan_21001 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_extension_id_21003_21022 = (function (){var omit_test_21010 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_21010,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_21010;
}
})();
var marshalled_message_21004_21023 = (function (){var omit_test_21011 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_21011,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_21011;
}
})();
var marshalled_options_21005_21024 = (function (){var omit_test_21012 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_21012,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_21012;
}
})();
var marshalled_response_callback_21006_21025 = ((function (marshalled_extension_id_21003_21022,marshalled_message_21004_21023,marshalled_options_21005_21024,callback_chan_21001){
return (function (cb_response_21013){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21014 = config__13447__auto__;
var G__21015 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$since,"26",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"extension-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__21016 = callback_chan_21001;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21014,G__21015,G__21016) : handler__13449__auto__.call(null,G__21014,G__21015,G__21016));
})().call(null,cb_response_21013);
});})(marshalled_extension_id_21003_21022,marshalled_message_21004_21023,marshalled_options_21005_21024,callback_chan_21001))
;
var result_21002_21026 = (function (){var final_args_array_21007 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_21003_21022,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_21004_21023,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_21005_21024,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_21006_21025,"response-callback",true], null)], null),"chrome.runtime.sendMessage");
var ns_21008 = (function (){var target_obj_21017 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21018 = goog.object.get(target_obj_21017,"chrome");
var next_obj_21019 = goog.object.get(next_obj_21018,"runtime");
return next_obj_21019;
})();
var config__13480__auto___21027 = config;
var api_check_fn__13481__auto___21028 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21027);

(api_check_fn__13481__auto___21028.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21028.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendMessage",ns_21008,"sendMessage") : api_check_fn__13481__auto___21028.call(null,"chrome.runtime.sendMessage",ns_21008,"sendMessage"));


var target_21009 = (function (){var target_obj_21020 = ns_21008;
var next_obj_21021 = goog.object.get(target_obj_21020,"sendMessage");
if(!((next_obj_21021 == null))){
return next_obj_21021;
} else {
return null;
}
})();
return target_21009.apply(ns_21008,final_args_array_21007);
})();

return callback_chan_21001;
});
chromex.ext.runtime.send_native_message_STAR_ = (function chromex$ext$runtime$send_native_message_STAR_(config,application,message){
var callback_chan_21048 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_application_21050_21067 = (function (){var omit_test_21056 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_21056,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_21056;
}
})();
var marshalled_message_21051_21068 = (function (){var omit_test_21057 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_21057,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_21057;
}
})();
var marshalled_response_callback_21052_21069 = ((function (marshalled_application_21050_21067,marshalled_message_21051_21068,callback_chan_21048){
return (function (cb_response_21058){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21059 = config__13447__auto__;
var G__21060 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_native_DASH_message,cljs.core.cst$kw$name,"sendNativeMessage",cljs.core.cst$kw$since,"28",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"application",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__21061 = callback_chan_21048;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21059,G__21060,G__21061) : handler__13449__auto__.call(null,G__21059,G__21060,G__21061));
})().call(null,cb_response_21058);
});})(marshalled_application_21050_21067,marshalled_message_21051_21068,callback_chan_21048))
;
var result_21049_21070 = (function (){var final_args_array_21053 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_21050_21067,"application",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_21051_21068,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_21052_21069,"response-callback",true], null)], null),"chrome.runtime.sendNativeMessage");
var ns_21054 = (function (){var target_obj_21062 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21063 = goog.object.get(target_obj_21062,"chrome");
var next_obj_21064 = goog.object.get(next_obj_21063,"runtime");
return next_obj_21064;
})();
var config__13480__auto___21071 = config;
var api_check_fn__13481__auto___21072 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21071);

(api_check_fn__13481__auto___21072.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21072.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendNativeMessage",ns_21054,"sendNativeMessage") : api_check_fn__13481__auto___21072.call(null,"chrome.runtime.sendNativeMessage",ns_21054,"sendNativeMessage"));


var target_21055 = (function (){var target_obj_21065 = ns_21054;
var next_obj_21066 = goog.object.get(target_obj_21065,"sendNativeMessage");
if(!((next_obj_21066 == null))){
return next_obj_21066;
} else {
return null;
}
})();
return target_21055.apply(ns_21054,final_args_array_21053);
})();

return callback_chan_21048;
});
chromex.ext.runtime.get_platform_info_STAR_ = (function chromex$ext$runtime$get_platform_info_STAR_(config){
var callback_chan_21088 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_21090_21103 = ((function (callback_chan_21088){
return (function (cb_platform_info_21094){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21095 = config__13447__auto__;
var G__21096 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_platform_DASH_info,cljs.core.cst$kw$name,"getPlatformInfo",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"platform-info",cljs.core.cst$kw$type,"runtime.PlatformInfo"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__21097 = callback_chan_21088;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21095,G__21096,G__21097) : handler__13449__auto__.call(null,G__21095,G__21096,G__21097));
})().call(null,cb_platform_info_21094);
});})(callback_chan_21088))
;
var result_21089_21104 = (function (){var final_args_array_21091 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_21090_21103,"callback",null], null)], null),"chrome.runtime.getPlatformInfo");
var ns_21092 = (function (){var target_obj_21098 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21099 = goog.object.get(target_obj_21098,"chrome");
var next_obj_21100 = goog.object.get(next_obj_21099,"runtime");
return next_obj_21100;
})();
var config__13480__auto___21105 = config;
var api_check_fn__13481__auto___21106 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21105);

(api_check_fn__13481__auto___21106.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21106.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPlatformInfo",ns_21092,"getPlatformInfo") : api_check_fn__13481__auto___21106.call(null,"chrome.runtime.getPlatformInfo",ns_21092,"getPlatformInfo"));


var target_21093 = (function (){var target_obj_21101 = ns_21092;
var next_obj_21102 = goog.object.get(target_obj_21101,"getPlatformInfo");
if(!((next_obj_21102 == null))){
return next_obj_21102;
} else {
return null;
}
})();
return target_21093.apply(ns_21092,final_args_array_21091);
})();

return callback_chan_21088;
});
chromex.ext.runtime.get_package_directory_entry_STAR_ = (function chromex$ext$runtime$get_package_directory_entry_STAR_(config){
var callback_chan_21122 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_21124_21137 = ((function (callback_chan_21122){
return (function (cb_directory_entry_21128){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21129 = config__13447__auto__;
var G__21130 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_package_DASH_directory_DASH_entry,cljs.core.cst$kw$name,"getPackageDirectoryEntry",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"directory-entry",cljs.core.cst$kw$type,"DirectoryEntry"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__21131 = callback_chan_21122;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21129,G__21130,G__21131) : handler__13449__auto__.call(null,G__21129,G__21130,G__21131));
})().call(null,cb_directory_entry_21128);
});})(callback_chan_21122))
;
var result_21123_21138 = (function (){var final_args_array_21125 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_21124_21137,"callback",null], null)], null),"chrome.runtime.getPackageDirectoryEntry");
var ns_21126 = (function (){var target_obj_21132 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21133 = goog.object.get(target_obj_21132,"chrome");
var next_obj_21134 = goog.object.get(next_obj_21133,"runtime");
return next_obj_21134;
})();
var config__13480__auto___21139 = config;
var api_check_fn__13481__auto___21140 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21139);

(api_check_fn__13481__auto___21140.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21140.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPackageDirectoryEntry",ns_21126,"getPackageDirectoryEntry") : api_check_fn__13481__auto___21140.call(null,"chrome.runtime.getPackageDirectoryEntry",ns_21126,"getPackageDirectoryEntry"));


var target_21127 = (function (){var target_obj_21135 = ns_21126;
var next_obj_21136 = goog.object.get(target_obj_21135,"getPackageDirectoryEntry");
if(!((next_obj_21136 == null))){
return next_obj_21136;
} else {
return null;
}
})();
return target_21127.apply(ns_21126,final_args_array_21125);
})();

return callback_chan_21122;
});
chromex.ext.runtime.on_startup_STAR_ = (function chromex$ext$runtime$on_startup_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21155 = arguments.length;
var i__8119__auto___21156 = (0);
while(true){
if((i__8119__auto___21156 < len__8118__auto___21155)){
args__8125__auto__.push((arguments[i__8119__auto___21156]));

var G__21157 = (i__8119__auto___21156 + (1));
i__8119__auto___21156 = G__21157;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21144 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21147 = config__13447__auto__;
var G__21148 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_startup;
var G__21149 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21147,G__21148,G__21149) : handler__13449__auto__.call(null,G__21147,G__21148,G__21149));
})();
var handler_fn_21145 = event_fn_21144;
var logging_fn__20428__auto__ = ((function (event_fn_21144,handler_fn_21145){
return (function (){

return (handler_fn_21145.cljs$core$IFn$_invoke$arity$0 ? handler_fn_21145.cljs$core$IFn$_invoke$arity$0() : handler_fn_21145.call(null));
});})(event_fn_21144,handler_fn_21145))
;
var ns_obj_21146 = (function (){var target_obj_21150 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21151 = goog.object.get(target_obj_21150,"chrome");
var next_obj_21152 = goog.object.get(next_obj_21151,"runtime");
return next_obj_21152;
})();
var config__13480__auto___21158 = config;
var api_check_fn__13481__auto___21159 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21158);

(api_check_fn__13481__auto___21159.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21159.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onStartup",ns_obj_21146,"onStartup") : api_check_fn__13481__auto___21159.call(null,"chrome.runtime.onStartup",ns_obj_21146,"onStartup"));

var event_obj__20429__auto__ = (function (){var target_obj_21153 = ns_obj_21146;
var next_obj_21154 = goog.object.get(target_obj_21153,"onStartup");
return next_obj_21154;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_startup_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_startup_STAR_.cljs$lang$applyTo = (function (seq21141){
var G__21142 = cljs.core.first(seq21141);
var seq21141__$1 = cljs.core.next(seq21141);
var G__21143 = cljs.core.first(seq21141__$1);
var seq21141__$2 = cljs.core.next(seq21141__$1);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21142,G__21143,seq21141__$2);
});

chromex.ext.runtime.on_installed_STAR_ = (function chromex$ext$runtime$on_installed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21176 = arguments.length;
var i__8119__auto___21177 = (0);
while(true){
if((i__8119__auto___21177 < len__8118__auto___21176)){
args__8125__auto__.push((arguments[i__8119__auto___21177]));

var G__21178 = (i__8119__auto___21177 + (1));
i__8119__auto___21177 = G__21178;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21163 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21168 = config__13447__auto__;
var G__21169 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_installed;
var G__21170 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21168,G__21169,G__21170) : handler__13449__auto__.call(null,G__21168,G__21169,G__21170));
})();
var handler_fn_21164 = ((function (event_fn_21163){
return (function (cb_details_21166){
return (event_fn_21163.cljs$core$IFn$_invoke$arity$1 ? event_fn_21163.cljs$core$IFn$_invoke$arity$1(cb_details_21166) : event_fn_21163.call(null,cb_details_21166));
});})(event_fn_21163))
;
var logging_fn__20428__auto__ = ((function (event_fn_21163,handler_fn_21164){
return (function (cb_param_details_21167){

return handler_fn_21164(cb_param_details_21167);
});})(event_fn_21163,handler_fn_21164))
;
var ns_obj_21165 = (function (){var target_obj_21171 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21172 = goog.object.get(target_obj_21171,"chrome");
var next_obj_21173 = goog.object.get(next_obj_21172,"runtime");
return next_obj_21173;
})();
var config__13480__auto___21179 = config;
var api_check_fn__13481__auto___21180 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21179);

(api_check_fn__13481__auto___21180.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21180.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onInstalled",ns_obj_21165,"onInstalled") : api_check_fn__13481__auto___21180.call(null,"chrome.runtime.onInstalled",ns_obj_21165,"onInstalled"));

var event_obj__20429__auto__ = (function (){var target_obj_21174 = ns_obj_21165;
var next_obj_21175 = goog.object.get(target_obj_21174,"onInstalled");
return next_obj_21175;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_installed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_installed_STAR_.cljs$lang$applyTo = (function (seq21160){
var G__21161 = cljs.core.first(seq21160);
var seq21160__$1 = cljs.core.next(seq21160);
var G__21162 = cljs.core.first(seq21160__$1);
var seq21160__$2 = cljs.core.next(seq21160__$1);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21161,G__21162,seq21160__$2);
});

chromex.ext.runtime.on_suspend_STAR_ = (function chromex$ext$runtime$on_suspend_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21195 = arguments.length;
var i__8119__auto___21196 = (0);
while(true){
if((i__8119__auto___21196 < len__8118__auto___21195)){
args__8125__auto__.push((arguments[i__8119__auto___21196]));

var G__21197 = (i__8119__auto___21196 + (1));
i__8119__auto___21196 = G__21197;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21184 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21187 = config__13447__auto__;
var G__21188 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend;
var G__21189 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21187,G__21188,G__21189) : handler__13449__auto__.call(null,G__21187,G__21188,G__21189));
})();
var handler_fn_21185 = event_fn_21184;
var logging_fn__20428__auto__ = ((function (event_fn_21184,handler_fn_21185){
return (function (){

return (handler_fn_21185.cljs$core$IFn$_invoke$arity$0 ? handler_fn_21185.cljs$core$IFn$_invoke$arity$0() : handler_fn_21185.call(null));
});})(event_fn_21184,handler_fn_21185))
;
var ns_obj_21186 = (function (){var target_obj_21190 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21191 = goog.object.get(target_obj_21190,"chrome");
var next_obj_21192 = goog.object.get(next_obj_21191,"runtime");
return next_obj_21192;
})();
var config__13480__auto___21198 = config;
var api_check_fn__13481__auto___21199 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21198);

(api_check_fn__13481__auto___21199.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21199.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspend",ns_obj_21186,"onSuspend") : api_check_fn__13481__auto___21199.call(null,"chrome.runtime.onSuspend",ns_obj_21186,"onSuspend"));

var event_obj__20429__auto__ = (function (){var target_obj_21193 = ns_obj_21186;
var next_obj_21194 = goog.object.get(target_obj_21193,"onSuspend");
return next_obj_21194;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_suspend_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_suspend_STAR_.cljs$lang$applyTo = (function (seq21181){
var G__21182 = cljs.core.first(seq21181);
var seq21181__$1 = cljs.core.next(seq21181);
var G__21183 = cljs.core.first(seq21181__$1);
var seq21181__$2 = cljs.core.next(seq21181__$1);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21182,G__21183,seq21181__$2);
});

chromex.ext.runtime.on_suspend_canceled_STAR_ = (function chromex$ext$runtime$on_suspend_canceled_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21214 = arguments.length;
var i__8119__auto___21215 = (0);
while(true){
if((i__8119__auto___21215 < len__8118__auto___21214)){
args__8125__auto__.push((arguments[i__8119__auto___21215]));

var G__21216 = (i__8119__auto___21215 + (1));
i__8119__auto___21215 = G__21216;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21203 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21206 = config__13447__auto__;
var G__21207 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend_DASH_canceled;
var G__21208 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21206,G__21207,G__21208) : handler__13449__auto__.call(null,G__21206,G__21207,G__21208));
})();
var handler_fn_21204 = event_fn_21203;
var logging_fn__20428__auto__ = ((function (event_fn_21203,handler_fn_21204){
return (function (){

return (handler_fn_21204.cljs$core$IFn$_invoke$arity$0 ? handler_fn_21204.cljs$core$IFn$_invoke$arity$0() : handler_fn_21204.call(null));
});})(event_fn_21203,handler_fn_21204))
;
var ns_obj_21205 = (function (){var target_obj_21209 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21210 = goog.object.get(target_obj_21209,"chrome");
var next_obj_21211 = goog.object.get(next_obj_21210,"runtime");
return next_obj_21211;
})();
var config__13480__auto___21217 = config;
var api_check_fn__13481__auto___21218 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21217);

(api_check_fn__13481__auto___21218.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21218.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspendCanceled",ns_obj_21205,"onSuspendCanceled") : api_check_fn__13481__auto___21218.call(null,"chrome.runtime.onSuspendCanceled",ns_obj_21205,"onSuspendCanceled"));

var event_obj__20429__auto__ = (function (){var target_obj_21212 = ns_obj_21205;
var next_obj_21213 = goog.object.get(target_obj_21212,"onSuspendCanceled");
return next_obj_21213;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$applyTo = (function (seq21200){
var G__21201 = cljs.core.first(seq21200);
var seq21200__$1 = cljs.core.next(seq21200);
var G__21202 = cljs.core.first(seq21200__$1);
var seq21200__$2 = cljs.core.next(seq21200__$1);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21201,G__21202,seq21200__$2);
});

chromex.ext.runtime.on_update_available_STAR_ = (function chromex$ext$runtime$on_update_available_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21235 = arguments.length;
var i__8119__auto___21236 = (0);
while(true){
if((i__8119__auto___21236 < len__8118__auto___21235)){
args__8125__auto__.push((arguments[i__8119__auto___21236]));

var G__21237 = (i__8119__auto___21236 + (1));
i__8119__auto___21236 = G__21237;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21222 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21227 = config__13447__auto__;
var G__21228 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_update_DASH_available;
var G__21229 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21227,G__21228,G__21229) : handler__13449__auto__.call(null,G__21227,G__21228,G__21229));
})();
var handler_fn_21223 = ((function (event_fn_21222){
return (function (cb_details_21225){
return (event_fn_21222.cljs$core$IFn$_invoke$arity$1 ? event_fn_21222.cljs$core$IFn$_invoke$arity$1(cb_details_21225) : event_fn_21222.call(null,cb_details_21225));
});})(event_fn_21222))
;
var logging_fn__20428__auto__ = ((function (event_fn_21222,handler_fn_21223){
return (function (cb_param_details_21226){

return handler_fn_21223(cb_param_details_21226);
});})(event_fn_21222,handler_fn_21223))
;
var ns_obj_21224 = (function (){var target_obj_21230 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21231 = goog.object.get(target_obj_21230,"chrome");
var next_obj_21232 = goog.object.get(next_obj_21231,"runtime");
return next_obj_21232;
})();
var config__13480__auto___21238 = config;
var api_check_fn__13481__auto___21239 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21238);

(api_check_fn__13481__auto___21239.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21239.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onUpdateAvailable",ns_obj_21224,"onUpdateAvailable") : api_check_fn__13481__auto___21239.call(null,"chrome.runtime.onUpdateAvailable",ns_obj_21224,"onUpdateAvailable"));

var event_obj__20429__auto__ = (function (){var target_obj_21233 = ns_obj_21224;
var next_obj_21234 = goog.object.get(target_obj_21233,"onUpdateAvailable");
return next_obj_21234;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_update_available_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_update_available_STAR_.cljs$lang$applyTo = (function (seq21219){
var G__21220 = cljs.core.first(seq21219);
var seq21219__$1 = cljs.core.next(seq21219);
var G__21221 = cljs.core.first(seq21219__$1);
var seq21219__$2 = cljs.core.next(seq21219__$1);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21220,G__21221,seq21219__$2);
});

chromex.ext.runtime.on_browser_update_available_STAR_ = (function chromex$ext$runtime$on_browser_update_available_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21254 = arguments.length;
var i__8119__auto___21255 = (0);
while(true){
if((i__8119__auto___21255 < len__8118__auto___21254)){
args__8125__auto__.push((arguments[i__8119__auto___21255]));

var G__21256 = (i__8119__auto___21255 + (1));
i__8119__auto___21255 = G__21256;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21243 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21246 = config__13447__auto__;
var G__21247 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_browser_DASH_update_DASH_available;
var G__21248 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21246,G__21247,G__21248) : handler__13449__auto__.call(null,G__21246,G__21247,G__21248));
})();
var handler_fn_21244 = event_fn_21243;
var logging_fn__20428__auto__ = ((function (event_fn_21243,handler_fn_21244){
return (function (){

return (handler_fn_21244.cljs$core$IFn$_invoke$arity$0 ? handler_fn_21244.cljs$core$IFn$_invoke$arity$0() : handler_fn_21244.call(null));
});})(event_fn_21243,handler_fn_21244))
;
var ns_obj_21245 = (function (){var target_obj_21249 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21250 = goog.object.get(target_obj_21249,"chrome");
var next_obj_21251 = goog.object.get(next_obj_21250,"runtime");
return next_obj_21251;
})();
var config__13480__auto___21257 = config;
var api_check_fn__13481__auto___21258 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21257);

(api_check_fn__13481__auto___21258.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21258.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onBrowserUpdateAvailable",ns_obj_21245,"onBrowserUpdateAvailable") : api_check_fn__13481__auto___21258.call(null,"chrome.runtime.onBrowserUpdateAvailable",ns_obj_21245,"onBrowserUpdateAvailable"));

var event_obj__20429__auto__ = (function (){var target_obj_21252 = ns_obj_21245;
var next_obj_21253 = goog.object.get(target_obj_21252,"onBrowserUpdateAvailable");
return next_obj_21253;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$applyTo = (function (seq21240){
var G__21241 = cljs.core.first(seq21240);
var seq21240__$1 = cljs.core.next(seq21240);
var G__21242 = cljs.core.first(seq21240__$1);
var seq21240__$2 = cljs.core.next(seq21240__$1);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21241,G__21242,seq21240__$2);
});

chromex.ext.runtime.on_connect_STAR_ = (function chromex$ext$runtime$on_connect_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21276 = arguments.length;
var i__8119__auto___21277 = (0);
while(true){
if((i__8119__auto___21277 < len__8118__auto___21276)){
args__8125__auto__.push((arguments[i__8119__auto___21277]));

var G__21278 = (i__8119__auto___21277 + (1));
i__8119__auto___21277 = G__21278;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21262 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21267 = config__13447__auto__;
var G__21268 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect;
var G__21269 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21267,G__21268,G__21269) : handler__13449__auto__.call(null,G__21267,G__21268,G__21269));
})();
var handler_fn_21263 = ((function (event_fn_21262){
return (function (cb_port_21265){
var G__21270 = chromex.marshalling.from_native_chrome_port(config,cb_port_21265);
return (event_fn_21262.cljs$core$IFn$_invoke$arity$1 ? event_fn_21262.cljs$core$IFn$_invoke$arity$1(G__21270) : event_fn_21262.call(null,G__21270));
});})(event_fn_21262))
;
var logging_fn__20428__auto__ = ((function (event_fn_21262,handler_fn_21263){
return (function (cb_param_port_21266){

return handler_fn_21263(cb_param_port_21266);
});})(event_fn_21262,handler_fn_21263))
;
var ns_obj_21264 = (function (){var target_obj_21271 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21272 = goog.object.get(target_obj_21271,"chrome");
var next_obj_21273 = goog.object.get(next_obj_21272,"runtime");
return next_obj_21273;
})();
var config__13480__auto___21279 = config;
var api_check_fn__13481__auto___21280 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21279);

(api_check_fn__13481__auto___21280.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21280.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnect",ns_obj_21264,"onConnect") : api_check_fn__13481__auto___21280.call(null,"chrome.runtime.onConnect",ns_obj_21264,"onConnect"));

var event_obj__20429__auto__ = (function (){var target_obj_21274 = ns_obj_21264;
var next_obj_21275 = goog.object.get(target_obj_21274,"onConnect");
return next_obj_21275;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_connect_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_connect_STAR_.cljs$lang$applyTo = (function (seq21259){
var G__21260 = cljs.core.first(seq21259);
var seq21259__$1 = cljs.core.next(seq21259);
var G__21261 = cljs.core.first(seq21259__$1);
var seq21259__$2 = cljs.core.next(seq21259__$1);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21260,G__21261,seq21259__$2);
});

chromex.ext.runtime.on_connect_external_STAR_ = (function chromex$ext$runtime$on_connect_external_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21298 = arguments.length;
var i__8119__auto___21299 = (0);
while(true){
if((i__8119__auto___21299 < len__8118__auto___21298)){
args__8125__auto__.push((arguments[i__8119__auto___21299]));

var G__21300 = (i__8119__auto___21299 + (1));
i__8119__auto___21299 = G__21300;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21284 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21289 = config__13447__auto__;
var G__21290 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_external;
var G__21291 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21289,G__21290,G__21291) : handler__13449__auto__.call(null,G__21289,G__21290,G__21291));
})();
var handler_fn_21285 = ((function (event_fn_21284){
return (function (cb_port_21287){
var G__21292 = chromex.marshalling.from_native_chrome_port(config,cb_port_21287);
return (event_fn_21284.cljs$core$IFn$_invoke$arity$1 ? event_fn_21284.cljs$core$IFn$_invoke$arity$1(G__21292) : event_fn_21284.call(null,G__21292));
});})(event_fn_21284))
;
var logging_fn__20428__auto__ = ((function (event_fn_21284,handler_fn_21285){
return (function (cb_param_port_21288){

return handler_fn_21285(cb_param_port_21288);
});})(event_fn_21284,handler_fn_21285))
;
var ns_obj_21286 = (function (){var target_obj_21293 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21294 = goog.object.get(target_obj_21293,"chrome");
var next_obj_21295 = goog.object.get(next_obj_21294,"runtime");
return next_obj_21295;
})();
var config__13480__auto___21301 = config;
var api_check_fn__13481__auto___21302 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21301);

(api_check_fn__13481__auto___21302.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21302.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectExternal",ns_obj_21286,"onConnectExternal") : api_check_fn__13481__auto___21302.call(null,"chrome.runtime.onConnectExternal",ns_obj_21286,"onConnectExternal"));

var event_obj__20429__auto__ = (function (){var target_obj_21296 = ns_obj_21286;
var next_obj_21297 = goog.object.get(target_obj_21296,"onConnectExternal");
return next_obj_21297;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$applyTo = (function (seq21281){
var G__21282 = cljs.core.first(seq21281);
var seq21281__$1 = cljs.core.next(seq21281);
var G__21283 = cljs.core.first(seq21281__$1);
var seq21281__$2 = cljs.core.next(seq21281__$1);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21282,G__21283,seq21281__$2);
});

chromex.ext.runtime.on_message_STAR_ = (function chromex$ext$runtime$on_message_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21323 = arguments.length;
var i__8119__auto___21324 = (0);
while(true){
if((i__8119__auto___21324 < len__8118__auto___21323)){
args__8125__auto__.push((arguments[i__8119__auto___21324]));

var G__21325 = (i__8119__auto___21324 + (1));
i__8119__auto___21324 = G__21325;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21306 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21315 = config__13447__auto__;
var G__21316 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message;
var G__21317 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21315,G__21316,G__21317) : handler__13449__auto__.call(null,G__21315,G__21316,G__21317));
})();
var handler_fn_21307 = ((function (event_fn_21306){
return (function (cb_message_21309,cb_sender_21310,cb_send_response_21311){
return (event_fn_21306.cljs$core$IFn$_invoke$arity$3 ? event_fn_21306.cljs$core$IFn$_invoke$arity$3(cb_message_21309,cb_sender_21310,cb_send_response_21311) : event_fn_21306.call(null,cb_message_21309,cb_sender_21310,cb_send_response_21311));
});})(event_fn_21306))
;
var logging_fn__20428__auto__ = ((function (event_fn_21306,handler_fn_21307){
return (function (cb_param_message_21312,cb_param_sender_21313,cb_param_send_response_21314){

return handler_fn_21307(cb_param_message_21312,cb_param_sender_21313,cb_param_send_response_21314);
});})(event_fn_21306,handler_fn_21307))
;
var ns_obj_21308 = (function (){var target_obj_21318 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21319 = goog.object.get(target_obj_21318,"chrome");
var next_obj_21320 = goog.object.get(next_obj_21319,"runtime");
return next_obj_21320;
})();
var config__13480__auto___21326 = config;
var api_check_fn__13481__auto___21327 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21326);

(api_check_fn__13481__auto___21327.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21327.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessage",ns_obj_21308,"onMessage") : api_check_fn__13481__auto___21327.call(null,"chrome.runtime.onMessage",ns_obj_21308,"onMessage"));

var event_obj__20429__auto__ = (function (){var target_obj_21321 = ns_obj_21308;
var next_obj_21322 = goog.object.get(target_obj_21321,"onMessage");
return next_obj_21322;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_message_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_message_STAR_.cljs$lang$applyTo = (function (seq21303){
var G__21304 = cljs.core.first(seq21303);
var seq21303__$1 = cljs.core.next(seq21303);
var G__21305 = cljs.core.first(seq21303__$1);
var seq21303__$2 = cljs.core.next(seq21303__$1);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21304,G__21305,seq21303__$2);
});

chromex.ext.runtime.on_message_external_STAR_ = (function chromex$ext$runtime$on_message_external_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21348 = arguments.length;
var i__8119__auto___21349 = (0);
while(true){
if((i__8119__auto___21349 < len__8118__auto___21348)){
args__8125__auto__.push((arguments[i__8119__auto___21349]));

var G__21350 = (i__8119__auto___21349 + (1));
i__8119__auto___21349 = G__21350;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21331 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21340 = config__13447__auto__;
var G__21341 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message_DASH_external;
var G__21342 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21340,G__21341,G__21342) : handler__13449__auto__.call(null,G__21340,G__21341,G__21342));
})();
var handler_fn_21332 = ((function (event_fn_21331){
return (function (cb_message_21334,cb_sender_21335,cb_send_response_21336){
return (event_fn_21331.cljs$core$IFn$_invoke$arity$3 ? event_fn_21331.cljs$core$IFn$_invoke$arity$3(cb_message_21334,cb_sender_21335,cb_send_response_21336) : event_fn_21331.call(null,cb_message_21334,cb_sender_21335,cb_send_response_21336));
});})(event_fn_21331))
;
var logging_fn__20428__auto__ = ((function (event_fn_21331,handler_fn_21332){
return (function (cb_param_message_21337,cb_param_sender_21338,cb_param_send_response_21339){

return handler_fn_21332(cb_param_message_21337,cb_param_sender_21338,cb_param_send_response_21339);
});})(event_fn_21331,handler_fn_21332))
;
var ns_obj_21333 = (function (){var target_obj_21343 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21344 = goog.object.get(target_obj_21343,"chrome");
var next_obj_21345 = goog.object.get(next_obj_21344,"runtime");
return next_obj_21345;
})();
var config__13480__auto___21351 = config;
var api_check_fn__13481__auto___21352 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21351);

(api_check_fn__13481__auto___21352.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21352.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessageExternal",ns_obj_21333,"onMessageExternal") : api_check_fn__13481__auto___21352.call(null,"chrome.runtime.onMessageExternal",ns_obj_21333,"onMessageExternal"));

var event_obj__20429__auto__ = (function (){var target_obj_21346 = ns_obj_21333;
var next_obj_21347 = goog.object.get(target_obj_21346,"onMessageExternal");
return next_obj_21347;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_message_external_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_message_external_STAR_.cljs$lang$applyTo = (function (seq21328){
var G__21329 = cljs.core.first(seq21328);
var seq21328__$1 = cljs.core.next(seq21328);
var G__21330 = cljs.core.first(seq21328__$1);
var seq21328__$2 = cljs.core.next(seq21328__$1);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21329,G__21330,seq21328__$2);
});

chromex.ext.runtime.on_restart_required_STAR_ = (function chromex$ext$runtime$on_restart_required_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21369 = arguments.length;
var i__8119__auto___21370 = (0);
while(true){
if((i__8119__auto___21370 < len__8118__auto___21369)){
args__8125__auto__.push((arguments[i__8119__auto___21370]));

var G__21371 = (i__8119__auto___21370 + (1));
i__8119__auto___21370 = G__21371;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21356 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21361 = config__13447__auto__;
var G__21362 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_restart_DASH_required;
var G__21363 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21361,G__21362,G__21363) : handler__13449__auto__.call(null,G__21361,G__21362,G__21363));
})();
var handler_fn_21357 = ((function (event_fn_21356){
return (function (cb_reason_21359){
return (event_fn_21356.cljs$core$IFn$_invoke$arity$1 ? event_fn_21356.cljs$core$IFn$_invoke$arity$1(cb_reason_21359) : event_fn_21356.call(null,cb_reason_21359));
});})(event_fn_21356))
;
var logging_fn__20428__auto__ = ((function (event_fn_21356,handler_fn_21357){
return (function (cb_param_reason_21360){

return handler_fn_21357(cb_param_reason_21360);
});})(event_fn_21356,handler_fn_21357))
;
var ns_obj_21358 = (function (){var target_obj_21364 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21365 = goog.object.get(target_obj_21364,"chrome");
var next_obj_21366 = goog.object.get(next_obj_21365,"runtime");
return next_obj_21366;
})();
var config__13480__auto___21372 = config;
var api_check_fn__13481__auto___21373 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21372);

(api_check_fn__13481__auto___21373.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21373.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onRestartRequired",ns_obj_21358,"onRestartRequired") : api_check_fn__13481__auto___21373.call(null,"chrome.runtime.onRestartRequired",ns_obj_21358,"onRestartRequired"));

var event_obj__20429__auto__ = (function (){var target_obj_21367 = ns_obj_21358;
var next_obj_21368 = goog.object.get(target_obj_21367,"onRestartRequired");
return next_obj_21368;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$applyTo = (function (seq21353){
var G__21354 = cljs.core.first(seq21353);
var seq21353__$1 = cljs.core.next(seq21353);
var G__21355 = cljs.core.first(seq21353__$1);
var seq21353__$2 = cljs.core.next(seq21353__$1);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21354,G__21355,seq21353__$2);
});


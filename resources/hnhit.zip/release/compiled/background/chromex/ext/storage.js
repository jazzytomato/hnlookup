// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.storage');
goog.require('cljs.core');
goog.require('chromex.core');
chromex.ext.storage.sync_STAR_ = (function chromex$ext$storage$sync_STAR_(config){
var result_21429 = (function (){var final_args_array_21430 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.storage.sync");
var ns_21431 = (function (){var target_obj_21433 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21434 = goog.object.get(target_obj_21433,"chrome");
var next_obj_21435 = goog.object.get(next_obj_21434,"storage");
return next_obj_21435;
})();


var target_21432 = (function (){var target_obj_21436 = ns_21431;
var next_obj_21437 = goog.object.get(target_obj_21436,"sync");
if(!((next_obj_21437 == null))){
return next_obj_21437;
} else {
return null;
}
})();
return target_21432;
})();
return chromex.marshalling.from_native_chrome_storage_area(config,result_21429);
});
chromex.ext.storage.local_STAR_ = (function chromex$ext$storage$local_STAR_(config){
var result_21447 = (function (){var final_args_array_21448 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.storage.local");
var ns_21449 = (function (){var target_obj_21451 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21452 = goog.object.get(target_obj_21451,"chrome");
var next_obj_21453 = goog.object.get(next_obj_21452,"storage");
return next_obj_21453;
})();


var target_21450 = (function (){var target_obj_21454 = ns_21449;
var next_obj_21455 = goog.object.get(target_obj_21454,"local");
if(!((next_obj_21455 == null))){
return next_obj_21455;
} else {
return null;
}
})();
return target_21450;
})();
return chromex.marshalling.from_native_chrome_storage_area(config,result_21447);
});
chromex.ext.storage.managed_STAR_ = (function chromex$ext$storage$managed_STAR_(config){
var result_21465 = (function (){var final_args_array_21466 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.storage.managed");
var ns_21467 = (function (){var target_obj_21469 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21470 = goog.object.get(target_obj_21469,"chrome");
var next_obj_21471 = goog.object.get(next_obj_21470,"storage");
return next_obj_21471;
})();


var target_21468 = (function (){var target_obj_21472 = ns_21467;
var next_obj_21473 = goog.object.get(target_obj_21472,"managed");
if(!((next_obj_21473 == null))){
return next_obj_21473;
} else {
return null;
}
})();
return target_21468;
})();
return chromex.marshalling.from_native_chrome_storage_area(config,result_21465);
});
chromex.ext.storage.on_changed_STAR_ = (function chromex$ext$storage$on_changed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___21492 = arguments.length;
var i__8119__auto___21493 = (0);
while(true){
if((i__8119__auto___21493 < len__8118__auto___21492)){
args__8125__auto__.push((arguments[i__8119__auto___21493]));

var G__21494 = (i__8119__auto___21493 + (1));
i__8119__auto___21493 = G__21494;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.storage.on_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.storage.on_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_21477 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__21484 = config__13447__auto__;
var G__21485 = cljs.core.cst$kw$chromex$ext$storage_SLASH_on_DASH_changed;
var G__21486 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__21484,G__21485,G__21486) : handler__13449__auto__.call(null,G__21484,G__21485,G__21486));
})();
var handler_fn_21478 = ((function (event_fn_21477){
return (function (cb_changes_21480,cb_area_name_21481){
return (event_fn_21477.cljs$core$IFn$_invoke$arity$2 ? event_fn_21477.cljs$core$IFn$_invoke$arity$2(cb_changes_21480,cb_area_name_21481) : event_fn_21477.call(null,cb_changes_21480,cb_area_name_21481));
});})(event_fn_21477))
;
var logging_fn__20428__auto__ = ((function (event_fn_21477,handler_fn_21478){
return (function (cb_param_changes_21482,cb_param_area_name_21483){

return handler_fn_21478(cb_param_changes_21482,cb_param_area_name_21483);
});})(event_fn_21477,handler_fn_21478))
;
var ns_obj_21479 = (function (){var target_obj_21487 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_21488 = goog.object.get(target_obj_21487,"chrome");
var next_obj_21489 = goog.object.get(next_obj_21488,"storage");
return next_obj_21489;
})();
var config__13480__auto___21495 = config;
var api_check_fn__13481__auto___21496 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___21495);

(api_check_fn__13481__auto___21496.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___21496.cljs$core$IFn$_invoke$arity$3("chrome.storage.onChanged",ns_obj_21479,"onChanged") : api_check_fn__13481__auto___21496.call(null,"chrome.storage.onChanged",ns_obj_21479,"onChanged"));

var event_obj__20429__auto__ = (function (){var target_obj_21490 = ns_obj_21479;
var next_obj_21491 = goog.object.get(target_obj_21490,"onChanged");
return next_obj_21491;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.storage.on_changed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.storage.on_changed_STAR_.cljs$lang$applyTo = (function (seq21474){
var G__21475 = cljs.core.first(seq21474);
var seq21474__$1 = cljs.core.next(seq21474);
var G__21476 = cljs.core.first(seq21474__$1);
var seq21474__$2 = cljs.core.next(seq21474__$1);
return chromex.ext.storage.on_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__21475,G__21476,seq21474__$2);
});


// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.marshalling');
goog.require('cljs.core');
goog.require('chromex.protocols');
goog.require('chromex.config');
goog.require('chromex.chrome_port');
goog.require('chromex.chrome_storage_area');
chromex.marshalling.from_native_chrome_port = (function chromex$marshalling$from_native_chrome_port(config,native_chrome_port){
return chromex.chrome_port.make_chrome_port(config,native_chrome_port);
});
chromex.marshalling.to_native_chrome_port = (function chromex$marshalling$to_native_chrome_port(_config,chrome_port){

return chromex.protocols.get_native_port(chrome_port);
});
chromex.marshalling.from_native_chrome_storage_area = (function chromex$marshalling$from_native_chrome_storage_area(config,native_chrome_storage_area){
return chromex.chrome_storage_area.make_chrome_storage_area(config,native_chrome_storage_area);
});
chromex.marshalling.to_native_chrome_storage_area = (function chromex$marshalling$to_native_chrome_storage_area(_config,chrome_storage_area){

return chromex.protocols.get_native_storage_area(chrome_storage_area);
});

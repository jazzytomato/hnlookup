// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('hnhit.background');
goog.require('cljs.core');
goog.require('hnhit.background.core');

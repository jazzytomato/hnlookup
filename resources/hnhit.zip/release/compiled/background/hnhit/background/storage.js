// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('hnhit.background.storage');
goog.require('cljs.core');
goog.require('cljs.core.async');
goog.require('chromex.logging');
goog.require('chromex.protocols');
goog.require('chromex.ext.storage');
hnhit.background.storage.test_storage_BANG_ = (function hnhit$background$storage$test_storage_BANG_(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
chromex.protocols.set(local_storage,({"key1": "string", "key2": [(1),(2),(3)], "key3": true, "key4": null}));

var c__15224__auto___21764 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___21764,local_storage){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___21764,local_storage){
return (function (state_21681){
var state_val_21682 = (state_21681[(1)]);
if((state_val_21682 === (1))){
var inst_21668 = chromex.protocols.get.cljs$core$IFn$_invoke$arity$1(local_storage);
var state_21681__$1 = state_21681;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_21681__$1,(2),inst_21668);
} else {
if((state_val_21682 === (2))){
var inst_21673 = (state_21681[(7)]);
var inst_21670 = (state_21681[(2)]);
var inst_21671 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_21670,(0),null);
var inst_21672 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_21671,(0),null);
var inst_21673__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_21670,(1),null);
var state_21681__$1 = (function (){var statearr_21683 = state_21681;
(statearr_21683[(8)] = inst_21672);

(statearr_21683[(7)] = inst_21673__$1);

return statearr_21683;
})();
if(cljs.core.truth_(inst_21673__$1)){
var statearr_21684_21765 = state_21681__$1;
(statearr_21684_21765[(1)] = (3));

} else {
var statearr_21685_21766 = state_21681__$1;
(statearr_21685_21766[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21682 === (3))){
var inst_21673 = (state_21681[(7)]);
var inst_21675 = (inst_21673.cljs$core$IFn$_invoke$arity$2 ? inst_21673.cljs$core$IFn$_invoke$arity$2("fetch all error:",inst_21673) : inst_21673.call(null,"fetch all error:",inst_21673));
var state_21681__$1 = state_21681;
var statearr_21686_21767 = state_21681__$1;
(statearr_21686_21767[(2)] = inst_21675);

(statearr_21686_21767[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21682 === (4))){
var inst_21672 = (state_21681[(8)]);
var inst_21677 = console.log("fetch all:",inst_21672);
var state_21681__$1 = (function (){var statearr_21687 = state_21681;
(statearr_21687[(9)] = inst_21677);

return statearr_21687;
})();
var statearr_21688_21768 = state_21681__$1;
(statearr_21688_21768[(2)] = null);

(statearr_21688_21768[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21682 === (5))){
var inst_21679 = (state_21681[(2)]);
var state_21681__$1 = state_21681;
return cljs.core.async.impl.ioc_helpers.return_chan(state_21681__$1,inst_21679);
} else {
return null;
}
}
}
}
}
});})(c__15224__auto___21764,local_storage))
;
return ((function (switch__15098__auto__,c__15224__auto___21764,local_storage){
return (function() {
var hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__ = null;
var hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____0 = (function (){
var statearr_21692 = [null,null,null,null,null,null,null,null,null,null];
(statearr_21692[(0)] = hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__);

(statearr_21692[(1)] = (1));

return statearr_21692;
});
var hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____1 = (function (state_21681){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_21681);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e21693){if((e21693 instanceof Object)){
var ex__15102__auto__ = e21693;
var statearr_21694_21769 = state_21681;
(statearr_21694_21769[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_21681);

return cljs.core.cst$kw$recur;
} else {
throw e21693;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__21770 = state_21681;
state_21681 = G__21770;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__ = function(state_21681){
switch(arguments.length){
case 0:
return hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____0.call(this);
case 1:
return hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____1.call(this,state_21681);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____0;
hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____1;
return hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___21764,local_storage))
})();
var state__15226__auto__ = (function (){var statearr_21695 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_21695[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___21764);

return statearr_21695;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___21764,local_storage))
);


var c__15224__auto___21771 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___21771,local_storage){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___21771,local_storage){
return (function (state_21715){
var state_val_21716 = (state_21715[(1)]);
if((state_val_21716 === (1))){
var inst_21702 = chromex.protocols.get.cljs$core$IFn$_invoke$arity$2(local_storage,"key1");
var state_21715__$1 = state_21715;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_21715__$1,(2),inst_21702);
} else {
if((state_val_21716 === (2))){
var inst_21707 = (state_21715[(7)]);
var inst_21704 = (state_21715[(2)]);
var inst_21705 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_21704,(0),null);
var inst_21706 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_21705,(0),null);
var inst_21707__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_21704,(1),null);
var state_21715__$1 = (function (){var statearr_21717 = state_21715;
(statearr_21717[(8)] = inst_21706);

(statearr_21717[(7)] = inst_21707__$1);

return statearr_21717;
})();
if(cljs.core.truth_(inst_21707__$1)){
var statearr_21718_21772 = state_21715__$1;
(statearr_21718_21772[(1)] = (3));

} else {
var statearr_21719_21773 = state_21715__$1;
(statearr_21719_21773[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21716 === (3))){
var inst_21707 = (state_21715[(7)]);
var inst_21709 = (inst_21707.cljs$core$IFn$_invoke$arity$2 ? inst_21707.cljs$core$IFn$_invoke$arity$2("fetch key1 error:",inst_21707) : inst_21707.call(null,"fetch key1 error:",inst_21707));
var state_21715__$1 = state_21715;
var statearr_21720_21774 = state_21715__$1;
(statearr_21720_21774[(2)] = inst_21709);

(statearr_21720_21774[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21716 === (4))){
var inst_21706 = (state_21715[(8)]);
var inst_21711 = console.log("fetch key1:",inst_21706);
var state_21715__$1 = (function (){var statearr_21721 = state_21715;
(statearr_21721[(9)] = inst_21711);

return statearr_21721;
})();
var statearr_21722_21775 = state_21715__$1;
(statearr_21722_21775[(2)] = null);

(statearr_21722_21775[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21716 === (5))){
var inst_21713 = (state_21715[(2)]);
var state_21715__$1 = state_21715;
return cljs.core.async.impl.ioc_helpers.return_chan(state_21715__$1,inst_21713);
} else {
return null;
}
}
}
}
}
});})(c__15224__auto___21771,local_storage))
;
return ((function (switch__15098__auto__,c__15224__auto___21771,local_storage){
return (function() {
var hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__ = null;
var hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____0 = (function (){
var statearr_21726 = [null,null,null,null,null,null,null,null,null,null];
(statearr_21726[(0)] = hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__);

(statearr_21726[(1)] = (1));

return statearr_21726;
});
var hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____1 = (function (state_21715){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_21715);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e21727){if((e21727 instanceof Object)){
var ex__15102__auto__ = e21727;
var statearr_21728_21776 = state_21715;
(statearr_21728_21776[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_21715);

return cljs.core.cst$kw$recur;
} else {
throw e21727;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__21777 = state_21715;
state_21715 = G__21777;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__ = function(state_21715){
switch(arguments.length){
case 0:
return hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____0.call(this);
case 1:
return hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____1.call(this,state_21715);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____0;
hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____1;
return hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___21771,local_storage))
})();
var state__15226__auto__ = (function (){var statearr_21729 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_21729[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___21771);

return statearr_21729;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___21771,local_storage))
);


var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__,local_storage){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__,local_storage){
return (function (state_21749){
var state_val_21750 = (state_21749[(1)]);
if((state_val_21750 === (1))){
var inst_21736 = chromex.protocols.get.cljs$core$IFn$_invoke$arity$2(local_storage,["key2","key3"]);
var state_21749__$1 = state_21749;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_21749__$1,(2),inst_21736);
} else {
if((state_val_21750 === (2))){
var inst_21741 = (state_21749[(7)]);
var inst_21738 = (state_21749[(2)]);
var inst_21739 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_21738,(0),null);
var inst_21740 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_21739,(0),null);
var inst_21741__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_21738,(1),null);
var state_21749__$1 = (function (){var statearr_21751 = state_21749;
(statearr_21751[(7)] = inst_21741__$1);

(statearr_21751[(8)] = inst_21740);

return statearr_21751;
})();
if(cljs.core.truth_(inst_21741__$1)){
var statearr_21752_21778 = state_21749__$1;
(statearr_21752_21778[(1)] = (3));

} else {
var statearr_21753_21779 = state_21749__$1;
(statearr_21753_21779[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_21750 === (3))){
var inst_21741 = (state_21749[(7)]);
var inst_21743 = (inst_21741.cljs$core$IFn$_invoke$arity$2 ? inst_21741.cljs$core$IFn$_invoke$arity$2("fetch key2 and key3 error:",inst_21741) : inst_21741.call(null,"fetch key2 and key3 error:",inst_21741));
var state_21749__$1 = state_21749;
var statearr_21754_21780 = state_21749__$1;
(statearr_21754_21780[(2)] = inst_21743);

(statearr_21754_21780[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21750 === (4))){
var inst_21740 = (state_21749[(8)]);
var inst_21745 = console.log("fetch key2 and key3:",inst_21740);
var state_21749__$1 = (function (){var statearr_21755 = state_21749;
(statearr_21755[(9)] = inst_21745);

return statearr_21755;
})();
var statearr_21756_21781 = state_21749__$1;
(statearr_21756_21781[(2)] = null);

(statearr_21756_21781[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_21750 === (5))){
var inst_21747 = (state_21749[(2)]);
var state_21749__$1 = state_21749;
return cljs.core.async.impl.ioc_helpers.return_chan(state_21749__$1,inst_21747);
} else {
return null;
}
}
}
}
}
});})(c__15224__auto__,local_storage))
;
return ((function (switch__15098__auto__,c__15224__auto__,local_storage){
return (function() {
var hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__ = null;
var hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____0 = (function (){
var statearr_21760 = [null,null,null,null,null,null,null,null,null,null];
(statearr_21760[(0)] = hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__);

(statearr_21760[(1)] = (1));

return statearr_21760;
});
var hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____1 = (function (state_21749){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_21749);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e21761){if((e21761 instanceof Object)){
var ex__15102__auto__ = e21761;
var statearr_21762_21782 = state_21749;
(statearr_21762_21782[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_21749);

return cljs.core.cst$kw$recur;
} else {
throw e21761;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__21783 = state_21749;
state_21749 = G__21783;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__ = function(state_21749){
switch(arguments.length){
case 0:
return hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____0.call(this);
case 1:
return hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____1.call(this,state_21749);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____0;
hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto____1;
return hnhit$background$storage$test_storage_BANG__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__,local_storage))
})();
var state__15226__auto__ = (function (){var statearr_21763 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_21763[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_21763;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__,local_storage))
);

return c__15224__auto__;
});

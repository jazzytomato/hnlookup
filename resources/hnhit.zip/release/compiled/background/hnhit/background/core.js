// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('hnhit.background.core');
goog.require('cljs.core');
goog.require('chromex.ext.runtime');
goog.require('chromex.protocols');
goog.require('goog.string');
goog.require('chromex.chrome_event_channel');
goog.require('chromex.logging');
goog.require('chromex.ext.tabs');
goog.require('cljs.core.async');
goog.require('goog.string.format');
goog.require('hnhit.background.storage');
hnhit.background.core.clients = (function (){var G__23274 = cljs.core.PersistentVector.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__23274) : cljs.core.atom.call(null,G__23274));
})();
hnhit.background.core.add_client_BANG_ = (function hnhit$background$core$add_client_BANG_(client){
console.log("BACKGROUND: client connected",chromex.protocols.get_sender(client));


return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(hnhit.background.core.clients,cljs.core.conj,client);
});
hnhit.background.core.remove_client_BANG_ = (function hnhit$background$core$remove_client_BANG_(client){
console.log("BACKGROUND: client disconnected",chromex.protocols.get_sender(client));


var remove_item = (function (coll,item){
return cljs.core.remove.cljs$core$IFn$_invoke$arity$2((function (p1__23275_SHARP_){
return (item === p1__23275_SHARP_);
}),coll);
});
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(hnhit.background.core.clients,remove_item,client);
});
hnhit.background.core.run_client_message_loop_BANG_ = (function hnhit$background$core$run_client_message_loop_BANG_(client){
var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_23322){
var state_val_23323 = (state_23322[(1)]);
if((state_val_23323 === (1))){
var state_23322__$1 = state_23322;
var statearr_23324_23340 = state_23322__$1;
(statearr_23324_23340[(2)] = null);

(statearr_23324_23340[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23323 === (2))){
var state_23322__$1 = state_23322;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_23322__$1,(4),client);
} else {
if((state_val_23323 === (3))){
var inst_23320 = (state_23322[(2)]);
var state_23322__$1 = state_23322;
return cljs.core.async.impl.ioc_helpers.return_chan(state_23322__$1,inst_23320);
} else {
if((state_val_23323 === (4))){
var inst_23310 = (state_23322[(7)]);
var inst_23310__$1 = (state_23322[(2)]);
var state_23322__$1 = (function (){var statearr_23325 = state_23322;
(statearr_23325[(7)] = inst_23310__$1);

return statearr_23325;
})();
if(cljs.core.truth_(inst_23310__$1)){
var statearr_23326_23341 = state_23322__$1;
(statearr_23326_23341[(1)] = (5));

} else {
var statearr_23327_23342 = state_23322__$1;
(statearr_23327_23342[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23323 === (5))){
var inst_23310 = (state_23322[(7)]);
var inst_23312 = chromex.protocols.get_sender(client);
var inst_23313 = console.log("BACKGROUND: got client message:",inst_23310,"from",inst_23312);
var state_23322__$1 = (function (){var statearr_23328 = state_23322;
(statearr_23328[(8)] = inst_23313);

return statearr_23328;
})();
var statearr_23329_23343 = state_23322__$1;
(statearr_23329_23343[(2)] = null);

(statearr_23329_23343[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23323 === (6))){
var state_23322__$1 = state_23322;
var statearr_23330_23344 = state_23322__$1;
(statearr_23330_23344[(2)] = null);

(statearr_23330_23344[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23323 === (7))){
var inst_23317 = (state_23322[(2)]);
var inst_23318 = hnhit.background.core.remove_client_BANG_(client);
var state_23322__$1 = (function (){var statearr_23331 = state_23322;
(statearr_23331[(9)] = inst_23317);

return statearr_23331;
})();
var statearr_23332_23345 = state_23322__$1;
(statearr_23332_23345[(2)] = inst_23318);

(statearr_23332_23345[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto__ = null;
var hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto____0 = (function (){
var statearr_23336 = [null,null,null,null,null,null,null,null,null,null];
(statearr_23336[(0)] = hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto__);

(statearr_23336[(1)] = (1));

return statearr_23336;
});
var hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto____1 = (function (state_23322){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_23322);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e23337){if((e23337 instanceof Object)){
var ex__15102__auto__ = e23337;
var statearr_23338_23346 = state_23322;
(statearr_23338_23346[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_23322);

return cljs.core.cst$kw$recur;
} else {
throw e23337;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__23347 = state_23322;
state_23322 = G__23347;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto__ = function(state_23322){
switch(arguments.length){
case 0:
return hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto____0.call(this);
case 1:
return hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto____1.call(this,state_23322);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto____0;
hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto____1;
return hnhit$background$core$run_client_message_loop_BANG__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_23339 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_23339[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_23339;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});
hnhit.background.core.handle_client_connection_BANG_ = (function hnhit$background$core$handle_client_connection_BANG_(client){
hnhit.background.core.add_client_BANG_(client);

chromex.protocols.post_message_BANG_(client,"hello from BACKGROUND PAGE!");

return hnhit.background.core.run_client_message_loop_BANG_(client);
});
hnhit.background.core.tell_clients_about_new_tab_BANG_ = (function hnhit$background$core$tell_clients_about_new_tab_BANG_(){
var seq__23352 = cljs.core.seq((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(hnhit.background.core.clients) : cljs.core.deref.call(null,hnhit.background.core.clients)));
var chunk__23353 = null;
var count__23354 = (0);
var i__23355 = (0);
while(true){
if((i__23355 < count__23354)){
var client = chunk__23353.cljs$core$IIndexed$_nth$arity$2(null,i__23355);
chromex.protocols.post_message_BANG_(client,"a new tab was created");

var G__23356 = seq__23352;
var G__23357 = chunk__23353;
var G__23358 = count__23354;
var G__23359 = (i__23355 + (1));
seq__23352 = G__23356;
chunk__23353 = G__23357;
count__23354 = G__23358;
i__23355 = G__23359;
continue;
} else {
var temp__6728__auto__ = cljs.core.seq(seq__23352);
if(temp__6728__auto__){
var seq__23352__$1 = temp__6728__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__23352__$1)){
var c__7842__auto__ = cljs.core.chunk_first(seq__23352__$1);
var G__23360 = cljs.core.chunk_rest(seq__23352__$1);
var G__23361 = c__7842__auto__;
var G__23362 = cljs.core.count(c__7842__auto__);
var G__23363 = (0);
seq__23352 = G__23360;
chunk__23353 = G__23361;
count__23354 = G__23362;
i__23355 = G__23363;
continue;
} else {
var client = cljs.core.first(seq__23352__$1);
chromex.protocols.post_message_BANG_(client,"a new tab was created");

var G__23364 = cljs.core.next(seq__23352__$1);
var G__23365 = null;
var G__23366 = (0);
var G__23367 = (0);
seq__23352 = G__23364;
chunk__23353 = G__23365;
count__23354 = G__23366;
i__23355 = G__23367;
continue;
}
} else {
return null;
}
}
break;
}
});
hnhit.background.core.process_chrome_event = (function hnhit$background$core$process_chrome_event(event_num,event){
console.log(goog.string.format("BACKGROUND: got chrome event (%05d)",event_num),event);


var vec__23372 = event;
var event_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__23372,(0),null);
var event_args = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__23372,(1),null);
var G__23375 = (((event_id instanceof cljs.core.Keyword))?event_id.fqn:null);
switch (G__23375) {
case "chromex.ext.runtime/on-connect":
return cljs.core.apply.cljs$core$IFn$_invoke$arity$2(hnhit.background.core.handle_client_connection_BANG_,event_args);

break;
case "chromex.ext.tabs/on-created":
return hnhit.background.core.tell_clients_about_new_tab_BANG_();

break;
default:
return null;

}
});
hnhit.background.core.run_chrome_event_loop_BANG_ = (function hnhit$background$core$run_chrome_event_loop_BANG_(chrome_event_channel){
console.log("BACKGROUND: starting main event loop...");


var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_23426){
var state_val_23427 = (state_23426[(1)]);
if((state_val_23427 === (1))){
var inst_23411 = (1);
var state_23426__$1 = (function (){var statearr_23428 = state_23426;
(statearr_23428[(7)] = inst_23411);

return statearr_23428;
})();
var statearr_23429_23445 = state_23426__$1;
(statearr_23429_23445[(2)] = null);

(statearr_23429_23445[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23427 === (2))){
var state_23426__$1 = state_23426;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_23426__$1,(4),chrome_event_channel);
} else {
if((state_val_23427 === (3))){
var inst_23424 = (state_23426[(2)]);
var state_23426__$1 = state_23426;
return cljs.core.async.impl.ioc_helpers.return_chan(state_23426__$1,inst_23424);
} else {
if((state_val_23427 === (4))){
var inst_23414 = (state_23426[(8)]);
var inst_23414__$1 = (state_23426[(2)]);
var state_23426__$1 = (function (){var statearr_23430 = state_23426;
(statearr_23430[(8)] = inst_23414__$1);

return statearr_23430;
})();
if(cljs.core.truth_(inst_23414__$1)){
var statearr_23431_23446 = state_23426__$1;
(statearr_23431_23446[(1)] = (5));

} else {
var statearr_23432_23447 = state_23426__$1;
(statearr_23432_23447[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23427 === (5))){
var inst_23411 = (state_23426[(7)]);
var inst_23414 = (state_23426[(8)]);
var inst_23416 = hnhit.background.core.process_chrome_event(inst_23411,inst_23414);
var inst_23417 = (inst_23411 + (1));
var inst_23411__$1 = inst_23417;
var state_23426__$1 = (function (){var statearr_23433 = state_23426;
(statearr_23433[(7)] = inst_23411__$1);

(statearr_23433[(9)] = inst_23416);

return statearr_23433;
})();
var statearr_23434_23448 = state_23426__$1;
(statearr_23434_23448[(2)] = null);

(statearr_23434_23448[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23427 === (6))){
var state_23426__$1 = state_23426;
var statearr_23435_23449 = state_23426__$1;
(statearr_23435_23449[(2)] = null);

(statearr_23435_23449[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23427 === (7))){
var inst_23421 = (state_23426[(2)]);
var inst_23422 = console.log("BACKGROUND: leaving main event loop");
var state_23426__$1 = (function (){var statearr_23436 = state_23426;
(statearr_23436[(10)] = inst_23421);

(statearr_23436[(11)] = inst_23422);

return statearr_23436;
})();
var statearr_23437_23450 = state_23426__$1;
(statearr_23437_23450[(2)] = null);

(statearr_23437_23450[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto__ = null;
var hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto____0 = (function (){
var statearr_23441 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_23441[(0)] = hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto__);

(statearr_23441[(1)] = (1));

return statearr_23441;
});
var hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto____1 = (function (state_23426){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_23426);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e23442){if((e23442 instanceof Object)){
var ex__15102__auto__ = e23442;
var statearr_23443_23451 = state_23426;
(statearr_23443_23451[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_23426);

return cljs.core.cst$kw$recur;
} else {
throw e23442;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__23452 = state_23426;
state_23426 = G__23452;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto__ = function(state_23426){
switch(arguments.length){
case 0:
return hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto____0.call(this);
case 1:
return hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto____1.call(this,state_23426);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto____0;
hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto____1;
return hnhit$background$core$run_chrome_event_loop_BANG__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_23444 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_23444[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_23444;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});
hnhit.background.core.boot_chrome_event_loop_BANG_ = (function hnhit$background$core$boot_chrome_event_loop_BANG_(){
var chrome_event_channel = chromex.chrome_event_channel.make_chrome_event_channel(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0());
var chan23457_23461 = chrome_event_channel;
var config23458_23462 = chromex.config.get_active_config();
chromex.ext.tabs.on_created_STAR_(config23458_23462,chan23457_23461);

chromex.ext.tabs.on_updated_STAR_(config23458_23462,chan23457_23461);

chromex.ext.tabs.on_moved_STAR_(config23458_23462,chan23457_23461);

chromex.ext.tabs.on_activated_STAR_(config23458_23462,chan23457_23461);

chromex.ext.tabs.on_highlighted_STAR_(config23458_23462,chan23457_23461);

chromex.ext.tabs.on_detached_STAR_(config23458_23462,chan23457_23461);

chromex.ext.tabs.on_attached_STAR_(config23458_23462,chan23457_23461);

chromex.ext.tabs.on_removed_STAR_(config23458_23462,chan23457_23461);

chromex.ext.tabs.on_replaced_STAR_(config23458_23462,chan23457_23461);

chromex.ext.tabs.on_zoom_change_STAR_(config23458_23462,chan23457_23461);

var chan23459_23463 = chrome_event_channel;
var config23460_23464 = chromex.config.get_active_config();
chromex.ext.runtime.on_startup_STAR_(config23460_23464,chan23459_23463);

chromex.ext.runtime.on_installed_STAR_(config23460_23464,chan23459_23463);

chromex.ext.runtime.on_suspend_STAR_(config23460_23464,chan23459_23463);

chromex.ext.runtime.on_suspend_canceled_STAR_(config23460_23464,chan23459_23463);

chromex.ext.runtime.on_update_available_STAR_(config23460_23464,chan23459_23463);

chromex.ext.runtime.on_connect_STAR_(config23460_23464,chan23459_23463);

chromex.ext.runtime.on_connect_external_STAR_(config23460_23464,chan23459_23463);

chromex.ext.runtime.on_message_STAR_(config23460_23464,chan23459_23463);

chromex.ext.runtime.on_message_external_STAR_(config23460_23464,chan23459_23463);

chromex.ext.runtime.on_restart_required_STAR_(config23460_23464,chan23459_23463);

return hnhit.background.core.run_chrome_event_loop_BANG_(chrome_event_channel);
});
hnhit.background.core.init_BANG_ = (function hnhit$background$core$init_BANG_(){
console.log("BACKGROUND: init");


hnhit.background.storage.test_storage_BANG_();

return hnhit.background.core.boot_chrome_event_loop_BANG_();
});

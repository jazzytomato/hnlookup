// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('hnhit.content_script.core');
goog.require('cljs.core');
goog.require('cljs.core.async');
goog.require('cljs_http.client');
goog.require('chromex.logging');
goog.require('chromex.protocols');
goog.require('chromex.ext.runtime');
hnhit.content_script.core.process_message_BANG_ = (function hnhit$content_script$core$process_message_BANG_(message){
console.log("CONTENT SCRIPT: got message:",message);

return null;
});
hnhit.content_script.core.run_message_loop_BANG_ = (function hnhit$content_script$core$run_message_loop_BANG_(message_channel){
console.log("CONTENT SCRIPT: starting message loop...");


var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_48338){
var state_val_48339 = (state_48338[(1)]);
if((state_val_48339 === (1))){
var state_48338__$1 = state_48338;
var statearr_48340_48356 = state_48338__$1;
(statearr_48340_48356[(2)] = null);

(statearr_48340_48356[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_48339 === (2))){
var state_48338__$1 = state_48338;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_48338__$1,(4),message_channel);
} else {
if((state_val_48339 === (3))){
var inst_48336 = (state_48338[(2)]);
var state_48338__$1 = state_48338;
return cljs.core.async.impl.ioc_helpers.return_chan(state_48338__$1,inst_48336);
} else {
if((state_val_48339 === (4))){
var inst_48327 = (state_48338[(7)]);
var inst_48327__$1 = (state_48338[(2)]);
var state_48338__$1 = (function (){var statearr_48341 = state_48338;
(statearr_48341[(7)] = inst_48327__$1);

return statearr_48341;
})();
if(cljs.core.truth_(inst_48327__$1)){
var statearr_48342_48357 = state_48338__$1;
(statearr_48342_48357[(1)] = (5));

} else {
var statearr_48343_48358 = state_48338__$1;
(statearr_48343_48358[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_48339 === (5))){
var inst_48327 = (state_48338[(7)]);
var inst_48329 = hnhit.content_script.core.process_message_BANG_(inst_48327);
var state_48338__$1 = (function (){var statearr_48344 = state_48338;
(statearr_48344[(8)] = inst_48329);

return statearr_48344;
})();
var statearr_48345_48359 = state_48338__$1;
(statearr_48345_48359[(2)] = null);

(statearr_48345_48359[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_48339 === (6))){
var state_48338__$1 = state_48338;
var statearr_48346_48360 = state_48338__$1;
(statearr_48346_48360[(2)] = null);

(statearr_48346_48360[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_48339 === (7))){
var inst_48333 = (state_48338[(2)]);
var inst_48334 = console.log("CONTENT SCRIPT: leaving message loop");
var state_48338__$1 = (function (){var statearr_48347 = state_48338;
(statearr_48347[(9)] = inst_48334);

(statearr_48347[(10)] = inst_48333);

return statearr_48347;
})();
var statearr_48348_48361 = state_48338__$1;
(statearr_48348_48361[(2)] = null);

(statearr_48348_48361[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto__ = null;
var hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto____0 = (function (){
var statearr_48352 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_48352[(0)] = hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto__);

(statearr_48352[(1)] = (1));

return statearr_48352;
});
var hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto____1 = (function (state_48338){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_48338);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e48353){if((e48353 instanceof Object)){
var ex__15102__auto__ = e48353;
var statearr_48354_48362 = state_48338;
(statearr_48354_48362[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_48338);

return cljs.core.cst$kw$recur;
} else {
throw e48353;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__48363 = state_48338;
state_48338 = G__48363;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto__ = function(state_48338){
switch(arguments.length){
case 0:
return hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto____0.call(this);
case 1:
return hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto____1.call(this,state_48338);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto____0;
hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto____1;
return hnhit$content_script$core$run_message_loop_BANG__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_48355 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_48355[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_48355;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});
hnhit.content_script.core.do_page_analysis_BANG_ = (function hnhit$content_script$core$do_page_analysis_BANG_(background_port){
var script_elements = document.getElementsByTagName("script");
var script_count = script_elements.length;
var title = document.title;
var msg = [cljs.core.str("CONTENT SCRIPT: document '"),cljs.core.str(title),cljs.core.str("' contains "),cljs.core.str(script_count),cljs.core.str(" script tags.")].join('');
console.log(msg);


return chromex.protocols.post_message_BANG_(background_port,msg);
});
hnhit.content_script.core.connect_to_background_page_BANG_ = (function hnhit$content_script$core$connect_to_background_page_BANG_(){
var background_port = chromex.ext.runtime.connect_STAR_(chromex.config.get_active_config(),cljs.core.cst$kw$omit,cljs.core.cst$kw$omit);
chromex.protocols.post_message_BANG_(background_port,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$current_DASH_url,window.location], null));

hnhit.content_script.core.run_message_loop_BANG_(background_port);

return hnhit.content_script.core.do_page_analysis_BANG_(background_port);
});
hnhit.content_script.core.init_BANG_ = (function hnhit$content_script$core$init_BANG_(){
console.log("CONTENT SCRIPT: init");


return hnhit.content_script.core.connect_to_background_page_BANG_();
});

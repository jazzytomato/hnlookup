// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('hnhit.content_script');
goog.require('cljs.core');
goog.require('hnhit.content_script.core');

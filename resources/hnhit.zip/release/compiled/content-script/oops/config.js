// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.config');
goog.require('cljs.core');
oops.config.get_initial_runtime_config = (function oops$config$get_initial_runtime_config(){
return cljs.core.PersistentHashMap.fromArrays([cljs.core.cst$kw$warning_DASH_reporting,cljs.core.cst$kw$empty_DASH_selector_DASH_access,cljs.core.cst$kw$error_DASH_reporting,cljs.core.cst$kw$expected_DASH_function_DASH_value,cljs.core.cst$kw$child_DASH_factory,cljs.core.cst$kw$invalid_DASH_selector,cljs.core.cst$kw$throw_DASH_errors_DASH_from_DASH_macro_DASH_call_DASH_sites,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.cst$kw$missing_DASH_object_DASH_key],[cljs.core.cst$kw$console,cljs.core.cst$kw$warn,cljs.core.cst$kw$throw,cljs.core.cst$kw$error,cljs.core.cst$kw$js_DASH_obj,cljs.core.cst$kw$error,true,cljs.core.cst$kw$error,cljs.core.cst$kw$error]);
});
oops.config._STAR_runtime_config_STAR_ = oops.config.get_initial_runtime_config();
oops.config.set_current_runtime_config_BANG_ = (function oops$config$set_current_runtime_config_BANG_(new_config){

oops.config._STAR_runtime_config_STAR_ = new_config;

return new_config;
});
oops.config.get_current_runtime_config = (function oops$config$get_current_runtime_config(){
return oops.config._STAR_runtime_config_STAR_;
});
oops.config.update_current_runtime_config_BANG_ = (function oops$config$update_current_runtime_config_BANG_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___42689 = arguments.length;
var i__8119__auto___42690 = (0);
while(true){
if((i__8119__auto___42690 < len__8118__auto___42689)){
args__8125__auto__.push((arguments[i__8119__auto___42690]));

var G__42691 = (i__8119__auto___42690 + (1));
i__8119__auto___42690 = G__42691;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (f_or_map,args){
if(cljs.core.map_QMARK_(f_or_map)){
return oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic(cljs.core.merge,cljs.core.array_seq([f_or_map], 0));
} else {
return oops.config.set_current_runtime_config_BANG_(cljs.core.apply.cljs$core$IFn$_invoke$arity$3(f_or_map,oops.config.get_current_runtime_config(),args));
}
});

oops.config.update_current_runtime_config_BANG_.cljs$lang$maxFixedArity = (1);

oops.config.update_current_runtime_config_BANG_.cljs$lang$applyTo = (function (seq42687){
var G__42688 = cljs.core.first(seq42687);
var seq42687__$1 = cljs.core.next(seq42687);
return oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__42688,seq42687__$1);
});

oops.config.get_config_key = (function oops$config$get_config_key(var_args){
var args__8125__auto__ = [];
var len__8118__auto___42699 = arguments.length;
var i__8119__auto___42700 = (0);
while(true){
if((i__8119__auto___42700 < len__8118__auto___42699)){
args__8125__auto__.push((arguments[i__8119__auto___42700]));

var G__42701 = (i__8119__auto___42700 + (1));
i__8119__auto___42700 = G__42701;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic = (function (key,p__42694){
var vec__42695 = p__42694;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42695,(0),null);
var G__42698 = (function (){var or__6939__auto__ = config;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return oops.config.get_current_runtime_config();
}
})();
return (key.cljs$core$IFn$_invoke$arity$1 ? key.cljs$core$IFn$_invoke$arity$1(G__42698) : key.call(null,G__42698));
});

oops.config.get_config_key.cljs$lang$maxFixedArity = (1);

oops.config.get_config_key.cljs$lang$applyTo = (function (seq42692){
var G__42693 = cljs.core.first(seq42692);
var seq42692__$1 = cljs.core.next(seq42692);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(G__42693,seq42692__$1);
});

oops.config.has_config_key_QMARK_ = (function oops$config$has_config_key_QMARK_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___42708 = arguments.length;
var i__8119__auto___42709 = (0);
while(true){
if((i__8119__auto___42709 < len__8118__auto___42708)){
args__8125__auto__.push((arguments[i__8119__auto___42709]));

var G__42710 = (i__8119__auto___42709 + (1));
i__8119__auto___42709 = G__42710;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return oops.config.has_config_key_QMARK_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

oops.config.has_config_key_QMARK_.cljs$core$IFn$_invoke$arity$variadic = (function (key,p__42704){
var vec__42705 = p__42704;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42705,(0),null);
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$oops$config_SLASH_not_DASH_found,cljs.core.get.cljs$core$IFn$_invoke$arity$3((function (){var or__6939__auto__ = config;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return oops.config.get_current_runtime_config();
}
})(),key,cljs.core.cst$kw$oops$config_SLASH_not_DASH_found));
});

oops.config.has_config_key_QMARK_.cljs$lang$maxFixedArity = (1);

oops.config.has_config_key_QMARK_.cljs$lang$applyTo = (function (seq42702){
var G__42703 = cljs.core.first(seq42702);
var seq42702__$1 = cljs.core.next(seq42702);
return oops.config.has_config_key_QMARK_.cljs$core$IFn$_invoke$arity$variadic(G__42703,seq42702__$1);
});

oops.config.get_error_reporting = (function oops$config$get_error_reporting(var_args){
var args__8125__auto__ = [];
var len__8118__auto___42716 = arguments.length;
var i__8119__auto___42717 = (0);
while(true){
if((i__8119__auto___42717 < len__8118__auto___42716)){
args__8125__auto__.push((arguments[i__8119__auto___42717]));

var G__42718 = (i__8119__auto___42717 + (1));
i__8119__auto___42717 = G__42718;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_error_reporting.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_error_reporting.cljs$core$IFn$_invoke$arity$variadic = (function (p__42712){
var vec__42713 = p__42712;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42713,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$error_DASH_reporting,cljs.core.array_seq([config], 0));
});

oops.config.get_error_reporting.cljs$lang$maxFixedArity = (0);

oops.config.get_error_reporting.cljs$lang$applyTo = (function (seq42711){
return oops.config.get_error_reporting.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq42711));
});

oops.config.get_warning_reporting = (function oops$config$get_warning_reporting(var_args){
var args__8125__auto__ = [];
var len__8118__auto___42724 = arguments.length;
var i__8119__auto___42725 = (0);
while(true){
if((i__8119__auto___42725 < len__8118__auto___42724)){
args__8125__auto__.push((arguments[i__8119__auto___42725]));

var G__42726 = (i__8119__auto___42725 + (1));
i__8119__auto___42725 = G__42726;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_warning_reporting.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_warning_reporting.cljs$core$IFn$_invoke$arity$variadic = (function (p__42720){
var vec__42721 = p__42720;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42721,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$warning_DASH_reporting,cljs.core.array_seq([config], 0));
});

oops.config.get_warning_reporting.cljs$lang$maxFixedArity = (0);

oops.config.get_warning_reporting.cljs$lang$applyTo = (function (seq42719){
return oops.config.get_warning_reporting.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq42719));
});

oops.config.get_suppress_reporting = (function oops$config$get_suppress_reporting(var_args){
var args__8125__auto__ = [];
var len__8118__auto___42732 = arguments.length;
var i__8119__auto___42733 = (0);
while(true){
if((i__8119__auto___42733 < len__8118__auto___42732)){
args__8125__auto__.push((arguments[i__8119__auto___42733]));

var G__42734 = (i__8119__auto___42733 + (1));
i__8119__auto___42733 = G__42734;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_suppress_reporting.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_suppress_reporting.cljs$core$IFn$_invoke$arity$variadic = (function (p__42728){
var vec__42729 = p__42728;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42729,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$suppress_DASH_reporting,cljs.core.array_seq([config], 0));
});

oops.config.get_suppress_reporting.cljs$lang$maxFixedArity = (0);

oops.config.get_suppress_reporting.cljs$lang$applyTo = (function (seq42727){
return oops.config.get_suppress_reporting.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq42727));
});

oops.config.get_child_factory = (function oops$config$get_child_factory(var_args){
var args__8125__auto__ = [];
var len__8118__auto___42740 = arguments.length;
var i__8119__auto___42741 = (0);
while(true){
if((i__8119__auto___42741 < len__8118__auto___42740)){
args__8125__auto__.push((arguments[i__8119__auto___42741]));

var G__42742 = (i__8119__auto___42741 + (1));
i__8119__auto___42741 = G__42742;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_child_factory.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_child_factory.cljs$core$IFn$_invoke$arity$variadic = (function (p__42736){
var vec__42737 = p__42736;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42737,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$child_DASH_factory,cljs.core.array_seq([config], 0));
});

oops.config.get_child_factory.cljs$lang$maxFixedArity = (0);

oops.config.get_child_factory.cljs$lang$applyTo = (function (seq42735){
return oops.config.get_child_factory.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq42735));
});

oops.config.set_child_factory_BANG_ = (function oops$config$set_child_factory_BANG_(new_factory_fn){
return oops.config.update_current_runtime_config_BANG_(new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$child_DASH_factory,new_factory_fn], null));
});
oops.config.throw_errors_from_macro_call_sites_QMARK_ = (function oops$config$throw_errors_from_macro_call_sites_QMARK_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___42748 = arguments.length;
var i__8119__auto___42749 = (0);
while(true){
if((i__8119__auto___42749 < len__8118__auto___42748)){
args__8125__auto__.push((arguments[i__8119__auto___42749]));

var G__42750 = (i__8119__auto___42749 + (1));
i__8119__auto___42749 = G__42750;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$core$IFn$_invoke$arity$variadic = (function (p__42744){
var vec__42745 = p__42744;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42745,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$throw_DASH_errors_DASH_from_DASH_macro_DASH_call_DASH_sites,cljs.core.array_seq([config], 0)) === true;
});

oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$lang$maxFixedArity = (0);

oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$lang$applyTo = (function (seq42743){
return oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq42743));
});


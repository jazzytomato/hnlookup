// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.messages');
goog.require('cljs.core');
oops.messages.post_process_error_message = (function oops$messages$post_process_error_message(msg){
return [cljs.core.str("Oops, "),cljs.core.str(msg)].join('');
});
if(typeof oops.messages.runtime_message !== 'undefined'){
} else {
oops.messages.runtime_message = (function (){var method_table__7962__auto__ = (function (){var G__45683 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__45683) : cljs.core.atom.call(null,G__45683));
})();
var prefer_table__7963__auto__ = (function (){var G__45684 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__45684) : cljs.core.atom.call(null,G__45684));
})();
var method_cache__7964__auto__ = (function (){var G__45685 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__45685) : cljs.core.atom.call(null,G__45685));
})();
var cached_hierarchy__7965__auto__ = (function (){var G__45686 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__45686) : cljs.core.atom.call(null,G__45686));
})();
var hierarchy__7966__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$3(cljs.core.PersistentArrayMap.EMPTY,cljs.core.cst$kw$hierarchy,cljs.core.get_global_hierarchy());
return (new cljs.core.MultiFn(cljs.core.symbol.cljs$core$IFn$_invoke$arity$2("oops.messages","runtime-message"),((function (method_table__7962__auto__,prefer_table__7963__auto__,method_cache__7964__auto__,cached_hierarchy__7965__auto__,hierarchy__7966__auto__){
return (function() { 
var G__45687__delegate = function (type,_){
return type;
};
var G__45687 = function (type,var_args){
var _ = null;
if (arguments.length > 1) {
var G__45688__i = 0, G__45688__a = new Array(arguments.length -  1);
while (G__45688__i < G__45688__a.length) {G__45688__a[G__45688__i] = arguments[G__45688__i + 1]; ++G__45688__i;}
  _ = new cljs.core.IndexedSeq(G__45688__a,0);
} 
return G__45687__delegate.call(this,type,_);};
G__45687.cljs$lang$maxFixedArity = 1;
G__45687.cljs$lang$applyTo = (function (arglist__45689){
var type = cljs.core.first(arglist__45689);
var _ = cljs.core.rest(arglist__45689);
return G__45687__delegate(type,_);
});
G__45687.cljs$core$IFn$_invoke$arity$variadic = G__45687__delegate;
return G__45687;
})()
;})(method_table__7962__auto__,prefer_table__7963__auto__,method_cache__7964__auto__,cached_hierarchy__7965__auto__,hierarchy__7966__auto__))
,cljs.core.cst$kw$default,hierarchy__7966__auto__,method_table__7962__auto__,prefer_table__7963__auto__,method_cache__7964__auto__,cached_hierarchy__7965__auto__));
})();
}
oops.messages.runtime_message.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,(function (_type,info){
var map__45690 = info;
var map__45690__$1 = ((((!((map__45690 == null)))?((((map__45690.cljs$lang$protocol_mask$partition0$ & (64))) || (map__45690.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__45690):map__45690);
var flavor = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__45690__$1,cljs.core.cst$kw$flavor);
var path = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__45690__$1,cljs.core.cst$kw$path);
return oops.messages.post_process_error_message([cljs.core.str("Unexpected object value ("),cljs.core.str(flavor),cljs.core.str(")"),cljs.core.str(((!(cljs.core.empty_QMARK_(path)))?[cljs.core.str(" on key path '"),cljs.core.str(path),cljs.core.str("'")].join(''):null))].join(''));
}));
oops.messages.runtime_message.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$expected_DASH_function_DASH_value,(function (_type,info){
var map__45692 = info;
var map__45692__$1 = ((((!((map__45692 == null)))?((((map__45692.cljs$lang$protocol_mask$partition0$ & (64))) || (map__45692.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__45692):map__45692);
var soft_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__45692__$1,cljs.core.cst$kw$soft_QMARK_);
var path = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__45692__$1,cljs.core.cst$kw$path);
var fn = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__45692__$1,cljs.core.cst$kw$fn);
return oops.messages.post_process_error_message([cljs.core.str("Expected a function"),cljs.core.str((cljs.core.truth_(soft_QMARK_)?[cljs.core.str(" or nil")].join(''):null)),cljs.core.str(((!(cljs.core.empty_QMARK_(path)))?[cljs.core.str(" on key path '"),cljs.core.str(path),cljs.core.str("'")].join(''):null)),cljs.core.str(", got <"),cljs.core.str(goog.typeOf(fn)),cljs.core.str("> instead")].join(''));
}));
oops.messages.runtime_message.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$missing_DASH_object_DASH_key,(function (_type,info){
var map__45694 = info;
var map__45694__$1 = ((((!((map__45694 == null)))?((((map__45694.cljs$lang$protocol_mask$partition0$ & (64))) || (map__45694.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__45694):map__45694);
var key = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__45694__$1,cljs.core.cst$kw$key);
var path = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__45694__$1,cljs.core.cst$kw$path);
return oops.messages.post_process_error_message([cljs.core.str("Missing expected object key '"),cljs.core.str(key),cljs.core.str("'"),cljs.core.str(((!((cljs.core.empty_QMARK_(path)) || (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(path,key))))?[cljs.core.str(" on key path '"),cljs.core.str(path),cljs.core.str("'")].join(''):null))].join(''));
}));
oops.messages.runtime_message.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$invalid_DASH_selector,(function (_type){
return oops.messages.post_process_error_message("Invalid selector");
}));
oops.messages.runtime_message.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$empty_DASH_selector_DASH_access,(function (_type){
return oops.messages.post_process_error_message([cljs.core.str("Accessing target object with empty selector")].join(''));
}));

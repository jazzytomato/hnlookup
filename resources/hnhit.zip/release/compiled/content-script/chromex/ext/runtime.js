// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.runtime');
goog.require('cljs.core');
goog.require('chromex.core');
chromex.ext.runtime.last_error_STAR_ = (function chromex$ext$runtime$last_error_STAR_(config){
var result_47093 = (function (){var final_args_array_47094 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.lastError");
var ns_47095 = (function (){var target_obj_47097 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47098 = goog.object.get(target_obj_47097,"chrome");
var next_obj_47099 = goog.object.get(next_obj_47098,"runtime");
return next_obj_47099;
})();


var target_47096 = (function (){var target_obj_47100 = ns_47095;
var next_obj_47101 = goog.object.get(target_obj_47100,"lastError");
if(!((next_obj_47101 == null))){
return next_obj_47101;
} else {
return null;
}
})();
return target_47096;
})();
return result_47093;
});
chromex.ext.runtime.id_STAR_ = (function chromex$ext$runtime$id_STAR_(config){
var result_47111 = (function (){var final_args_array_47112 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.id");
var ns_47113 = (function (){var target_obj_47115 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47116 = goog.object.get(target_obj_47115,"chrome");
var next_obj_47117 = goog.object.get(next_obj_47116,"runtime");
return next_obj_47117;
})();


var target_47114 = (function (){var target_obj_47118 = ns_47113;
var next_obj_47119 = goog.object.get(target_obj_47118,"id");
if(!((next_obj_47119 == null))){
return next_obj_47119;
} else {
return null;
}
})();
return target_47114;
})();
return result_47111;
});
chromex.ext.runtime.get_background_page_STAR_ = (function chromex$ext$runtime$get_background_page_STAR_(config){
var callback_chan_47135 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_47137_47150 = ((function (callback_chan_47135){
return (function (cb_background_page_47141){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47142 = config__13447__auto__;
var G__47143 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_background_DASH_page,cljs.core.cst$kw$name,"getBackgroundPage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"background-page",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__47144 = callback_chan_47135;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47142,G__47143,G__47144) : handler__13449__auto__.call(null,G__47142,G__47143,G__47144));
})().call(null,cb_background_page_47141);
});})(callback_chan_47135))
;
var result_47136_47151 = (function (){var final_args_array_47138 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_47137_47150,"callback",null], null)], null),"chrome.runtime.getBackgroundPage");
var ns_47139 = (function (){var target_obj_47145 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47146 = goog.object.get(target_obj_47145,"chrome");
var next_obj_47147 = goog.object.get(next_obj_47146,"runtime");
return next_obj_47147;
})();
var config__13480__auto___47152 = config;
var api_check_fn__13481__auto___47153 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47152);

(api_check_fn__13481__auto___47153.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47153.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getBackgroundPage",ns_47139,"getBackgroundPage") : api_check_fn__13481__auto___47153.call(null,"chrome.runtime.getBackgroundPage",ns_47139,"getBackgroundPage"));


var target_47140 = (function (){var target_obj_47148 = ns_47139;
var next_obj_47149 = goog.object.get(target_obj_47148,"getBackgroundPage");
if(!((next_obj_47149 == null))){
return next_obj_47149;
} else {
return null;
}
})();
return target_47140.apply(ns_47139,final_args_array_47138);
})();

return callback_chan_47135;
});
chromex.ext.runtime.open_options_page_STAR_ = (function chromex$ext$runtime$open_options_page_STAR_(config){
var callback_chan_47168 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_47170_47182 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47174 = config__13447__auto__;
var G__47175 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_open_DASH_options_DASH_page,cljs.core.cst$kw$name,"openOptionsPage",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__47176 = callback_chan_47168;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47174,G__47175,G__47176) : handler__13449__auto__.call(null,G__47174,G__47175,G__47176));
})();
var result_47169_47183 = (function (){var final_args_array_47171 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_47170_47182,"callback",true], null)], null),"chrome.runtime.openOptionsPage");
var ns_47172 = (function (){var target_obj_47177 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47178 = goog.object.get(target_obj_47177,"chrome");
var next_obj_47179 = goog.object.get(next_obj_47178,"runtime");
return next_obj_47179;
})();
var config__13480__auto___47184 = config;
var api_check_fn__13481__auto___47185 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47184);

(api_check_fn__13481__auto___47185.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47185.cljs$core$IFn$_invoke$arity$3("chrome.runtime.openOptionsPage",ns_47172,"openOptionsPage") : api_check_fn__13481__auto___47185.call(null,"chrome.runtime.openOptionsPage",ns_47172,"openOptionsPage"));


var target_47173 = (function (){var target_obj_47180 = ns_47172;
var next_obj_47181 = goog.object.get(target_obj_47180,"openOptionsPage");
if(!((next_obj_47181 == null))){
return next_obj_47181;
} else {
return null;
}
})();
return target_47173.apply(ns_47172,final_args_array_47171);
})();

return callback_chan_47168;
});
chromex.ext.runtime.get_manifest_STAR_ = (function chromex$ext$runtime$get_manifest_STAR_(config){
var result_47195 = (function (){var final_args_array_47196 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.getManifest");
var ns_47197 = (function (){var target_obj_47199 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47200 = goog.object.get(target_obj_47199,"chrome");
var next_obj_47201 = goog.object.get(next_obj_47200,"runtime");
return next_obj_47201;
})();
var config__13480__auto___47204 = config;
var api_check_fn__13481__auto___47205 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47204);

(api_check_fn__13481__auto___47205.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47205.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getManifest",ns_47197,"getManifest") : api_check_fn__13481__auto___47205.call(null,"chrome.runtime.getManifest",ns_47197,"getManifest"));


var target_47198 = (function (){var target_obj_47202 = ns_47197;
var next_obj_47203 = goog.object.get(target_obj_47202,"getManifest");
if(!((next_obj_47203 == null))){
return next_obj_47203;
} else {
return null;
}
})();
return target_47198.apply(ns_47197,final_args_array_47196);
})();
return result_47195;
});
chromex.ext.runtime.get_url_STAR_ = (function chromex$ext$runtime$get_url_STAR_(config,path){
var marshalled_path_47218 = (function (){var omit_test_47222 = path;
if(cljs.core.keyword_identical_QMARK_(omit_test_47222,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_47222;
}
})();
var result_47217 = (function (){var final_args_array_47219 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_path_47218,"path",null], null)], null),"chrome.runtime.getURL");
var ns_47220 = (function (){var target_obj_47223 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47224 = goog.object.get(target_obj_47223,"chrome");
var next_obj_47225 = goog.object.get(next_obj_47224,"runtime");
return next_obj_47225;
})();
var config__13480__auto___47228 = config;
var api_check_fn__13481__auto___47229 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47228);

(api_check_fn__13481__auto___47229.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47229.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getURL",ns_47220,"getURL") : api_check_fn__13481__auto___47229.call(null,"chrome.runtime.getURL",ns_47220,"getURL"));


var target_47221 = (function (){var target_obj_47226 = ns_47220;
var next_obj_47227 = goog.object.get(target_obj_47226,"getURL");
if(!((next_obj_47227 == null))){
return next_obj_47227;
} else {
return null;
}
})();
return target_47221.apply(ns_47220,final_args_array_47219);
})();
return result_47217;
});
chromex.ext.runtime.set_uninstall_url_STAR_ = (function chromex$ext$runtime$set_uninstall_url_STAR_(config,url){
var callback_chan_47246 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_url_47248_47262 = (function (){var omit_test_47253 = url;
if(cljs.core.keyword_identical_QMARK_(omit_test_47253,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_47253;
}
})();
var marshalled_callback_47249_47263 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47254 = config__13447__auto__;
var G__47255 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_set_DASH_uninstall_DASH_url,cljs.core.cst$kw$name,"setUninstallURL",cljs.core.cst$kw$since,"41",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"url",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__47256 = callback_chan_47246;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47254,G__47255,G__47256) : handler__13449__auto__.call(null,G__47254,G__47255,G__47256));
})();
var result_47247_47264 = (function (){var final_args_array_47250 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_url_47248_47262,"url",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_47249_47263,"callback",true], null)], null),"chrome.runtime.setUninstallURL");
var ns_47251 = (function (){var target_obj_47257 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47258 = goog.object.get(target_obj_47257,"chrome");
var next_obj_47259 = goog.object.get(next_obj_47258,"runtime");
return next_obj_47259;
})();
var config__13480__auto___47265 = config;
var api_check_fn__13481__auto___47266 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47265);

(api_check_fn__13481__auto___47266.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47266.cljs$core$IFn$_invoke$arity$3("chrome.runtime.setUninstallURL",ns_47251,"setUninstallURL") : api_check_fn__13481__auto___47266.call(null,"chrome.runtime.setUninstallURL",ns_47251,"setUninstallURL"));


var target_47252 = (function (){var target_obj_47260 = ns_47251;
var next_obj_47261 = goog.object.get(target_obj_47260,"setUninstallURL");
if(!((next_obj_47261 == null))){
return next_obj_47261;
} else {
return null;
}
})();
return target_47252.apply(ns_47251,final_args_array_47250);
})();

return callback_chan_47246;
});
chromex.ext.runtime.reload_STAR_ = (function chromex$ext$runtime$reload_STAR_(config){
var result_47276 = (function (){var final_args_array_47277 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.reload");
var ns_47278 = (function (){var target_obj_47280 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47281 = goog.object.get(target_obj_47280,"chrome");
var next_obj_47282 = goog.object.get(next_obj_47281,"runtime");
return next_obj_47282;
})();
var config__13480__auto___47285 = config;
var api_check_fn__13481__auto___47286 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47285);

(api_check_fn__13481__auto___47286.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47286.cljs$core$IFn$_invoke$arity$3("chrome.runtime.reload",ns_47278,"reload") : api_check_fn__13481__auto___47286.call(null,"chrome.runtime.reload",ns_47278,"reload"));


var target_47279 = (function (){var target_obj_47283 = ns_47278;
var next_obj_47284 = goog.object.get(target_obj_47283,"reload");
if(!((next_obj_47284 == null))){
return next_obj_47284;
} else {
return null;
}
})();
return target_47279.apply(ns_47278,final_args_array_47277);
})();
return result_47276;
});
chromex.ext.runtime.request_update_check_STAR_ = (function chromex$ext$runtime$request_update_check_STAR_(config){
var callback_chan_47303 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_47305_47319 = ((function (callback_chan_47303){
return (function (cb_status_47309,cb_details_47310){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47311 = config__13447__auto__;
var G__47312 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_request_DASH_update_DASH_check,cljs.core.cst$kw$name,"requestUpdateCheck",cljs.core.cst$kw$since,"25",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"status",cljs.core.cst$kw$type,"runtime.RequestUpdateCheckStatus"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__47313 = callback_chan_47303;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47311,G__47312,G__47313) : handler__13449__auto__.call(null,G__47311,G__47312,G__47313));
})().call(null,cb_status_47309,cb_details_47310);
});})(callback_chan_47303))
;
var result_47304_47320 = (function (){var final_args_array_47306 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_47305_47319,"callback",null], null)], null),"chrome.runtime.requestUpdateCheck");
var ns_47307 = (function (){var target_obj_47314 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47315 = goog.object.get(target_obj_47314,"chrome");
var next_obj_47316 = goog.object.get(next_obj_47315,"runtime");
return next_obj_47316;
})();
var config__13480__auto___47321 = config;
var api_check_fn__13481__auto___47322 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47321);

(api_check_fn__13481__auto___47322.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47322.cljs$core$IFn$_invoke$arity$3("chrome.runtime.requestUpdateCheck",ns_47307,"requestUpdateCheck") : api_check_fn__13481__auto___47322.call(null,"chrome.runtime.requestUpdateCheck",ns_47307,"requestUpdateCheck"));


var target_47308 = (function (){var target_obj_47317 = ns_47307;
var next_obj_47318 = goog.object.get(target_obj_47317,"requestUpdateCheck");
if(!((next_obj_47318 == null))){
return next_obj_47318;
} else {
return null;
}
})();
return target_47308.apply(ns_47307,final_args_array_47306);
})();

return callback_chan_47303;
});
chromex.ext.runtime.restart_STAR_ = (function chromex$ext$runtime$restart_STAR_(config){
var result_47332 = (function (){var final_args_array_47333 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.restart");
var ns_47334 = (function (){var target_obj_47336 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47337 = goog.object.get(target_obj_47336,"chrome");
var next_obj_47338 = goog.object.get(next_obj_47337,"runtime");
return next_obj_47338;
})();
var config__13480__auto___47341 = config;
var api_check_fn__13481__auto___47342 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47341);

(api_check_fn__13481__auto___47342.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47342.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restart",ns_47334,"restart") : api_check_fn__13481__auto___47342.call(null,"chrome.runtime.restart",ns_47334,"restart"));


var target_47335 = (function (){var target_obj_47339 = ns_47334;
var next_obj_47340 = goog.object.get(target_obj_47339,"restart");
if(!((next_obj_47340 == null))){
return next_obj_47340;
} else {
return null;
}
})();
return target_47335.apply(ns_47334,final_args_array_47333);
})();
return result_47332;
});
chromex.ext.runtime.restart_after_delay_STAR_ = (function chromex$ext$runtime$restart_after_delay_STAR_(config,seconds){
var callback_chan_47359 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_seconds_47361_47375 = (function (){var omit_test_47366 = seconds;
if(cljs.core.keyword_identical_QMARK_(omit_test_47366,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_47366;
}
})();
var marshalled_callback_47362_47376 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47367 = config__13447__auto__;
var G__47368 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_restart_DASH_after_DASH_delay,cljs.core.cst$kw$name,"restartAfterDelay",cljs.core.cst$kw$since,"53",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"seconds",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__47369 = callback_chan_47359;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47367,G__47368,G__47369) : handler__13449__auto__.call(null,G__47367,G__47368,G__47369));
})();
var result_47360_47377 = (function (){var final_args_array_47363 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_seconds_47361_47375,"seconds",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_47362_47376,"callback",true], null)], null),"chrome.runtime.restartAfterDelay");
var ns_47364 = (function (){var target_obj_47370 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47371 = goog.object.get(target_obj_47370,"chrome");
var next_obj_47372 = goog.object.get(next_obj_47371,"runtime");
return next_obj_47372;
})();
var config__13480__auto___47378 = config;
var api_check_fn__13481__auto___47379 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47378);

(api_check_fn__13481__auto___47379.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47379.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restartAfterDelay",ns_47364,"restartAfterDelay") : api_check_fn__13481__auto___47379.call(null,"chrome.runtime.restartAfterDelay",ns_47364,"restartAfterDelay"));


var target_47365 = (function (){var target_obj_47373 = ns_47364;
var next_obj_47374 = goog.object.get(target_obj_47373,"restartAfterDelay");
if(!((next_obj_47374 == null))){
return next_obj_47374;
} else {
return null;
}
})();
return target_47365.apply(ns_47364,final_args_array_47363);
})();

return callback_chan_47359;
});
chromex.ext.runtime.connect_STAR_ = (function chromex$ext$runtime$connect_STAR_(config,extension_id,connect_info){
var marshalled_extension_id_47394 = (function (){var omit_test_47399 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_47399,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_47399;
}
})();
var marshalled_connect_info_47395 = (function (){var omit_test_47400 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_47400,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_47400;
}
})();
var result_47393 = (function (){var final_args_array_47396 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_47394,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_47395,"connect-info",true], null)], null),"chrome.runtime.connect");
var ns_47397 = (function (){var target_obj_47401 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47402 = goog.object.get(target_obj_47401,"chrome");
var next_obj_47403 = goog.object.get(next_obj_47402,"runtime");
return next_obj_47403;
})();
var config__13480__auto___47406 = config;
var api_check_fn__13481__auto___47407 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47406);

(api_check_fn__13481__auto___47407.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47407.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connect",ns_47397,"connect") : api_check_fn__13481__auto___47407.call(null,"chrome.runtime.connect",ns_47397,"connect"));


var target_47398 = (function (){var target_obj_47404 = ns_47397;
var next_obj_47405 = goog.object.get(target_obj_47404,"connect");
if(!((next_obj_47405 == null))){
return next_obj_47405;
} else {
return null;
}
})();
return target_47398.apply(ns_47397,final_args_array_47396);
})();
return chromex.marshalling.from_native_chrome_port(config,result_47393);
});
chromex.ext.runtime.connect_native_STAR_ = (function chromex$ext$runtime$connect_native_STAR_(config,application){
var marshalled_application_47420 = (function (){var omit_test_47424 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_47424,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_47424;
}
})();
var result_47419 = (function (){var final_args_array_47421 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_47420,"application",null], null)], null),"chrome.runtime.connectNative");
var ns_47422 = (function (){var target_obj_47425 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47426 = goog.object.get(target_obj_47425,"chrome");
var next_obj_47427 = goog.object.get(next_obj_47426,"runtime");
return next_obj_47427;
})();
var config__13480__auto___47430 = config;
var api_check_fn__13481__auto___47431 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47430);

(api_check_fn__13481__auto___47431.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47431.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connectNative",ns_47422,"connectNative") : api_check_fn__13481__auto___47431.call(null,"chrome.runtime.connectNative",ns_47422,"connectNative"));


var target_47423 = (function (){var target_obj_47428 = ns_47422;
var next_obj_47429 = goog.object.get(target_obj_47428,"connectNative");
if(!((next_obj_47429 == null))){
return next_obj_47429;
} else {
return null;
}
})();
return target_47423.apply(ns_47422,final_args_array_47421);
})();
return chromex.marshalling.from_native_chrome_port(config,result_47419);
});
chromex.ext.runtime.send_message_STAR_ = (function chromex$ext$runtime$send_message_STAR_(config,extension_id,message,options){
var callback_chan_47453 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_extension_id_47455_47474 = (function (){var omit_test_47462 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_47462,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_47462;
}
})();
var marshalled_message_47456_47475 = (function (){var omit_test_47463 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_47463,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_47463;
}
})();
var marshalled_options_47457_47476 = (function (){var omit_test_47464 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_47464,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_47464;
}
})();
var marshalled_response_callback_47458_47477 = ((function (marshalled_extension_id_47455_47474,marshalled_message_47456_47475,marshalled_options_47457_47476,callback_chan_47453){
return (function (cb_response_47465){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47466 = config__13447__auto__;
var G__47467 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$since,"26",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"extension-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__47468 = callback_chan_47453;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47466,G__47467,G__47468) : handler__13449__auto__.call(null,G__47466,G__47467,G__47468));
})().call(null,cb_response_47465);
});})(marshalled_extension_id_47455_47474,marshalled_message_47456_47475,marshalled_options_47457_47476,callback_chan_47453))
;
var result_47454_47478 = (function (){var final_args_array_47459 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_47455_47474,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_47456_47475,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_47457_47476,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_47458_47477,"response-callback",true], null)], null),"chrome.runtime.sendMessage");
var ns_47460 = (function (){var target_obj_47469 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47470 = goog.object.get(target_obj_47469,"chrome");
var next_obj_47471 = goog.object.get(next_obj_47470,"runtime");
return next_obj_47471;
})();
var config__13480__auto___47479 = config;
var api_check_fn__13481__auto___47480 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47479);

(api_check_fn__13481__auto___47480.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47480.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendMessage",ns_47460,"sendMessage") : api_check_fn__13481__auto___47480.call(null,"chrome.runtime.sendMessage",ns_47460,"sendMessage"));


var target_47461 = (function (){var target_obj_47472 = ns_47460;
var next_obj_47473 = goog.object.get(target_obj_47472,"sendMessage");
if(!((next_obj_47473 == null))){
return next_obj_47473;
} else {
return null;
}
})();
return target_47461.apply(ns_47460,final_args_array_47459);
})();

return callback_chan_47453;
});
chromex.ext.runtime.send_native_message_STAR_ = (function chromex$ext$runtime$send_native_message_STAR_(config,application,message){
var callback_chan_47500 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_application_47502_47519 = (function (){var omit_test_47508 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_47508,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_47508;
}
})();
var marshalled_message_47503_47520 = (function (){var omit_test_47509 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_47509,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_47509;
}
})();
var marshalled_response_callback_47504_47521 = ((function (marshalled_application_47502_47519,marshalled_message_47503_47520,callback_chan_47500){
return (function (cb_response_47510){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47511 = config__13447__auto__;
var G__47512 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_native_DASH_message,cljs.core.cst$kw$name,"sendNativeMessage",cljs.core.cst$kw$since,"28",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"application",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__47513 = callback_chan_47500;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47511,G__47512,G__47513) : handler__13449__auto__.call(null,G__47511,G__47512,G__47513));
})().call(null,cb_response_47510);
});})(marshalled_application_47502_47519,marshalled_message_47503_47520,callback_chan_47500))
;
var result_47501_47522 = (function (){var final_args_array_47505 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_47502_47519,"application",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_47503_47520,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_47504_47521,"response-callback",true], null)], null),"chrome.runtime.sendNativeMessage");
var ns_47506 = (function (){var target_obj_47514 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47515 = goog.object.get(target_obj_47514,"chrome");
var next_obj_47516 = goog.object.get(next_obj_47515,"runtime");
return next_obj_47516;
})();
var config__13480__auto___47523 = config;
var api_check_fn__13481__auto___47524 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47523);

(api_check_fn__13481__auto___47524.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47524.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendNativeMessage",ns_47506,"sendNativeMessage") : api_check_fn__13481__auto___47524.call(null,"chrome.runtime.sendNativeMessage",ns_47506,"sendNativeMessage"));


var target_47507 = (function (){var target_obj_47517 = ns_47506;
var next_obj_47518 = goog.object.get(target_obj_47517,"sendNativeMessage");
if(!((next_obj_47518 == null))){
return next_obj_47518;
} else {
return null;
}
})();
return target_47507.apply(ns_47506,final_args_array_47505);
})();

return callback_chan_47500;
});
chromex.ext.runtime.get_platform_info_STAR_ = (function chromex$ext$runtime$get_platform_info_STAR_(config){
var callback_chan_47540 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_47542_47555 = ((function (callback_chan_47540){
return (function (cb_platform_info_47546){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47547 = config__13447__auto__;
var G__47548 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_platform_DASH_info,cljs.core.cst$kw$name,"getPlatformInfo",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"platform-info",cljs.core.cst$kw$type,"runtime.PlatformInfo"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__47549 = callback_chan_47540;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47547,G__47548,G__47549) : handler__13449__auto__.call(null,G__47547,G__47548,G__47549));
})().call(null,cb_platform_info_47546);
});})(callback_chan_47540))
;
var result_47541_47556 = (function (){var final_args_array_47543 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_47542_47555,"callback",null], null)], null),"chrome.runtime.getPlatformInfo");
var ns_47544 = (function (){var target_obj_47550 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47551 = goog.object.get(target_obj_47550,"chrome");
var next_obj_47552 = goog.object.get(next_obj_47551,"runtime");
return next_obj_47552;
})();
var config__13480__auto___47557 = config;
var api_check_fn__13481__auto___47558 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47557);

(api_check_fn__13481__auto___47558.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47558.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPlatformInfo",ns_47544,"getPlatformInfo") : api_check_fn__13481__auto___47558.call(null,"chrome.runtime.getPlatformInfo",ns_47544,"getPlatformInfo"));


var target_47545 = (function (){var target_obj_47553 = ns_47544;
var next_obj_47554 = goog.object.get(target_obj_47553,"getPlatformInfo");
if(!((next_obj_47554 == null))){
return next_obj_47554;
} else {
return null;
}
})();
return target_47545.apply(ns_47544,final_args_array_47543);
})();

return callback_chan_47540;
});
chromex.ext.runtime.get_package_directory_entry_STAR_ = (function chromex$ext$runtime$get_package_directory_entry_STAR_(config){
var callback_chan_47574 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_47576_47589 = ((function (callback_chan_47574){
return (function (cb_directory_entry_47580){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47581 = config__13447__auto__;
var G__47582 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_package_DASH_directory_DASH_entry,cljs.core.cst$kw$name,"getPackageDirectoryEntry",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"directory-entry",cljs.core.cst$kw$type,"DirectoryEntry"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__47583 = callback_chan_47574;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47581,G__47582,G__47583) : handler__13449__auto__.call(null,G__47581,G__47582,G__47583));
})().call(null,cb_directory_entry_47580);
});})(callback_chan_47574))
;
var result_47575_47590 = (function (){var final_args_array_47577 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_47576_47589,"callback",null], null)], null),"chrome.runtime.getPackageDirectoryEntry");
var ns_47578 = (function (){var target_obj_47584 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47585 = goog.object.get(target_obj_47584,"chrome");
var next_obj_47586 = goog.object.get(next_obj_47585,"runtime");
return next_obj_47586;
})();
var config__13480__auto___47591 = config;
var api_check_fn__13481__auto___47592 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47591);

(api_check_fn__13481__auto___47592.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47592.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPackageDirectoryEntry",ns_47578,"getPackageDirectoryEntry") : api_check_fn__13481__auto___47592.call(null,"chrome.runtime.getPackageDirectoryEntry",ns_47578,"getPackageDirectoryEntry"));


var target_47579 = (function (){var target_obj_47587 = ns_47578;
var next_obj_47588 = goog.object.get(target_obj_47587,"getPackageDirectoryEntry");
if(!((next_obj_47588 == null))){
return next_obj_47588;
} else {
return null;
}
})();
return target_47579.apply(ns_47578,final_args_array_47577);
})();

return callback_chan_47574;
});
chromex.ext.runtime.on_startup_STAR_ = (function chromex$ext$runtime$on_startup_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47607 = arguments.length;
var i__8119__auto___47608 = (0);
while(true){
if((i__8119__auto___47608 < len__8118__auto___47607)){
args__8125__auto__.push((arguments[i__8119__auto___47608]));

var G__47609 = (i__8119__auto___47608 + (1));
i__8119__auto___47608 = G__47609;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_47596 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47599 = config__13447__auto__;
var G__47600 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_startup;
var G__47601 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47599,G__47600,G__47601) : handler__13449__auto__.call(null,G__47599,G__47600,G__47601));
})();
var handler_fn_47597 = event_fn_47596;
var logging_fn__20428__auto__ = ((function (event_fn_47596,handler_fn_47597){
return (function (){

return (handler_fn_47597.cljs$core$IFn$_invoke$arity$0 ? handler_fn_47597.cljs$core$IFn$_invoke$arity$0() : handler_fn_47597.call(null));
});})(event_fn_47596,handler_fn_47597))
;
var ns_obj_47598 = (function (){var target_obj_47602 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47603 = goog.object.get(target_obj_47602,"chrome");
var next_obj_47604 = goog.object.get(next_obj_47603,"runtime");
return next_obj_47604;
})();
var config__13480__auto___47610 = config;
var api_check_fn__13481__auto___47611 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47610);

(api_check_fn__13481__auto___47611.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47611.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onStartup",ns_obj_47598,"onStartup") : api_check_fn__13481__auto___47611.call(null,"chrome.runtime.onStartup",ns_obj_47598,"onStartup"));

var event_obj__20429__auto__ = (function (){var target_obj_47605 = ns_obj_47598;
var next_obj_47606 = goog.object.get(target_obj_47605,"onStartup");
return next_obj_47606;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_startup_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_startup_STAR_.cljs$lang$applyTo = (function (seq47593){
var G__47594 = cljs.core.first(seq47593);
var seq47593__$1 = cljs.core.next(seq47593);
var G__47595 = cljs.core.first(seq47593__$1);
var seq47593__$2 = cljs.core.next(seq47593__$1);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__47594,G__47595,seq47593__$2);
});

chromex.ext.runtime.on_installed_STAR_ = (function chromex$ext$runtime$on_installed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47628 = arguments.length;
var i__8119__auto___47629 = (0);
while(true){
if((i__8119__auto___47629 < len__8118__auto___47628)){
args__8125__auto__.push((arguments[i__8119__auto___47629]));

var G__47630 = (i__8119__auto___47629 + (1));
i__8119__auto___47629 = G__47630;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_47615 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47620 = config__13447__auto__;
var G__47621 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_installed;
var G__47622 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47620,G__47621,G__47622) : handler__13449__auto__.call(null,G__47620,G__47621,G__47622));
})();
var handler_fn_47616 = ((function (event_fn_47615){
return (function (cb_details_47618){
return (event_fn_47615.cljs$core$IFn$_invoke$arity$1 ? event_fn_47615.cljs$core$IFn$_invoke$arity$1(cb_details_47618) : event_fn_47615.call(null,cb_details_47618));
});})(event_fn_47615))
;
var logging_fn__20428__auto__ = ((function (event_fn_47615,handler_fn_47616){
return (function (cb_param_details_47619){

return handler_fn_47616(cb_param_details_47619);
});})(event_fn_47615,handler_fn_47616))
;
var ns_obj_47617 = (function (){var target_obj_47623 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47624 = goog.object.get(target_obj_47623,"chrome");
var next_obj_47625 = goog.object.get(next_obj_47624,"runtime");
return next_obj_47625;
})();
var config__13480__auto___47631 = config;
var api_check_fn__13481__auto___47632 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47631);

(api_check_fn__13481__auto___47632.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47632.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onInstalled",ns_obj_47617,"onInstalled") : api_check_fn__13481__auto___47632.call(null,"chrome.runtime.onInstalled",ns_obj_47617,"onInstalled"));

var event_obj__20429__auto__ = (function (){var target_obj_47626 = ns_obj_47617;
var next_obj_47627 = goog.object.get(target_obj_47626,"onInstalled");
return next_obj_47627;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_installed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_installed_STAR_.cljs$lang$applyTo = (function (seq47612){
var G__47613 = cljs.core.first(seq47612);
var seq47612__$1 = cljs.core.next(seq47612);
var G__47614 = cljs.core.first(seq47612__$1);
var seq47612__$2 = cljs.core.next(seq47612__$1);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__47613,G__47614,seq47612__$2);
});

chromex.ext.runtime.on_suspend_STAR_ = (function chromex$ext$runtime$on_suspend_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47647 = arguments.length;
var i__8119__auto___47648 = (0);
while(true){
if((i__8119__auto___47648 < len__8118__auto___47647)){
args__8125__auto__.push((arguments[i__8119__auto___47648]));

var G__47649 = (i__8119__auto___47648 + (1));
i__8119__auto___47648 = G__47649;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_47636 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47639 = config__13447__auto__;
var G__47640 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend;
var G__47641 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47639,G__47640,G__47641) : handler__13449__auto__.call(null,G__47639,G__47640,G__47641));
})();
var handler_fn_47637 = event_fn_47636;
var logging_fn__20428__auto__ = ((function (event_fn_47636,handler_fn_47637){
return (function (){

return (handler_fn_47637.cljs$core$IFn$_invoke$arity$0 ? handler_fn_47637.cljs$core$IFn$_invoke$arity$0() : handler_fn_47637.call(null));
});})(event_fn_47636,handler_fn_47637))
;
var ns_obj_47638 = (function (){var target_obj_47642 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47643 = goog.object.get(target_obj_47642,"chrome");
var next_obj_47644 = goog.object.get(next_obj_47643,"runtime");
return next_obj_47644;
})();
var config__13480__auto___47650 = config;
var api_check_fn__13481__auto___47651 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47650);

(api_check_fn__13481__auto___47651.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47651.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspend",ns_obj_47638,"onSuspend") : api_check_fn__13481__auto___47651.call(null,"chrome.runtime.onSuspend",ns_obj_47638,"onSuspend"));

var event_obj__20429__auto__ = (function (){var target_obj_47645 = ns_obj_47638;
var next_obj_47646 = goog.object.get(target_obj_47645,"onSuspend");
return next_obj_47646;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_suspend_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_suspend_STAR_.cljs$lang$applyTo = (function (seq47633){
var G__47634 = cljs.core.first(seq47633);
var seq47633__$1 = cljs.core.next(seq47633);
var G__47635 = cljs.core.first(seq47633__$1);
var seq47633__$2 = cljs.core.next(seq47633__$1);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__47634,G__47635,seq47633__$2);
});

chromex.ext.runtime.on_suspend_canceled_STAR_ = (function chromex$ext$runtime$on_suspend_canceled_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47666 = arguments.length;
var i__8119__auto___47667 = (0);
while(true){
if((i__8119__auto___47667 < len__8118__auto___47666)){
args__8125__auto__.push((arguments[i__8119__auto___47667]));

var G__47668 = (i__8119__auto___47667 + (1));
i__8119__auto___47667 = G__47668;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_47655 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47658 = config__13447__auto__;
var G__47659 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend_DASH_canceled;
var G__47660 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47658,G__47659,G__47660) : handler__13449__auto__.call(null,G__47658,G__47659,G__47660));
})();
var handler_fn_47656 = event_fn_47655;
var logging_fn__20428__auto__ = ((function (event_fn_47655,handler_fn_47656){
return (function (){

return (handler_fn_47656.cljs$core$IFn$_invoke$arity$0 ? handler_fn_47656.cljs$core$IFn$_invoke$arity$0() : handler_fn_47656.call(null));
});})(event_fn_47655,handler_fn_47656))
;
var ns_obj_47657 = (function (){var target_obj_47661 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47662 = goog.object.get(target_obj_47661,"chrome");
var next_obj_47663 = goog.object.get(next_obj_47662,"runtime");
return next_obj_47663;
})();
var config__13480__auto___47669 = config;
var api_check_fn__13481__auto___47670 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47669);

(api_check_fn__13481__auto___47670.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47670.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspendCanceled",ns_obj_47657,"onSuspendCanceled") : api_check_fn__13481__auto___47670.call(null,"chrome.runtime.onSuspendCanceled",ns_obj_47657,"onSuspendCanceled"));

var event_obj__20429__auto__ = (function (){var target_obj_47664 = ns_obj_47657;
var next_obj_47665 = goog.object.get(target_obj_47664,"onSuspendCanceled");
return next_obj_47665;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$applyTo = (function (seq47652){
var G__47653 = cljs.core.first(seq47652);
var seq47652__$1 = cljs.core.next(seq47652);
var G__47654 = cljs.core.first(seq47652__$1);
var seq47652__$2 = cljs.core.next(seq47652__$1);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__47653,G__47654,seq47652__$2);
});

chromex.ext.runtime.on_update_available_STAR_ = (function chromex$ext$runtime$on_update_available_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47687 = arguments.length;
var i__8119__auto___47688 = (0);
while(true){
if((i__8119__auto___47688 < len__8118__auto___47687)){
args__8125__auto__.push((arguments[i__8119__auto___47688]));

var G__47689 = (i__8119__auto___47688 + (1));
i__8119__auto___47688 = G__47689;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_47674 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47679 = config__13447__auto__;
var G__47680 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_update_DASH_available;
var G__47681 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47679,G__47680,G__47681) : handler__13449__auto__.call(null,G__47679,G__47680,G__47681));
})();
var handler_fn_47675 = ((function (event_fn_47674){
return (function (cb_details_47677){
return (event_fn_47674.cljs$core$IFn$_invoke$arity$1 ? event_fn_47674.cljs$core$IFn$_invoke$arity$1(cb_details_47677) : event_fn_47674.call(null,cb_details_47677));
});})(event_fn_47674))
;
var logging_fn__20428__auto__ = ((function (event_fn_47674,handler_fn_47675){
return (function (cb_param_details_47678){

return handler_fn_47675(cb_param_details_47678);
});})(event_fn_47674,handler_fn_47675))
;
var ns_obj_47676 = (function (){var target_obj_47682 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47683 = goog.object.get(target_obj_47682,"chrome");
var next_obj_47684 = goog.object.get(next_obj_47683,"runtime");
return next_obj_47684;
})();
var config__13480__auto___47690 = config;
var api_check_fn__13481__auto___47691 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47690);

(api_check_fn__13481__auto___47691.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47691.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onUpdateAvailable",ns_obj_47676,"onUpdateAvailable") : api_check_fn__13481__auto___47691.call(null,"chrome.runtime.onUpdateAvailable",ns_obj_47676,"onUpdateAvailable"));

var event_obj__20429__auto__ = (function (){var target_obj_47685 = ns_obj_47676;
var next_obj_47686 = goog.object.get(target_obj_47685,"onUpdateAvailable");
return next_obj_47686;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_update_available_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_update_available_STAR_.cljs$lang$applyTo = (function (seq47671){
var G__47672 = cljs.core.first(seq47671);
var seq47671__$1 = cljs.core.next(seq47671);
var G__47673 = cljs.core.first(seq47671__$1);
var seq47671__$2 = cljs.core.next(seq47671__$1);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__47672,G__47673,seq47671__$2);
});

chromex.ext.runtime.on_browser_update_available_STAR_ = (function chromex$ext$runtime$on_browser_update_available_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47706 = arguments.length;
var i__8119__auto___47707 = (0);
while(true){
if((i__8119__auto___47707 < len__8118__auto___47706)){
args__8125__auto__.push((arguments[i__8119__auto___47707]));

var G__47708 = (i__8119__auto___47707 + (1));
i__8119__auto___47707 = G__47708;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_47695 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47698 = config__13447__auto__;
var G__47699 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_browser_DASH_update_DASH_available;
var G__47700 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47698,G__47699,G__47700) : handler__13449__auto__.call(null,G__47698,G__47699,G__47700));
})();
var handler_fn_47696 = event_fn_47695;
var logging_fn__20428__auto__ = ((function (event_fn_47695,handler_fn_47696){
return (function (){

return (handler_fn_47696.cljs$core$IFn$_invoke$arity$0 ? handler_fn_47696.cljs$core$IFn$_invoke$arity$0() : handler_fn_47696.call(null));
});})(event_fn_47695,handler_fn_47696))
;
var ns_obj_47697 = (function (){var target_obj_47701 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47702 = goog.object.get(target_obj_47701,"chrome");
var next_obj_47703 = goog.object.get(next_obj_47702,"runtime");
return next_obj_47703;
})();
var config__13480__auto___47709 = config;
var api_check_fn__13481__auto___47710 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47709);

(api_check_fn__13481__auto___47710.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47710.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onBrowserUpdateAvailable",ns_obj_47697,"onBrowserUpdateAvailable") : api_check_fn__13481__auto___47710.call(null,"chrome.runtime.onBrowserUpdateAvailable",ns_obj_47697,"onBrowserUpdateAvailable"));

var event_obj__20429__auto__ = (function (){var target_obj_47704 = ns_obj_47697;
var next_obj_47705 = goog.object.get(target_obj_47704,"onBrowserUpdateAvailable");
return next_obj_47705;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$applyTo = (function (seq47692){
var G__47693 = cljs.core.first(seq47692);
var seq47692__$1 = cljs.core.next(seq47692);
var G__47694 = cljs.core.first(seq47692__$1);
var seq47692__$2 = cljs.core.next(seq47692__$1);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__47693,G__47694,seq47692__$2);
});

chromex.ext.runtime.on_connect_STAR_ = (function chromex$ext$runtime$on_connect_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47728 = arguments.length;
var i__8119__auto___47729 = (0);
while(true){
if((i__8119__auto___47729 < len__8118__auto___47728)){
args__8125__auto__.push((arguments[i__8119__auto___47729]));

var G__47730 = (i__8119__auto___47729 + (1));
i__8119__auto___47729 = G__47730;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_47714 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47719 = config__13447__auto__;
var G__47720 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect;
var G__47721 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47719,G__47720,G__47721) : handler__13449__auto__.call(null,G__47719,G__47720,G__47721));
})();
var handler_fn_47715 = ((function (event_fn_47714){
return (function (cb_port_47717){
var G__47722 = chromex.marshalling.from_native_chrome_port(config,cb_port_47717);
return (event_fn_47714.cljs$core$IFn$_invoke$arity$1 ? event_fn_47714.cljs$core$IFn$_invoke$arity$1(G__47722) : event_fn_47714.call(null,G__47722));
});})(event_fn_47714))
;
var logging_fn__20428__auto__ = ((function (event_fn_47714,handler_fn_47715){
return (function (cb_param_port_47718){

return handler_fn_47715(cb_param_port_47718);
});})(event_fn_47714,handler_fn_47715))
;
var ns_obj_47716 = (function (){var target_obj_47723 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47724 = goog.object.get(target_obj_47723,"chrome");
var next_obj_47725 = goog.object.get(next_obj_47724,"runtime");
return next_obj_47725;
})();
var config__13480__auto___47731 = config;
var api_check_fn__13481__auto___47732 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47731);

(api_check_fn__13481__auto___47732.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47732.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnect",ns_obj_47716,"onConnect") : api_check_fn__13481__auto___47732.call(null,"chrome.runtime.onConnect",ns_obj_47716,"onConnect"));

var event_obj__20429__auto__ = (function (){var target_obj_47726 = ns_obj_47716;
var next_obj_47727 = goog.object.get(target_obj_47726,"onConnect");
return next_obj_47727;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_connect_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_connect_STAR_.cljs$lang$applyTo = (function (seq47711){
var G__47712 = cljs.core.first(seq47711);
var seq47711__$1 = cljs.core.next(seq47711);
var G__47713 = cljs.core.first(seq47711__$1);
var seq47711__$2 = cljs.core.next(seq47711__$1);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__47712,G__47713,seq47711__$2);
});

chromex.ext.runtime.on_connect_external_STAR_ = (function chromex$ext$runtime$on_connect_external_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47750 = arguments.length;
var i__8119__auto___47751 = (0);
while(true){
if((i__8119__auto___47751 < len__8118__auto___47750)){
args__8125__auto__.push((arguments[i__8119__auto___47751]));

var G__47752 = (i__8119__auto___47751 + (1));
i__8119__auto___47751 = G__47752;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_47736 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47741 = config__13447__auto__;
var G__47742 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_external;
var G__47743 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47741,G__47742,G__47743) : handler__13449__auto__.call(null,G__47741,G__47742,G__47743));
})();
var handler_fn_47737 = ((function (event_fn_47736){
return (function (cb_port_47739){
var G__47744 = chromex.marshalling.from_native_chrome_port(config,cb_port_47739);
return (event_fn_47736.cljs$core$IFn$_invoke$arity$1 ? event_fn_47736.cljs$core$IFn$_invoke$arity$1(G__47744) : event_fn_47736.call(null,G__47744));
});})(event_fn_47736))
;
var logging_fn__20428__auto__ = ((function (event_fn_47736,handler_fn_47737){
return (function (cb_param_port_47740){

return handler_fn_47737(cb_param_port_47740);
});})(event_fn_47736,handler_fn_47737))
;
var ns_obj_47738 = (function (){var target_obj_47745 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47746 = goog.object.get(target_obj_47745,"chrome");
var next_obj_47747 = goog.object.get(next_obj_47746,"runtime");
return next_obj_47747;
})();
var config__13480__auto___47753 = config;
var api_check_fn__13481__auto___47754 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47753);

(api_check_fn__13481__auto___47754.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47754.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectExternal",ns_obj_47738,"onConnectExternal") : api_check_fn__13481__auto___47754.call(null,"chrome.runtime.onConnectExternal",ns_obj_47738,"onConnectExternal"));

var event_obj__20429__auto__ = (function (){var target_obj_47748 = ns_obj_47738;
var next_obj_47749 = goog.object.get(target_obj_47748,"onConnectExternal");
return next_obj_47749;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$applyTo = (function (seq47733){
var G__47734 = cljs.core.first(seq47733);
var seq47733__$1 = cljs.core.next(seq47733);
var G__47735 = cljs.core.first(seq47733__$1);
var seq47733__$2 = cljs.core.next(seq47733__$1);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__47734,G__47735,seq47733__$2);
});

chromex.ext.runtime.on_message_STAR_ = (function chromex$ext$runtime$on_message_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47775 = arguments.length;
var i__8119__auto___47776 = (0);
while(true){
if((i__8119__auto___47776 < len__8118__auto___47775)){
args__8125__auto__.push((arguments[i__8119__auto___47776]));

var G__47777 = (i__8119__auto___47776 + (1));
i__8119__auto___47776 = G__47777;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_47758 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47767 = config__13447__auto__;
var G__47768 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message;
var G__47769 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47767,G__47768,G__47769) : handler__13449__auto__.call(null,G__47767,G__47768,G__47769));
})();
var handler_fn_47759 = ((function (event_fn_47758){
return (function (cb_message_47761,cb_sender_47762,cb_send_response_47763){
return (event_fn_47758.cljs$core$IFn$_invoke$arity$3 ? event_fn_47758.cljs$core$IFn$_invoke$arity$3(cb_message_47761,cb_sender_47762,cb_send_response_47763) : event_fn_47758.call(null,cb_message_47761,cb_sender_47762,cb_send_response_47763));
});})(event_fn_47758))
;
var logging_fn__20428__auto__ = ((function (event_fn_47758,handler_fn_47759){
return (function (cb_param_message_47764,cb_param_sender_47765,cb_param_send_response_47766){

return handler_fn_47759(cb_param_message_47764,cb_param_sender_47765,cb_param_send_response_47766);
});})(event_fn_47758,handler_fn_47759))
;
var ns_obj_47760 = (function (){var target_obj_47770 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47771 = goog.object.get(target_obj_47770,"chrome");
var next_obj_47772 = goog.object.get(next_obj_47771,"runtime");
return next_obj_47772;
})();
var config__13480__auto___47778 = config;
var api_check_fn__13481__auto___47779 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47778);

(api_check_fn__13481__auto___47779.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47779.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessage",ns_obj_47760,"onMessage") : api_check_fn__13481__auto___47779.call(null,"chrome.runtime.onMessage",ns_obj_47760,"onMessage"));

var event_obj__20429__auto__ = (function (){var target_obj_47773 = ns_obj_47760;
var next_obj_47774 = goog.object.get(target_obj_47773,"onMessage");
return next_obj_47774;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_message_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_message_STAR_.cljs$lang$applyTo = (function (seq47755){
var G__47756 = cljs.core.first(seq47755);
var seq47755__$1 = cljs.core.next(seq47755);
var G__47757 = cljs.core.first(seq47755__$1);
var seq47755__$2 = cljs.core.next(seq47755__$1);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__47756,G__47757,seq47755__$2);
});

chromex.ext.runtime.on_message_external_STAR_ = (function chromex$ext$runtime$on_message_external_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47800 = arguments.length;
var i__8119__auto___47801 = (0);
while(true){
if((i__8119__auto___47801 < len__8118__auto___47800)){
args__8125__auto__.push((arguments[i__8119__auto___47801]));

var G__47802 = (i__8119__auto___47801 + (1));
i__8119__auto___47801 = G__47802;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_47783 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47792 = config__13447__auto__;
var G__47793 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message_DASH_external;
var G__47794 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47792,G__47793,G__47794) : handler__13449__auto__.call(null,G__47792,G__47793,G__47794));
})();
var handler_fn_47784 = ((function (event_fn_47783){
return (function (cb_message_47786,cb_sender_47787,cb_send_response_47788){
return (event_fn_47783.cljs$core$IFn$_invoke$arity$3 ? event_fn_47783.cljs$core$IFn$_invoke$arity$3(cb_message_47786,cb_sender_47787,cb_send_response_47788) : event_fn_47783.call(null,cb_message_47786,cb_sender_47787,cb_send_response_47788));
});})(event_fn_47783))
;
var logging_fn__20428__auto__ = ((function (event_fn_47783,handler_fn_47784){
return (function (cb_param_message_47789,cb_param_sender_47790,cb_param_send_response_47791){

return handler_fn_47784(cb_param_message_47789,cb_param_sender_47790,cb_param_send_response_47791);
});})(event_fn_47783,handler_fn_47784))
;
var ns_obj_47785 = (function (){var target_obj_47795 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47796 = goog.object.get(target_obj_47795,"chrome");
var next_obj_47797 = goog.object.get(next_obj_47796,"runtime");
return next_obj_47797;
})();
var config__13480__auto___47803 = config;
var api_check_fn__13481__auto___47804 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47803);

(api_check_fn__13481__auto___47804.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47804.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessageExternal",ns_obj_47785,"onMessageExternal") : api_check_fn__13481__auto___47804.call(null,"chrome.runtime.onMessageExternal",ns_obj_47785,"onMessageExternal"));

var event_obj__20429__auto__ = (function (){var target_obj_47798 = ns_obj_47785;
var next_obj_47799 = goog.object.get(target_obj_47798,"onMessageExternal");
return next_obj_47799;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_message_external_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_message_external_STAR_.cljs$lang$applyTo = (function (seq47780){
var G__47781 = cljs.core.first(seq47780);
var seq47780__$1 = cljs.core.next(seq47780);
var G__47782 = cljs.core.first(seq47780__$1);
var seq47780__$2 = cljs.core.next(seq47780__$1);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__47781,G__47782,seq47780__$2);
});

chromex.ext.runtime.on_restart_required_STAR_ = (function chromex$ext$runtime$on_restart_required_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47821 = arguments.length;
var i__8119__auto___47822 = (0);
while(true){
if((i__8119__auto___47822 < len__8118__auto___47821)){
args__8125__auto__.push((arguments[i__8119__auto___47822]));

var G__47823 = (i__8119__auto___47822 + (1));
i__8119__auto___47822 = G__47823;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_47808 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__47813 = config__13447__auto__;
var G__47814 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_restart_DASH_required;
var G__47815 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__47813,G__47814,G__47815) : handler__13449__auto__.call(null,G__47813,G__47814,G__47815));
})();
var handler_fn_47809 = ((function (event_fn_47808){
return (function (cb_reason_47811){
return (event_fn_47808.cljs$core$IFn$_invoke$arity$1 ? event_fn_47808.cljs$core$IFn$_invoke$arity$1(cb_reason_47811) : event_fn_47808.call(null,cb_reason_47811));
});})(event_fn_47808))
;
var logging_fn__20428__auto__ = ((function (event_fn_47808,handler_fn_47809){
return (function (cb_param_reason_47812){

return handler_fn_47809(cb_param_reason_47812);
});})(event_fn_47808,handler_fn_47809))
;
var ns_obj_47810 = (function (){var target_obj_47816 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47817 = goog.object.get(target_obj_47816,"chrome");
var next_obj_47818 = goog.object.get(next_obj_47817,"runtime");
return next_obj_47818;
})();
var config__13480__auto___47824 = config;
var api_check_fn__13481__auto___47825 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___47824);

(api_check_fn__13481__auto___47825.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___47825.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onRestartRequired",ns_obj_47810,"onRestartRequired") : api_check_fn__13481__auto___47825.call(null,"chrome.runtime.onRestartRequired",ns_obj_47810,"onRestartRequired"));

var event_obj__20429__auto__ = (function (){var target_obj_47819 = ns_obj_47810;
var next_obj_47820 = goog.object.get(target_obj_47819,"onRestartRequired");
return next_obj_47820;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$applyTo = (function (seq47805){
var G__47806 = cljs.core.first(seq47805);
var seq47805__$1 = cljs.core.next(seq47805);
var G__47807 = cljs.core.first(seq47805__$1);
var seq47805__$2 = cljs.core.next(seq47805__$1);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__47806,G__47807,seq47805__$2);
});


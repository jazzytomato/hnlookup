// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.support');
goog.require('cljs.core');
goog.require('goog.object');
chromex.support.prepare_final_args_array = (function chromex$support$prepare_final_args_array(arg_descriptors,api){
var should_omit_QMARK_ = (function (p__42780){
var vec__42781 = p__42780;
var val = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42781,(0),null);
var param_name = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42781,(1),null);
var can_be_omitted_QMARK_ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42781,(2),null);
if(cljs.core.keyword_identical_QMARK_(val,cljs.core.cst$kw$omit)){

return true;
} else {
return null;
}
});
return cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(cljs.core.map.cljs$core$IFn$_invoke$arity$2(cljs.core.first,cljs.core.remove.cljs$core$IFn$_invoke$arity$2(should_omit_QMARK_,arg_descriptors)));
});

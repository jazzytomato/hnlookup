// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.defaults');
goog.require('cljs.core');
goog.require('cljs.core.async');
goog.require('chromex.support');
goog.require('oops.core');
goog.require('goog.object');
goog.require('chromex.error');
goog.require('chromex.protocols');
chromex.defaults.log_prefix = "[chromex]";
chromex.defaults.console_log = (function chromex$defaults$console_log(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47007 = arguments.length;
var i__8119__auto___47008 = (0);
while(true){
if((i__8119__auto___47008 < len__8118__auto___47007)){
args__8125__auto__.push((arguments[i__8119__auto___47008]));

var G__47009 = (i__8119__auto___47008 + (1));
i__8119__auto___47008 = G__47009;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.log.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(args));
});

chromex.defaults.console_log.cljs$lang$maxFixedArity = (0);

chromex.defaults.console_log.cljs$lang$applyTo = (function (seq47006){
return chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq47006));
});

chromex.defaults.console_error = (function chromex$defaults$console_error(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47011 = arguments.length;
var i__8119__auto___47012 = (0);
while(true){
if((i__8119__auto___47012 < len__8118__auto___47011)){
args__8125__auto__.push((arguments[i__8119__auto___47012]));

var G__47013 = (i__8119__auto___47012 + (1));
i__8119__auto___47012 = G__47013;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.error.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(args));
});

chromex.defaults.console_error.cljs$lang$maxFixedArity = (0);

chromex.defaults.console_error.cljs$lang$applyTo = (function (seq47010){
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq47010));
});

chromex.defaults.default_logger = (function chromex$defaults$default_logger(var_args){
var args__8125__auto__ = [];
var len__8118__auto___47015 = arguments.length;
var i__8119__auto___47016 = (0);
while(true){
if((i__8119__auto___47016 < len__8118__auto___47015)){
args__8125__auto__.push((arguments[i__8119__auto___47016]));

var G__47017 = (i__8119__auto___47016 + (1));
i__8119__auto___47016 = G__47017;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return cljs.core.apply.cljs$core$IFn$_invoke$arity$3(chromex.defaults.console_log,chromex.defaults.log_prefix,args);
});

chromex.defaults.default_logger.cljs$lang$maxFixedArity = (0);

chromex.defaults.default_logger.cljs$lang$applyTo = (function (seq47014){
return chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq47014));
});

chromex.defaults.default_callback_error_reporter = (function chromex$defaults$default_callback_error_reporter(descriptor,error){
var function$ = (function (){var or__6939__auto__ = [cljs.core.str(cljs.core.namespace(cljs.core.cst$kw$id.cljs$core$IFn$_invoke$arity$1(descriptor))),cljs.core.str("/"),cljs.core.str(cljs.core.name(cljs.core.cst$kw$id.cljs$core$IFn$_invoke$arity$1(descriptor)))].join('');
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return "an unknown function";
}
})();
var explanation = (function (){var target_obj_47020 = error;
var next_obj_47021 = goog.object.get(target_obj_47020,"message");
return next_obj_47021;
})();
var message = [cljs.core.str("an error occured during the call to "),cljs.core.str(function$),cljs.core.str((cljs.core.truth_(explanation)?[cljs.core.str(": "),cljs.core.str(explanation)].join(''):null))].join('');
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([chromex.defaults.log_prefix,message,"Details:",error], 0));
});
chromex.defaults.report_error_if_needed_BANG_ = (function chromex$defaults$report_error_if_needed_BANG_(config,descriptor,error){
var temp__6728__auto__ = cljs.core.cst$kw$callback_DASH_error_DASH_reporter.cljs$core$IFn$_invoke$arity$1(config);
if(cljs.core.truth_(temp__6728__auto__)){
var error_reporter = temp__6728__auto__;

return (error_reporter.cljs$core$IFn$_invoke$arity$2 ? error_reporter.cljs$core$IFn$_invoke$arity$2(descriptor,error) : error_reporter.call(null,descriptor,error));
} else {
return null;
}
});
chromex.defaults.default_callback_fn_factory = (function chromex$defaults$default_callback_fn_factory(config,descriptor,chan){
return (function() { 
var G__47028__delegate = function (args){
var temp__6726__auto___47029 = (function (){var target_obj_47025 = chrome;
var next_obj_47026 = goog.object.get(target_obj_47025,"runtime");
var next_obj_47027 = goog.object.get(next_obj_47026,"lastError");
if(!((next_obj_47027 == null))){
return next_obj_47027;
} else {
return null;
}
})();
if(cljs.core.truth_(temp__6726__auto___47029)){
var error_47030 = temp__6726__auto___47029;
chromex.error.set_last_error_BANG_(error_47030);

chromex.defaults.report_error_if_needed_BANG_(config,descriptor,error_47030);
} else {
chromex.error.set_last_error_BANG_(null);

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,cljs.core.vec(args));
}

return cljs.core.async.close_BANG_(chan);
};
var G__47028 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__47031__i = 0, G__47031__a = new Array(arguments.length -  0);
while (G__47031__i < G__47031__a.length) {G__47031__a[G__47031__i] = arguments[G__47031__i + 0]; ++G__47031__i;}
  args = new cljs.core.IndexedSeq(G__47031__a,0);
} 
return G__47028__delegate.call(this,args);};
G__47028.cljs$lang$maxFixedArity = 0;
G__47028.cljs$lang$applyTo = (function (arglist__47032){
var args = cljs.core.seq(arglist__47032);
return G__47028__delegate(args);
});
G__47028.cljs$core$IFn$_invoke$arity$variadic = G__47028__delegate;
return G__47028;
})()
;
});
chromex.defaults.default_callback_channel_factory = (function chromex$defaults$default_callback_channel_factory(_config){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_event_listener_factory = (function chromex$defaults$default_event_listener_factory(_config,event_id,chan){
return (function() { 
var G__47033__delegate = function (args){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [event_id,cljs.core.vec(args)], null));
};
var G__47033 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__47034__i = 0, G__47034__a = new Array(arguments.length -  0);
while (G__47034__i < G__47034__a.length) {G__47034__a[G__47034__i] = arguments[G__47034__i + 0]; ++G__47034__i;}
  args = new cljs.core.IndexedSeq(G__47034__a,0);
} 
return G__47033__delegate.call(this,args);};
G__47033.cljs$lang$maxFixedArity = 0;
G__47033.cljs$lang$applyTo = (function (arglist__47035){
var args = cljs.core.seq(arglist__47035);
return G__47033__delegate(args);
});
G__47033.cljs$core$IFn$_invoke$arity$variadic = G__47033__delegate;
return G__47033;
})()
;
});
chromex.defaults.default_missing_api_check = (function chromex$defaults$default_missing_api_check(api,obj,key){
if(cljs.core.not(goog.object.containsKey(obj,key))){
throw (new Error([cljs.core.str("Chromex library tried to access a missing Chrome API object '"),cljs.core.str(api),cljs.core.str("'.\n"),cljs.core.str("Your Chrome version might be too old or too recent for running this extension.\n"),cljs.core.str("This is a failure which probably requires a software update.")].join('')));
} else {
return null;
}
});
chromex.defaults.default_chrome_storage_area_callback_fn_factory = (function chromex$defaults$default_chrome_storage_area_callback_fn_factory(config,chan){
return (function() { 
var G__47044__delegate = function (args){
var last_error = (function (){var target_obj_47040 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_47041 = goog.object.get(target_obj_47040,"chrome");
var next_obj_47042 = goog.object.get(next_obj_47041,"runtime");
var next_obj_47043 = goog.object.get(next_obj_47042,"lastError");
if(!((next_obj_47043 == null))){
return next_obj_47043;
} else {
return null;
}
})();
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vec(args),last_error], null));
};
var G__47044 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__47045__i = 0, G__47045__a = new Array(arguments.length -  0);
while (G__47045__i < G__47045__a.length) {G__47045__a[G__47045__i] = arguments[G__47045__i + 0]; ++G__47045__i;}
  args = new cljs.core.IndexedSeq(G__47045__a,0);
} 
return G__47044__delegate.call(this,args);};
G__47044.cljs$lang$maxFixedArity = 0;
G__47044.cljs$lang$applyTo = (function (arglist__47046){
var args = cljs.core.seq(arglist__47046);
return G__47044__delegate(args);
});
G__47044.cljs$core$IFn$_invoke$arity$variadic = G__47044__delegate;
return G__47044;
})()
;
});
chromex.defaults.default_chrome_storage_area_callback_channel_factory = (function chromex$defaults$default_chrome_storage_area_callback_channel_factory(_config){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_port_channel_factory = (function chromex$defaults$default_chrome_port_channel_factory(_config){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_port_on_message_fn_factory = (function chromex$defaults$default_chrome_port_on_message_fn_factory(config,chrome_port){
return (function (message){
if((message == null)){
var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_received_DASH_nil_DASH_message;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$2(config__13447__auto__,chrome_port) : handler__13449__auto__.call(null,config__13447__auto__,chrome_port));
} else {
chromex.protocols.put_message_BANG_(chrome_port,message);

return null;
}
});
});
chromex.defaults.default_chrome_port_on_disconnect_fn_factory = (function chromex$defaults$default_chrome_port_on_disconnect_fn_factory(_config,chrome_port){
return (function (){
chromex.protocols.close_resources_BANG_(chrome_port);

chromex.protocols.set_connected_BANG_(chrome_port,false);

return null;
});
});
chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_disconnect_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_post_message_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_disconnect_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_message_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_post_message_called_with_nil = (function chromex$defaults$default_chrome_port_post_message_called_with_nil(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_received_nil_message = (function chromex$defaults$default_chrome_port_received_nil_message(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_put_message_called_on_disconnected_port(_config,_chrome_port,message){
return null;
});
chromex.defaults.default_config = cljs.core.PersistentHashMap.fromArrays([cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_put_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_channel_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_with_DASH_nil,cljs.core.cst$kw$chrome_DASH_port_DASH_channel_DASH_factory,cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn,cljs.core.cst$kw$chrome_DASH_port_DASH_received_DASH_nil_DASH_message,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$root,cljs.core.cst$kw$event_DASH_listener_DASH_factory,cljs.core.cst$kw$callback_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_fn_DASH_factory,cljs.core.cst$kw$callback_DASH_error_DASH_reporter,cljs.core.cst$kw$callback_DASH_channel_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_fn_DASH_factory],[chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port,chromex.defaults.default_chrome_storage_area_callback_channel_factory,chromex.defaults.default_chrome_port_post_message_called_with_nil,chromex.defaults.default_chrome_port_channel_factory,chromex.defaults.default_missing_api_check,chromex.defaults.default_chrome_port_received_nil_message,chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_message_fn_factory,chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port,goog.global,chromex.defaults.default_event_listener_factory,chromex.defaults.default_callback_fn_factory,chromex.defaults.default_chrome_storage_area_callback_fn_factory,chromex.defaults.default_callback_error_reporter,chromex.defaults.default_callback_channel_factory,chromex.defaults.default_chrome_port_on_disconnect_fn_factory]);

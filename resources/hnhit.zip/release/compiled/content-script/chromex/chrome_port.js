// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_port');
goog.require('cljs.core');
goog.require('oops.core');
goog.require('chromex.support');
goog.require('chromex.protocols');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async');

/**
* @constructor
 * @implements {chromex.protocols.IChromePort}
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {chromex.protocols.IChromePortState}
*/
chromex.chrome_port.ChromePort = (function (config,native_chrome_port,channel,connected_QMARK_){
this.config = config;
this.native_chrome_port = native_chrome_port;
this.channel = channel;
this.connected_QMARK_ = connected_QMARK_;
})
chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePort$ = true;

chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePort$get_native_port$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_port;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePort$get_name$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var target_obj_46943 = self__.native_chrome_port;
var next_obj_46944 = goog.object.get(target_obj_46943,"name");
return next_obj_46944;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePort$get_sender$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var target_obj_46945 = self__.native_chrome_port;
var next_obj_46946 = goog.object.get(target_obj_46945,"sender");
return next_obj_46946;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePort$post_message_BANG_$arity$2 = (function (this$,message){
var self__ = this;
var this$__$1 = this;
if((message == null)){
var config__13447__auto__ = self__.config;
var handler_key__13448__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_with_DASH_nil;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$2(config__13447__auto__,this$__$1) : handler__13449__auto__.call(null,config__13447__auto__,this$__$1));
} else {
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_46947 = self__.native_chrome_port;
var fn_46948 = (function (){var next_obj_46949 = goog.object.get(target_obj_46947,"postMessage");
return next_obj_46949;
})();
if(!((fn_46948 == null))){
return fn_46948.call(target_obj_46947,message);
} else {
return null;
}
} else {
var config__13447__auto__ = self__.config;
var handler_key__13448__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$2(config__13447__auto__,this$__$1) : handler__13449__auto__.call(null,config__13447__auto__,this$__$1));
}
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePort$disconnect_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_46950 = self__.native_chrome_port;
var fn_46951 = (function (){var next_obj_46952 = goog.object.get(target_obj_46950,"disconnect");
return next_obj_46952;
})();
if(!((fn_46951 == null))){
return fn_46951.call(target_obj_46950);
} else {
return null;
}
} else {
var config__13447__auto__ = self__.config;
var handler_key__13448__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$2(config__13447__auto__,this$__$1) : handler__13449__auto__.call(null,config__13447__auto__,this$__$1));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePort$on_disconnect_BANG_$arity$2 = (function (this$,callback){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var on_disconnect_event = (function (){var target_obj_46953 = self__.native_chrome_port;
var next_obj_46954 = goog.object.get(target_obj_46953,"onDisconnect");
return next_obj_46954;
})();

var target_obj_46955 = on_disconnect_event;
var fn_46956 = (function (){var next_obj_46957 = goog.object.get(target_obj_46955,"addListener");
return next_obj_46957;
})();
if(!((fn_46956 == null))){
return fn_46956.call(target_obj_46955,callback);
} else {
return null;
}
} else {
var config__13447__auto__ = self__.config;
var handler_key__13448__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$2(config__13447__auto__,this$__$1) : handler__13449__auto__.call(null,config__13447__auto__,this$__$1));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePort$on_message_BANG_$arity$2 = (function (this$,callback){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var on_message_event = (function (){var target_obj_46958 = self__.native_chrome_port;
var next_obj_46959 = goog.object.get(target_obj_46958,"onMessage");
return next_obj_46959;
})();

var target_obj_46960 = on_message_event;
var fn_46961 = (function (){var next_obj_46962 = goog.object.get(target_obj_46960,"addListener");
return next_obj_46962;
})();
if(!((fn_46961 == null))){
return fn_46961.call(target_obj_46960,callback);
} else {
return null;
}
} else {
var config__13447__auto__ = self__.config;
var handler_key__13448__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$2(config__13447__auto__,this$__$1) : handler__13449__auto__.call(null,config__13447__auto__,this$__$1));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePortState$ = true;

chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePortState$set_connected_BANG_$arity$2 = (function (_this,val){
var self__ = this;
var _this__$1 = this;
return self__.connected_QMARK_ = val;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePortState$put_message_BANG_$arity$2 = (function (this$,message){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(self__.channel,message);
} else {
var config__13447__auto__ = self__.config;
var handler_key__13448__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_put_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(config__13447__auto__,this$__$1,message) : handler__13449__auto__.call(null,config__13447__auto__,this$__$1,message));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$IChromePortState$close_resources_BANG_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.channel);
});

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_this,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.channel,handler);
});

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$ = true;

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.channel);
});

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return chromex.protocols.disconnect_BANG_(this$__$1);
});

chromex.chrome_port.ChromePort.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$config,cljs.core.cst$sym$native_DASH_chrome_DASH_port,cljs.core.cst$sym$channel,cljs.core.with_meta(cljs.core.cst$sym$connected_QMARK_,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$mutable,true], null))], null);
});

chromex.chrome_port.ChromePort.cljs$lang$type = true;

chromex.chrome_port.ChromePort.cljs$lang$ctorStr = "chromex.chrome-port/ChromePort";

chromex.chrome_port.ChromePort.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"chromex.chrome-port/ChromePort");
});

chromex.chrome_port.__GT_ChromePort = (function chromex$chrome_port$__GT_ChromePort(config,native_chrome_port,channel,connected_QMARK_){
return (new chromex.chrome_port.ChromePort(config,native_chrome_port,channel,connected_QMARK_));
});

chromex.chrome_port.make_chrome_port = (function chromex$chrome_port$make_chrome_port(config,native_chrome_port){

var channel = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var chrome_port = (new chromex.chrome_port.ChromePort(config,native_chrome_port,channel,true));
chrome_port.chromex$protocols$IChromePort$on_message_BANG_$arity$2(null,(function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$2(config__13447__auto__,chrome_port) : handler__13449__auto__.call(null,config__13447__auto__,chrome_port));
})());

chrome_port.chromex$protocols$IChromePort$on_disconnect_BANG_$arity$2(null,(function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$2(config__13447__auto__,chrome_port) : handler__13449__auto__.call(null,config__13447__auto__,chrome_port));
})());

return chrome_port;
});

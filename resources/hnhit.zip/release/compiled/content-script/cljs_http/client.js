// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('cljs_http.client');
goog.require('cljs.core');
goog.require('goog.Uri');
goog.require('cljs_http.core');
goog.require('no.en.core');
goog.require('cljs_http.util');
goog.require('cljs.core.async');
goog.require('clojure.string');
goog.require('cljs.reader');
cljs_http.client.if_pos = (function cljs_http$client$if_pos(v){
if(cljs.core.truth_((function (){var and__6927__auto__ = v;
if(cljs.core.truth_(and__6927__auto__)){
return (v > (0));
} else {
return and__6927__auto__;
}
})())){
return v;
} else {
return null;
}
});
/**
 * Parse `s` as query params and return a hash map.
 */
cljs_http.client.parse_query_params = (function cljs_http$client$parse_query_params(s){
if(!(clojure.string.blank_QMARK_(s))){
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3((function (p1__48061_SHARP_,p2__48060_SHARP_){
var vec__48065 = clojure.string.split.cljs$core$IFn$_invoke$arity$2(p2__48060_SHARP_,/=/);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48065,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48065,(1),null);
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__48061_SHARP_,cljs.core.keyword.cljs$core$IFn$_invoke$arity$1(no.en.core.url_decode(k)),no.en.core.url_decode(v));
}),cljs.core.PersistentArrayMap.EMPTY,clojure.string.split.cljs$core$IFn$_invoke$arity$2([cljs.core.str(s)].join(''),/&/));
} else {
return null;
}
});
/**
 * Parse `url` into a hash map.
 */
cljs_http.client.parse_url = (function cljs_http$client$parse_url(url){
if(!(clojure.string.blank_QMARK_(url))){
var uri = goog.Uri.parse(url);
var query_data = uri.getQueryData();
return new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$scheme,cljs.core.keyword.cljs$core$IFn$_invoke$arity$1(uri.getScheme()),cljs.core.cst$kw$server_DASH_name,uri.getDomain(),cljs.core.cst$kw$server_DASH_port,cljs_http.client.if_pos(uri.getPort()),cljs.core.cst$kw$uri,uri.getPath(),cljs.core.cst$kw$query_DASH_string,((cljs.core.not(query_data.isEmpty()))?[cljs.core.str(query_data)].join(''):null),cljs.core.cst$kw$query_DASH_params,((cljs.core.not(query_data.isEmpty()))?cljs_http.client.parse_query_params([cljs.core.str(query_data)].join('')):null)], null);
} else {
return null;
}
});
cljs_http.client.unexceptional_status_QMARK_ = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 13, [(205),null,(206),null,(300),null,(204),null,(307),null,(303),null,(301),null,(201),null,(302),null,(202),null,(200),null,(203),null,(207),null], null), null);
cljs_http.client.generate_query_string = (function cljs_http$client$generate_query_string(params){
return clojure.string.join.cljs$core$IFn$_invoke$arity$2("&",cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p__48072){
var vec__48073 = p__48072;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48073,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48073,(1),null);
return [cljs.core.str(no.en.core.url_encode(cljs.core.name(k))),cljs.core.str("="),cljs.core.str(no.en.core.url_encode([cljs.core.str(v)].join('')))].join('');
}),params));
});
/**
 * Decocde the :body of `response` with `decode-fn` if the content type matches.
 */
cljs_http.client.decode_body = (function cljs_http$client$decode_body(response,decode_fn,content_type){
if(cljs.core.truth_(cljs.core.re_find(cljs.core.re_pattern([cljs.core.str("(?i)"),cljs.core.str(content_type)].join('')),[cljs.core.str(cljs.core.get.cljs$core$IFn$_invoke$arity$3(cljs.core.cst$kw$headers.cljs$core$IFn$_invoke$arity$1(response),"content-type",""))].join('')))){
return cljs.core.update_in.cljs$core$IFn$_invoke$arity$3(response,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$body], null),decode_fn);
} else {
return response;
}
});
/**
 * Encode :edn-params in the `request` :body and set the appropriate
 *   Content Type header.
 */
cljs_http.client.wrap_edn_params = (function cljs_http$client$wrap_edn_params(client){
return (function (request){
var temp__6726__auto__ = cljs.core.cst$kw$edn_DASH_params.cljs$core$IFn$_invoke$arity$1(request);
if(cljs.core.truth_(temp__6726__auto__)){
var params = temp__6726__auto__;
var G__48077 = cljs.core.assoc_in(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(request,cljs.core.cst$kw$edn_DASH_params),cljs.core.cst$kw$body,cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([params], 0))),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"content-type"], null),"application/edn");
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__48077) : client.call(null,G__48077));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
}
});
});
/**
 * Decode application/edn responses.
 */
cljs_http.client.wrap_edn_response = (function cljs_http$client$wrap_edn_response(client){
return (function (request){
var channel = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__15224__auto___48112 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___48112,channel){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___48112,channel){
return (function (state_48102){
var state_val_48103 = (state_48102[(1)]);
if((state_val_48103 === (1))){
var inst_48095 = (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
var state_48102__$1 = state_48102;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_48102__$1,(2),inst_48095);
} else {
if((state_val_48103 === (2))){
var inst_48097 = (state_48102[(2)]);
var inst_48098 = cljs_http.client.decode_body(inst_48097,cljs.reader.read_string,"application/edn");
var inst_48099 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(channel,inst_48098);
var inst_48100 = cljs.core.async.close_BANG_(channel);
var state_48102__$1 = (function (){var statearr_48104 = state_48102;
(statearr_48104[(7)] = inst_48099);

return statearr_48104;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_48102__$1,inst_48100);
} else {
return null;
}
}
});})(c__15224__auto___48112,channel))
;
return ((function (switch__15098__auto__,c__15224__auto___48112,channel){
return (function() {
var cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__ = null;
var cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____0 = (function (){
var statearr_48108 = [null,null,null,null,null,null,null,null];
(statearr_48108[(0)] = cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__);

(statearr_48108[(1)] = (1));

return statearr_48108;
});
var cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____1 = (function (state_48102){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_48102);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e48109){if((e48109 instanceof Object)){
var ex__15102__auto__ = e48109;
var statearr_48110_48113 = state_48102;
(statearr_48110_48113[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_48102);

return cljs.core.cst$kw$recur;
} else {
throw e48109;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__48114 = state_48102;
state_48102 = G__48114;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__ = function(state_48102){
switch(arguments.length){
case 0:
return cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____0.call(this);
case 1:
return cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____1.call(this,state_48102);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____0;
cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____1;
return cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___48112,channel))
})();
var state__15226__auto__ = (function (){var statearr_48111 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_48111[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___48112);

return statearr_48111;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___48112,channel))
);


return channel;
});
});
cljs_http.client.wrap_accept = (function cljs_http$client$wrap_accept(var_args){
var args__8125__auto__ = [];
var len__8118__auto___48122 = arguments.length;
var i__8119__auto___48123 = (0);
while(true){
if((i__8119__auto___48123 < len__8118__auto___48122)){
args__8125__auto__.push((arguments[i__8119__auto___48123]));

var G__48124 = (i__8119__auto___48123 + (1));
i__8119__auto___48123 = G__48124;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.wrap_accept.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.wrap_accept.cljs$core$IFn$_invoke$arity$variadic = (function (client,p__48117){
var vec__48118 = p__48117;
var accept = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48118,(0),null);
return ((function (vec__48118,accept){
return (function (request){
var temp__6726__auto__ = (function (){var or__6939__auto__ = cljs.core.cst$kw$accept.cljs$core$IFn$_invoke$arity$1(request);
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return accept;
}
})();
if(cljs.core.truth_(temp__6726__auto__)){
var accept__$1 = temp__6726__auto__;
var G__48121 = cljs.core.assoc_in(request,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"accept"], null),accept__$1);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__48121) : client.call(null,G__48121));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
}
});
;})(vec__48118,accept))
});

cljs_http.client.wrap_accept.cljs$lang$maxFixedArity = (1);

cljs_http.client.wrap_accept.cljs$lang$applyTo = (function (seq48115){
var G__48116 = cljs.core.first(seq48115);
var seq48115__$1 = cljs.core.next(seq48115);
return cljs_http.client.wrap_accept.cljs$core$IFn$_invoke$arity$variadic(G__48116,seq48115__$1);
});

cljs_http.client.wrap_content_type = (function cljs_http$client$wrap_content_type(var_args){
var args__8125__auto__ = [];
var len__8118__auto___48132 = arguments.length;
var i__8119__auto___48133 = (0);
while(true){
if((i__8119__auto___48133 < len__8118__auto___48132)){
args__8125__auto__.push((arguments[i__8119__auto___48133]));

var G__48134 = (i__8119__auto___48133 + (1));
i__8119__auto___48133 = G__48134;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.wrap_content_type.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.wrap_content_type.cljs$core$IFn$_invoke$arity$variadic = (function (client,p__48127){
var vec__48128 = p__48127;
var content_type = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48128,(0),null);
return ((function (vec__48128,content_type){
return (function (request){
var temp__6726__auto__ = (function (){var or__6939__auto__ = cljs.core.cst$kw$content_DASH_type.cljs$core$IFn$_invoke$arity$1(request);
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return content_type;
}
})();
if(cljs.core.truth_(temp__6726__auto__)){
var content_type__$1 = temp__6726__auto__;
var G__48131 = cljs.core.assoc_in(request,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"content-type"], null),content_type__$1);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__48131) : client.call(null,G__48131));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
}
});
;})(vec__48128,content_type))
});

cljs_http.client.wrap_content_type.cljs$lang$maxFixedArity = (1);

cljs_http.client.wrap_content_type.cljs$lang$applyTo = (function (seq48125){
var G__48126 = cljs.core.first(seq48125);
var seq48125__$1 = cljs.core.next(seq48125);
return cljs_http.client.wrap_content_type.cljs$core$IFn$_invoke$arity$variadic(G__48126,seq48125__$1);
});

/**
 * Encode :json-params in the `request` :body and set the appropriate
 *   Content Type header.
 */
cljs_http.client.wrap_json_params = (function cljs_http$client$wrap_json_params(client){
return (function (request){
var temp__6726__auto__ = cljs.core.cst$kw$json_DASH_params.cljs$core$IFn$_invoke$arity$1(request);
if(cljs.core.truth_(temp__6726__auto__)){
var params = temp__6726__auto__;
var G__48136 = cljs.core.assoc_in(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(request,cljs.core.cst$kw$json_DASH_params),cljs.core.cst$kw$body,cljs_http.util.json_encode(params)),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"content-type"], null),"application/json");
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__48136) : client.call(null,G__48136));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
}
});
});
/**
 * Decode application/json responses.
 */
cljs_http.client.wrap_json_response = (function cljs_http$client$wrap_json_response(client){
return (function (request){
var channel = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__15224__auto___48171 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___48171,channel){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___48171,channel){
return (function (state_48161){
var state_val_48162 = (state_48161[(1)]);
if((state_val_48162 === (1))){
var inst_48154 = (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
var state_48161__$1 = state_48161;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_48161__$1,(2),inst_48154);
} else {
if((state_val_48162 === (2))){
var inst_48156 = (state_48161[(2)]);
var inst_48157 = cljs_http.client.decode_body(inst_48156,cljs_http.util.json_decode,"application/json");
var inst_48158 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(channel,inst_48157);
var inst_48159 = cljs.core.async.close_BANG_(channel);
var state_48161__$1 = (function (){var statearr_48163 = state_48161;
(statearr_48163[(7)] = inst_48158);

return statearr_48163;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_48161__$1,inst_48159);
} else {
return null;
}
}
});})(c__15224__auto___48171,channel))
;
return ((function (switch__15098__auto__,c__15224__auto___48171,channel){
return (function() {
var cljs_http$client$wrap_json_response_$_state_machine__15099__auto__ = null;
var cljs_http$client$wrap_json_response_$_state_machine__15099__auto____0 = (function (){
var statearr_48167 = [null,null,null,null,null,null,null,null];
(statearr_48167[(0)] = cljs_http$client$wrap_json_response_$_state_machine__15099__auto__);

(statearr_48167[(1)] = (1));

return statearr_48167;
});
var cljs_http$client$wrap_json_response_$_state_machine__15099__auto____1 = (function (state_48161){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_48161);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e48168){if((e48168 instanceof Object)){
var ex__15102__auto__ = e48168;
var statearr_48169_48172 = state_48161;
(statearr_48169_48172[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_48161);

return cljs.core.cst$kw$recur;
} else {
throw e48168;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__48173 = state_48161;
state_48161 = G__48173;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs_http$client$wrap_json_response_$_state_machine__15099__auto__ = function(state_48161){
switch(arguments.length){
case 0:
return cljs_http$client$wrap_json_response_$_state_machine__15099__auto____0.call(this);
case 1:
return cljs_http$client$wrap_json_response_$_state_machine__15099__auto____1.call(this,state_48161);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs_http$client$wrap_json_response_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs_http$client$wrap_json_response_$_state_machine__15099__auto____0;
cljs_http$client$wrap_json_response_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs_http$client$wrap_json_response_$_state_machine__15099__auto____1;
return cljs_http$client$wrap_json_response_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___48171,channel))
})();
var state__15226__auto__ = (function (){var statearr_48170 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_48170[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___48171);

return statearr_48170;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___48171,channel))
);


return channel;
});
});
cljs_http.client.wrap_query_params = (function cljs_http$client$wrap_query_params(client){
return (function (p__48178){
var map__48179 = p__48178;
var map__48179__$1 = ((((!((map__48179 == null)))?((((map__48179.cljs$lang$protocol_mask$partition0$ & (64))) || (map__48179.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__48179):map__48179);
var req = map__48179__$1;
var query_params = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__48179__$1,cljs.core.cst$kw$query_DASH_params);
if(cljs.core.truth_(query_params)){
var G__48181 = cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(req,cljs.core.cst$kw$query_DASH_params),cljs.core.cst$kw$query_DASH_string,cljs_http.client.generate_query_string(query_params));
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__48181) : client.call(null,G__48181));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(req) : client.call(null,req));
}
});
});
cljs_http.client.wrap_android_cors_bugfix = (function cljs_http$client$wrap_android_cors_bugfix(client){
return (function (request){
var G__48183 = (cljs.core.truth_(cljs_http.util.android_QMARK_())?cljs.core.assoc_in(request,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$query_DASH_params,cljs.core.cst$kw$android], null),Math.random()):request);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__48183) : client.call(null,G__48183));
});
});
cljs_http.client.wrap_method = (function cljs_http$client$wrap_method(client){
return (function (req){
var temp__6726__auto__ = cljs.core.cst$kw$method.cljs$core$IFn$_invoke$arity$1(req);
if(cljs.core.truth_(temp__6726__auto__)){
var m = temp__6726__auto__;
var G__48185 = cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(req,cljs.core.cst$kw$method),cljs.core.cst$kw$request_DASH_method,m);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__48185) : client.call(null,G__48185));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(req) : client.call(null,req));
}
});
});
cljs_http.client.wrap_server_name = (function cljs_http$client$wrap_server_name(client,server_name){
return (function (p1__48186_SHARP_){
var G__48188 = cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__48186_SHARP_,cljs.core.cst$kw$server_DASH_name,server_name);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__48188) : client.call(null,G__48188));
});
});
cljs_http.client.wrap_url = (function cljs_http$client$wrap_url(client){
return (function (p__48194){
var map__48195 = p__48194;
var map__48195__$1 = ((((!((map__48195 == null)))?((((map__48195.cljs$lang$protocol_mask$partition0$ & (64))) || (map__48195.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__48195):map__48195);
var req = map__48195__$1;
var query_params = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__48195__$1,cljs.core.cst$kw$query_DASH_params);
var temp__6726__auto__ = cljs_http.client.parse_url(cljs.core.cst$kw$url.cljs$core$IFn$_invoke$arity$1(req));
if(cljs.core.truth_(temp__6726__auto__)){
var spec = temp__6726__auto__;
var G__48197 = cljs.core.update_in.cljs$core$IFn$_invoke$arity$3(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,spec], 0)),cljs.core.cst$kw$url),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$query_DASH_params], null),((function (spec,temp__6726__auto__,map__48195,map__48195__$1,req,query_params){
return (function (p1__48189_SHARP_){
return cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([p1__48189_SHARP_,query_params], 0));
});})(spec,temp__6726__auto__,map__48195,map__48195__$1,req,query_params))
);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__48197) : client.call(null,G__48197));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(req) : client.call(null,req));
}
});
});
/**
 * Middleware converting the :basic-auth option or `credentials` into
 *   an Authorization header.
 */
cljs_http.client.wrap_basic_auth = (function cljs_http$client$wrap_basic_auth(var_args){
var args__8125__auto__ = [];
var len__8118__auto___48205 = arguments.length;
var i__8119__auto___48206 = (0);
while(true){
if((i__8119__auto___48206 < len__8118__auto___48205)){
args__8125__auto__.push((arguments[i__8119__auto___48206]));

var G__48207 = (i__8119__auto___48206 + (1));
i__8119__auto___48206 = G__48207;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.wrap_basic_auth.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.wrap_basic_auth.cljs$core$IFn$_invoke$arity$variadic = (function (client,p__48200){
var vec__48201 = p__48200;
var credentials = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48201,(0),null);
return ((function (vec__48201,credentials){
return (function (req){
var credentials__$1 = (function (){var or__6939__auto__ = cljs.core.cst$kw$basic_DASH_auth.cljs$core$IFn$_invoke$arity$1(req);
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return credentials;
}
})();
if(!(cljs.core.empty_QMARK_(credentials__$1))){
var G__48204 = cljs.core.assoc_in(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(req,cljs.core.cst$kw$basic_DASH_auth),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"authorization"], null),cljs_http.util.basic_auth(credentials__$1));
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__48204) : client.call(null,G__48204));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(req) : client.call(null,req));
}
});
;})(vec__48201,credentials))
});

cljs_http.client.wrap_basic_auth.cljs$lang$maxFixedArity = (1);

cljs_http.client.wrap_basic_auth.cljs$lang$applyTo = (function (seq48198){
var G__48199 = cljs.core.first(seq48198);
var seq48198__$1 = cljs.core.next(seq48198);
return cljs_http.client.wrap_basic_auth.cljs$core$IFn$_invoke$arity$variadic(G__48199,seq48198__$1);
});

/**
 * Middleware converting the :oauth-token option into an Authorization header.
 */
cljs_http.client.wrap_oauth = (function cljs_http$client$wrap_oauth(client){
return (function (req){
var temp__6726__auto__ = cljs.core.cst$kw$oauth_DASH_token.cljs$core$IFn$_invoke$arity$1(req);
if(cljs.core.truth_(temp__6726__auto__)){
var oauth_token = temp__6726__auto__;
var G__48209 = cljs.core.assoc_in(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(req,cljs.core.cst$kw$oauth_DASH_token),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"authorization"], null),[cljs.core.str("Bearer "),cljs.core.str(oauth_token)].join(''));
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__48209) : client.call(null,G__48209));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(req) : client.call(null,req));
}
});
});
/**
 * Returns a battaries-included HTTP request function coresponding to the given
 * core client. See client/client.
 */
cljs_http.client.wrap_request = (function cljs_http$client$wrap_request(request){
return cljs_http.client.wrap_url(cljs_http.client.wrap_method(cljs_http.client.wrap_android_cors_bugfix(cljs_http.client.wrap_oauth(cljs_http.client.wrap_basic_auth(cljs_http.client.wrap_query_params(cljs_http.client.wrap_json_response(cljs_http.client.wrap_json_params(cljs_http.client.wrap_edn_response(cljs_http.client.wrap_edn_params(request))))))))));
});
/**
 * Executes the HTTP request corresponding to the given map and returns the
 * response map for corresponding to the resulting HTTP response.
 * 
 * In addition to the standard Ring request keys, the following keys are also
 * recognized:
 * * :url
 * * :method
 * * :query-params
 */
cljs_http.client.request = cljs_http.client.wrap_request(cljs_http.core.request);
/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.delete$ = (function cljs_http$client$delete(var_args){
var args__8125__auto__ = [];
var len__8118__auto___48217 = arguments.length;
var i__8119__auto___48218 = (0);
while(true){
if((i__8119__auto___48218 < len__8118__auto___48217)){
args__8125__auto__.push((arguments[i__8119__auto___48218]));

var G__48219 = (i__8119__auto___48218 + (1));
i__8119__auto___48218 = G__48219;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.delete$.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.delete$.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__48212){
var vec__48213 = p__48212;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48213,(0),null);
var G__48216 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$delete,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__48216) : cljs_http.client.request.call(null,G__48216));
});

cljs_http.client.delete$.cljs$lang$maxFixedArity = (1);

cljs_http.client.delete$.cljs$lang$applyTo = (function (seq48210){
var G__48211 = cljs.core.first(seq48210);
var seq48210__$1 = cljs.core.next(seq48210);
return cljs_http.client.delete$.cljs$core$IFn$_invoke$arity$variadic(G__48211,seq48210__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.get = (function cljs_http$client$get(var_args){
var args__8125__auto__ = [];
var len__8118__auto___48227 = arguments.length;
var i__8119__auto___48228 = (0);
while(true){
if((i__8119__auto___48228 < len__8118__auto___48227)){
args__8125__auto__.push((arguments[i__8119__auto___48228]));

var G__48229 = (i__8119__auto___48228 + (1));
i__8119__auto___48228 = G__48229;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.get.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.get.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__48222){
var vec__48223 = p__48222;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48223,(0),null);
var G__48226 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$get,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__48226) : cljs_http.client.request.call(null,G__48226));
});

cljs_http.client.get.cljs$lang$maxFixedArity = (1);

cljs_http.client.get.cljs$lang$applyTo = (function (seq48220){
var G__48221 = cljs.core.first(seq48220);
var seq48220__$1 = cljs.core.next(seq48220);
return cljs_http.client.get.cljs$core$IFn$_invoke$arity$variadic(G__48221,seq48220__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.head = (function cljs_http$client$head(var_args){
var args__8125__auto__ = [];
var len__8118__auto___48237 = arguments.length;
var i__8119__auto___48238 = (0);
while(true){
if((i__8119__auto___48238 < len__8118__auto___48237)){
args__8125__auto__.push((arguments[i__8119__auto___48238]));

var G__48239 = (i__8119__auto___48238 + (1));
i__8119__auto___48238 = G__48239;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.head.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.head.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__48232){
var vec__48233 = p__48232;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48233,(0),null);
var G__48236 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$head,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__48236) : cljs_http.client.request.call(null,G__48236));
});

cljs_http.client.head.cljs$lang$maxFixedArity = (1);

cljs_http.client.head.cljs$lang$applyTo = (function (seq48230){
var G__48231 = cljs.core.first(seq48230);
var seq48230__$1 = cljs.core.next(seq48230);
return cljs_http.client.head.cljs$core$IFn$_invoke$arity$variadic(G__48231,seq48230__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.move = (function cljs_http$client$move(var_args){
var args__8125__auto__ = [];
var len__8118__auto___48247 = arguments.length;
var i__8119__auto___48248 = (0);
while(true){
if((i__8119__auto___48248 < len__8118__auto___48247)){
args__8125__auto__.push((arguments[i__8119__auto___48248]));

var G__48249 = (i__8119__auto___48248 + (1));
i__8119__auto___48248 = G__48249;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.move.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.move.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__48242){
var vec__48243 = p__48242;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48243,(0),null);
var G__48246 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$move,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__48246) : cljs_http.client.request.call(null,G__48246));
});

cljs_http.client.move.cljs$lang$maxFixedArity = (1);

cljs_http.client.move.cljs$lang$applyTo = (function (seq48240){
var G__48241 = cljs.core.first(seq48240);
var seq48240__$1 = cljs.core.next(seq48240);
return cljs_http.client.move.cljs$core$IFn$_invoke$arity$variadic(G__48241,seq48240__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.options = (function cljs_http$client$options(var_args){
var args__8125__auto__ = [];
var len__8118__auto___48257 = arguments.length;
var i__8119__auto___48258 = (0);
while(true){
if((i__8119__auto___48258 < len__8118__auto___48257)){
args__8125__auto__.push((arguments[i__8119__auto___48258]));

var G__48259 = (i__8119__auto___48258 + (1));
i__8119__auto___48258 = G__48259;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.options.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.options.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__48252){
var vec__48253 = p__48252;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48253,(0),null);
var G__48256 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$options,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__48256) : cljs_http.client.request.call(null,G__48256));
});

cljs_http.client.options.cljs$lang$maxFixedArity = (1);

cljs_http.client.options.cljs$lang$applyTo = (function (seq48250){
var G__48251 = cljs.core.first(seq48250);
var seq48250__$1 = cljs.core.next(seq48250);
return cljs_http.client.options.cljs$core$IFn$_invoke$arity$variadic(G__48251,seq48250__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.patch = (function cljs_http$client$patch(var_args){
var args__8125__auto__ = [];
var len__8118__auto___48267 = arguments.length;
var i__8119__auto___48268 = (0);
while(true){
if((i__8119__auto___48268 < len__8118__auto___48267)){
args__8125__auto__.push((arguments[i__8119__auto___48268]));

var G__48269 = (i__8119__auto___48268 + (1));
i__8119__auto___48268 = G__48269;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.patch.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.patch.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__48262){
var vec__48263 = p__48262;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48263,(0),null);
var G__48266 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$patch,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__48266) : cljs_http.client.request.call(null,G__48266));
});

cljs_http.client.patch.cljs$lang$maxFixedArity = (1);

cljs_http.client.patch.cljs$lang$applyTo = (function (seq48260){
var G__48261 = cljs.core.first(seq48260);
var seq48260__$1 = cljs.core.next(seq48260);
return cljs_http.client.patch.cljs$core$IFn$_invoke$arity$variadic(G__48261,seq48260__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.post = (function cljs_http$client$post(var_args){
var args__8125__auto__ = [];
var len__8118__auto___48277 = arguments.length;
var i__8119__auto___48278 = (0);
while(true){
if((i__8119__auto___48278 < len__8118__auto___48277)){
args__8125__auto__.push((arguments[i__8119__auto___48278]));

var G__48279 = (i__8119__auto___48278 + (1));
i__8119__auto___48278 = G__48279;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.post.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.post.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__48272){
var vec__48273 = p__48272;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48273,(0),null);
var G__48276 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$post,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__48276) : cljs_http.client.request.call(null,G__48276));
});

cljs_http.client.post.cljs$lang$maxFixedArity = (1);

cljs_http.client.post.cljs$lang$applyTo = (function (seq48270){
var G__48271 = cljs.core.first(seq48270);
var seq48270__$1 = cljs.core.next(seq48270);
return cljs_http.client.post.cljs$core$IFn$_invoke$arity$variadic(G__48271,seq48270__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.put = (function cljs_http$client$put(var_args){
var args__8125__auto__ = [];
var len__8118__auto___48287 = arguments.length;
var i__8119__auto___48288 = (0);
while(true){
if((i__8119__auto___48288 < len__8118__auto___48287)){
args__8125__auto__.push((arguments[i__8119__auto___48288]));

var G__48289 = (i__8119__auto___48288 + (1));
i__8119__auto___48288 = G__48289;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.put.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.put.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__48282){
var vec__48283 = p__48282;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__48283,(0),null);
var G__48286 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$put,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__48286) : cljs_http.client.request.call(null,G__48286));
});

cljs_http.client.put.cljs$lang$maxFixedArity = (1);

cljs_http.client.put.cljs$lang$applyTo = (function (seq48280){
var G__48281 = cljs.core.first(seq48280);
var seq48280__$1 = cljs.core.next(seq48280);
return cljs_http.client.put.cljs$core$IFn$_invoke$arity$variadic(G__48281,seq48280__$1);
});


// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var args42889 = [];
var len__8118__auto___42895 = arguments.length;
var i__8119__auto___42896 = (0);
while(true){
if((i__8119__auto___42896 < len__8118__auto___42895)){
args42889.push((arguments[i__8119__auto___42896]));

var G__42897 = (i__8119__auto___42896 + (1));
i__8119__auto___42896 = G__42897;
continue;
} else {
}
break;
}

var G__42891 = args42889.length;
switch (G__42891) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args42889.length)].join('')));

}
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(f,true);
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if(typeof cljs.core.async.t_cljs$core$async42892 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async42892 = (function (f,blockable,meta42893){
this.f = f;
this.blockable = blockable;
this.meta42893 = meta42893;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async42892.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_42894,meta42893__$1){
var self__ = this;
var _42894__$1 = this;
return (new cljs.core.async.t_cljs$core$async42892(self__.f,self__.blockable,meta42893__$1));
});

cljs.core.async.t_cljs$core$async42892.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_42894){
var self__ = this;
var _42894__$1 = this;
return self__.meta42893;
});

cljs.core.async.t_cljs$core$async42892.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async42892.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async42892.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
});

cljs.core.async.t_cljs$core$async42892.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
});

cljs.core.async.t_cljs$core$async42892.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$blockable,cljs.core.cst$sym$meta42893], null);
});

cljs.core.async.t_cljs$core$async42892.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async42892.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async42892";

cljs.core.async.t_cljs$core$async42892.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async42892");
});

cljs.core.async.__GT_t_cljs$core$async42892 = (function cljs$core$async$__GT_t_cljs$core$async42892(f__$1,blockable__$1,meta42893){
return (new cljs.core.async.t_cljs$core$async42892(f__$1,blockable__$1,meta42893));
});

}

return (new cljs.core.async.t_cljs$core$async42892(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
});

cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2;

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer(n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if(!((buff == null))){
if((false) || (buff.cljs$core$async$impl$protocols$UnblockingBuffer$)){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var args42901 = [];
var len__8118__auto___42904 = arguments.length;
var i__8119__auto___42905 = (0);
while(true){
if((i__8119__auto___42905 < len__8118__auto___42904)){
args42901.push((arguments[i__8119__auto___42905]));

var G__42906 = (i__8119__auto___42905 + (1));
i__8119__auto___42905 = G__42906;
continue;
} else {
}
break;
}

var G__42903 = args42901.length;
switch (G__42903) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args42901.length)].join('')));

}
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,xform,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
} else {
}

return cljs.core.async.impl.channels.chan.cljs$core$IFn$_invoke$arity$3(((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer(buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
});

cljs.core.async.chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var args42908 = [];
var len__8118__auto___42911 = arguments.length;
var i__8119__auto___42912 = (0);
while(true){
if((i__8119__auto___42912 < len__8118__auto___42911)){
args42908.push((arguments[i__8119__auto___42912]));

var G__42913 = (i__8119__auto___42912 + (1));
i__8119__auto___42912 = G__42913;
continue;
} else {
}
break;
}

var G__42910 = args42908.length;
switch (G__42910) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args42908.length)].join('')));

}
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2(xform,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(cljs.core.async.impl.buffers.promise_buffer(),xform,ex_handler);
});

cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout(msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var args42915 = [];
var len__8118__auto___42918 = arguments.length;
var i__8119__auto___42919 = (0);
while(true){
if((i__8119__auto___42919 < len__8118__auto___42918)){
args42915.push((arguments[i__8119__auto___42919]));

var G__42920 = (i__8119__auto___42919 + (1));
i__8119__auto___42919 = G__42920;
continue;
} else {
}
break;
}

var G__42917 = args42915.length;
switch (G__42917) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args42915.length)].join('')));

}
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3(port,fn1,true);
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(ret)){
var val_42922 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret));
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_42922) : fn1.call(null,val_42922));
} else {
cljs.core.async.impl.dispatch.run(((function (val_42922,ret){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_42922) : fn1.call(null,val_42922));
});})(val_42922,ret))
);
}
} else {
}

return null;
});

cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3;

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn0 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn0 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var args42923 = [];
var len__8118__auto___42926 = arguments.length;
var i__8119__auto___42927 = (0);
while(true){
if((i__8119__auto___42927 < len__8118__auto___42926)){
args42923.push((arguments[i__8119__auto___42927]));

var G__42928 = (i__8119__auto___42927 + (1));
i__8119__auto___42927 = G__42928;
continue;
} else {
}
break;
}

var G__42925 = args42923.length;
switch (G__42925) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args42923.length)].join('')));

}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__6726__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__6726__auto__)){
var ret = temp__6726__auto__;
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret));
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4(port,val,fn1,true);
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__6726__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(temp__6726__auto__)){
var retb = temp__6726__auto__;
var ret = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(retb) : cljs.core.deref.call(null,retb));
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
} else {
cljs.core.async.impl.dispatch.run(((function (ret,retb,temp__6726__auto__){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
});})(ret,retb,temp__6726__auto__))
);
}

return ret;
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4;

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_(port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__7952__auto___42930 = n;
var x_42931 = (0);
while(true){
if((x_42931 < n__7952__auto___42930)){
(a[x_42931] = (0));

var G__42932 = (x_42931 + (1));
x_42931 = G__42932;
continue;
} else {
}
break;
}

var i = (1);
while(true){
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(i,n)){
return a;
} else {
var j = cljs.core.rand_int(i);
(a[i] = (a[j]));

(a[j] = i);

var G__42933 = (i + (1));
i = G__42933;
continue;
}
break;
}
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(true) : cljs.core.atom.call(null,true));
if(typeof cljs.core.async.t_cljs$core$async42937 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async42937 = (function (alt_flag,flag,meta42938){
this.alt_flag = alt_flag;
this.flag = flag;
this.meta42938 = meta42938;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async42937.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (flag){
return (function (_42939,meta42938__$1){
var self__ = this;
var _42939__$1 = this;
return (new cljs.core.async.t_cljs$core$async42937(self__.alt_flag,self__.flag,meta42938__$1));
});})(flag))
;

cljs.core.async.t_cljs$core$async42937.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (flag){
return (function (_42939){
var self__ = this;
var _42939__$1 = this;
return self__.meta42938;
});})(flag))
;

cljs.core.async.t_cljs$core$async42937.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async42937.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(self__.flag) : cljs.core.deref.call(null,self__.flag));
});})(flag))
;

cljs.core.async.t_cljs$core$async42937.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async42937.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(self__.flag,null) : cljs.core.reset_BANG_.call(null,self__.flag,null));

return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async42937.getBasis = ((function (flag){
return (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$alt_DASH_flag,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$private,true,cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(cljs.core.PersistentVector.EMPTY))], null)),cljs.core.cst$sym$flag,cljs.core.cst$sym$meta42938], null);
});})(flag))
;

cljs.core.async.t_cljs$core$async42937.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async42937.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async42937";

cljs.core.async.t_cljs$core$async42937.cljs$lang$ctorPrWriter = ((function (flag){
return (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async42937");
});})(flag))
;

cljs.core.async.__GT_t_cljs$core$async42937 = ((function (flag){
return (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async42937(alt_flag__$1,flag__$1,meta42938){
return (new cljs.core.async.t_cljs$core$async42937(alt_flag__$1,flag__$1,meta42938));
});})(flag))
;

}

return (new cljs.core.async.t_cljs$core$async42937(cljs$core$async$alt_flag,flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if(typeof cljs.core.async.t_cljs$core$async42943 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async42943 = (function (alt_handler,flag,cb,meta42944){
this.alt_handler = alt_handler;
this.flag = flag;
this.cb = cb;
this.meta42944 = meta42944;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async42943.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_42945,meta42944__$1){
var self__ = this;
var _42945__$1 = this;
return (new cljs.core.async.t_cljs$core$async42943(self__.alt_handler,self__.flag,self__.cb,meta42944__$1));
});

cljs.core.async.t_cljs$core$async42943.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_42945){
var self__ = this;
var _42945__$1 = this;
return self__.meta42944;
});

cljs.core.async.t_cljs$core$async42943.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async42943.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.flag);
});

cljs.core.async.t_cljs$core$async42943.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async42943.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit(self__.flag);

return self__.cb;
});

cljs.core.async.t_cljs$core$async42943.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$alt_DASH_handler,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$private,true,cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$cb], null)))], null)),cljs.core.cst$sym$flag,cljs.core.cst$sym$cb,cljs.core.cst$sym$meta42944], null);
});

cljs.core.async.t_cljs$core$async42943.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async42943.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async42943";

cljs.core.async.t_cljs$core$async42943.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async42943");
});

cljs.core.async.__GT_t_cljs$core$async42943 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async42943(alt_handler__$1,flag__$1,cb__$1,meta42944){
return (new cljs.core.async.t_cljs$core$async42943(alt_handler__$1,flag__$1,cb__$1,meta42944));
});

}

return (new cljs.core.async.t_cljs$core$async42943(cljs$core$async$alt_handler,flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){
var flag = cljs.core.async.alt_flag();
var n = cljs.core.count(ports);
var idxs = cljs.core.async.random_array(n);
var priority = cljs.core.cst$kw$priority.cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ports,idx);
var wport = ((cljs.core.vector_QMARK_(port))?(port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((0)) : port.call(null,(0))):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = (port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((1)) : port.call(null,(1)));
return cljs.core.async.impl.protocols.put_BANG_(wport,val,cljs.core.async.alt_handler(flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__42946_SHARP_){
var G__42950 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__42946_SHARP_,wport], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__42950) : fret.call(null,G__42950));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.alt_handler(flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__42947_SHARP_){
var G__42951 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__42947_SHARP_,port], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__42951) : fret.call(null,G__42951));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(vbox) : cljs.core.deref.call(null,vbox)),(function (){var or__6939__auto__ = wport;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return port;
}
})()], null));
} else {
var G__42952 = (i + (1));
i = G__42952;
continue;
}
} else {
return null;
}
break;
}
})();
var or__6939__auto__ = ret;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
if(cljs.core.contains_QMARK_(opts,cljs.core.cst$kw$default)){
var temp__6728__auto__ = (function (){var and__6927__auto__ = cljs.core.async.impl.protocols.active_QMARK_(flag);
if(cljs.core.truth_(and__6927__auto__)){
return cljs.core.async.impl.protocols.commit(flag);
} else {
return and__6927__auto__;
}
})();
if(cljs.core.truth_(temp__6728__auto__)){
var got = temp__6728__auto__;
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$default.cljs$core$IFn$_invoke$arity$1(opts),cljs.core.cst$kw$default], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___42958 = arguments.length;
var i__8119__auto___42959 = (0);
while(true){
if((i__8119__auto___42959 < len__8118__auto___42958)){
args__8125__auto__.push((arguments[i__8119__auto___42959]));

var G__42960 = (i__8119__auto___42959 + (1));
i__8119__auto___42959 = G__42960;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__42955){
var map__42956 = p__42955;
var map__42956__$1 = ((((!((map__42956 == null)))?((((map__42956.cljs$lang$protocol_mask$partition0$ & (64))) || (map__42956.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__42956):map__42956);
var opts = map__42956__$1;
throw (new Error("alts! used not in (go ...) block"));
});

cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1);

cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq42953){
var G__42954 = cljs.core.first(seq42953);
var seq42953__$1 = cljs.core.next(seq42953);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__42954,seq42953__$1);
});

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret));
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret));
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var args42961 = [];
var len__8118__auto___43011 = arguments.length;
var i__8119__auto___43012 = (0);
while(true){
if((i__8119__auto___43012 < len__8118__auto___43011)){
args42961.push((arguments[i__8119__auto___43012]));

var G__43013 = (i__8119__auto___43012 + (1));
i__8119__auto___43012 = G__43013;
continue;
} else {
}
break;
}

var G__42963 = args42961.length;
switch (G__42963) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args42961.length)].join('')));

}
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3(from,to,true);
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__15224__auto___43015 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___43015){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___43015){
return (function (state_42987){
var state_val_42988 = (state_42987[(1)]);
if((state_val_42988 === (7))){
var inst_42983 = (state_42987[(2)]);
var state_42987__$1 = state_42987;
var statearr_42989_43016 = state_42987__$1;
(statearr_42989_43016[(2)] = inst_42983);

(statearr_42989_43016[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_42988 === (1))){
var state_42987__$1 = state_42987;
var statearr_42990_43017 = state_42987__$1;
(statearr_42990_43017[(2)] = null);

(statearr_42990_43017[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_42988 === (4))){
var inst_42966 = (state_42987[(7)]);
var inst_42966__$1 = (state_42987[(2)]);
var inst_42967 = (inst_42966__$1 == null);
var state_42987__$1 = (function (){var statearr_42991 = state_42987;
(statearr_42991[(7)] = inst_42966__$1);

return statearr_42991;
})();
if(cljs.core.truth_(inst_42967)){
var statearr_42992_43018 = state_42987__$1;
(statearr_42992_43018[(1)] = (5));

} else {
var statearr_42993_43019 = state_42987__$1;
(statearr_42993_43019[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_42988 === (13))){
var state_42987__$1 = state_42987;
var statearr_42994_43020 = state_42987__$1;
(statearr_42994_43020[(2)] = null);

(statearr_42994_43020[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_42988 === (6))){
var inst_42966 = (state_42987[(7)]);
var state_42987__$1 = state_42987;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_42987__$1,(11),to,inst_42966);
} else {
if((state_val_42988 === (3))){
var inst_42985 = (state_42987[(2)]);
var state_42987__$1 = state_42987;
return cljs.core.async.impl.ioc_helpers.return_chan(state_42987__$1,inst_42985);
} else {
if((state_val_42988 === (12))){
var state_42987__$1 = state_42987;
var statearr_42995_43021 = state_42987__$1;
(statearr_42995_43021[(2)] = null);

(statearr_42995_43021[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_42988 === (2))){
var state_42987__$1 = state_42987;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_42987__$1,(4),from);
} else {
if((state_val_42988 === (11))){
var inst_42976 = (state_42987[(2)]);
var state_42987__$1 = state_42987;
if(cljs.core.truth_(inst_42976)){
var statearr_42996_43022 = state_42987__$1;
(statearr_42996_43022[(1)] = (12));

} else {
var statearr_42997_43023 = state_42987__$1;
(statearr_42997_43023[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_42988 === (9))){
var state_42987__$1 = state_42987;
var statearr_42998_43024 = state_42987__$1;
(statearr_42998_43024[(2)] = null);

(statearr_42998_43024[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_42988 === (5))){
var state_42987__$1 = state_42987;
if(cljs.core.truth_(close_QMARK_)){
var statearr_42999_43025 = state_42987__$1;
(statearr_42999_43025[(1)] = (8));

} else {
var statearr_43000_43026 = state_42987__$1;
(statearr_43000_43026[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_42988 === (14))){
var inst_42981 = (state_42987[(2)]);
var state_42987__$1 = state_42987;
var statearr_43001_43027 = state_42987__$1;
(statearr_43001_43027[(2)] = inst_42981);

(statearr_43001_43027[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_42988 === (10))){
var inst_42973 = (state_42987[(2)]);
var state_42987__$1 = state_42987;
var statearr_43002_43028 = state_42987__$1;
(statearr_43002_43028[(2)] = inst_42973);

(statearr_43002_43028[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_42988 === (8))){
var inst_42970 = cljs.core.async.close_BANG_(to);
var state_42987__$1 = state_42987;
var statearr_43003_43029 = state_42987__$1;
(statearr_43003_43029[(2)] = inst_42970);

(statearr_43003_43029[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___43015))
;
return ((function (switch__15098__auto__,c__15224__auto___43015){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_43007 = [null,null,null,null,null,null,null,null];
(statearr_43007[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_43007[(1)] = (1));

return statearr_43007;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_42987){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_42987);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e43008){if((e43008 instanceof Object)){
var ex__15102__auto__ = e43008;
var statearr_43009_43030 = state_42987;
(statearr_43009_43030[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_42987);

return cljs.core.cst$kw$recur;
} else {
throw e43008;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__43031 = state_42987;
state_42987 = G__43031;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_42987){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_42987);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___43015))
})();
var state__15226__auto__ = (function (){var statearr_43010 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_43010[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___43015);

return statearr_43010;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___43015))
);


return to;
});

cljs.core.async.pipe.cljs$lang$maxFixedArity = 3;

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){

var jobs = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var results = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var process = ((function (jobs,results){
return (function (p__43219){
var vec__43220 = p__43219;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43220,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43220,(1),null);
var job = vec__43220;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((1),xf,ex_handler);
var c__15224__auto___43406 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___43406,res,vec__43220,v,p,job,jobs,results){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___43406,res,vec__43220,v,p,job,jobs,results){
return (function (state_43227){
var state_val_43228 = (state_43227[(1)]);
if((state_val_43228 === (1))){
var state_43227__$1 = state_43227;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_43227__$1,(2),res,v);
} else {
if((state_val_43228 === (2))){
var inst_43224 = (state_43227[(2)]);
var inst_43225 = cljs.core.async.close_BANG_(res);
var state_43227__$1 = (function (){var statearr_43229 = state_43227;
(statearr_43229[(7)] = inst_43224);

return statearr_43229;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_43227__$1,inst_43225);
} else {
return null;
}
}
});})(c__15224__auto___43406,res,vec__43220,v,p,job,jobs,results))
;
return ((function (switch__15098__auto__,c__15224__auto___43406,res,vec__43220,v,p,job,jobs,results){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_43233 = [null,null,null,null,null,null,null,null];
(statearr_43233[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__);

(statearr_43233[(1)] = (1));

return statearr_43233;
});
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1 = (function (state_43227){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_43227);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e43234){if((e43234 instanceof Object)){
var ex__15102__auto__ = e43234;
var statearr_43235_43407 = state_43227;
(statearr_43235_43407[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_43227);

return cljs.core.cst$kw$recur;
} else {
throw e43234;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__43408 = state_43227;
state_43227 = G__43408;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = function(state_43227){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1.call(this,state_43227);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___43406,res,vec__43220,v,p,job,jobs,results))
})();
var state__15226__auto__ = (function (){var statearr_43236 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_43236[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___43406);

return statearr_43236;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___43406,res,vec__43220,v,p,job,jobs,results))
);


cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results))
;
var async = ((function (jobs,results,process){
return (function (p__43237){
var vec__43238 = p__43237;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43238,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43238,(1),null);
var job = vec__43238;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
(xf.cljs$core$IFn$_invoke$arity$2 ? xf.cljs$core$IFn$_invoke$arity$2(v,res) : xf.call(null,v,res));

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results,process))
;
var n__7952__auto___43409 = n;
var __43410 = (0);
while(true){
if((__43410 < n__7952__auto___43409)){
var G__43241_43411 = (((type instanceof cljs.core.Keyword))?type.fqn:null);
switch (G__43241_43411) {
case "compute":
var c__15224__auto___43413 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__43410,c__15224__auto___43413,G__43241_43411,n__7952__auto___43409,jobs,results,process,async){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (__43410,c__15224__auto___43413,G__43241_43411,n__7952__auto___43409,jobs,results,process,async){
return (function (state_43254){
var state_val_43255 = (state_43254[(1)]);
if((state_val_43255 === (1))){
var state_43254__$1 = state_43254;
var statearr_43256_43414 = state_43254__$1;
(statearr_43256_43414[(2)] = null);

(statearr_43256_43414[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43255 === (2))){
var state_43254__$1 = state_43254;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_43254__$1,(4),jobs);
} else {
if((state_val_43255 === (3))){
var inst_43252 = (state_43254[(2)]);
var state_43254__$1 = state_43254;
return cljs.core.async.impl.ioc_helpers.return_chan(state_43254__$1,inst_43252);
} else {
if((state_val_43255 === (4))){
var inst_43244 = (state_43254[(2)]);
var inst_43245 = process(inst_43244);
var state_43254__$1 = state_43254;
if(cljs.core.truth_(inst_43245)){
var statearr_43257_43415 = state_43254__$1;
(statearr_43257_43415[(1)] = (5));

} else {
var statearr_43258_43416 = state_43254__$1;
(statearr_43258_43416[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43255 === (5))){
var state_43254__$1 = state_43254;
var statearr_43259_43417 = state_43254__$1;
(statearr_43259_43417[(2)] = null);

(statearr_43259_43417[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43255 === (6))){
var state_43254__$1 = state_43254;
var statearr_43260_43418 = state_43254__$1;
(statearr_43260_43418[(2)] = null);

(statearr_43260_43418[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43255 === (7))){
var inst_43250 = (state_43254[(2)]);
var state_43254__$1 = state_43254;
var statearr_43261_43419 = state_43254__$1;
(statearr_43261_43419[(2)] = inst_43250);

(statearr_43261_43419[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__43410,c__15224__auto___43413,G__43241_43411,n__7952__auto___43409,jobs,results,process,async))
;
return ((function (__43410,switch__15098__auto__,c__15224__auto___43413,G__43241_43411,n__7952__auto___43409,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_43265 = [null,null,null,null,null,null,null];
(statearr_43265[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__);

(statearr_43265[(1)] = (1));

return statearr_43265;
});
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1 = (function (state_43254){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_43254);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e43266){if((e43266 instanceof Object)){
var ex__15102__auto__ = e43266;
var statearr_43267_43420 = state_43254;
(statearr_43267_43420[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_43254);

return cljs.core.cst$kw$recur;
} else {
throw e43266;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__43421 = state_43254;
state_43254 = G__43421;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = function(state_43254){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1.call(this,state_43254);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__;
})()
;})(__43410,switch__15098__auto__,c__15224__auto___43413,G__43241_43411,n__7952__auto___43409,jobs,results,process,async))
})();
var state__15226__auto__ = (function (){var statearr_43268 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_43268[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___43413);

return statearr_43268;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(__43410,c__15224__auto___43413,G__43241_43411,n__7952__auto___43409,jobs,results,process,async))
);


break;
case "async":
var c__15224__auto___43422 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__43410,c__15224__auto___43422,G__43241_43411,n__7952__auto___43409,jobs,results,process,async){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (__43410,c__15224__auto___43422,G__43241_43411,n__7952__auto___43409,jobs,results,process,async){
return (function (state_43281){
var state_val_43282 = (state_43281[(1)]);
if((state_val_43282 === (1))){
var state_43281__$1 = state_43281;
var statearr_43283_43423 = state_43281__$1;
(statearr_43283_43423[(2)] = null);

(statearr_43283_43423[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43282 === (2))){
var state_43281__$1 = state_43281;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_43281__$1,(4),jobs);
} else {
if((state_val_43282 === (3))){
var inst_43279 = (state_43281[(2)]);
var state_43281__$1 = state_43281;
return cljs.core.async.impl.ioc_helpers.return_chan(state_43281__$1,inst_43279);
} else {
if((state_val_43282 === (4))){
var inst_43271 = (state_43281[(2)]);
var inst_43272 = async(inst_43271);
var state_43281__$1 = state_43281;
if(cljs.core.truth_(inst_43272)){
var statearr_43284_43424 = state_43281__$1;
(statearr_43284_43424[(1)] = (5));

} else {
var statearr_43285_43425 = state_43281__$1;
(statearr_43285_43425[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43282 === (5))){
var state_43281__$1 = state_43281;
var statearr_43286_43426 = state_43281__$1;
(statearr_43286_43426[(2)] = null);

(statearr_43286_43426[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43282 === (6))){
var state_43281__$1 = state_43281;
var statearr_43287_43427 = state_43281__$1;
(statearr_43287_43427[(2)] = null);

(statearr_43287_43427[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43282 === (7))){
var inst_43277 = (state_43281[(2)]);
var state_43281__$1 = state_43281;
var statearr_43288_43428 = state_43281__$1;
(statearr_43288_43428[(2)] = inst_43277);

(statearr_43288_43428[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__43410,c__15224__auto___43422,G__43241_43411,n__7952__auto___43409,jobs,results,process,async))
;
return ((function (__43410,switch__15098__auto__,c__15224__auto___43422,G__43241_43411,n__7952__auto___43409,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_43292 = [null,null,null,null,null,null,null];
(statearr_43292[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__);

(statearr_43292[(1)] = (1));

return statearr_43292;
});
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1 = (function (state_43281){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_43281);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e43293){if((e43293 instanceof Object)){
var ex__15102__auto__ = e43293;
var statearr_43294_43429 = state_43281;
(statearr_43294_43429[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_43281);

return cljs.core.cst$kw$recur;
} else {
throw e43293;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__43430 = state_43281;
state_43281 = G__43430;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = function(state_43281){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1.call(this,state_43281);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__;
})()
;})(__43410,switch__15098__auto__,c__15224__auto___43422,G__43241_43411,n__7952__auto___43409,jobs,results,process,async))
})();
var state__15226__auto__ = (function (){var statearr_43295 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_43295[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___43422);

return statearr_43295;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(__43410,c__15224__auto___43422,G__43241_43411,n__7952__auto___43409,jobs,results,process,async))
);


break;
default:
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(type)].join('')));

}

var G__43431 = (__43410 + (1));
__43410 = G__43431;
continue;
} else {
}
break;
}

var c__15224__auto___43432 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___43432,jobs,results,process,async){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___43432,jobs,results,process,async){
return (function (state_43317){
var state_val_43318 = (state_43317[(1)]);
if((state_val_43318 === (1))){
var state_43317__$1 = state_43317;
var statearr_43319_43433 = state_43317__$1;
(statearr_43319_43433[(2)] = null);

(statearr_43319_43433[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43318 === (2))){
var state_43317__$1 = state_43317;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_43317__$1,(4),from);
} else {
if((state_val_43318 === (3))){
var inst_43315 = (state_43317[(2)]);
var state_43317__$1 = state_43317;
return cljs.core.async.impl.ioc_helpers.return_chan(state_43317__$1,inst_43315);
} else {
if((state_val_43318 === (4))){
var inst_43298 = (state_43317[(7)]);
var inst_43298__$1 = (state_43317[(2)]);
var inst_43299 = (inst_43298__$1 == null);
var state_43317__$1 = (function (){var statearr_43320 = state_43317;
(statearr_43320[(7)] = inst_43298__$1);

return statearr_43320;
})();
if(cljs.core.truth_(inst_43299)){
var statearr_43321_43434 = state_43317__$1;
(statearr_43321_43434[(1)] = (5));

} else {
var statearr_43322_43435 = state_43317__$1;
(statearr_43322_43435[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43318 === (5))){
var inst_43301 = cljs.core.async.close_BANG_(jobs);
var state_43317__$1 = state_43317;
var statearr_43323_43436 = state_43317__$1;
(statearr_43323_43436[(2)] = inst_43301);

(statearr_43323_43436[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43318 === (6))){
var inst_43303 = (state_43317[(8)]);
var inst_43298 = (state_43317[(7)]);
var inst_43303__$1 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_43304 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_43305 = [inst_43298,inst_43303__$1];
var inst_43306 = (new cljs.core.PersistentVector(null,2,(5),inst_43304,inst_43305,null));
var state_43317__$1 = (function (){var statearr_43324 = state_43317;
(statearr_43324[(8)] = inst_43303__$1);

return statearr_43324;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_43317__$1,(8),jobs,inst_43306);
} else {
if((state_val_43318 === (7))){
var inst_43313 = (state_43317[(2)]);
var state_43317__$1 = state_43317;
var statearr_43325_43437 = state_43317__$1;
(statearr_43325_43437[(2)] = inst_43313);

(statearr_43325_43437[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43318 === (8))){
var inst_43303 = (state_43317[(8)]);
var inst_43308 = (state_43317[(2)]);
var state_43317__$1 = (function (){var statearr_43326 = state_43317;
(statearr_43326[(9)] = inst_43308);

return statearr_43326;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_43317__$1,(9),results,inst_43303);
} else {
if((state_val_43318 === (9))){
var inst_43310 = (state_43317[(2)]);
var state_43317__$1 = (function (){var statearr_43327 = state_43317;
(statearr_43327[(10)] = inst_43310);

return statearr_43327;
})();
var statearr_43328_43438 = state_43317__$1;
(statearr_43328_43438[(2)] = null);

(statearr_43328_43438[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___43432,jobs,results,process,async))
;
return ((function (switch__15098__auto__,c__15224__auto___43432,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_43332 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_43332[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__);

(statearr_43332[(1)] = (1));

return statearr_43332;
});
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1 = (function (state_43317){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_43317);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e43333){if((e43333 instanceof Object)){
var ex__15102__auto__ = e43333;
var statearr_43334_43439 = state_43317;
(statearr_43334_43439[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_43317);

return cljs.core.cst$kw$recur;
} else {
throw e43333;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__43440 = state_43317;
state_43317 = G__43440;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = function(state_43317){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1.call(this,state_43317);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___43432,jobs,results,process,async))
})();
var state__15226__auto__ = (function (){var statearr_43335 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_43335[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___43432);

return statearr_43335;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___43432,jobs,results,process,async))
);


var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__,jobs,results,process,async){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__,jobs,results,process,async){
return (function (state_43373){
var state_val_43374 = (state_43373[(1)]);
if((state_val_43374 === (7))){
var inst_43369 = (state_43373[(2)]);
var state_43373__$1 = state_43373;
var statearr_43375_43441 = state_43373__$1;
(statearr_43375_43441[(2)] = inst_43369);

(statearr_43375_43441[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (20))){
var state_43373__$1 = state_43373;
var statearr_43376_43442 = state_43373__$1;
(statearr_43376_43442[(2)] = null);

(statearr_43376_43442[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (1))){
var state_43373__$1 = state_43373;
var statearr_43377_43443 = state_43373__$1;
(statearr_43377_43443[(2)] = null);

(statearr_43377_43443[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (4))){
var inst_43338 = (state_43373[(7)]);
var inst_43338__$1 = (state_43373[(2)]);
var inst_43339 = (inst_43338__$1 == null);
var state_43373__$1 = (function (){var statearr_43378 = state_43373;
(statearr_43378[(7)] = inst_43338__$1);

return statearr_43378;
})();
if(cljs.core.truth_(inst_43339)){
var statearr_43379_43444 = state_43373__$1;
(statearr_43379_43444[(1)] = (5));

} else {
var statearr_43380_43445 = state_43373__$1;
(statearr_43380_43445[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (15))){
var inst_43351 = (state_43373[(8)]);
var state_43373__$1 = state_43373;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_43373__$1,(18),to,inst_43351);
} else {
if((state_val_43374 === (21))){
var inst_43364 = (state_43373[(2)]);
var state_43373__$1 = state_43373;
var statearr_43381_43446 = state_43373__$1;
(statearr_43381_43446[(2)] = inst_43364);

(statearr_43381_43446[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (13))){
var inst_43366 = (state_43373[(2)]);
var state_43373__$1 = (function (){var statearr_43382 = state_43373;
(statearr_43382[(9)] = inst_43366);

return statearr_43382;
})();
var statearr_43383_43447 = state_43373__$1;
(statearr_43383_43447[(2)] = null);

(statearr_43383_43447[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (6))){
var inst_43338 = (state_43373[(7)]);
var state_43373__$1 = state_43373;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_43373__$1,(11),inst_43338);
} else {
if((state_val_43374 === (17))){
var inst_43359 = (state_43373[(2)]);
var state_43373__$1 = state_43373;
if(cljs.core.truth_(inst_43359)){
var statearr_43384_43448 = state_43373__$1;
(statearr_43384_43448[(1)] = (19));

} else {
var statearr_43385_43449 = state_43373__$1;
(statearr_43385_43449[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (3))){
var inst_43371 = (state_43373[(2)]);
var state_43373__$1 = state_43373;
return cljs.core.async.impl.ioc_helpers.return_chan(state_43373__$1,inst_43371);
} else {
if((state_val_43374 === (12))){
var inst_43348 = (state_43373[(10)]);
var state_43373__$1 = state_43373;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_43373__$1,(14),inst_43348);
} else {
if((state_val_43374 === (2))){
var state_43373__$1 = state_43373;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_43373__$1,(4),results);
} else {
if((state_val_43374 === (19))){
var state_43373__$1 = state_43373;
var statearr_43386_43450 = state_43373__$1;
(statearr_43386_43450[(2)] = null);

(statearr_43386_43450[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (11))){
var inst_43348 = (state_43373[(2)]);
var state_43373__$1 = (function (){var statearr_43387 = state_43373;
(statearr_43387[(10)] = inst_43348);

return statearr_43387;
})();
var statearr_43388_43451 = state_43373__$1;
(statearr_43388_43451[(2)] = null);

(statearr_43388_43451[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (9))){
var state_43373__$1 = state_43373;
var statearr_43389_43452 = state_43373__$1;
(statearr_43389_43452[(2)] = null);

(statearr_43389_43452[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (5))){
var state_43373__$1 = state_43373;
if(cljs.core.truth_(close_QMARK_)){
var statearr_43390_43453 = state_43373__$1;
(statearr_43390_43453[(1)] = (8));

} else {
var statearr_43391_43454 = state_43373__$1;
(statearr_43391_43454[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (14))){
var inst_43353 = (state_43373[(11)]);
var inst_43351 = (state_43373[(8)]);
var inst_43351__$1 = (state_43373[(2)]);
var inst_43352 = (inst_43351__$1 == null);
var inst_43353__$1 = cljs.core.not(inst_43352);
var state_43373__$1 = (function (){var statearr_43392 = state_43373;
(statearr_43392[(11)] = inst_43353__$1);

(statearr_43392[(8)] = inst_43351__$1);

return statearr_43392;
})();
if(inst_43353__$1){
var statearr_43393_43455 = state_43373__$1;
(statearr_43393_43455[(1)] = (15));

} else {
var statearr_43394_43456 = state_43373__$1;
(statearr_43394_43456[(1)] = (16));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (16))){
var inst_43353 = (state_43373[(11)]);
var state_43373__$1 = state_43373;
var statearr_43395_43457 = state_43373__$1;
(statearr_43395_43457[(2)] = inst_43353);

(statearr_43395_43457[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (10))){
var inst_43345 = (state_43373[(2)]);
var state_43373__$1 = state_43373;
var statearr_43396_43458 = state_43373__$1;
(statearr_43396_43458[(2)] = inst_43345);

(statearr_43396_43458[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (18))){
var inst_43356 = (state_43373[(2)]);
var state_43373__$1 = state_43373;
var statearr_43397_43459 = state_43373__$1;
(statearr_43397_43459[(2)] = inst_43356);

(statearr_43397_43459[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43374 === (8))){
var inst_43342 = cljs.core.async.close_BANG_(to);
var state_43373__$1 = state_43373;
var statearr_43398_43460 = state_43373__$1;
(statearr_43398_43460[(2)] = inst_43342);

(statearr_43398_43460[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto__,jobs,results,process,async))
;
return ((function (switch__15098__auto__,c__15224__auto__,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_43402 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_43402[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__);

(statearr_43402[(1)] = (1));

return statearr_43402;
});
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1 = (function (state_43373){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_43373);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e43403){if((e43403 instanceof Object)){
var ex__15102__auto__ = e43403;
var statearr_43404_43461 = state_43373;
(statearr_43404_43461[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_43373);

return cljs.core.cst$kw$recur;
} else {
throw e43403;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__43462 = state_43373;
state_43373 = G__43462;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = function(state_43373){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1.call(this,state_43373);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__,jobs,results,process,async))
})();
var state__15226__auto__ = (function (){var statearr_43405 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_43405[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_43405;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__,jobs,results,process,async))
);

return c__15224__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var args43463 = [];
var len__8118__auto___43466 = arguments.length;
var i__8119__auto___43467 = (0);
while(true){
if((i__8119__auto___43467 < len__8118__auto___43466)){
args43463.push((arguments[i__8119__auto___43467]));

var G__43468 = (i__8119__auto___43467 + (1));
i__8119__auto___43467 = G__43468;
continue;
} else {
}
break;
}

var G__43465 = args43463.length;
switch (G__43465) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args43463.length)].join('')));

}
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5(n,to,af,from,true);
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_(n,to,af,from,close_QMARK_,null,cljs.core.cst$kw$async);
});

cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5;

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var args43470 = [];
var len__8118__auto___43473 = arguments.length;
var i__8119__auto___43474 = (0);
while(true){
if((i__8119__auto___43474 < len__8118__auto___43473)){
args43470.push((arguments[i__8119__auto___43474]));

var G__43475 = (i__8119__auto___43474 + (1));
i__8119__auto___43474 = G__43475;
continue;
} else {
}
break;
}

var G__43472 = args43470.length;
switch (G__43472) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args43470.length)].join('')));

}
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5(n,to,xf,from,true);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6(n,to,xf,from,close_QMARK_,null);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,cljs.core.cst$kw$compute);
});

cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6;

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var args43477 = [];
var len__8118__auto___43530 = arguments.length;
var i__8119__auto___43531 = (0);
while(true){
if((i__8119__auto___43531 < len__8118__auto___43530)){
args43477.push((arguments[i__8119__auto___43531]));

var G__43532 = (i__8119__auto___43531 + (1));
i__8119__auto___43531 = G__43532;
continue;
} else {
}
break;
}

var G__43479 = args43477.length;
switch (G__43479) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args43477.length)].join('')));

}
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4(p,ch,null,null);
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(t_buf_or_n);
var fc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(f_buf_or_n);
var c__15224__auto___43534 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___43534,tc,fc){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___43534,tc,fc){
return (function (state_43505){
var state_val_43506 = (state_43505[(1)]);
if((state_val_43506 === (7))){
var inst_43501 = (state_43505[(2)]);
var state_43505__$1 = state_43505;
var statearr_43507_43535 = state_43505__$1;
(statearr_43507_43535[(2)] = inst_43501);

(statearr_43507_43535[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43506 === (1))){
var state_43505__$1 = state_43505;
var statearr_43508_43536 = state_43505__$1;
(statearr_43508_43536[(2)] = null);

(statearr_43508_43536[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43506 === (4))){
var inst_43482 = (state_43505[(7)]);
var inst_43482__$1 = (state_43505[(2)]);
var inst_43483 = (inst_43482__$1 == null);
var state_43505__$1 = (function (){var statearr_43509 = state_43505;
(statearr_43509[(7)] = inst_43482__$1);

return statearr_43509;
})();
if(cljs.core.truth_(inst_43483)){
var statearr_43510_43537 = state_43505__$1;
(statearr_43510_43537[(1)] = (5));

} else {
var statearr_43511_43538 = state_43505__$1;
(statearr_43511_43538[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43506 === (13))){
var state_43505__$1 = state_43505;
var statearr_43512_43539 = state_43505__$1;
(statearr_43512_43539[(2)] = null);

(statearr_43512_43539[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43506 === (6))){
var inst_43482 = (state_43505[(7)]);
var inst_43488 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_43482) : p.call(null,inst_43482));
var state_43505__$1 = state_43505;
if(cljs.core.truth_(inst_43488)){
var statearr_43513_43540 = state_43505__$1;
(statearr_43513_43540[(1)] = (9));

} else {
var statearr_43514_43541 = state_43505__$1;
(statearr_43514_43541[(1)] = (10));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43506 === (3))){
var inst_43503 = (state_43505[(2)]);
var state_43505__$1 = state_43505;
return cljs.core.async.impl.ioc_helpers.return_chan(state_43505__$1,inst_43503);
} else {
if((state_val_43506 === (12))){
var state_43505__$1 = state_43505;
var statearr_43515_43542 = state_43505__$1;
(statearr_43515_43542[(2)] = null);

(statearr_43515_43542[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43506 === (2))){
var state_43505__$1 = state_43505;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_43505__$1,(4),ch);
} else {
if((state_val_43506 === (11))){
var inst_43482 = (state_43505[(7)]);
var inst_43492 = (state_43505[(2)]);
var state_43505__$1 = state_43505;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_43505__$1,(8),inst_43492,inst_43482);
} else {
if((state_val_43506 === (9))){
var state_43505__$1 = state_43505;
var statearr_43516_43543 = state_43505__$1;
(statearr_43516_43543[(2)] = tc);

(statearr_43516_43543[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43506 === (5))){
var inst_43485 = cljs.core.async.close_BANG_(tc);
var inst_43486 = cljs.core.async.close_BANG_(fc);
var state_43505__$1 = (function (){var statearr_43517 = state_43505;
(statearr_43517[(8)] = inst_43485);

return statearr_43517;
})();
var statearr_43518_43544 = state_43505__$1;
(statearr_43518_43544[(2)] = inst_43486);

(statearr_43518_43544[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43506 === (14))){
var inst_43499 = (state_43505[(2)]);
var state_43505__$1 = state_43505;
var statearr_43519_43545 = state_43505__$1;
(statearr_43519_43545[(2)] = inst_43499);

(statearr_43519_43545[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43506 === (10))){
var state_43505__$1 = state_43505;
var statearr_43520_43546 = state_43505__$1;
(statearr_43520_43546[(2)] = fc);

(statearr_43520_43546[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43506 === (8))){
var inst_43494 = (state_43505[(2)]);
var state_43505__$1 = state_43505;
if(cljs.core.truth_(inst_43494)){
var statearr_43521_43547 = state_43505__$1;
(statearr_43521_43547[(1)] = (12));

} else {
var statearr_43522_43548 = state_43505__$1;
(statearr_43522_43548[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___43534,tc,fc))
;
return ((function (switch__15098__auto__,c__15224__auto___43534,tc,fc){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_43526 = [null,null,null,null,null,null,null,null,null];
(statearr_43526[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_43526[(1)] = (1));

return statearr_43526;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_43505){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_43505);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e43527){if((e43527 instanceof Object)){
var ex__15102__auto__ = e43527;
var statearr_43528_43549 = state_43505;
(statearr_43528_43549[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_43505);

return cljs.core.cst$kw$recur;
} else {
throw e43527;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__43550 = state_43505;
state_43505 = G__43550;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_43505){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_43505);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___43534,tc,fc))
})();
var state__15226__auto__ = (function (){var statearr_43529 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_43529[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___43534);

return statearr_43529;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___43534,tc,fc))
);


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
});

cljs.core.async.split.cljs$lang$maxFixedArity = 4;

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_43614){
var state_val_43615 = (state_43614[(1)]);
if((state_val_43615 === (7))){
var inst_43610 = (state_43614[(2)]);
var state_43614__$1 = state_43614;
var statearr_43616_43637 = state_43614__$1;
(statearr_43616_43637[(2)] = inst_43610);

(statearr_43616_43637[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43615 === (1))){
var inst_43594 = init;
var state_43614__$1 = (function (){var statearr_43617 = state_43614;
(statearr_43617[(7)] = inst_43594);

return statearr_43617;
})();
var statearr_43618_43638 = state_43614__$1;
(statearr_43618_43638[(2)] = null);

(statearr_43618_43638[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43615 === (4))){
var inst_43597 = (state_43614[(8)]);
var inst_43597__$1 = (state_43614[(2)]);
var inst_43598 = (inst_43597__$1 == null);
var state_43614__$1 = (function (){var statearr_43619 = state_43614;
(statearr_43619[(8)] = inst_43597__$1);

return statearr_43619;
})();
if(cljs.core.truth_(inst_43598)){
var statearr_43620_43639 = state_43614__$1;
(statearr_43620_43639[(1)] = (5));

} else {
var statearr_43621_43640 = state_43614__$1;
(statearr_43621_43640[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43615 === (6))){
var inst_43594 = (state_43614[(7)]);
var inst_43601 = (state_43614[(9)]);
var inst_43597 = (state_43614[(8)]);
var inst_43601__$1 = (f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(inst_43594,inst_43597) : f.call(null,inst_43594,inst_43597));
var inst_43602 = cljs.core.reduced_QMARK_(inst_43601__$1);
var state_43614__$1 = (function (){var statearr_43622 = state_43614;
(statearr_43622[(9)] = inst_43601__$1);

return statearr_43622;
})();
if(inst_43602){
var statearr_43623_43641 = state_43614__$1;
(statearr_43623_43641[(1)] = (8));

} else {
var statearr_43624_43642 = state_43614__$1;
(statearr_43624_43642[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43615 === (3))){
var inst_43612 = (state_43614[(2)]);
var state_43614__$1 = state_43614;
return cljs.core.async.impl.ioc_helpers.return_chan(state_43614__$1,inst_43612);
} else {
if((state_val_43615 === (2))){
var state_43614__$1 = state_43614;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_43614__$1,(4),ch);
} else {
if((state_val_43615 === (9))){
var inst_43601 = (state_43614[(9)]);
var inst_43594 = inst_43601;
var state_43614__$1 = (function (){var statearr_43625 = state_43614;
(statearr_43625[(7)] = inst_43594);

return statearr_43625;
})();
var statearr_43626_43643 = state_43614__$1;
(statearr_43626_43643[(2)] = null);

(statearr_43626_43643[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43615 === (5))){
var inst_43594 = (state_43614[(7)]);
var state_43614__$1 = state_43614;
var statearr_43627_43644 = state_43614__$1;
(statearr_43627_43644[(2)] = inst_43594);

(statearr_43627_43644[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43615 === (10))){
var inst_43608 = (state_43614[(2)]);
var state_43614__$1 = state_43614;
var statearr_43628_43645 = state_43614__$1;
(statearr_43628_43645[(2)] = inst_43608);

(statearr_43628_43645[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43615 === (8))){
var inst_43601 = (state_43614[(9)]);
var inst_43604 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(inst_43601) : cljs.core.deref.call(null,inst_43601));
var state_43614__$1 = state_43614;
var statearr_43629_43646 = state_43614__$1;
(statearr_43629_43646[(2)] = inst_43604);

(statearr_43629_43646[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var cljs$core$async$reduce_$_state_machine__15099__auto__ = null;
var cljs$core$async$reduce_$_state_machine__15099__auto____0 = (function (){
var statearr_43633 = [null,null,null,null,null,null,null,null,null,null];
(statearr_43633[(0)] = cljs$core$async$reduce_$_state_machine__15099__auto__);

(statearr_43633[(1)] = (1));

return statearr_43633;
});
var cljs$core$async$reduce_$_state_machine__15099__auto____1 = (function (state_43614){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_43614);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e43634){if((e43634 instanceof Object)){
var ex__15102__auto__ = e43634;
var statearr_43635_43647 = state_43614;
(statearr_43635_43647[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_43614);

return cljs.core.cst$kw$recur;
} else {
throw e43634;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__43648 = state_43614;
state_43614 = G__43648;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__15099__auto__ = function(state_43614){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__15099__auto____1.call(this,state_43614);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__15099__auto____0;
cljs$core$async$reduce_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__15099__auto____1;
return cljs$core$async$reduce_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_43636 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_43636[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_43636;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var args43649 = [];
var len__8118__auto___43701 = arguments.length;
var i__8119__auto___43702 = (0);
while(true){
if((i__8119__auto___43702 < len__8118__auto___43701)){
args43649.push((arguments[i__8119__auto___43702]));

var G__43703 = (i__8119__auto___43702 + (1));
i__8119__auto___43702 = G__43703;
continue;
} else {
}
break;
}

var G__43651 = args43649.length;
switch (G__43651) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args43649.length)].join('')));

}
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3(ch,coll,true);
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_43676){
var state_val_43677 = (state_43676[(1)]);
if((state_val_43677 === (7))){
var inst_43658 = (state_43676[(2)]);
var state_43676__$1 = state_43676;
var statearr_43678_43705 = state_43676__$1;
(statearr_43678_43705[(2)] = inst_43658);

(statearr_43678_43705[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43677 === (1))){
var inst_43652 = cljs.core.seq(coll);
var inst_43653 = inst_43652;
var state_43676__$1 = (function (){var statearr_43679 = state_43676;
(statearr_43679[(7)] = inst_43653);

return statearr_43679;
})();
var statearr_43680_43706 = state_43676__$1;
(statearr_43680_43706[(2)] = null);

(statearr_43680_43706[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43677 === (4))){
var inst_43653 = (state_43676[(7)]);
var inst_43656 = cljs.core.first(inst_43653);
var state_43676__$1 = state_43676;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_43676__$1,(7),ch,inst_43656);
} else {
if((state_val_43677 === (13))){
var inst_43670 = (state_43676[(2)]);
var state_43676__$1 = state_43676;
var statearr_43681_43707 = state_43676__$1;
(statearr_43681_43707[(2)] = inst_43670);

(statearr_43681_43707[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43677 === (6))){
var inst_43661 = (state_43676[(2)]);
var state_43676__$1 = state_43676;
if(cljs.core.truth_(inst_43661)){
var statearr_43682_43708 = state_43676__$1;
(statearr_43682_43708[(1)] = (8));

} else {
var statearr_43683_43709 = state_43676__$1;
(statearr_43683_43709[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43677 === (3))){
var inst_43674 = (state_43676[(2)]);
var state_43676__$1 = state_43676;
return cljs.core.async.impl.ioc_helpers.return_chan(state_43676__$1,inst_43674);
} else {
if((state_val_43677 === (12))){
var state_43676__$1 = state_43676;
var statearr_43684_43710 = state_43676__$1;
(statearr_43684_43710[(2)] = null);

(statearr_43684_43710[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43677 === (2))){
var inst_43653 = (state_43676[(7)]);
var state_43676__$1 = state_43676;
if(cljs.core.truth_(inst_43653)){
var statearr_43685_43711 = state_43676__$1;
(statearr_43685_43711[(1)] = (4));

} else {
var statearr_43686_43712 = state_43676__$1;
(statearr_43686_43712[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43677 === (11))){
var inst_43667 = cljs.core.async.close_BANG_(ch);
var state_43676__$1 = state_43676;
var statearr_43687_43713 = state_43676__$1;
(statearr_43687_43713[(2)] = inst_43667);

(statearr_43687_43713[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43677 === (9))){
var state_43676__$1 = state_43676;
if(cljs.core.truth_(close_QMARK_)){
var statearr_43688_43714 = state_43676__$1;
(statearr_43688_43714[(1)] = (11));

} else {
var statearr_43689_43715 = state_43676__$1;
(statearr_43689_43715[(1)] = (12));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_43677 === (5))){
var inst_43653 = (state_43676[(7)]);
var state_43676__$1 = state_43676;
var statearr_43690_43716 = state_43676__$1;
(statearr_43690_43716[(2)] = inst_43653);

(statearr_43690_43716[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43677 === (10))){
var inst_43672 = (state_43676[(2)]);
var state_43676__$1 = state_43676;
var statearr_43691_43717 = state_43676__$1;
(statearr_43691_43717[(2)] = inst_43672);

(statearr_43691_43717[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_43677 === (8))){
var inst_43653 = (state_43676[(7)]);
var inst_43663 = cljs.core.next(inst_43653);
var inst_43653__$1 = inst_43663;
var state_43676__$1 = (function (){var statearr_43692 = state_43676;
(statearr_43692[(7)] = inst_43653__$1);

return statearr_43692;
})();
var statearr_43693_43718 = state_43676__$1;
(statearr_43693_43718[(2)] = null);

(statearr_43693_43718[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_43697 = [null,null,null,null,null,null,null,null];
(statearr_43697[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_43697[(1)] = (1));

return statearr_43697;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_43676){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_43676);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e43698){if((e43698 instanceof Object)){
var ex__15102__auto__ = e43698;
var statearr_43699_43719 = state_43676;
(statearr_43699_43719[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_43676);

return cljs.core.cst$kw$recur;
} else {
throw e43698;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__43720 = state_43676;
state_43676 = G__43720;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_43676){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_43676);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_43700 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_43700[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_43700;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});

cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(cljs.core.bounded_count((100),coll));
cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2(ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((!((_ == null))) && (!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__7652__auto__ = (((_ == null))?null:_);
var m__7653__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__7653__auto__.call(null,_));
} else {
var m__7653__auto____$1 = (cljs.core.async.muxch_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1(_) : m__7653__auto____$1.call(null,_));
} else {
throw cljs.core.missing_protocol("Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((!((m == null))) && (!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$3 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__7653__auto__.call(null,m,ch,close_QMARK_));
} else {
var m__7653__auto____$1 = (cljs.core.async.tap_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$3 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__7653__auto____$1.call(null,m,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto__.call(null,m,ch));
} else {
var m__7653__auto____$1 = (cljs.core.async.untap_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((!((m == null))) && (!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__7653__auto__.call(null,m));
} else {
var m__7653__auto____$1 = (cljs.core.async.untap_all_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1(m) : m__7653__auto____$1.call(null,m));
} else {
throw cljs.core.missing_protocol("Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = (function (){var G__43949 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__43949) : cljs.core.atom.call(null,G__43949));
})();
var m = (function (){
if(typeof cljs.core.async.t_cljs$core$async43950 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async43950 = (function (mult,ch,cs,meta43951){
this.mult = mult;
this.ch = ch;
this.cs = cs;
this.meta43951 = meta43951;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async43950.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs){
return (function (_43952,meta43951__$1){
var self__ = this;
var _43952__$1 = this;
return (new cljs.core.async.t_cljs$core$async43950(self__.mult,self__.ch,self__.cs,meta43951__$1));
});})(cs))
;

cljs.core.async.t_cljs$core$async43950.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs){
return (function (_43952){
var self__ = this;
var _43952__$1 = this;
return self__.meta43951;
});})(cs))
;

cljs.core.async.t_cljs$core$async43950.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async43950.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(cs))
;

cljs.core.async.t_cljs$core$async43950.prototype.cljs$core$async$Mult$ = true;

cljs.core.async.t_cljs$core$async43950.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = ((function (cs){
return (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async43950.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = ((function (cs){
return (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch__$1);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async43950.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
var G__43953_44177 = self__.cs;
var G__43954_44178 = cljs.core.PersistentArrayMap.EMPTY;
(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__43953_44177,G__43954_44178) : cljs.core.reset_BANG_.call(null,G__43953_44177,G__43954_44178));

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async43950.getBasis = ((function (cs){
return (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$mult,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch], null))),cljs.core.cst$kw$doc,"Creates and returns a mult(iple) of the supplied channel. Channels\n  containing copies of the channel can be created with 'tap', and\n  detached with 'untap'.\n\n  Each item is distributed to all taps in parallel and synchronously,\n  i.e. each tap must accept before the next item is distributed. Use\n  buffering/windowing to prevent slow taps from holding up the mult.\n\n  Items received when there are no taps get dropped.\n\n  If a tap puts to a closed channel, it will be removed from the mult."], null)),cljs.core.cst$sym$ch,cljs.core.cst$sym$cs,cljs.core.cst$sym$meta43951], null);
});})(cs))
;

cljs.core.async.t_cljs$core$async43950.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async43950.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async43950";

cljs.core.async.t_cljs$core$async43950.cljs$lang$ctorPrWriter = ((function (cs){
return (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async43950");
});})(cs))
;

cljs.core.async.__GT_t_cljs$core$async43950 = ((function (cs){
return (function cljs$core$async$mult_$___GT_t_cljs$core$async43950(mult__$1,ch__$1,cs__$1,meta43951){
return (new cljs.core.async.t_cljs$core$async43950(mult__$1,ch__$1,cs__$1,meta43951));
});})(cs))
;

}

return (new cljs.core.async.t_cljs$core$async43950(cljs$core$async$mult,ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null) : cljs.core.atom.call(null,null));
var done = ((function (cs,m,dchan,dctr){
return (function (_){
if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,true);
} else {
return null;
}
});})(cs,m,dchan,dctr))
;
var c__15224__auto___44179 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___44179,cs,m,dchan,dctr,done){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___44179,cs,m,dchan,dctr,done){
return (function (state_44089){
var state_val_44090 = (state_44089[(1)]);
if((state_val_44090 === (7))){
var inst_44085 = (state_44089[(2)]);
var state_44089__$1 = state_44089;
var statearr_44091_44180 = state_44089__$1;
(statearr_44091_44180[(2)] = inst_44085);

(statearr_44091_44180[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (20))){
var inst_43988 = (state_44089[(7)]);
var inst_44000 = cljs.core.first(inst_43988);
var inst_44001 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_44000,(0),null);
var inst_44002 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_44000,(1),null);
var state_44089__$1 = (function (){var statearr_44092 = state_44089;
(statearr_44092[(8)] = inst_44001);

return statearr_44092;
})();
if(cljs.core.truth_(inst_44002)){
var statearr_44093_44181 = state_44089__$1;
(statearr_44093_44181[(1)] = (22));

} else {
var statearr_44094_44182 = state_44089__$1;
(statearr_44094_44182[(1)] = (23));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (27))){
var inst_43957 = (state_44089[(9)]);
var inst_44037 = (state_44089[(10)]);
var inst_44032 = (state_44089[(11)]);
var inst_44030 = (state_44089[(12)]);
var inst_44037__$1 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_44030,inst_44032);
var inst_44038 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_44037__$1,inst_43957,done);
var state_44089__$1 = (function (){var statearr_44095 = state_44089;
(statearr_44095[(10)] = inst_44037__$1);

return statearr_44095;
})();
if(cljs.core.truth_(inst_44038)){
var statearr_44096_44183 = state_44089__$1;
(statearr_44096_44183[(1)] = (30));

} else {
var statearr_44097_44184 = state_44089__$1;
(statearr_44097_44184[(1)] = (31));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (1))){
var state_44089__$1 = state_44089;
var statearr_44098_44185 = state_44089__$1;
(statearr_44098_44185[(2)] = null);

(statearr_44098_44185[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (24))){
var inst_43988 = (state_44089[(7)]);
var inst_44007 = (state_44089[(2)]);
var inst_44008 = cljs.core.next(inst_43988);
var inst_43966 = inst_44008;
var inst_43967 = null;
var inst_43968 = (0);
var inst_43969 = (0);
var state_44089__$1 = (function (){var statearr_44099 = state_44089;
(statearr_44099[(13)] = inst_43966);

(statearr_44099[(14)] = inst_44007);

(statearr_44099[(15)] = inst_43969);

(statearr_44099[(16)] = inst_43968);

(statearr_44099[(17)] = inst_43967);

return statearr_44099;
})();
var statearr_44100_44186 = state_44089__$1;
(statearr_44100_44186[(2)] = null);

(statearr_44100_44186[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (39))){
var state_44089__$1 = state_44089;
var statearr_44104_44187 = state_44089__$1;
(statearr_44104_44187[(2)] = null);

(statearr_44104_44187[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (4))){
var inst_43957 = (state_44089[(9)]);
var inst_43957__$1 = (state_44089[(2)]);
var inst_43958 = (inst_43957__$1 == null);
var state_44089__$1 = (function (){var statearr_44105 = state_44089;
(statearr_44105[(9)] = inst_43957__$1);

return statearr_44105;
})();
if(cljs.core.truth_(inst_43958)){
var statearr_44106_44188 = state_44089__$1;
(statearr_44106_44188[(1)] = (5));

} else {
var statearr_44107_44189 = state_44089__$1;
(statearr_44107_44189[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (15))){
var inst_43966 = (state_44089[(13)]);
var inst_43969 = (state_44089[(15)]);
var inst_43968 = (state_44089[(16)]);
var inst_43967 = (state_44089[(17)]);
var inst_43984 = (state_44089[(2)]);
var inst_43985 = (inst_43969 + (1));
var tmp44101 = inst_43966;
var tmp44102 = inst_43968;
var tmp44103 = inst_43967;
var inst_43966__$1 = tmp44101;
var inst_43967__$1 = tmp44103;
var inst_43968__$1 = tmp44102;
var inst_43969__$1 = inst_43985;
var state_44089__$1 = (function (){var statearr_44108 = state_44089;
(statearr_44108[(13)] = inst_43966__$1);

(statearr_44108[(15)] = inst_43969__$1);

(statearr_44108[(18)] = inst_43984);

(statearr_44108[(16)] = inst_43968__$1);

(statearr_44108[(17)] = inst_43967__$1);

return statearr_44108;
})();
var statearr_44109_44190 = state_44089__$1;
(statearr_44109_44190[(2)] = null);

(statearr_44109_44190[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (21))){
var inst_44011 = (state_44089[(2)]);
var state_44089__$1 = state_44089;
var statearr_44113_44191 = state_44089__$1;
(statearr_44113_44191[(2)] = inst_44011);

(statearr_44113_44191[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (31))){
var inst_44037 = (state_44089[(10)]);
var inst_44041 = done(null);
var inst_44042 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_44037);
var state_44089__$1 = (function (){var statearr_44114 = state_44089;
(statearr_44114[(19)] = inst_44041);

return statearr_44114;
})();
var statearr_44115_44192 = state_44089__$1;
(statearr_44115_44192[(2)] = inst_44042);

(statearr_44115_44192[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (32))){
var inst_44029 = (state_44089[(20)]);
var inst_44031 = (state_44089[(21)]);
var inst_44032 = (state_44089[(11)]);
var inst_44030 = (state_44089[(12)]);
var inst_44044 = (state_44089[(2)]);
var inst_44045 = (inst_44032 + (1));
var tmp44110 = inst_44029;
var tmp44111 = inst_44031;
var tmp44112 = inst_44030;
var inst_44029__$1 = tmp44110;
var inst_44030__$1 = tmp44112;
var inst_44031__$1 = tmp44111;
var inst_44032__$1 = inst_44045;
var state_44089__$1 = (function (){var statearr_44116 = state_44089;
(statearr_44116[(20)] = inst_44029__$1);

(statearr_44116[(21)] = inst_44031__$1);

(statearr_44116[(22)] = inst_44044);

(statearr_44116[(11)] = inst_44032__$1);

(statearr_44116[(12)] = inst_44030__$1);

return statearr_44116;
})();
var statearr_44117_44193 = state_44089__$1;
(statearr_44117_44193[(2)] = null);

(statearr_44117_44193[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (40))){
var inst_44057 = (state_44089[(23)]);
var inst_44061 = done(null);
var inst_44062 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_44057);
var state_44089__$1 = (function (){var statearr_44118 = state_44089;
(statearr_44118[(24)] = inst_44061);

return statearr_44118;
})();
var statearr_44119_44194 = state_44089__$1;
(statearr_44119_44194[(2)] = inst_44062);

(statearr_44119_44194[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (33))){
var inst_44048 = (state_44089[(25)]);
var inst_44050 = cljs.core.chunked_seq_QMARK_(inst_44048);
var state_44089__$1 = state_44089;
if(inst_44050){
var statearr_44120_44195 = state_44089__$1;
(statearr_44120_44195[(1)] = (36));

} else {
var statearr_44121_44196 = state_44089__$1;
(statearr_44121_44196[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (13))){
var inst_43978 = (state_44089[(26)]);
var inst_43981 = cljs.core.async.close_BANG_(inst_43978);
var state_44089__$1 = state_44089;
var statearr_44122_44197 = state_44089__$1;
(statearr_44122_44197[(2)] = inst_43981);

(statearr_44122_44197[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (22))){
var inst_44001 = (state_44089[(8)]);
var inst_44004 = cljs.core.async.close_BANG_(inst_44001);
var state_44089__$1 = state_44089;
var statearr_44123_44198 = state_44089__$1;
(statearr_44123_44198[(2)] = inst_44004);

(statearr_44123_44198[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (36))){
var inst_44048 = (state_44089[(25)]);
var inst_44052 = cljs.core.chunk_first(inst_44048);
var inst_44053 = cljs.core.chunk_rest(inst_44048);
var inst_44054 = cljs.core.count(inst_44052);
var inst_44029 = inst_44053;
var inst_44030 = inst_44052;
var inst_44031 = inst_44054;
var inst_44032 = (0);
var state_44089__$1 = (function (){var statearr_44124 = state_44089;
(statearr_44124[(20)] = inst_44029);

(statearr_44124[(21)] = inst_44031);

(statearr_44124[(11)] = inst_44032);

(statearr_44124[(12)] = inst_44030);

return statearr_44124;
})();
var statearr_44125_44199 = state_44089__$1;
(statearr_44125_44199[(2)] = null);

(statearr_44125_44199[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (41))){
var inst_44048 = (state_44089[(25)]);
var inst_44064 = (state_44089[(2)]);
var inst_44065 = cljs.core.next(inst_44048);
var inst_44029 = inst_44065;
var inst_44030 = null;
var inst_44031 = (0);
var inst_44032 = (0);
var state_44089__$1 = (function (){var statearr_44126 = state_44089;
(statearr_44126[(27)] = inst_44064);

(statearr_44126[(20)] = inst_44029);

(statearr_44126[(21)] = inst_44031);

(statearr_44126[(11)] = inst_44032);

(statearr_44126[(12)] = inst_44030);

return statearr_44126;
})();
var statearr_44127_44200 = state_44089__$1;
(statearr_44127_44200[(2)] = null);

(statearr_44127_44200[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (43))){
var state_44089__$1 = state_44089;
var statearr_44128_44201 = state_44089__$1;
(statearr_44128_44201[(2)] = null);

(statearr_44128_44201[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (29))){
var inst_44073 = (state_44089[(2)]);
var state_44089__$1 = state_44089;
var statearr_44129_44202 = state_44089__$1;
(statearr_44129_44202[(2)] = inst_44073);

(statearr_44129_44202[(1)] = (26));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (44))){
var inst_44082 = (state_44089[(2)]);
var state_44089__$1 = (function (){var statearr_44130 = state_44089;
(statearr_44130[(28)] = inst_44082);

return statearr_44130;
})();
var statearr_44131_44203 = state_44089__$1;
(statearr_44131_44203[(2)] = null);

(statearr_44131_44203[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (6))){
var inst_44021 = (state_44089[(29)]);
var inst_44020 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(cs) : cljs.core.deref.call(null,cs));
var inst_44021__$1 = cljs.core.keys(inst_44020);
var inst_44022 = cljs.core.count(inst_44021__$1);
var inst_44023 = (cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,inst_44022) : cljs.core.reset_BANG_.call(null,dctr,inst_44022));
var inst_44028 = cljs.core.seq(inst_44021__$1);
var inst_44029 = inst_44028;
var inst_44030 = null;
var inst_44031 = (0);
var inst_44032 = (0);
var state_44089__$1 = (function (){var statearr_44132 = state_44089;
(statearr_44132[(20)] = inst_44029);

(statearr_44132[(21)] = inst_44031);

(statearr_44132[(29)] = inst_44021__$1);

(statearr_44132[(30)] = inst_44023);

(statearr_44132[(11)] = inst_44032);

(statearr_44132[(12)] = inst_44030);

return statearr_44132;
})();
var statearr_44133_44204 = state_44089__$1;
(statearr_44133_44204[(2)] = null);

(statearr_44133_44204[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (28))){
var inst_44029 = (state_44089[(20)]);
var inst_44048 = (state_44089[(25)]);
var inst_44048__$1 = cljs.core.seq(inst_44029);
var state_44089__$1 = (function (){var statearr_44134 = state_44089;
(statearr_44134[(25)] = inst_44048__$1);

return statearr_44134;
})();
if(inst_44048__$1){
var statearr_44135_44205 = state_44089__$1;
(statearr_44135_44205[(1)] = (33));

} else {
var statearr_44136_44206 = state_44089__$1;
(statearr_44136_44206[(1)] = (34));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (25))){
var inst_44031 = (state_44089[(21)]);
var inst_44032 = (state_44089[(11)]);
var inst_44034 = (inst_44032 < inst_44031);
var inst_44035 = inst_44034;
var state_44089__$1 = state_44089;
if(cljs.core.truth_(inst_44035)){
var statearr_44137_44207 = state_44089__$1;
(statearr_44137_44207[(1)] = (27));

} else {
var statearr_44138_44208 = state_44089__$1;
(statearr_44138_44208[(1)] = (28));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (34))){
var state_44089__$1 = state_44089;
var statearr_44139_44209 = state_44089__$1;
(statearr_44139_44209[(2)] = null);

(statearr_44139_44209[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (17))){
var state_44089__$1 = state_44089;
var statearr_44140_44210 = state_44089__$1;
(statearr_44140_44210[(2)] = null);

(statearr_44140_44210[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (3))){
var inst_44087 = (state_44089[(2)]);
var state_44089__$1 = state_44089;
return cljs.core.async.impl.ioc_helpers.return_chan(state_44089__$1,inst_44087);
} else {
if((state_val_44090 === (12))){
var inst_44016 = (state_44089[(2)]);
var state_44089__$1 = state_44089;
var statearr_44141_44211 = state_44089__$1;
(statearr_44141_44211[(2)] = inst_44016);

(statearr_44141_44211[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (2))){
var state_44089__$1 = state_44089;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_44089__$1,(4),ch);
} else {
if((state_val_44090 === (23))){
var state_44089__$1 = state_44089;
var statearr_44142_44212 = state_44089__$1;
(statearr_44142_44212[(2)] = null);

(statearr_44142_44212[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (35))){
var inst_44071 = (state_44089[(2)]);
var state_44089__$1 = state_44089;
var statearr_44143_44213 = state_44089__$1;
(statearr_44143_44213[(2)] = inst_44071);

(statearr_44143_44213[(1)] = (29));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (19))){
var inst_43988 = (state_44089[(7)]);
var inst_43992 = cljs.core.chunk_first(inst_43988);
var inst_43993 = cljs.core.chunk_rest(inst_43988);
var inst_43994 = cljs.core.count(inst_43992);
var inst_43966 = inst_43993;
var inst_43967 = inst_43992;
var inst_43968 = inst_43994;
var inst_43969 = (0);
var state_44089__$1 = (function (){var statearr_44144 = state_44089;
(statearr_44144[(13)] = inst_43966);

(statearr_44144[(15)] = inst_43969);

(statearr_44144[(16)] = inst_43968);

(statearr_44144[(17)] = inst_43967);

return statearr_44144;
})();
var statearr_44145_44214 = state_44089__$1;
(statearr_44145_44214[(2)] = null);

(statearr_44145_44214[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (11))){
var inst_43966 = (state_44089[(13)]);
var inst_43988 = (state_44089[(7)]);
var inst_43988__$1 = cljs.core.seq(inst_43966);
var state_44089__$1 = (function (){var statearr_44146 = state_44089;
(statearr_44146[(7)] = inst_43988__$1);

return statearr_44146;
})();
if(inst_43988__$1){
var statearr_44147_44215 = state_44089__$1;
(statearr_44147_44215[(1)] = (16));

} else {
var statearr_44148_44216 = state_44089__$1;
(statearr_44148_44216[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (9))){
var inst_44018 = (state_44089[(2)]);
var state_44089__$1 = state_44089;
var statearr_44149_44217 = state_44089__$1;
(statearr_44149_44217[(2)] = inst_44018);

(statearr_44149_44217[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (5))){
var inst_43964 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(cs) : cljs.core.deref.call(null,cs));
var inst_43965 = cljs.core.seq(inst_43964);
var inst_43966 = inst_43965;
var inst_43967 = null;
var inst_43968 = (0);
var inst_43969 = (0);
var state_44089__$1 = (function (){var statearr_44150 = state_44089;
(statearr_44150[(13)] = inst_43966);

(statearr_44150[(15)] = inst_43969);

(statearr_44150[(16)] = inst_43968);

(statearr_44150[(17)] = inst_43967);

return statearr_44150;
})();
var statearr_44151_44218 = state_44089__$1;
(statearr_44151_44218[(2)] = null);

(statearr_44151_44218[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (14))){
var state_44089__$1 = state_44089;
var statearr_44152_44219 = state_44089__$1;
(statearr_44152_44219[(2)] = null);

(statearr_44152_44219[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (45))){
var inst_44079 = (state_44089[(2)]);
var state_44089__$1 = state_44089;
var statearr_44153_44220 = state_44089__$1;
(statearr_44153_44220[(2)] = inst_44079);

(statearr_44153_44220[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (26))){
var inst_44021 = (state_44089[(29)]);
var inst_44075 = (state_44089[(2)]);
var inst_44076 = cljs.core.seq(inst_44021);
var state_44089__$1 = (function (){var statearr_44154 = state_44089;
(statearr_44154[(31)] = inst_44075);

return statearr_44154;
})();
if(inst_44076){
var statearr_44155_44221 = state_44089__$1;
(statearr_44155_44221[(1)] = (42));

} else {
var statearr_44156_44222 = state_44089__$1;
(statearr_44156_44222[(1)] = (43));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (16))){
var inst_43988 = (state_44089[(7)]);
var inst_43990 = cljs.core.chunked_seq_QMARK_(inst_43988);
var state_44089__$1 = state_44089;
if(inst_43990){
var statearr_44157_44223 = state_44089__$1;
(statearr_44157_44223[(1)] = (19));

} else {
var statearr_44158_44224 = state_44089__$1;
(statearr_44158_44224[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (38))){
var inst_44068 = (state_44089[(2)]);
var state_44089__$1 = state_44089;
var statearr_44159_44225 = state_44089__$1;
(statearr_44159_44225[(2)] = inst_44068);

(statearr_44159_44225[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (30))){
var state_44089__$1 = state_44089;
var statearr_44160_44226 = state_44089__$1;
(statearr_44160_44226[(2)] = null);

(statearr_44160_44226[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (10))){
var inst_43969 = (state_44089[(15)]);
var inst_43967 = (state_44089[(17)]);
var inst_43977 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_43967,inst_43969);
var inst_43978 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_43977,(0),null);
var inst_43979 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_43977,(1),null);
var state_44089__$1 = (function (){var statearr_44161 = state_44089;
(statearr_44161[(26)] = inst_43978);

return statearr_44161;
})();
if(cljs.core.truth_(inst_43979)){
var statearr_44162_44227 = state_44089__$1;
(statearr_44162_44227[(1)] = (13));

} else {
var statearr_44163_44228 = state_44089__$1;
(statearr_44163_44228[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (18))){
var inst_44014 = (state_44089[(2)]);
var state_44089__$1 = state_44089;
var statearr_44164_44229 = state_44089__$1;
(statearr_44164_44229[(2)] = inst_44014);

(statearr_44164_44229[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (42))){
var state_44089__$1 = state_44089;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_44089__$1,(45),dchan);
} else {
if((state_val_44090 === (37))){
var inst_43957 = (state_44089[(9)]);
var inst_44057 = (state_44089[(23)]);
var inst_44048 = (state_44089[(25)]);
var inst_44057__$1 = cljs.core.first(inst_44048);
var inst_44058 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_44057__$1,inst_43957,done);
var state_44089__$1 = (function (){var statearr_44165 = state_44089;
(statearr_44165[(23)] = inst_44057__$1);

return statearr_44165;
})();
if(cljs.core.truth_(inst_44058)){
var statearr_44166_44230 = state_44089__$1;
(statearr_44166_44230[(1)] = (39));

} else {
var statearr_44167_44231 = state_44089__$1;
(statearr_44167_44231[(1)] = (40));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44090 === (8))){
var inst_43969 = (state_44089[(15)]);
var inst_43968 = (state_44089[(16)]);
var inst_43971 = (inst_43969 < inst_43968);
var inst_43972 = inst_43971;
var state_44089__$1 = state_44089;
if(cljs.core.truth_(inst_43972)){
var statearr_44168_44232 = state_44089__$1;
(statearr_44168_44232[(1)] = (10));

} else {
var statearr_44169_44233 = state_44089__$1;
(statearr_44169_44233[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___44179,cs,m,dchan,dctr,done))
;
return ((function (switch__15098__auto__,c__15224__auto___44179,cs,m,dchan,dctr,done){
return (function() {
var cljs$core$async$mult_$_state_machine__15099__auto__ = null;
var cljs$core$async$mult_$_state_machine__15099__auto____0 = (function (){
var statearr_44173 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_44173[(0)] = cljs$core$async$mult_$_state_machine__15099__auto__);

(statearr_44173[(1)] = (1));

return statearr_44173;
});
var cljs$core$async$mult_$_state_machine__15099__auto____1 = (function (state_44089){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_44089);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e44174){if((e44174 instanceof Object)){
var ex__15102__auto__ = e44174;
var statearr_44175_44234 = state_44089;
(statearr_44175_44234[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_44089);

return cljs.core.cst$kw$recur;
} else {
throw e44174;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__44235 = state_44089;
state_44089 = G__44235;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__15099__auto__ = function(state_44089){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__15099__auto____1.call(this,state_44089);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__15099__auto____0;
cljs$core$async$mult_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__15099__auto____1;
return cljs$core$async$mult_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___44179,cs,m,dchan,dctr,done))
})();
var state__15226__auto__ = (function (){var statearr_44176 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_44176[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___44179);

return statearr_44176;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___44179,cs,m,dchan,dctr,done))
);


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var args44236 = [];
var len__8118__auto___44239 = arguments.length;
var i__8119__auto___44240 = (0);
while(true){
if((i__8119__auto___44240 < len__8118__auto___44239)){
args44236.push((arguments[i__8119__auto___44240]));

var G__44241 = (i__8119__auto___44240 + (1));
i__8119__auto___44240 = G__44241;
continue;
} else {
}
break;
}

var G__44238 = args44236.length;
switch (G__44238) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args44236.length)].join('')));

}
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(mult,ch,true);
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_(mult,ch,close_QMARK_);

return ch;
});

cljs.core.async.tap.cljs$lang$maxFixedArity = 3;

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_(mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_(mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto__.call(null,m,ch));
} else {
var m__7653__auto____$1 = (cljs.core.async.admix_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto__.call(null,m,ch));
} else {
var m__7653__auto____$1 = (cljs.core.async.unmix_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((!((m == null))) && (!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__7653__auto__.call(null,m));
} else {
var m__7653__auto____$1 = (cljs.core.async.unmix_all_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1(m) : m__7653__auto____$1.call(null,m));
} else {
throw cljs.core.missing_protocol("Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((!((m == null))) && (!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__7653__auto__.call(null,m,state_map));
} else {
var m__7653__auto____$1 = (cljs.core.async.toggle_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__7653__auto____$1.call(null,m,state_map));
} else {
throw cljs.core.missing_protocol("Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((!((m == null))) && (!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__7653__auto__.call(null,m,mode));
} else {
var m__7653__auto____$1 = (cljs.core.async.solo_mode_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(m,mode) : m__7653__auto____$1.call(null,m,mode));
} else {
throw cljs.core.missing_protocol("Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___44253 = arguments.length;
var i__8119__auto___44254 = (0);
while(true){
if((i__8119__auto___44254 < len__8118__auto___44253)){
args__8125__auto__.push((arguments[i__8119__auto___44254]));

var G__44255 = (i__8119__auto___44254 + (1));
i__8119__auto___44254 = G__44255;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((3) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__8126__auto__);
});

cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__44247){
var map__44248 = p__44247;
var map__44248__$1 = ((((!((map__44248 == null)))?((((map__44248.cljs$lang$protocol_mask$partition0$ & (64))) || (map__44248.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__44248):map__44248);
var opts = map__44248__$1;
var statearr_44250_44256 = state;
(statearr_44250_44256[cljs.core.async.impl.ioc_helpers.STATE_IDX] = cont_block);


var temp__6728__auto__ = cljs.core.async.do_alts(((function (map__44248,map__44248__$1,opts){
return (function (val){
var statearr_44251_44257 = state;
(statearr_44251_44257[cljs.core.async.impl.ioc_helpers.VALUE_IDX] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state);
});})(map__44248,map__44248__$1,opts))
,ports,opts);
if(cljs.core.truth_(temp__6728__auto__)){
var cb = temp__6728__auto__;
var statearr_44252_44258 = state;
(statearr_44252_44258[cljs.core.async.impl.ioc_helpers.VALUE_IDX] = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(cb) : cljs.core.deref.call(null,cb)));


return cljs.core.cst$kw$recur;
} else {
return null;
}
});

cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3);

cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq44243){
var G__44244 = cljs.core.first(seq44243);
var seq44243__$1 = cljs.core.next(seq44243);
var G__44245 = cljs.core.first(seq44243__$1);
var seq44243__$2 = cljs.core.next(seq44243__$1);
var G__44246 = cljs.core.first(seq44243__$2);
var seq44243__$3 = cljs.core.next(seq44243__$2);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__44244,G__44245,G__44246,seq44243__$3);
});

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = (function (){var G__44428 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__44428) : cljs.core.atom.call(null,G__44428));
})();
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$pause,null,cljs.core.cst$kw$mute,null], null), null);
var attrs = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(solo_modes,cljs.core.cst$kw$solo);
var solo_mode = (function (){var G__44429 = cljs.core.cst$kw$mute;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__44429) : cljs.core.atom.call(null,G__44429));
})();
var change = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var changed = ((function (cs,solo_modes,attrs,solo_mode,change){
return (function (){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(change,true);
});})(cs,solo_modes,attrs,solo_mode,change))
;
var pick = ((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (attr,chs){
return cljs.core.reduce_kv(((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (ret,c,v){
if(cljs.core.truth_((attr.cljs$core$IFn$_invoke$arity$1 ? attr.cljs$core$IFn$_invoke$arity$1(v) : attr.call(null,v)))){
return cljs.core.conj.cljs$core$IFn$_invoke$arity$2(ret,c);
} else {
return ret;
}
});})(cs,solo_modes,attrs,solo_mode,change,changed))
,cljs.core.PersistentHashSet.EMPTY,chs);
});})(cs,solo_modes,attrs,solo_mode,change,changed))
;
var calc_state = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick){
return (function (){
var chs = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(cs) : cljs.core.deref.call(null,cs));
var mode = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(solo_mode) : cljs.core.deref.call(null,solo_mode));
var solos = pick(cljs.core.cst$kw$solo,chs);
var pauses = pick(cljs.core.cst$kw$pause,chs);
return new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$solos,solos,cljs.core.cst$kw$mutes,pick(cljs.core.cst$kw$mute,chs),cljs.core.cst$kw$reads,cljs.core.conj.cljs$core$IFn$_invoke$arity$2((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,cljs.core.cst$kw$pause)) && (!(cljs.core.empty_QMARK_(solos))))?cljs.core.vec(solos):cljs.core.vec(cljs.core.remove.cljs$core$IFn$_invoke$arity$2(pauses,cljs.core.keys(chs)))),change)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick))
;
var m = (function (){
if(typeof cljs.core.async.t_cljs$core$async44430 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async44430 = (function (change,mix,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,meta44431){
this.change = change;
this.mix = mix;
this.solo_mode = solo_mode;
this.pick = pick;
this.cs = cs;
this.calc_state = calc_state;
this.out = out;
this.changed = changed;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.meta44431 = meta44431;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async44430.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_44432,meta44431__$1){
var self__ = this;
var _44432__$1 = this;
return (new cljs.core.async.t_cljs$core$async44430(self__.change,self__.mix,self__.solo_mode,self__.pick,self__.cs,self__.calc_state,self__.out,self__.changed,self__.solo_modes,self__.attrs,meta44431__$1));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async44430.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_44432){
var self__ = this;
var _44432__$1 = this;
return self__.meta44431;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async44430.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async44430.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async44430.prototype.cljs$core$async$Mix$ = true;

cljs.core.async.t_cljs$core$async44430.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async44430.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async44430.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
var G__44433_44597 = self__.cs;
var G__44434_44598 = cljs.core.PersistentArrayMap.EMPTY;
(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__44433_44597,G__44434_44598) : cljs.core.reset_BANG_.call(null,G__44433_44597,G__44434_44598));

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async44430.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.partial.cljs$core$IFn$_invoke$arity$2(cljs.core.merge_with,cljs.core.merge),state_map);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async44430.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,mode){
var self__ = this;
var ___$1 = this;

(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(self__.solo_mode,mode) : cljs.core.reset_BANG_.call(null,self__.solo_mode,mode));

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async44430.getBasis = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (){
return new cljs.core.PersistentVector(null, 11, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$change,cljs.core.with_meta(cljs.core.cst$sym$mix,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$out], null))),cljs.core.cst$kw$doc,"Creates and returns a mix of one or more input channels which will\n  be put on the supplied out channel. Input sources can be added to\n  the mix with 'admix', and removed with 'unmix'. A mix supports\n  soloing, muting and pausing multiple inputs atomically using\n  'toggle', and can solo using either muting or pausing as determined\n  by 'solo-mode'.\n\n  Each channel can have zero or more boolean modes set via 'toggle':\n\n  :solo - when true, only this (ond other soloed) channel(s) will appear\n          in the mix output channel. :mute and :pause states of soloed\n          channels are ignored. If solo-mode is :mute, non-soloed\n          channels are muted, if :pause, non-soloed channels are\n          paused.\n\n  :mute - muted channels will have their contents consumed but not included in the mix\n  :pause - paused channels will not have their contents consumed (and thus also not included in the mix)\n"], null)),cljs.core.cst$sym$solo_DASH_mode,cljs.core.cst$sym$pick,cljs.core.cst$sym$cs,cljs.core.cst$sym$calc_DASH_state,cljs.core.cst$sym$out,cljs.core.cst$sym$changed,cljs.core.cst$sym$solo_DASH_modes,cljs.core.cst$sym$attrs,cljs.core.cst$sym$meta44431], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async44430.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async44430.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async44430";

cljs.core.async.t_cljs$core$async44430.cljs$lang$ctorPrWriter = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async44430");
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.__GT_t_cljs$core$async44430 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function cljs$core$async$mix_$___GT_t_cljs$core$async44430(change__$1,mix__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta44431){
return (new cljs.core.async.t_cljs$core$async44430(change__$1,mix__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta44431));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

}

return (new cljs.core.async.t_cljs$core$async44430(change,cljs$core$async$mix,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__15224__auto___44599 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___44599,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___44599,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (state_44534){
var state_val_44535 = (state_44534[(1)]);
if((state_val_44535 === (7))){
var inst_44450 = (state_44534[(2)]);
var state_44534__$1 = state_44534;
var statearr_44536_44600 = state_44534__$1;
(statearr_44536_44600[(2)] = inst_44450);

(statearr_44536_44600[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (20))){
var inst_44462 = (state_44534[(7)]);
var state_44534__$1 = state_44534;
var statearr_44537_44601 = state_44534__$1;
(statearr_44537_44601[(2)] = inst_44462);

(statearr_44537_44601[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (27))){
var state_44534__$1 = state_44534;
var statearr_44538_44602 = state_44534__$1;
(statearr_44538_44602[(2)] = null);

(statearr_44538_44602[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (1))){
var inst_44438 = (state_44534[(8)]);
var inst_44438__$1 = calc_state();
var inst_44440 = (inst_44438__$1 == null);
var inst_44441 = cljs.core.not(inst_44440);
var state_44534__$1 = (function (){var statearr_44539 = state_44534;
(statearr_44539[(8)] = inst_44438__$1);

return statearr_44539;
})();
if(inst_44441){
var statearr_44540_44603 = state_44534__$1;
(statearr_44540_44603[(1)] = (2));

} else {
var statearr_44541_44604 = state_44534__$1;
(statearr_44541_44604[(1)] = (3));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (24))){
var inst_44494 = (state_44534[(9)]);
var inst_44485 = (state_44534[(10)]);
var inst_44508 = (state_44534[(11)]);
var inst_44508__$1 = (inst_44485.cljs$core$IFn$_invoke$arity$1 ? inst_44485.cljs$core$IFn$_invoke$arity$1(inst_44494) : inst_44485.call(null,inst_44494));
var state_44534__$1 = (function (){var statearr_44542 = state_44534;
(statearr_44542[(11)] = inst_44508__$1);

return statearr_44542;
})();
if(cljs.core.truth_(inst_44508__$1)){
var statearr_44543_44605 = state_44534__$1;
(statearr_44543_44605[(1)] = (29));

} else {
var statearr_44544_44606 = state_44534__$1;
(statearr_44544_44606[(1)] = (30));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (4))){
var inst_44453 = (state_44534[(2)]);
var state_44534__$1 = state_44534;
if(cljs.core.truth_(inst_44453)){
var statearr_44545_44607 = state_44534__$1;
(statearr_44545_44607[(1)] = (8));

} else {
var statearr_44546_44608 = state_44534__$1;
(statearr_44546_44608[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (15))){
var inst_44479 = (state_44534[(2)]);
var state_44534__$1 = state_44534;
if(cljs.core.truth_(inst_44479)){
var statearr_44547_44609 = state_44534__$1;
(statearr_44547_44609[(1)] = (19));

} else {
var statearr_44548_44610 = state_44534__$1;
(statearr_44548_44610[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (21))){
var inst_44484 = (state_44534[(12)]);
var inst_44484__$1 = (state_44534[(2)]);
var inst_44485 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_44484__$1,cljs.core.cst$kw$solos);
var inst_44486 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_44484__$1,cljs.core.cst$kw$mutes);
var inst_44487 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_44484__$1,cljs.core.cst$kw$reads);
var state_44534__$1 = (function (){var statearr_44549 = state_44534;
(statearr_44549[(13)] = inst_44486);

(statearr_44549[(12)] = inst_44484__$1);

(statearr_44549[(10)] = inst_44485);

return statearr_44549;
})();
return cljs.core.async.ioc_alts_BANG_(state_44534__$1,(22),inst_44487);
} else {
if((state_val_44535 === (31))){
var inst_44516 = (state_44534[(2)]);
var state_44534__$1 = state_44534;
if(cljs.core.truth_(inst_44516)){
var statearr_44550_44611 = state_44534__$1;
(statearr_44550_44611[(1)] = (32));

} else {
var statearr_44551_44612 = state_44534__$1;
(statearr_44551_44612[(1)] = (33));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (32))){
var inst_44493 = (state_44534[(14)]);
var state_44534__$1 = state_44534;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_44534__$1,(35),out,inst_44493);
} else {
if((state_val_44535 === (33))){
var inst_44484 = (state_44534[(12)]);
var inst_44462 = inst_44484;
var state_44534__$1 = (function (){var statearr_44552 = state_44534;
(statearr_44552[(7)] = inst_44462);

return statearr_44552;
})();
var statearr_44553_44613 = state_44534__$1;
(statearr_44553_44613[(2)] = null);

(statearr_44553_44613[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (13))){
var inst_44462 = (state_44534[(7)]);
var inst_44469 = inst_44462.cljs$lang$protocol_mask$partition0$;
var inst_44470 = (inst_44469 & (64));
var inst_44471 = inst_44462.cljs$core$ISeq$;
var inst_44472 = (inst_44470) || (inst_44471);
var state_44534__$1 = state_44534;
if(cljs.core.truth_(inst_44472)){
var statearr_44554_44614 = state_44534__$1;
(statearr_44554_44614[(1)] = (16));

} else {
var statearr_44555_44615 = state_44534__$1;
(statearr_44555_44615[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (22))){
var inst_44494 = (state_44534[(9)]);
var inst_44493 = (state_44534[(14)]);
var inst_44492 = (state_44534[(2)]);
var inst_44493__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_44492,(0),null);
var inst_44494__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_44492,(1),null);
var inst_44495 = (inst_44493__$1 == null);
var inst_44496 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_44494__$1,change);
var inst_44497 = (inst_44495) || (inst_44496);
var state_44534__$1 = (function (){var statearr_44556 = state_44534;
(statearr_44556[(9)] = inst_44494__$1);

(statearr_44556[(14)] = inst_44493__$1);

return statearr_44556;
})();
if(cljs.core.truth_(inst_44497)){
var statearr_44557_44616 = state_44534__$1;
(statearr_44557_44616[(1)] = (23));

} else {
var statearr_44558_44617 = state_44534__$1;
(statearr_44558_44617[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (36))){
var inst_44484 = (state_44534[(12)]);
var inst_44462 = inst_44484;
var state_44534__$1 = (function (){var statearr_44559 = state_44534;
(statearr_44559[(7)] = inst_44462);

return statearr_44559;
})();
var statearr_44560_44618 = state_44534__$1;
(statearr_44560_44618[(2)] = null);

(statearr_44560_44618[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (29))){
var inst_44508 = (state_44534[(11)]);
var state_44534__$1 = state_44534;
var statearr_44561_44619 = state_44534__$1;
(statearr_44561_44619[(2)] = inst_44508);

(statearr_44561_44619[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (6))){
var state_44534__$1 = state_44534;
var statearr_44562_44620 = state_44534__$1;
(statearr_44562_44620[(2)] = false);

(statearr_44562_44620[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (28))){
var inst_44504 = (state_44534[(2)]);
var inst_44505 = calc_state();
var inst_44462 = inst_44505;
var state_44534__$1 = (function (){var statearr_44563 = state_44534;
(statearr_44563[(7)] = inst_44462);

(statearr_44563[(15)] = inst_44504);

return statearr_44563;
})();
var statearr_44564_44621 = state_44534__$1;
(statearr_44564_44621[(2)] = null);

(statearr_44564_44621[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (25))){
var inst_44530 = (state_44534[(2)]);
var state_44534__$1 = state_44534;
var statearr_44565_44622 = state_44534__$1;
(statearr_44565_44622[(2)] = inst_44530);

(statearr_44565_44622[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (34))){
var inst_44528 = (state_44534[(2)]);
var state_44534__$1 = state_44534;
var statearr_44566_44623 = state_44534__$1;
(statearr_44566_44623[(2)] = inst_44528);

(statearr_44566_44623[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (17))){
var state_44534__$1 = state_44534;
var statearr_44567_44624 = state_44534__$1;
(statearr_44567_44624[(2)] = false);

(statearr_44567_44624[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (3))){
var state_44534__$1 = state_44534;
var statearr_44568_44625 = state_44534__$1;
(statearr_44568_44625[(2)] = false);

(statearr_44568_44625[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (12))){
var inst_44532 = (state_44534[(2)]);
var state_44534__$1 = state_44534;
return cljs.core.async.impl.ioc_helpers.return_chan(state_44534__$1,inst_44532);
} else {
if((state_val_44535 === (2))){
var inst_44438 = (state_44534[(8)]);
var inst_44443 = inst_44438.cljs$lang$protocol_mask$partition0$;
var inst_44444 = (inst_44443 & (64));
var inst_44445 = inst_44438.cljs$core$ISeq$;
var inst_44446 = (inst_44444) || (inst_44445);
var state_44534__$1 = state_44534;
if(cljs.core.truth_(inst_44446)){
var statearr_44569_44626 = state_44534__$1;
(statearr_44569_44626[(1)] = (5));

} else {
var statearr_44570_44627 = state_44534__$1;
(statearr_44570_44627[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (23))){
var inst_44493 = (state_44534[(14)]);
var inst_44499 = (inst_44493 == null);
var state_44534__$1 = state_44534;
if(cljs.core.truth_(inst_44499)){
var statearr_44571_44628 = state_44534__$1;
(statearr_44571_44628[(1)] = (26));

} else {
var statearr_44572_44629 = state_44534__$1;
(statearr_44572_44629[(1)] = (27));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (35))){
var inst_44519 = (state_44534[(2)]);
var state_44534__$1 = state_44534;
if(cljs.core.truth_(inst_44519)){
var statearr_44573_44630 = state_44534__$1;
(statearr_44573_44630[(1)] = (36));

} else {
var statearr_44574_44631 = state_44534__$1;
(statearr_44574_44631[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (19))){
var inst_44462 = (state_44534[(7)]);
var inst_44481 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_44462);
var state_44534__$1 = state_44534;
var statearr_44575_44632 = state_44534__$1;
(statearr_44575_44632[(2)] = inst_44481);

(statearr_44575_44632[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (11))){
var inst_44462 = (state_44534[(7)]);
var inst_44466 = (inst_44462 == null);
var inst_44467 = cljs.core.not(inst_44466);
var state_44534__$1 = state_44534;
if(inst_44467){
var statearr_44576_44633 = state_44534__$1;
(statearr_44576_44633[(1)] = (13));

} else {
var statearr_44577_44634 = state_44534__$1;
(statearr_44577_44634[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (9))){
var inst_44438 = (state_44534[(8)]);
var state_44534__$1 = state_44534;
var statearr_44578_44635 = state_44534__$1;
(statearr_44578_44635[(2)] = inst_44438);

(statearr_44578_44635[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (5))){
var state_44534__$1 = state_44534;
var statearr_44579_44636 = state_44534__$1;
(statearr_44579_44636[(2)] = true);

(statearr_44579_44636[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (14))){
var state_44534__$1 = state_44534;
var statearr_44580_44637 = state_44534__$1;
(statearr_44580_44637[(2)] = false);

(statearr_44580_44637[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (26))){
var inst_44494 = (state_44534[(9)]);
var inst_44501 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(cs,cljs.core.dissoc,inst_44494);
var state_44534__$1 = state_44534;
var statearr_44581_44638 = state_44534__$1;
(statearr_44581_44638[(2)] = inst_44501);

(statearr_44581_44638[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (16))){
var state_44534__$1 = state_44534;
var statearr_44582_44639 = state_44534__$1;
(statearr_44582_44639[(2)] = true);

(statearr_44582_44639[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (38))){
var inst_44524 = (state_44534[(2)]);
var state_44534__$1 = state_44534;
var statearr_44583_44640 = state_44534__$1;
(statearr_44583_44640[(2)] = inst_44524);

(statearr_44583_44640[(1)] = (34));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (30))){
var inst_44486 = (state_44534[(13)]);
var inst_44494 = (state_44534[(9)]);
var inst_44485 = (state_44534[(10)]);
var inst_44511 = cljs.core.empty_QMARK_(inst_44485);
var inst_44512 = (inst_44486.cljs$core$IFn$_invoke$arity$1 ? inst_44486.cljs$core$IFn$_invoke$arity$1(inst_44494) : inst_44486.call(null,inst_44494));
var inst_44513 = cljs.core.not(inst_44512);
var inst_44514 = (inst_44511) && (inst_44513);
var state_44534__$1 = state_44534;
var statearr_44584_44641 = state_44534__$1;
(statearr_44584_44641[(2)] = inst_44514);

(statearr_44584_44641[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (10))){
var inst_44438 = (state_44534[(8)]);
var inst_44458 = (state_44534[(2)]);
var inst_44459 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_44458,cljs.core.cst$kw$solos);
var inst_44460 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_44458,cljs.core.cst$kw$mutes);
var inst_44461 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_44458,cljs.core.cst$kw$reads);
var inst_44462 = inst_44438;
var state_44534__$1 = (function (){var statearr_44585 = state_44534;
(statearr_44585[(16)] = inst_44459);

(statearr_44585[(17)] = inst_44461);

(statearr_44585[(18)] = inst_44460);

(statearr_44585[(7)] = inst_44462);

return statearr_44585;
})();
var statearr_44586_44642 = state_44534__$1;
(statearr_44586_44642[(2)] = null);

(statearr_44586_44642[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (18))){
var inst_44476 = (state_44534[(2)]);
var state_44534__$1 = state_44534;
var statearr_44587_44643 = state_44534__$1;
(statearr_44587_44643[(2)] = inst_44476);

(statearr_44587_44643[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (37))){
var state_44534__$1 = state_44534;
var statearr_44588_44644 = state_44534__$1;
(statearr_44588_44644[(2)] = null);

(statearr_44588_44644[(1)] = (38));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44535 === (8))){
var inst_44438 = (state_44534[(8)]);
var inst_44455 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_44438);
var state_44534__$1 = state_44534;
var statearr_44589_44645 = state_44534__$1;
(statearr_44589_44645[(2)] = inst_44455);

(statearr_44589_44645[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___44599,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
;
return ((function (switch__15098__auto__,c__15224__auto___44599,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function() {
var cljs$core$async$mix_$_state_machine__15099__auto__ = null;
var cljs$core$async$mix_$_state_machine__15099__auto____0 = (function (){
var statearr_44593 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_44593[(0)] = cljs$core$async$mix_$_state_machine__15099__auto__);

(statearr_44593[(1)] = (1));

return statearr_44593;
});
var cljs$core$async$mix_$_state_machine__15099__auto____1 = (function (state_44534){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_44534);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e44594){if((e44594 instanceof Object)){
var ex__15102__auto__ = e44594;
var statearr_44595_44646 = state_44534;
(statearr_44595_44646[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_44534);

return cljs.core.cst$kw$recur;
} else {
throw e44594;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__44647 = state_44534;
state_44534 = G__44647;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__15099__auto__ = function(state_44534){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__15099__auto____1.call(this,state_44534);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__15099__auto____0;
cljs$core$async$mix_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__15099__auto____1;
return cljs$core$async$mix_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___44599,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
})();
var state__15226__auto__ = (function (){var statearr_44596 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_44596[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___44599);

return statearr_44596;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___44599,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
);


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_(mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_(mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_(mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_(mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_(mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((!((p == null))) && (!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__7652__auto__ = (((p == null))?null:p);
var m__7653__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$4 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__7653__auto__.call(null,p,v,ch,close_QMARK_));
} else {
var m__7653__auto____$1 = (cljs.core.async.sub_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$4 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__7653__auto____$1.call(null,p,v,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__7652__auto__ = (((p == null))?null:p);
var m__7653__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$3 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__7653__auto__.call(null,p,v,ch));
} else {
var m__7653__auto____$1 = (cljs.core.async.unsub_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$3 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__7653__auto____$1.call(null,p,v,ch));
} else {
throw cljs.core.missing_protocol("Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var args44648 = [];
var len__8118__auto___44651 = arguments.length;
var i__8119__auto___44652 = (0);
while(true){
if((i__8119__auto___44652 < len__8118__auto___44651)){
args44648.push((arguments[i__8119__auto___44652]));

var G__44653 = (i__8119__auto___44652 + (1));
i__8119__auto___44652 = G__44653;
continue;
} else {
}
break;
}

var G__44650 = args44648.length;
switch (G__44650) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args44648.length)].join('')));

}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__7652__auto__ = (((p == null))?null:p);
var m__7653__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__7653__auto__.call(null,p));
} else {
var m__7653__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1(p) : m__7653__auto____$1.call(null,p));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__7652__auto__ = (((p == null))?null:p);
var m__7653__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__7653__auto__.call(null,p,v));
} else {
var m__7653__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(p,v) : m__7653__auto____$1.call(null,p,v));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2;


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var args44656 = [];
var len__8118__auto___44784 = arguments.length;
var i__8119__auto___44785 = (0);
while(true){
if((i__8119__auto___44785 < len__8118__auto___44784)){
args44656.push((arguments[i__8119__auto___44785]));

var G__44786 = (i__8119__auto___44785 + (1));
i__8119__auto___44785 = G__44786;
continue;
} else {
}
break;
}

var G__44658 = args44656.length;
switch (G__44658) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args44656.length)].join('')));

}
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3(ch,topic_fn,cljs.core.constantly(null));
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = (function (){var G__44659 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__44659) : cljs.core.atom.call(null,G__44659));
})();
var ensure_mult = ((function (mults){
return (function (topic){
var or__6939__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(mults) : cljs.core.deref.call(null,mults)),topic);
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(mults,((function (or__6939__auto__,mults){
return (function (p1__44655_SHARP_){
if(cljs.core.truth_((p1__44655_SHARP_.cljs$core$IFn$_invoke$arity$1 ? p1__44655_SHARP_.cljs$core$IFn$_invoke$arity$1(topic) : p1__44655_SHARP_.call(null,topic)))){
return p1__44655_SHARP_;
} else {
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__44655_SHARP_,topic,cljs.core.async.mult(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((buf_fn.cljs$core$IFn$_invoke$arity$1 ? buf_fn.cljs$core$IFn$_invoke$arity$1(topic) : buf_fn.call(null,topic)))));
}
});})(or__6939__auto__,mults))
),topic);
}
});})(mults))
;
var p = (function (){
if(typeof cljs.core.async.t_cljs$core$async44660 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async44660 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta44661){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta44661 = meta44661;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async44660.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (mults,ensure_mult){
return (function (_44662,meta44661__$1){
var self__ = this;
var _44662__$1 = this;
return (new cljs.core.async.t_cljs$core$async44660(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta44661__$1));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async44660.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (mults,ensure_mult){
return (function (_44662){
var self__ = this;
var _44662__$1 = this;
return self__.meta44661;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async44660.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async44660.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async44660.prototype.cljs$core$async$Pub$ = true;

cljs.core.async.t_cljs$core$async44660.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = (self__.ensure_mult.cljs$core$IFn$_invoke$arity$1 ? self__.ensure_mult.cljs$core$IFn$_invoke$arity$1(topic) : self__.ensure_mult.call(null,topic));
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(m,ch__$1,close_QMARK_);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async44660.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__6728__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(self__.mults) : cljs.core.deref.call(null,self__.mults)),topic);
if(cljs.core.truth_(temp__6728__auto__)){
var m = temp__6728__auto__;
return cljs.core.async.untap(m,ch__$1);
} else {
return null;
}
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async44660.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
var G__44663 = self__.mults;
var G__44664 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__44663,G__44664) : cljs.core.reset_BANG_.call(null,G__44663,G__44664));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async44660.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = ((function (mults,ensure_mult){
return (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.mults,cljs.core.dissoc,topic);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async44660.getBasis = ((function (mults,ensure_mult){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$topic_DASH_fn,cljs.core.cst$sym$buf_DASH_fn,cljs.core.cst$sym$mults,cljs.core.cst$sym$ensure_DASH_mult,cljs.core.cst$sym$meta44661], null);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async44660.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async44660.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async44660";

cljs.core.async.t_cljs$core$async44660.cljs$lang$ctorPrWriter = ((function (mults,ensure_mult){
return (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async44660");
});})(mults,ensure_mult))
;

cljs.core.async.__GT_t_cljs$core$async44660 = ((function (mults,ensure_mult){
return (function cljs$core$async$__GT_t_cljs$core$async44660(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta44661){
return (new cljs.core.async.t_cljs$core$async44660(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta44661));
});})(mults,ensure_mult))
;

}

return (new cljs.core.async.t_cljs$core$async44660(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__15224__auto___44788 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___44788,mults,ensure_mult,p){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___44788,mults,ensure_mult,p){
return (function (state_44736){
var state_val_44737 = (state_44736[(1)]);
if((state_val_44737 === (7))){
var inst_44732 = (state_44736[(2)]);
var state_44736__$1 = state_44736;
var statearr_44738_44789 = state_44736__$1;
(statearr_44738_44789[(2)] = inst_44732);

(statearr_44738_44789[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (20))){
var state_44736__$1 = state_44736;
var statearr_44739_44790 = state_44736__$1;
(statearr_44739_44790[(2)] = null);

(statearr_44739_44790[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (1))){
var state_44736__$1 = state_44736;
var statearr_44740_44791 = state_44736__$1;
(statearr_44740_44791[(2)] = null);

(statearr_44740_44791[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (24))){
var inst_44715 = (state_44736[(7)]);
var inst_44724 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(mults,cljs.core.dissoc,inst_44715);
var state_44736__$1 = state_44736;
var statearr_44741_44792 = state_44736__$1;
(statearr_44741_44792[(2)] = inst_44724);

(statearr_44741_44792[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (4))){
var inst_44667 = (state_44736[(8)]);
var inst_44667__$1 = (state_44736[(2)]);
var inst_44668 = (inst_44667__$1 == null);
var state_44736__$1 = (function (){var statearr_44742 = state_44736;
(statearr_44742[(8)] = inst_44667__$1);

return statearr_44742;
})();
if(cljs.core.truth_(inst_44668)){
var statearr_44743_44793 = state_44736__$1;
(statearr_44743_44793[(1)] = (5));

} else {
var statearr_44744_44794 = state_44736__$1;
(statearr_44744_44794[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (15))){
var inst_44709 = (state_44736[(2)]);
var state_44736__$1 = state_44736;
var statearr_44745_44795 = state_44736__$1;
(statearr_44745_44795[(2)] = inst_44709);

(statearr_44745_44795[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (21))){
var inst_44729 = (state_44736[(2)]);
var state_44736__$1 = (function (){var statearr_44746 = state_44736;
(statearr_44746[(9)] = inst_44729);

return statearr_44746;
})();
var statearr_44747_44796 = state_44736__$1;
(statearr_44747_44796[(2)] = null);

(statearr_44747_44796[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (13))){
var inst_44691 = (state_44736[(10)]);
var inst_44693 = cljs.core.chunked_seq_QMARK_(inst_44691);
var state_44736__$1 = state_44736;
if(inst_44693){
var statearr_44748_44797 = state_44736__$1;
(statearr_44748_44797[(1)] = (16));

} else {
var statearr_44749_44798 = state_44736__$1;
(statearr_44749_44798[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (22))){
var inst_44721 = (state_44736[(2)]);
var state_44736__$1 = state_44736;
if(cljs.core.truth_(inst_44721)){
var statearr_44750_44799 = state_44736__$1;
(statearr_44750_44799[(1)] = (23));

} else {
var statearr_44751_44800 = state_44736__$1;
(statearr_44751_44800[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (6))){
var inst_44717 = (state_44736[(11)]);
var inst_44715 = (state_44736[(7)]);
var inst_44667 = (state_44736[(8)]);
var inst_44715__$1 = (topic_fn.cljs$core$IFn$_invoke$arity$1 ? topic_fn.cljs$core$IFn$_invoke$arity$1(inst_44667) : topic_fn.call(null,inst_44667));
var inst_44716 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(mults) : cljs.core.deref.call(null,mults));
var inst_44717__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_44716,inst_44715__$1);
var state_44736__$1 = (function (){var statearr_44752 = state_44736;
(statearr_44752[(11)] = inst_44717__$1);

(statearr_44752[(7)] = inst_44715__$1);

return statearr_44752;
})();
if(cljs.core.truth_(inst_44717__$1)){
var statearr_44753_44801 = state_44736__$1;
(statearr_44753_44801[(1)] = (19));

} else {
var statearr_44754_44802 = state_44736__$1;
(statearr_44754_44802[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (25))){
var inst_44726 = (state_44736[(2)]);
var state_44736__$1 = state_44736;
var statearr_44755_44803 = state_44736__$1;
(statearr_44755_44803[(2)] = inst_44726);

(statearr_44755_44803[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (17))){
var inst_44691 = (state_44736[(10)]);
var inst_44700 = cljs.core.first(inst_44691);
var inst_44701 = cljs.core.async.muxch_STAR_(inst_44700);
var inst_44702 = cljs.core.async.close_BANG_(inst_44701);
var inst_44703 = cljs.core.next(inst_44691);
var inst_44677 = inst_44703;
var inst_44678 = null;
var inst_44679 = (0);
var inst_44680 = (0);
var state_44736__$1 = (function (){var statearr_44756 = state_44736;
(statearr_44756[(12)] = inst_44679);

(statearr_44756[(13)] = inst_44702);

(statearr_44756[(14)] = inst_44680);

(statearr_44756[(15)] = inst_44677);

(statearr_44756[(16)] = inst_44678);

return statearr_44756;
})();
var statearr_44757_44804 = state_44736__$1;
(statearr_44757_44804[(2)] = null);

(statearr_44757_44804[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (3))){
var inst_44734 = (state_44736[(2)]);
var state_44736__$1 = state_44736;
return cljs.core.async.impl.ioc_helpers.return_chan(state_44736__$1,inst_44734);
} else {
if((state_val_44737 === (12))){
var inst_44711 = (state_44736[(2)]);
var state_44736__$1 = state_44736;
var statearr_44758_44805 = state_44736__$1;
(statearr_44758_44805[(2)] = inst_44711);

(statearr_44758_44805[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (2))){
var state_44736__$1 = state_44736;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_44736__$1,(4),ch);
} else {
if((state_val_44737 === (23))){
var state_44736__$1 = state_44736;
var statearr_44759_44806 = state_44736__$1;
(statearr_44759_44806[(2)] = null);

(statearr_44759_44806[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (19))){
var inst_44717 = (state_44736[(11)]);
var inst_44667 = (state_44736[(8)]);
var inst_44719 = cljs.core.async.muxch_STAR_(inst_44717);
var state_44736__$1 = state_44736;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_44736__$1,(22),inst_44719,inst_44667);
} else {
if((state_val_44737 === (11))){
var inst_44691 = (state_44736[(10)]);
var inst_44677 = (state_44736[(15)]);
var inst_44691__$1 = cljs.core.seq(inst_44677);
var state_44736__$1 = (function (){var statearr_44760 = state_44736;
(statearr_44760[(10)] = inst_44691__$1);

return statearr_44760;
})();
if(inst_44691__$1){
var statearr_44761_44807 = state_44736__$1;
(statearr_44761_44807[(1)] = (13));

} else {
var statearr_44762_44808 = state_44736__$1;
(statearr_44762_44808[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (9))){
var inst_44713 = (state_44736[(2)]);
var state_44736__$1 = state_44736;
var statearr_44763_44809 = state_44736__$1;
(statearr_44763_44809[(2)] = inst_44713);

(statearr_44763_44809[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (5))){
var inst_44674 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(mults) : cljs.core.deref.call(null,mults));
var inst_44675 = cljs.core.vals(inst_44674);
var inst_44676 = cljs.core.seq(inst_44675);
var inst_44677 = inst_44676;
var inst_44678 = null;
var inst_44679 = (0);
var inst_44680 = (0);
var state_44736__$1 = (function (){var statearr_44764 = state_44736;
(statearr_44764[(12)] = inst_44679);

(statearr_44764[(14)] = inst_44680);

(statearr_44764[(15)] = inst_44677);

(statearr_44764[(16)] = inst_44678);

return statearr_44764;
})();
var statearr_44765_44810 = state_44736__$1;
(statearr_44765_44810[(2)] = null);

(statearr_44765_44810[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (14))){
var state_44736__$1 = state_44736;
var statearr_44769_44811 = state_44736__$1;
(statearr_44769_44811[(2)] = null);

(statearr_44769_44811[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (16))){
var inst_44691 = (state_44736[(10)]);
var inst_44695 = cljs.core.chunk_first(inst_44691);
var inst_44696 = cljs.core.chunk_rest(inst_44691);
var inst_44697 = cljs.core.count(inst_44695);
var inst_44677 = inst_44696;
var inst_44678 = inst_44695;
var inst_44679 = inst_44697;
var inst_44680 = (0);
var state_44736__$1 = (function (){var statearr_44770 = state_44736;
(statearr_44770[(12)] = inst_44679);

(statearr_44770[(14)] = inst_44680);

(statearr_44770[(15)] = inst_44677);

(statearr_44770[(16)] = inst_44678);

return statearr_44770;
})();
var statearr_44771_44812 = state_44736__$1;
(statearr_44771_44812[(2)] = null);

(statearr_44771_44812[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (10))){
var inst_44679 = (state_44736[(12)]);
var inst_44680 = (state_44736[(14)]);
var inst_44677 = (state_44736[(15)]);
var inst_44678 = (state_44736[(16)]);
var inst_44685 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_44678,inst_44680);
var inst_44686 = cljs.core.async.muxch_STAR_(inst_44685);
var inst_44687 = cljs.core.async.close_BANG_(inst_44686);
var inst_44688 = (inst_44680 + (1));
var tmp44766 = inst_44679;
var tmp44767 = inst_44677;
var tmp44768 = inst_44678;
var inst_44677__$1 = tmp44767;
var inst_44678__$1 = tmp44768;
var inst_44679__$1 = tmp44766;
var inst_44680__$1 = inst_44688;
var state_44736__$1 = (function (){var statearr_44772 = state_44736;
(statearr_44772[(12)] = inst_44679__$1);

(statearr_44772[(14)] = inst_44680__$1);

(statearr_44772[(15)] = inst_44677__$1);

(statearr_44772[(16)] = inst_44678__$1);

(statearr_44772[(17)] = inst_44687);

return statearr_44772;
})();
var statearr_44773_44813 = state_44736__$1;
(statearr_44773_44813[(2)] = null);

(statearr_44773_44813[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (18))){
var inst_44706 = (state_44736[(2)]);
var state_44736__$1 = state_44736;
var statearr_44774_44814 = state_44736__$1;
(statearr_44774_44814[(2)] = inst_44706);

(statearr_44774_44814[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44737 === (8))){
var inst_44679 = (state_44736[(12)]);
var inst_44680 = (state_44736[(14)]);
var inst_44682 = (inst_44680 < inst_44679);
var inst_44683 = inst_44682;
var state_44736__$1 = state_44736;
if(cljs.core.truth_(inst_44683)){
var statearr_44775_44815 = state_44736__$1;
(statearr_44775_44815[(1)] = (10));

} else {
var statearr_44776_44816 = state_44736__$1;
(statearr_44776_44816[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___44788,mults,ensure_mult,p))
;
return ((function (switch__15098__auto__,c__15224__auto___44788,mults,ensure_mult,p){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_44780 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_44780[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_44780[(1)] = (1));

return statearr_44780;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_44736){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_44736);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e44781){if((e44781 instanceof Object)){
var ex__15102__auto__ = e44781;
var statearr_44782_44817 = state_44736;
(statearr_44782_44817[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_44736);

return cljs.core.cst$kw$recur;
} else {
throw e44781;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__44818 = state_44736;
state_44736 = G__44818;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_44736){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_44736);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___44788,mults,ensure_mult,p))
})();
var state__15226__auto__ = (function (){var statearr_44783 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_44783[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___44788);

return statearr_44783;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___44788,mults,ensure_mult,p))
);


return p;
});

cljs.core.async.pub.cljs$lang$maxFixedArity = 3;

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var args44819 = [];
var len__8118__auto___44822 = arguments.length;
var i__8119__auto___44823 = (0);
while(true){
if((i__8119__auto___44823 < len__8118__auto___44822)){
args44819.push((arguments[i__8119__auto___44823]));

var G__44824 = (i__8119__auto___44823 + (1));
i__8119__auto___44823 = G__44824;
continue;
} else {
}
break;
}

var G__44821 = args44819.length;
switch (G__44821) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args44819.length)].join('')));

}
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4(p,topic,ch,true);
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_(p,topic,ch,close_QMARK_);
});

cljs.core.async.sub.cljs$lang$maxFixedArity = 4;

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_(p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var args44826 = [];
var len__8118__auto___44829 = arguments.length;
var i__8119__auto___44830 = (0);
while(true){
if((i__8119__auto___44830 < len__8118__auto___44829)){
args44826.push((arguments[i__8119__auto___44830]));

var G__44831 = (i__8119__auto___44830 + (1));
i__8119__auto___44830 = G__44831;
continue;
} else {
}
break;
}

var G__44828 = args44826.length;
switch (G__44828) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args44826.length)].join('')));

}
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1(p);
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2(p,topic);
});

cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2;

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var args44833 = [];
var len__8118__auto___44904 = arguments.length;
var i__8119__auto___44905 = (0);
while(true){
if((i__8119__auto___44905 < len__8118__auto___44904)){
args44833.push((arguments[i__8119__auto___44905]));

var G__44906 = (i__8119__auto___44905 + (1));
i__8119__auto___44905 = G__44906;
continue;
} else {
}
break;
}

var G__44835 = args44833.length;
switch (G__44835) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args44833.length)].join('')));

}
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3(f,chs,null);
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec(chs);
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var cnt = cljs.core.count(chs__$1);
var rets = cljs.core.object_array.cljs$core$IFn$_invoke$arity$1(cnt);
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null) : cljs.core.atom.call(null,null));
var done = cljs.core.mapv.cljs$core$IFn$_invoke$arity$2(((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (i){
return ((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,rets.slice((0)));
} else {
return null;
}
});
;})(chs__$1,out,cnt,rets,dchan,dctr))
});})(chs__$1,out,cnt,rets,dchan,dctr))
,cljs.core.range.cljs$core$IFn$_invoke$arity$1(cnt));
var c__15224__auto___44908 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___44908,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___44908,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (state_44874){
var state_val_44875 = (state_44874[(1)]);
if((state_val_44875 === (7))){
var state_44874__$1 = state_44874;
var statearr_44876_44909 = state_44874__$1;
(statearr_44876_44909[(2)] = null);

(statearr_44876_44909[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (1))){
var state_44874__$1 = state_44874;
var statearr_44877_44910 = state_44874__$1;
(statearr_44877_44910[(2)] = null);

(statearr_44877_44910[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (4))){
var inst_44838 = (state_44874[(7)]);
var inst_44840 = (inst_44838 < cnt);
var state_44874__$1 = state_44874;
if(cljs.core.truth_(inst_44840)){
var statearr_44878_44911 = state_44874__$1;
(statearr_44878_44911[(1)] = (6));

} else {
var statearr_44879_44912 = state_44874__$1;
(statearr_44879_44912[(1)] = (7));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (15))){
var inst_44870 = (state_44874[(2)]);
var state_44874__$1 = state_44874;
var statearr_44880_44913 = state_44874__$1;
(statearr_44880_44913[(2)] = inst_44870);

(statearr_44880_44913[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (13))){
var inst_44863 = cljs.core.async.close_BANG_(out);
var state_44874__$1 = state_44874;
var statearr_44881_44914 = state_44874__$1;
(statearr_44881_44914[(2)] = inst_44863);

(statearr_44881_44914[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (6))){
var state_44874__$1 = state_44874;
var statearr_44882_44915 = state_44874__$1;
(statearr_44882_44915[(2)] = null);

(statearr_44882_44915[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (3))){
var inst_44872 = (state_44874[(2)]);
var state_44874__$1 = state_44874;
return cljs.core.async.impl.ioc_helpers.return_chan(state_44874__$1,inst_44872);
} else {
if((state_val_44875 === (12))){
var inst_44860 = (state_44874[(8)]);
var inst_44860__$1 = (state_44874[(2)]);
var inst_44861 = cljs.core.some(cljs.core.nil_QMARK_,inst_44860__$1);
var state_44874__$1 = (function (){var statearr_44883 = state_44874;
(statearr_44883[(8)] = inst_44860__$1);

return statearr_44883;
})();
if(cljs.core.truth_(inst_44861)){
var statearr_44884_44916 = state_44874__$1;
(statearr_44884_44916[(1)] = (13));

} else {
var statearr_44885_44917 = state_44874__$1;
(statearr_44885_44917[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (2))){
var inst_44837 = (cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cnt) : cljs.core.reset_BANG_.call(null,dctr,cnt));
var inst_44838 = (0);
var state_44874__$1 = (function (){var statearr_44886 = state_44874;
(statearr_44886[(9)] = inst_44837);

(statearr_44886[(7)] = inst_44838);

return statearr_44886;
})();
var statearr_44887_44918 = state_44874__$1;
(statearr_44887_44918[(2)] = null);

(statearr_44887_44918[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (11))){
var inst_44838 = (state_44874[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame(state_44874,(10),Object,null,(9));
var inst_44847 = (chs__$1.cljs$core$IFn$_invoke$arity$1 ? chs__$1.cljs$core$IFn$_invoke$arity$1(inst_44838) : chs__$1.call(null,inst_44838));
var inst_44848 = (done.cljs$core$IFn$_invoke$arity$1 ? done.cljs$core$IFn$_invoke$arity$1(inst_44838) : done.call(null,inst_44838));
var inst_44849 = cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2(inst_44847,inst_44848);
var state_44874__$1 = state_44874;
var statearr_44888_44919 = state_44874__$1;
(statearr_44888_44919[(2)] = inst_44849);


cljs.core.async.impl.ioc_helpers.process_exception(state_44874__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (9))){
var inst_44838 = (state_44874[(7)]);
var inst_44851 = (state_44874[(2)]);
var inst_44852 = (inst_44838 + (1));
var inst_44838__$1 = inst_44852;
var state_44874__$1 = (function (){var statearr_44889 = state_44874;
(statearr_44889[(10)] = inst_44851);

(statearr_44889[(7)] = inst_44838__$1);

return statearr_44889;
})();
var statearr_44890_44920 = state_44874__$1;
(statearr_44890_44920[(2)] = null);

(statearr_44890_44920[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (5))){
var inst_44858 = (state_44874[(2)]);
var state_44874__$1 = (function (){var statearr_44891 = state_44874;
(statearr_44891[(11)] = inst_44858);

return statearr_44891;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_44874__$1,(12),dchan);
} else {
if((state_val_44875 === (14))){
var inst_44860 = (state_44874[(8)]);
var inst_44865 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(f,inst_44860);
var state_44874__$1 = state_44874;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_44874__$1,(16),out,inst_44865);
} else {
if((state_val_44875 === (16))){
var inst_44867 = (state_44874[(2)]);
var state_44874__$1 = (function (){var statearr_44892 = state_44874;
(statearr_44892[(12)] = inst_44867);

return statearr_44892;
})();
var statearr_44893_44921 = state_44874__$1;
(statearr_44893_44921[(2)] = null);

(statearr_44893_44921[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (10))){
var inst_44842 = (state_44874[(2)]);
var inst_44843 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec);
var state_44874__$1 = (function (){var statearr_44894 = state_44874;
(statearr_44894[(13)] = inst_44842);

return statearr_44894;
})();
var statearr_44895_44922 = state_44874__$1;
(statearr_44895_44922[(2)] = inst_44843);


cljs.core.async.impl.ioc_helpers.process_exception(state_44874__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_44875 === (8))){
var inst_44856 = (state_44874[(2)]);
var state_44874__$1 = state_44874;
var statearr_44896_44923 = state_44874__$1;
(statearr_44896_44923[(2)] = inst_44856);

(statearr_44896_44923[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___44908,chs__$1,out,cnt,rets,dchan,dctr,done))
;
return ((function (switch__15098__auto__,c__15224__auto___44908,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_44900 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_44900[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_44900[(1)] = (1));

return statearr_44900;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_44874){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_44874);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e44901){if((e44901 instanceof Object)){
var ex__15102__auto__ = e44901;
var statearr_44902_44924 = state_44874;
(statearr_44902_44924[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_44874);

return cljs.core.cst$kw$recur;
} else {
throw e44901;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__44925 = state_44874;
state_44874 = G__44925;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_44874){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_44874);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___44908,chs__$1,out,cnt,rets,dchan,dctr,done))
})();
var state__15226__auto__ = (function (){var statearr_44903 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_44903[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___44908);

return statearr_44903;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___44908,chs__$1,out,cnt,rets,dchan,dctr,done))
);


return out;
});

cljs.core.async.map.cljs$lang$maxFixedArity = 3;

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var args44927 = [];
var len__8118__auto___44985 = arguments.length;
var i__8119__auto___44986 = (0);
while(true){
if((i__8119__auto___44986 < len__8118__auto___44985)){
args44927.push((arguments[i__8119__auto___44986]));

var G__44987 = (i__8119__auto___44986 + (1));
i__8119__auto___44986 = G__44987;
continue;
} else {
}
break;
}

var G__44929 = args44927.length;
switch (G__44929) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args44927.length)].join('')));

}
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2(chs,null);
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___44989 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___44989,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___44989,out){
return (function (state_44961){
var state_val_44962 = (state_44961[(1)]);
if((state_val_44962 === (7))){
var inst_44940 = (state_44961[(7)]);
var inst_44941 = (state_44961[(8)]);
var inst_44940__$1 = (state_44961[(2)]);
var inst_44941__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_44940__$1,(0),null);
var inst_44942 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_44940__$1,(1),null);
var inst_44943 = (inst_44941__$1 == null);
var state_44961__$1 = (function (){var statearr_44963 = state_44961;
(statearr_44963[(7)] = inst_44940__$1);

(statearr_44963[(9)] = inst_44942);

(statearr_44963[(8)] = inst_44941__$1);

return statearr_44963;
})();
if(cljs.core.truth_(inst_44943)){
var statearr_44964_44990 = state_44961__$1;
(statearr_44964_44990[(1)] = (8));

} else {
var statearr_44965_44991 = state_44961__$1;
(statearr_44965_44991[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44962 === (1))){
var inst_44930 = cljs.core.vec(chs);
var inst_44931 = inst_44930;
var state_44961__$1 = (function (){var statearr_44966 = state_44961;
(statearr_44966[(10)] = inst_44931);

return statearr_44966;
})();
var statearr_44967_44992 = state_44961__$1;
(statearr_44967_44992[(2)] = null);

(statearr_44967_44992[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44962 === (4))){
var inst_44931 = (state_44961[(10)]);
var state_44961__$1 = state_44961;
return cljs.core.async.ioc_alts_BANG_(state_44961__$1,(7),inst_44931);
} else {
if((state_val_44962 === (6))){
var inst_44957 = (state_44961[(2)]);
var state_44961__$1 = state_44961;
var statearr_44968_44993 = state_44961__$1;
(statearr_44968_44993[(2)] = inst_44957);

(statearr_44968_44993[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44962 === (3))){
var inst_44959 = (state_44961[(2)]);
var state_44961__$1 = state_44961;
return cljs.core.async.impl.ioc_helpers.return_chan(state_44961__$1,inst_44959);
} else {
if((state_val_44962 === (2))){
var inst_44931 = (state_44961[(10)]);
var inst_44933 = cljs.core.count(inst_44931);
var inst_44934 = (inst_44933 > (0));
var state_44961__$1 = state_44961;
if(cljs.core.truth_(inst_44934)){
var statearr_44970_44994 = state_44961__$1;
(statearr_44970_44994[(1)] = (4));

} else {
var statearr_44971_44995 = state_44961__$1;
(statearr_44971_44995[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_44962 === (11))){
var inst_44931 = (state_44961[(10)]);
var inst_44950 = (state_44961[(2)]);
var tmp44969 = inst_44931;
var inst_44931__$1 = tmp44969;
var state_44961__$1 = (function (){var statearr_44972 = state_44961;
(statearr_44972[(10)] = inst_44931__$1);

(statearr_44972[(11)] = inst_44950);

return statearr_44972;
})();
var statearr_44973_44996 = state_44961__$1;
(statearr_44973_44996[(2)] = null);

(statearr_44973_44996[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44962 === (9))){
var inst_44941 = (state_44961[(8)]);
var state_44961__$1 = state_44961;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_44961__$1,(11),out,inst_44941);
} else {
if((state_val_44962 === (5))){
var inst_44955 = cljs.core.async.close_BANG_(out);
var state_44961__$1 = state_44961;
var statearr_44974_44997 = state_44961__$1;
(statearr_44974_44997[(2)] = inst_44955);

(statearr_44974_44997[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44962 === (10))){
var inst_44953 = (state_44961[(2)]);
var state_44961__$1 = state_44961;
var statearr_44975_44998 = state_44961__$1;
(statearr_44975_44998[(2)] = inst_44953);

(statearr_44975_44998[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_44962 === (8))){
var inst_44940 = (state_44961[(7)]);
var inst_44942 = (state_44961[(9)]);
var inst_44931 = (state_44961[(10)]);
var inst_44941 = (state_44961[(8)]);
var inst_44945 = (function (){var cs = inst_44931;
var vec__44936 = inst_44940;
var v = inst_44941;
var c = inst_44942;
return ((function (cs,vec__44936,v,c,inst_44940,inst_44942,inst_44931,inst_44941,state_val_44962,c__15224__auto___44989,out){
return (function (p1__44926_SHARP_){
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(c,p1__44926_SHARP_);
});
;})(cs,vec__44936,v,c,inst_44940,inst_44942,inst_44931,inst_44941,state_val_44962,c__15224__auto___44989,out))
})();
var inst_44946 = cljs.core.filterv(inst_44945,inst_44931);
var inst_44931__$1 = inst_44946;
var state_44961__$1 = (function (){var statearr_44976 = state_44961;
(statearr_44976[(10)] = inst_44931__$1);

return statearr_44976;
})();
var statearr_44977_44999 = state_44961__$1;
(statearr_44977_44999[(2)] = null);

(statearr_44977_44999[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___44989,out))
;
return ((function (switch__15098__auto__,c__15224__auto___44989,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_44981 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_44981[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_44981[(1)] = (1));

return statearr_44981;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_44961){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_44961);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e44982){if((e44982 instanceof Object)){
var ex__15102__auto__ = e44982;
var statearr_44983_45000 = state_44961;
(statearr_44983_45000[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_44961);

return cljs.core.cst$kw$recur;
} else {
throw e44982;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__45001 = state_44961;
state_44961 = G__45001;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_44961){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_44961);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___44989,out))
})();
var state__15226__auto__ = (function (){var statearr_44984 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_44984[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___44989);

return statearr_44984;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___44989,out))
);


return out;
});

cljs.core.async.merge.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce(cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var args45002 = [];
var len__8118__auto___45051 = arguments.length;
var i__8119__auto___45052 = (0);
while(true){
if((i__8119__auto___45052 < len__8118__auto___45051)){
args45002.push((arguments[i__8119__auto___45052]));

var G__45053 = (i__8119__auto___45052 + (1));
i__8119__auto___45052 = G__45053;
continue;
} else {
}
break;
}

var G__45004 = args45002.length;
switch (G__45004) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args45002.length)].join('')));

}
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___45055 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___45055,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___45055,out){
return (function (state_45028){
var state_val_45029 = (state_45028[(1)]);
if((state_val_45029 === (7))){
var inst_45010 = (state_45028[(7)]);
var inst_45010__$1 = (state_45028[(2)]);
var inst_45011 = (inst_45010__$1 == null);
var inst_45012 = cljs.core.not(inst_45011);
var state_45028__$1 = (function (){var statearr_45030 = state_45028;
(statearr_45030[(7)] = inst_45010__$1);

return statearr_45030;
})();
if(inst_45012){
var statearr_45031_45056 = state_45028__$1;
(statearr_45031_45056[(1)] = (8));

} else {
var statearr_45032_45057 = state_45028__$1;
(statearr_45032_45057[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45029 === (1))){
var inst_45005 = (0);
var state_45028__$1 = (function (){var statearr_45033 = state_45028;
(statearr_45033[(8)] = inst_45005);

return statearr_45033;
})();
var statearr_45034_45058 = state_45028__$1;
(statearr_45034_45058[(2)] = null);

(statearr_45034_45058[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45029 === (4))){
var state_45028__$1 = state_45028;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_45028__$1,(7),ch);
} else {
if((state_val_45029 === (6))){
var inst_45023 = (state_45028[(2)]);
var state_45028__$1 = state_45028;
var statearr_45035_45059 = state_45028__$1;
(statearr_45035_45059[(2)] = inst_45023);

(statearr_45035_45059[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45029 === (3))){
var inst_45025 = (state_45028[(2)]);
var inst_45026 = cljs.core.async.close_BANG_(out);
var state_45028__$1 = (function (){var statearr_45036 = state_45028;
(statearr_45036[(9)] = inst_45025);

return statearr_45036;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_45028__$1,inst_45026);
} else {
if((state_val_45029 === (2))){
var inst_45005 = (state_45028[(8)]);
var inst_45007 = (inst_45005 < n);
var state_45028__$1 = state_45028;
if(cljs.core.truth_(inst_45007)){
var statearr_45037_45060 = state_45028__$1;
(statearr_45037_45060[(1)] = (4));

} else {
var statearr_45038_45061 = state_45028__$1;
(statearr_45038_45061[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45029 === (11))){
var inst_45005 = (state_45028[(8)]);
var inst_45015 = (state_45028[(2)]);
var inst_45016 = (inst_45005 + (1));
var inst_45005__$1 = inst_45016;
var state_45028__$1 = (function (){var statearr_45039 = state_45028;
(statearr_45039[(8)] = inst_45005__$1);

(statearr_45039[(10)] = inst_45015);

return statearr_45039;
})();
var statearr_45040_45062 = state_45028__$1;
(statearr_45040_45062[(2)] = null);

(statearr_45040_45062[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45029 === (9))){
var state_45028__$1 = state_45028;
var statearr_45041_45063 = state_45028__$1;
(statearr_45041_45063[(2)] = null);

(statearr_45041_45063[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45029 === (5))){
var state_45028__$1 = state_45028;
var statearr_45042_45064 = state_45028__$1;
(statearr_45042_45064[(2)] = null);

(statearr_45042_45064[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45029 === (10))){
var inst_45020 = (state_45028[(2)]);
var state_45028__$1 = state_45028;
var statearr_45043_45065 = state_45028__$1;
(statearr_45043_45065[(2)] = inst_45020);

(statearr_45043_45065[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45029 === (8))){
var inst_45010 = (state_45028[(7)]);
var state_45028__$1 = state_45028;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_45028__$1,(11),out,inst_45010);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___45055,out))
;
return ((function (switch__15098__auto__,c__15224__auto___45055,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_45047 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_45047[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_45047[(1)] = (1));

return statearr_45047;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_45028){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_45028);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e45048){if((e45048 instanceof Object)){
var ex__15102__auto__ = e45048;
var statearr_45049_45066 = state_45028;
(statearr_45049_45066[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_45028);

return cljs.core.cst$kw$recur;
} else {
throw e45048;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__45067 = state_45028;
state_45028 = G__45067;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_45028){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_45028);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___45055,out))
})();
var state__15226__auto__ = (function (){var statearr_45050 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_45050[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___45055);

return statearr_45050;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___45055,out))
);


return out;
});

cljs.core.async.take.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if(typeof cljs.core.async.t_cljs$core$async45077 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async45077 = (function (map_LT_,f,ch,meta45078){
this.map_LT_ = map_LT_;
this.f = f;
this.ch = ch;
this.meta45078 = meta45078;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async45077.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_45079,meta45078__$1){
var self__ = this;
var _45079__$1 = this;
return (new cljs.core.async.t_cljs$core$async45077(self__.map_LT_,self__.f,self__.ch,meta45078__$1));
});

cljs.core.async.t_cljs$core$async45077.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_45079){
var self__ = this;
var _45079__$1 = this;
return self__.meta45078;
});

cljs.core.async.t_cljs$core$async45077.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async45077.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async45077.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async45077.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async45077.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_(self__.ch,(function (){
if(typeof cljs.core.async.t_cljs$core$async45080 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async45080 = (function (map_LT_,f,ch,meta45078,_,fn1,meta45081){
this.map_LT_ = map_LT_;
this.f = f;
this.ch = ch;
this.meta45078 = meta45078;
this._ = _;
this.fn1 = fn1;
this.meta45081 = meta45081;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async45080.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (___$1){
return (function (_45082,meta45081__$1){
var self__ = this;
var _45082__$1 = this;
return (new cljs.core.async.t_cljs$core$async45080(self__.map_LT_,self__.f,self__.ch,self__.meta45078,self__._,self__.fn1,meta45081__$1));
});})(___$1))
;

cljs.core.async.t_cljs$core$async45080.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (___$1){
return (function (_45082){
var self__ = this;
var _45082__$1 = this;
return self__.meta45081;
});})(___$1))
;

cljs.core.async.t_cljs$core$async45080.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async45080.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.fn1);
});})(___$1))
;

cljs.core.async.t_cljs$core$async45080.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
});})(___$1))
;

cljs.core.async.t_cljs$core$async45080.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit(self__.fn1);
return ((function (f1,___$2,___$1){
return (function (p1__45068_SHARP_){
var G__45083 = (((p1__45068_SHARP_ == null))?null:(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(p1__45068_SHARP_) : self__.f.call(null,p1__45068_SHARP_)));
return (f1.cljs$core$IFn$_invoke$arity$1 ? f1.cljs$core$IFn$_invoke$arity$1(G__45083) : f1.call(null,G__45083));
});
;})(f1,___$2,___$1))
});})(___$1))
;

cljs.core.async.t_cljs$core$async45080.getBasis = ((function (___$1){
return (function (){
return new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$map_LT_,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch], null))),cljs.core.cst$kw$doc,"Deprecated - this function will be removed. Use transducer instead"], null)),cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta45078,cljs.core.with_meta(cljs.core.cst$sym$_,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$tag,cljs.core.cst$sym$cljs$core$async_SLASH_t_cljs$core$async45077], null)),cljs.core.cst$sym$fn1,cljs.core.cst$sym$meta45081], null);
});})(___$1))
;

cljs.core.async.t_cljs$core$async45080.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async45080.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async45080";

cljs.core.async.t_cljs$core$async45080.cljs$lang$ctorPrWriter = ((function (___$1){
return (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async45080");
});})(___$1))
;

cljs.core.async.__GT_t_cljs$core$async45080 = ((function (___$1){
return (function cljs$core$async$map_LT__$___GT_t_cljs$core$async45080(map_LT___$1,f__$1,ch__$1,meta45078__$1,___$2,fn1__$1,meta45081){
return (new cljs.core.async.t_cljs$core$async45080(map_LT___$1,f__$1,ch__$1,meta45078__$1,___$2,fn1__$1,meta45081));
});})(___$1))
;

}

return (new cljs.core.async.t_cljs$core$async45080(self__.map_LT_,self__.f,self__.ch,self__.meta45078,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__6927__auto__ = ret;
if(cljs.core.truth_(and__6927__auto__)){
return !(((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret)) == null));
} else {
return and__6927__auto__;
}
})())){
return cljs.core.async.impl.channels.box((function (){var G__45084 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret));
return (self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(G__45084) : self__.f.call(null,G__45084));
})());
} else {
return ret;
}
});

cljs.core.async.t_cljs$core$async45077.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async45077.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
});

cljs.core.async.t_cljs$core$async45077.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$map_LT_,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch], null))),cljs.core.cst$kw$doc,"Deprecated - this function will be removed. Use transducer instead"], null)),cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta45078], null);
});

cljs.core.async.t_cljs$core$async45077.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async45077.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async45077";

cljs.core.async.t_cljs$core$async45077.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async45077");
});

cljs.core.async.__GT_t_cljs$core$async45077 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async45077(map_LT___$1,f__$1,ch__$1,meta45078){
return (new cljs.core.async.t_cljs$core$async45077(map_LT___$1,f__$1,ch__$1,meta45078));
});

}

return (new cljs.core.async.t_cljs$core$async45077(cljs$core$async$map_LT_,f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if(typeof cljs.core.async.t_cljs$core$async45088 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async45088 = (function (map_GT_,f,ch,meta45089){
this.map_GT_ = map_GT_;
this.f = f;
this.ch = ch;
this.meta45089 = meta45089;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async45088.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_45090,meta45089__$1){
var self__ = this;
var _45090__$1 = this;
return (new cljs.core.async.t_cljs$core$async45088(self__.map_GT_,self__.f,self__.ch,meta45089__$1));
});

cljs.core.async.t_cljs$core$async45088.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_45090){
var self__ = this;
var _45090__$1 = this;
return self__.meta45089;
});

cljs.core.async.t_cljs$core$async45088.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async45088.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async45088.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async45088.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async45088.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async45088.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(val) : self__.f.call(null,val)),fn1);
});

cljs.core.async.t_cljs$core$async45088.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$map_GT_,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch], null))),cljs.core.cst$kw$doc,"Deprecated - this function will be removed. Use transducer instead"], null)),cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta45089], null);
});

cljs.core.async.t_cljs$core$async45088.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async45088.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async45088";

cljs.core.async.t_cljs$core$async45088.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async45088");
});

cljs.core.async.__GT_t_cljs$core$async45088 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async45088(map_GT___$1,f__$1,ch__$1,meta45089){
return (new cljs.core.async.t_cljs$core$async45088(map_GT___$1,f__$1,ch__$1,meta45089));
});

}

return (new cljs.core.async.t_cljs$core$async45088(cljs$core$async$map_GT_,f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if(typeof cljs.core.async.t_cljs$core$async45094 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async45094 = (function (filter_GT_,p,ch,meta45095){
this.filter_GT_ = filter_GT_;
this.p = p;
this.ch = ch;
this.meta45095 = meta45095;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async45094.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_45096,meta45095__$1){
var self__ = this;
var _45096__$1 = this;
return (new cljs.core.async.t_cljs$core$async45094(self__.filter_GT_,self__.p,self__.ch,meta45095__$1));
});

cljs.core.async.t_cljs$core$async45094.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_45096){
var self__ = this;
var _45096__$1 = this;
return self__.meta45095;
});

cljs.core.async.t_cljs$core$async45094.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async45094.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async45094.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async45094.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async45094.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async45094.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async45094.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_((self__.p.cljs$core$IFn$_invoke$arity$1 ? self__.p.cljs$core$IFn$_invoke$arity$1(val) : self__.p.call(null,val)))){
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box(cljs.core.not(cljs.core.async.impl.protocols.closed_QMARK_(self__.ch)));
}
});

cljs.core.async.t_cljs$core$async45094.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$filter_GT_,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$p,cljs.core.cst$sym$ch], null))),cljs.core.cst$kw$doc,"Deprecated - this function will be removed. Use transducer instead"], null)),cljs.core.cst$sym$p,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta45095], null);
});

cljs.core.async.t_cljs$core$async45094.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async45094.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async45094";

cljs.core.async.t_cljs$core$async45094.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async45094");
});

cljs.core.async.__GT_t_cljs$core$async45094 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async45094(filter_GT___$1,p__$1,ch__$1,meta45095){
return (new cljs.core.async.t_cljs$core$async45094(filter_GT___$1,p__$1,ch__$1,meta45095));
});

}

return (new cljs.core.async.t_cljs$core$async45094(cljs$core$async$filter_GT_,p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_(cljs.core.complement(p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var args45097 = [];
var len__8118__auto___45141 = arguments.length;
var i__8119__auto___45142 = (0);
while(true){
if((i__8119__auto___45142 < len__8118__auto___45141)){
args45097.push((arguments[i__8119__auto___45142]));

var G__45143 = (i__8119__auto___45142 + (1));
i__8119__auto___45142 = G__45143;
continue;
} else {
}
break;
}

var G__45099 = args45097.length;
switch (G__45099) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args45097.length)].join('')));

}
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___45145 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___45145,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___45145,out){
return (function (state_45120){
var state_val_45121 = (state_45120[(1)]);
if((state_val_45121 === (7))){
var inst_45116 = (state_45120[(2)]);
var state_45120__$1 = state_45120;
var statearr_45122_45146 = state_45120__$1;
(statearr_45122_45146[(2)] = inst_45116);

(statearr_45122_45146[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45121 === (1))){
var state_45120__$1 = state_45120;
var statearr_45123_45147 = state_45120__$1;
(statearr_45123_45147[(2)] = null);

(statearr_45123_45147[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45121 === (4))){
var inst_45102 = (state_45120[(7)]);
var inst_45102__$1 = (state_45120[(2)]);
var inst_45103 = (inst_45102__$1 == null);
var state_45120__$1 = (function (){var statearr_45124 = state_45120;
(statearr_45124[(7)] = inst_45102__$1);

return statearr_45124;
})();
if(cljs.core.truth_(inst_45103)){
var statearr_45125_45148 = state_45120__$1;
(statearr_45125_45148[(1)] = (5));

} else {
var statearr_45126_45149 = state_45120__$1;
(statearr_45126_45149[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45121 === (6))){
var inst_45102 = (state_45120[(7)]);
var inst_45107 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_45102) : p.call(null,inst_45102));
var state_45120__$1 = state_45120;
if(cljs.core.truth_(inst_45107)){
var statearr_45127_45150 = state_45120__$1;
(statearr_45127_45150[(1)] = (8));

} else {
var statearr_45128_45151 = state_45120__$1;
(statearr_45128_45151[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45121 === (3))){
var inst_45118 = (state_45120[(2)]);
var state_45120__$1 = state_45120;
return cljs.core.async.impl.ioc_helpers.return_chan(state_45120__$1,inst_45118);
} else {
if((state_val_45121 === (2))){
var state_45120__$1 = state_45120;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_45120__$1,(4),ch);
} else {
if((state_val_45121 === (11))){
var inst_45110 = (state_45120[(2)]);
var state_45120__$1 = state_45120;
var statearr_45129_45152 = state_45120__$1;
(statearr_45129_45152[(2)] = inst_45110);

(statearr_45129_45152[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45121 === (9))){
var state_45120__$1 = state_45120;
var statearr_45130_45153 = state_45120__$1;
(statearr_45130_45153[(2)] = null);

(statearr_45130_45153[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45121 === (5))){
var inst_45105 = cljs.core.async.close_BANG_(out);
var state_45120__$1 = state_45120;
var statearr_45131_45154 = state_45120__$1;
(statearr_45131_45154[(2)] = inst_45105);

(statearr_45131_45154[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45121 === (10))){
var inst_45113 = (state_45120[(2)]);
var state_45120__$1 = (function (){var statearr_45132 = state_45120;
(statearr_45132[(8)] = inst_45113);

return statearr_45132;
})();
var statearr_45133_45155 = state_45120__$1;
(statearr_45133_45155[(2)] = null);

(statearr_45133_45155[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45121 === (8))){
var inst_45102 = (state_45120[(7)]);
var state_45120__$1 = state_45120;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_45120__$1,(11),out,inst_45102);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___45145,out))
;
return ((function (switch__15098__auto__,c__15224__auto___45145,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_45137 = [null,null,null,null,null,null,null,null,null];
(statearr_45137[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_45137[(1)] = (1));

return statearr_45137;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_45120){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_45120);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e45138){if((e45138 instanceof Object)){
var ex__15102__auto__ = e45138;
var statearr_45139_45156 = state_45120;
(statearr_45139_45156[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_45120);

return cljs.core.cst$kw$recur;
} else {
throw e45138;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__45157 = state_45120;
state_45120 = G__45157;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_45120){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_45120);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___45145,out))
})();
var state__15226__auto__ = (function (){var statearr_45140 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_45140[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___45145);

return statearr_45140;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___45145,out))
);


return out;
});

cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var args45158 = [];
var len__8118__auto___45161 = arguments.length;
var i__8119__auto___45162 = (0);
while(true){
if((i__8119__auto___45162 < len__8118__auto___45161)){
args45158.push((arguments[i__8119__auto___45162]));

var G__45163 = (i__8119__auto___45162 + (1));
i__8119__auto___45162 = G__45163;
continue;
} else {
}
break;
}

var G__45160 = args45158.length;
switch (G__45160) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args45158.length)].join('')));

}
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(cljs.core.complement(p),ch,buf_or_n);
});

cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3;

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_45330){
var state_val_45331 = (state_45330[(1)]);
if((state_val_45331 === (7))){
var inst_45326 = (state_45330[(2)]);
var state_45330__$1 = state_45330;
var statearr_45332_45373 = state_45330__$1;
(statearr_45332_45373[(2)] = inst_45326);

(statearr_45332_45373[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (20))){
var inst_45296 = (state_45330[(7)]);
var inst_45307 = (state_45330[(2)]);
var inst_45308 = cljs.core.next(inst_45296);
var inst_45282 = inst_45308;
var inst_45283 = null;
var inst_45284 = (0);
var inst_45285 = (0);
var state_45330__$1 = (function (){var statearr_45333 = state_45330;
(statearr_45333[(8)] = inst_45282);

(statearr_45333[(9)] = inst_45283);

(statearr_45333[(10)] = inst_45285);

(statearr_45333[(11)] = inst_45284);

(statearr_45333[(12)] = inst_45307);

return statearr_45333;
})();
var statearr_45334_45374 = state_45330__$1;
(statearr_45334_45374[(2)] = null);

(statearr_45334_45374[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (1))){
var state_45330__$1 = state_45330;
var statearr_45335_45375 = state_45330__$1;
(statearr_45335_45375[(2)] = null);

(statearr_45335_45375[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (4))){
var inst_45271 = (state_45330[(13)]);
var inst_45271__$1 = (state_45330[(2)]);
var inst_45272 = (inst_45271__$1 == null);
var state_45330__$1 = (function (){var statearr_45336 = state_45330;
(statearr_45336[(13)] = inst_45271__$1);

return statearr_45336;
})();
if(cljs.core.truth_(inst_45272)){
var statearr_45337_45376 = state_45330__$1;
(statearr_45337_45376[(1)] = (5));

} else {
var statearr_45338_45377 = state_45330__$1;
(statearr_45338_45377[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (15))){
var state_45330__$1 = state_45330;
var statearr_45342_45378 = state_45330__$1;
(statearr_45342_45378[(2)] = null);

(statearr_45342_45378[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (21))){
var state_45330__$1 = state_45330;
var statearr_45343_45379 = state_45330__$1;
(statearr_45343_45379[(2)] = null);

(statearr_45343_45379[(1)] = (23));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (13))){
var inst_45282 = (state_45330[(8)]);
var inst_45283 = (state_45330[(9)]);
var inst_45285 = (state_45330[(10)]);
var inst_45284 = (state_45330[(11)]);
var inst_45292 = (state_45330[(2)]);
var inst_45293 = (inst_45285 + (1));
var tmp45339 = inst_45282;
var tmp45340 = inst_45283;
var tmp45341 = inst_45284;
var inst_45282__$1 = tmp45339;
var inst_45283__$1 = tmp45340;
var inst_45284__$1 = tmp45341;
var inst_45285__$1 = inst_45293;
var state_45330__$1 = (function (){var statearr_45344 = state_45330;
(statearr_45344[(14)] = inst_45292);

(statearr_45344[(8)] = inst_45282__$1);

(statearr_45344[(9)] = inst_45283__$1);

(statearr_45344[(10)] = inst_45285__$1);

(statearr_45344[(11)] = inst_45284__$1);

return statearr_45344;
})();
var statearr_45345_45380 = state_45330__$1;
(statearr_45345_45380[(2)] = null);

(statearr_45345_45380[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (22))){
var state_45330__$1 = state_45330;
var statearr_45346_45381 = state_45330__$1;
(statearr_45346_45381[(2)] = null);

(statearr_45346_45381[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (6))){
var inst_45271 = (state_45330[(13)]);
var inst_45280 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_45271) : f.call(null,inst_45271));
var inst_45281 = cljs.core.seq(inst_45280);
var inst_45282 = inst_45281;
var inst_45283 = null;
var inst_45284 = (0);
var inst_45285 = (0);
var state_45330__$1 = (function (){var statearr_45347 = state_45330;
(statearr_45347[(8)] = inst_45282);

(statearr_45347[(9)] = inst_45283);

(statearr_45347[(10)] = inst_45285);

(statearr_45347[(11)] = inst_45284);

return statearr_45347;
})();
var statearr_45348_45382 = state_45330__$1;
(statearr_45348_45382[(2)] = null);

(statearr_45348_45382[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (17))){
var inst_45296 = (state_45330[(7)]);
var inst_45300 = cljs.core.chunk_first(inst_45296);
var inst_45301 = cljs.core.chunk_rest(inst_45296);
var inst_45302 = cljs.core.count(inst_45300);
var inst_45282 = inst_45301;
var inst_45283 = inst_45300;
var inst_45284 = inst_45302;
var inst_45285 = (0);
var state_45330__$1 = (function (){var statearr_45349 = state_45330;
(statearr_45349[(8)] = inst_45282);

(statearr_45349[(9)] = inst_45283);

(statearr_45349[(10)] = inst_45285);

(statearr_45349[(11)] = inst_45284);

return statearr_45349;
})();
var statearr_45350_45383 = state_45330__$1;
(statearr_45350_45383[(2)] = null);

(statearr_45350_45383[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (3))){
var inst_45328 = (state_45330[(2)]);
var state_45330__$1 = state_45330;
return cljs.core.async.impl.ioc_helpers.return_chan(state_45330__$1,inst_45328);
} else {
if((state_val_45331 === (12))){
var inst_45316 = (state_45330[(2)]);
var state_45330__$1 = state_45330;
var statearr_45351_45384 = state_45330__$1;
(statearr_45351_45384[(2)] = inst_45316);

(statearr_45351_45384[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (2))){
var state_45330__$1 = state_45330;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_45330__$1,(4),in$);
} else {
if((state_val_45331 === (23))){
var inst_45324 = (state_45330[(2)]);
var state_45330__$1 = state_45330;
var statearr_45352_45385 = state_45330__$1;
(statearr_45352_45385[(2)] = inst_45324);

(statearr_45352_45385[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (19))){
var inst_45311 = (state_45330[(2)]);
var state_45330__$1 = state_45330;
var statearr_45353_45386 = state_45330__$1;
(statearr_45353_45386[(2)] = inst_45311);

(statearr_45353_45386[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (11))){
var inst_45296 = (state_45330[(7)]);
var inst_45282 = (state_45330[(8)]);
var inst_45296__$1 = cljs.core.seq(inst_45282);
var state_45330__$1 = (function (){var statearr_45354 = state_45330;
(statearr_45354[(7)] = inst_45296__$1);

return statearr_45354;
})();
if(inst_45296__$1){
var statearr_45355_45387 = state_45330__$1;
(statearr_45355_45387[(1)] = (14));

} else {
var statearr_45356_45388 = state_45330__$1;
(statearr_45356_45388[(1)] = (15));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (9))){
var inst_45318 = (state_45330[(2)]);
var inst_45319 = cljs.core.async.impl.protocols.closed_QMARK_(out);
var state_45330__$1 = (function (){var statearr_45357 = state_45330;
(statearr_45357[(15)] = inst_45318);

return statearr_45357;
})();
if(cljs.core.truth_(inst_45319)){
var statearr_45358_45389 = state_45330__$1;
(statearr_45358_45389[(1)] = (21));

} else {
var statearr_45359_45390 = state_45330__$1;
(statearr_45359_45390[(1)] = (22));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (5))){
var inst_45274 = cljs.core.async.close_BANG_(out);
var state_45330__$1 = state_45330;
var statearr_45360_45391 = state_45330__$1;
(statearr_45360_45391[(2)] = inst_45274);

(statearr_45360_45391[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (14))){
var inst_45296 = (state_45330[(7)]);
var inst_45298 = cljs.core.chunked_seq_QMARK_(inst_45296);
var state_45330__$1 = state_45330;
if(inst_45298){
var statearr_45361_45392 = state_45330__$1;
(statearr_45361_45392[(1)] = (17));

} else {
var statearr_45362_45393 = state_45330__$1;
(statearr_45362_45393[(1)] = (18));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (16))){
var inst_45314 = (state_45330[(2)]);
var state_45330__$1 = state_45330;
var statearr_45363_45394 = state_45330__$1;
(statearr_45363_45394[(2)] = inst_45314);

(statearr_45363_45394[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45331 === (10))){
var inst_45283 = (state_45330[(9)]);
var inst_45285 = (state_45330[(10)]);
var inst_45290 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_45283,inst_45285);
var state_45330__$1 = state_45330;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_45330__$1,(13),out,inst_45290);
} else {
if((state_val_45331 === (18))){
var inst_45296 = (state_45330[(7)]);
var inst_45305 = cljs.core.first(inst_45296);
var state_45330__$1 = state_45330;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_45330__$1,(20),out,inst_45305);
} else {
if((state_val_45331 === (8))){
var inst_45285 = (state_45330[(10)]);
var inst_45284 = (state_45330[(11)]);
var inst_45287 = (inst_45285 < inst_45284);
var inst_45288 = inst_45287;
var state_45330__$1 = state_45330;
if(cljs.core.truth_(inst_45288)){
var statearr_45364_45395 = state_45330__$1;
(statearr_45364_45395[(1)] = (10));

} else {
var statearr_45365_45396 = state_45330__$1;
(statearr_45365_45396[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_45369 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_45369[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__);

(statearr_45369[(1)] = (1));

return statearr_45369;
});
var cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____1 = (function (state_45330){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_45330);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e45370){if((e45370 instanceof Object)){
var ex__15102__auto__ = e45370;
var statearr_45371_45397 = state_45330;
(statearr_45371_45397[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_45330);

return cljs.core.cst$kw$recur;
} else {
throw e45370;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__45398 = state_45330;
state_45330 = G__45398;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__ = function(state_45330){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____1.call(this,state_45330);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_45372 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_45372[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_45372;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var args45399 = [];
var len__8118__auto___45402 = arguments.length;
var i__8119__auto___45403 = (0);
while(true){
if((i__8119__auto___45403 < len__8118__auto___45402)){
args45399.push((arguments[i__8119__auto___45403]));

var G__45404 = (i__8119__auto___45403 + (1));
i__8119__auto___45403 = G__45404;
continue;
} else {
}
break;
}

var G__45401 = args45399.length;
switch (G__45401) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args45399.length)].join('')));

}
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3(f,in$,null);
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return out;
});

cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var args45406 = [];
var len__8118__auto___45409 = arguments.length;
var i__8119__auto___45410 = (0);
while(true){
if((i__8119__auto___45410 < len__8118__auto___45409)){
args45406.push((arguments[i__8119__auto___45410]));

var G__45411 = (i__8119__auto___45410 + (1));
i__8119__auto___45410 = G__45411;
continue;
} else {
}
break;
}

var G__45408 = args45406.length;
switch (G__45408) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args45406.length)].join('')));

}
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3(f,out,null);
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return in$;
});

cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var args45413 = [];
var len__8118__auto___45464 = arguments.length;
var i__8119__auto___45465 = (0);
while(true){
if((i__8119__auto___45465 < len__8118__auto___45464)){
args45413.push((arguments[i__8119__auto___45465]));

var G__45466 = (i__8119__auto___45465 + (1));
i__8119__auto___45465 = G__45466;
continue;
} else {
}
break;
}

var G__45415 = args45413.length;
switch (G__45415) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args45413.length)].join('')));

}
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2(ch,null);
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___45468 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___45468,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___45468,out){
return (function (state_45439){
var state_val_45440 = (state_45439[(1)]);
if((state_val_45440 === (7))){
var inst_45434 = (state_45439[(2)]);
var state_45439__$1 = state_45439;
var statearr_45441_45469 = state_45439__$1;
(statearr_45441_45469[(2)] = inst_45434);

(statearr_45441_45469[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45440 === (1))){
var inst_45416 = null;
var state_45439__$1 = (function (){var statearr_45442 = state_45439;
(statearr_45442[(7)] = inst_45416);

return statearr_45442;
})();
var statearr_45443_45470 = state_45439__$1;
(statearr_45443_45470[(2)] = null);

(statearr_45443_45470[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45440 === (4))){
var inst_45419 = (state_45439[(8)]);
var inst_45419__$1 = (state_45439[(2)]);
var inst_45420 = (inst_45419__$1 == null);
var inst_45421 = cljs.core.not(inst_45420);
var state_45439__$1 = (function (){var statearr_45444 = state_45439;
(statearr_45444[(8)] = inst_45419__$1);

return statearr_45444;
})();
if(inst_45421){
var statearr_45445_45471 = state_45439__$1;
(statearr_45445_45471[(1)] = (5));

} else {
var statearr_45446_45472 = state_45439__$1;
(statearr_45446_45472[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45440 === (6))){
var state_45439__$1 = state_45439;
var statearr_45447_45473 = state_45439__$1;
(statearr_45447_45473[(2)] = null);

(statearr_45447_45473[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45440 === (3))){
var inst_45436 = (state_45439[(2)]);
var inst_45437 = cljs.core.async.close_BANG_(out);
var state_45439__$1 = (function (){var statearr_45448 = state_45439;
(statearr_45448[(9)] = inst_45436);

return statearr_45448;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_45439__$1,inst_45437);
} else {
if((state_val_45440 === (2))){
var state_45439__$1 = state_45439;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_45439__$1,(4),ch);
} else {
if((state_val_45440 === (11))){
var inst_45419 = (state_45439[(8)]);
var inst_45428 = (state_45439[(2)]);
var inst_45416 = inst_45419;
var state_45439__$1 = (function (){var statearr_45449 = state_45439;
(statearr_45449[(10)] = inst_45428);

(statearr_45449[(7)] = inst_45416);

return statearr_45449;
})();
var statearr_45450_45474 = state_45439__$1;
(statearr_45450_45474[(2)] = null);

(statearr_45450_45474[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45440 === (9))){
var inst_45419 = (state_45439[(8)]);
var state_45439__$1 = state_45439;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_45439__$1,(11),out,inst_45419);
} else {
if((state_val_45440 === (5))){
var inst_45419 = (state_45439[(8)]);
var inst_45416 = (state_45439[(7)]);
var inst_45423 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_45419,inst_45416);
var state_45439__$1 = state_45439;
if(inst_45423){
var statearr_45452_45475 = state_45439__$1;
(statearr_45452_45475[(1)] = (8));

} else {
var statearr_45453_45476 = state_45439__$1;
(statearr_45453_45476[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45440 === (10))){
var inst_45431 = (state_45439[(2)]);
var state_45439__$1 = state_45439;
var statearr_45454_45477 = state_45439__$1;
(statearr_45454_45477[(2)] = inst_45431);

(statearr_45454_45477[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45440 === (8))){
var inst_45416 = (state_45439[(7)]);
var tmp45451 = inst_45416;
var inst_45416__$1 = tmp45451;
var state_45439__$1 = (function (){var statearr_45455 = state_45439;
(statearr_45455[(7)] = inst_45416__$1);

return statearr_45455;
})();
var statearr_45456_45478 = state_45439__$1;
(statearr_45456_45478[(2)] = null);

(statearr_45456_45478[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___45468,out))
;
return ((function (switch__15098__auto__,c__15224__auto___45468,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_45460 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_45460[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_45460[(1)] = (1));

return statearr_45460;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_45439){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_45439);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e45461){if((e45461 instanceof Object)){
var ex__15102__auto__ = e45461;
var statearr_45462_45479 = state_45439;
(statearr_45462_45479[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_45439);

return cljs.core.cst$kw$recur;
} else {
throw e45461;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__45480 = state_45439;
state_45439 = G__45480;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_45439){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_45439);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___45468,out))
})();
var state__15226__auto__ = (function (){var statearr_45463 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_45463[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___45468);

return statearr_45463;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___45468,out))
);


return out;
});

cljs.core.async.unique.cljs$lang$maxFixedArity = 2;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var args45481 = [];
var len__8118__auto___45551 = arguments.length;
var i__8119__auto___45552 = (0);
while(true){
if((i__8119__auto___45552 < len__8118__auto___45551)){
args45481.push((arguments[i__8119__auto___45552]));

var G__45553 = (i__8119__auto___45552 + (1));
i__8119__auto___45552 = G__45553;
continue;
} else {
}
break;
}

var G__45483 = args45481.length;
switch (G__45483) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args45481.length)].join('')));

}
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___45555 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___45555,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___45555,out){
return (function (state_45521){
var state_val_45522 = (state_45521[(1)]);
if((state_val_45522 === (7))){
var inst_45517 = (state_45521[(2)]);
var state_45521__$1 = state_45521;
var statearr_45523_45556 = state_45521__$1;
(statearr_45523_45556[(2)] = inst_45517);

(statearr_45523_45556[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45522 === (1))){
var inst_45484 = (new Array(n));
var inst_45485 = inst_45484;
var inst_45486 = (0);
var state_45521__$1 = (function (){var statearr_45524 = state_45521;
(statearr_45524[(7)] = inst_45485);

(statearr_45524[(8)] = inst_45486);

return statearr_45524;
})();
var statearr_45525_45557 = state_45521__$1;
(statearr_45525_45557[(2)] = null);

(statearr_45525_45557[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45522 === (4))){
var inst_45489 = (state_45521[(9)]);
var inst_45489__$1 = (state_45521[(2)]);
var inst_45490 = (inst_45489__$1 == null);
var inst_45491 = cljs.core.not(inst_45490);
var state_45521__$1 = (function (){var statearr_45526 = state_45521;
(statearr_45526[(9)] = inst_45489__$1);

return statearr_45526;
})();
if(inst_45491){
var statearr_45527_45558 = state_45521__$1;
(statearr_45527_45558[(1)] = (5));

} else {
var statearr_45528_45559 = state_45521__$1;
(statearr_45528_45559[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45522 === (15))){
var inst_45511 = (state_45521[(2)]);
var state_45521__$1 = state_45521;
var statearr_45529_45560 = state_45521__$1;
(statearr_45529_45560[(2)] = inst_45511);

(statearr_45529_45560[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45522 === (13))){
var state_45521__$1 = state_45521;
var statearr_45530_45561 = state_45521__$1;
(statearr_45530_45561[(2)] = null);

(statearr_45530_45561[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45522 === (6))){
var inst_45486 = (state_45521[(8)]);
var inst_45507 = (inst_45486 > (0));
var state_45521__$1 = state_45521;
if(cljs.core.truth_(inst_45507)){
var statearr_45531_45562 = state_45521__$1;
(statearr_45531_45562[(1)] = (12));

} else {
var statearr_45532_45563 = state_45521__$1;
(statearr_45532_45563[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45522 === (3))){
var inst_45519 = (state_45521[(2)]);
var state_45521__$1 = state_45521;
return cljs.core.async.impl.ioc_helpers.return_chan(state_45521__$1,inst_45519);
} else {
if((state_val_45522 === (12))){
var inst_45485 = (state_45521[(7)]);
var inst_45509 = cljs.core.vec(inst_45485);
var state_45521__$1 = state_45521;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_45521__$1,(15),out,inst_45509);
} else {
if((state_val_45522 === (2))){
var state_45521__$1 = state_45521;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_45521__$1,(4),ch);
} else {
if((state_val_45522 === (11))){
var inst_45501 = (state_45521[(2)]);
var inst_45502 = (new Array(n));
var inst_45485 = inst_45502;
var inst_45486 = (0);
var state_45521__$1 = (function (){var statearr_45533 = state_45521;
(statearr_45533[(7)] = inst_45485);

(statearr_45533[(8)] = inst_45486);

(statearr_45533[(10)] = inst_45501);

return statearr_45533;
})();
var statearr_45534_45564 = state_45521__$1;
(statearr_45534_45564[(2)] = null);

(statearr_45534_45564[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45522 === (9))){
var inst_45485 = (state_45521[(7)]);
var inst_45499 = cljs.core.vec(inst_45485);
var state_45521__$1 = state_45521;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_45521__$1,(11),out,inst_45499);
} else {
if((state_val_45522 === (5))){
var inst_45485 = (state_45521[(7)]);
var inst_45494 = (state_45521[(11)]);
var inst_45486 = (state_45521[(8)]);
var inst_45489 = (state_45521[(9)]);
var inst_45493 = (inst_45485[inst_45486] = inst_45489);
var inst_45494__$1 = (inst_45486 + (1));
var inst_45495 = (inst_45494__$1 < n);
var state_45521__$1 = (function (){var statearr_45535 = state_45521;
(statearr_45535[(11)] = inst_45494__$1);

(statearr_45535[(12)] = inst_45493);

return statearr_45535;
})();
if(cljs.core.truth_(inst_45495)){
var statearr_45536_45565 = state_45521__$1;
(statearr_45536_45565[(1)] = (8));

} else {
var statearr_45537_45566 = state_45521__$1;
(statearr_45537_45566[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45522 === (14))){
var inst_45514 = (state_45521[(2)]);
var inst_45515 = cljs.core.async.close_BANG_(out);
var state_45521__$1 = (function (){var statearr_45539 = state_45521;
(statearr_45539[(13)] = inst_45514);

return statearr_45539;
})();
var statearr_45540_45567 = state_45521__$1;
(statearr_45540_45567[(2)] = inst_45515);

(statearr_45540_45567[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45522 === (10))){
var inst_45505 = (state_45521[(2)]);
var state_45521__$1 = state_45521;
var statearr_45541_45568 = state_45521__$1;
(statearr_45541_45568[(2)] = inst_45505);

(statearr_45541_45568[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45522 === (8))){
var inst_45485 = (state_45521[(7)]);
var inst_45494 = (state_45521[(11)]);
var tmp45538 = inst_45485;
var inst_45485__$1 = tmp45538;
var inst_45486 = inst_45494;
var state_45521__$1 = (function (){var statearr_45542 = state_45521;
(statearr_45542[(7)] = inst_45485__$1);

(statearr_45542[(8)] = inst_45486);

return statearr_45542;
})();
var statearr_45543_45569 = state_45521__$1;
(statearr_45543_45569[(2)] = null);

(statearr_45543_45569[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___45555,out))
;
return ((function (switch__15098__auto__,c__15224__auto___45555,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_45547 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_45547[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_45547[(1)] = (1));

return statearr_45547;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_45521){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_45521);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e45548){if((e45548 instanceof Object)){
var ex__15102__auto__ = e45548;
var statearr_45549_45570 = state_45521;
(statearr_45549_45570[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_45521);

return cljs.core.cst$kw$recur;
} else {
throw e45548;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__45571 = state_45521;
state_45521 = G__45571;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_45521){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_45521);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___45555,out))
})();
var state__15226__auto__ = (function (){var statearr_45550 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_45550[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___45555);

return statearr_45550;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___45555,out))
);


return out;
});

cljs.core.async.partition.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var args45572 = [];
var len__8118__auto___45646 = arguments.length;
var i__8119__auto___45647 = (0);
while(true){
if((i__8119__auto___45647 < len__8118__auto___45646)){
args45572.push((arguments[i__8119__auto___45647]));

var G__45648 = (i__8119__auto___45647 + (1));
i__8119__auto___45647 = G__45648;
continue;
} else {
}
break;
}

var G__45574 = args45572.length;
switch (G__45574) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args45572.length)].join('')));

}
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3(f,ch,null);
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___45650 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___45650,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___45650,out){
return (function (state_45616){
var state_val_45617 = (state_45616[(1)]);
if((state_val_45617 === (7))){
var inst_45612 = (state_45616[(2)]);
var state_45616__$1 = state_45616;
var statearr_45618_45651 = state_45616__$1;
(statearr_45618_45651[(2)] = inst_45612);

(statearr_45618_45651[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45617 === (1))){
var inst_45575 = [];
var inst_45576 = inst_45575;
var inst_45577 = cljs.core.cst$kw$cljs$core$async_SLASH_nothing;
var state_45616__$1 = (function (){var statearr_45619 = state_45616;
(statearr_45619[(7)] = inst_45577);

(statearr_45619[(8)] = inst_45576);

return statearr_45619;
})();
var statearr_45620_45652 = state_45616__$1;
(statearr_45620_45652[(2)] = null);

(statearr_45620_45652[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45617 === (4))){
var inst_45580 = (state_45616[(9)]);
var inst_45580__$1 = (state_45616[(2)]);
var inst_45581 = (inst_45580__$1 == null);
var inst_45582 = cljs.core.not(inst_45581);
var state_45616__$1 = (function (){var statearr_45621 = state_45616;
(statearr_45621[(9)] = inst_45580__$1);

return statearr_45621;
})();
if(inst_45582){
var statearr_45622_45653 = state_45616__$1;
(statearr_45622_45653[(1)] = (5));

} else {
var statearr_45623_45654 = state_45616__$1;
(statearr_45623_45654[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45617 === (15))){
var inst_45606 = (state_45616[(2)]);
var state_45616__$1 = state_45616;
var statearr_45624_45655 = state_45616__$1;
(statearr_45624_45655[(2)] = inst_45606);

(statearr_45624_45655[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45617 === (13))){
var state_45616__$1 = state_45616;
var statearr_45625_45656 = state_45616__$1;
(statearr_45625_45656[(2)] = null);

(statearr_45625_45656[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45617 === (6))){
var inst_45576 = (state_45616[(8)]);
var inst_45601 = inst_45576.length;
var inst_45602 = (inst_45601 > (0));
var state_45616__$1 = state_45616;
if(cljs.core.truth_(inst_45602)){
var statearr_45626_45657 = state_45616__$1;
(statearr_45626_45657[(1)] = (12));

} else {
var statearr_45627_45658 = state_45616__$1;
(statearr_45627_45658[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45617 === (3))){
var inst_45614 = (state_45616[(2)]);
var state_45616__$1 = state_45616;
return cljs.core.async.impl.ioc_helpers.return_chan(state_45616__$1,inst_45614);
} else {
if((state_val_45617 === (12))){
var inst_45576 = (state_45616[(8)]);
var inst_45604 = cljs.core.vec(inst_45576);
var state_45616__$1 = state_45616;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_45616__$1,(15),out,inst_45604);
} else {
if((state_val_45617 === (2))){
var state_45616__$1 = state_45616;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_45616__$1,(4),ch);
} else {
if((state_val_45617 === (11))){
var inst_45580 = (state_45616[(9)]);
var inst_45584 = (state_45616[(10)]);
var inst_45594 = (state_45616[(2)]);
var inst_45595 = [];
var inst_45596 = inst_45595.push(inst_45580);
var inst_45576 = inst_45595;
var inst_45577 = inst_45584;
var state_45616__$1 = (function (){var statearr_45628 = state_45616;
(statearr_45628[(7)] = inst_45577);

(statearr_45628[(8)] = inst_45576);

(statearr_45628[(11)] = inst_45596);

(statearr_45628[(12)] = inst_45594);

return statearr_45628;
})();
var statearr_45629_45659 = state_45616__$1;
(statearr_45629_45659[(2)] = null);

(statearr_45629_45659[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45617 === (9))){
var inst_45576 = (state_45616[(8)]);
var inst_45592 = cljs.core.vec(inst_45576);
var state_45616__$1 = state_45616;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_45616__$1,(11),out,inst_45592);
} else {
if((state_val_45617 === (5))){
var inst_45580 = (state_45616[(9)]);
var inst_45577 = (state_45616[(7)]);
var inst_45584 = (state_45616[(10)]);
var inst_45584__$1 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_45580) : f.call(null,inst_45580));
var inst_45585 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_45584__$1,inst_45577);
var inst_45586 = cljs.core.keyword_identical_QMARK_(inst_45577,cljs.core.cst$kw$cljs$core$async_SLASH_nothing);
var inst_45587 = (inst_45585) || (inst_45586);
var state_45616__$1 = (function (){var statearr_45630 = state_45616;
(statearr_45630[(10)] = inst_45584__$1);

return statearr_45630;
})();
if(cljs.core.truth_(inst_45587)){
var statearr_45631_45660 = state_45616__$1;
(statearr_45631_45660[(1)] = (8));

} else {
var statearr_45632_45661 = state_45616__$1;
(statearr_45632_45661[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_45617 === (14))){
var inst_45609 = (state_45616[(2)]);
var inst_45610 = cljs.core.async.close_BANG_(out);
var state_45616__$1 = (function (){var statearr_45634 = state_45616;
(statearr_45634[(13)] = inst_45609);

return statearr_45634;
})();
var statearr_45635_45662 = state_45616__$1;
(statearr_45635_45662[(2)] = inst_45610);

(statearr_45635_45662[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45617 === (10))){
var inst_45599 = (state_45616[(2)]);
var state_45616__$1 = state_45616;
var statearr_45636_45663 = state_45616__$1;
(statearr_45636_45663[(2)] = inst_45599);

(statearr_45636_45663[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_45617 === (8))){
var inst_45580 = (state_45616[(9)]);
var inst_45584 = (state_45616[(10)]);
var inst_45576 = (state_45616[(8)]);
var inst_45589 = inst_45576.push(inst_45580);
var tmp45633 = inst_45576;
var inst_45576__$1 = tmp45633;
var inst_45577 = inst_45584;
var state_45616__$1 = (function (){var statearr_45637 = state_45616;
(statearr_45637[(7)] = inst_45577);

(statearr_45637[(8)] = inst_45576__$1);

(statearr_45637[(14)] = inst_45589);

return statearr_45637;
})();
var statearr_45638_45664 = state_45616__$1;
(statearr_45638_45664[(2)] = null);

(statearr_45638_45664[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___45650,out))
;
return ((function (switch__15098__auto__,c__15224__auto___45650,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_45642 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_45642[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_45642[(1)] = (1));

return statearr_45642;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_45616){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_45616);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e45643){if((e45643 instanceof Object)){
var ex__15102__auto__ = e45643;
var statearr_45644_45665 = state_45616;
(statearr_45644_45665[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_45616);

return cljs.core.cst$kw$recur;
} else {
throw e45643;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__45666 = state_45616;
state_45616 = G__45666;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_45616){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_45616);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___45650,out))
})();
var state__15226__auto__ = (function (){var statearr_45645 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_45645[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___45650);

return statearr_45645;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___45650,out))
);


return out;
});

cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3;


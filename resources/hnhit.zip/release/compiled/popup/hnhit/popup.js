// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('hnhit.popup');
goog.require('cljs.core');
goog.require('hnhit.popup.core');
hnhit.popup.core.init_BANG_();

// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('hnhit.popup.core');
goog.require('cljs.core');
goog.require('chromex.ext.runtime');
goog.require('goog.dom.query');
goog.require('goog.dom');
goog.require('chromex.protocols');
goog.require('re_com.core');
goog.require('reagent.core');
goog.require('cljs_http.client');
goog.require('chromex.logging');
goog.require('chromex.ext.tabs');
goog.require('cljs.core.async');
goog.require('hnhit.popup.components');
if(typeof hnhit.popup.core.app_state !== 'undefined'){
} else {
hnhit.popup.core.app_state = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$items,cljs.core.PersistentVector.EMPTY,cljs.core.cst$kw$loading,false,cljs.core.cst$kw$error,null,cljs.core.cst$kw$url,null,cljs.core.cst$kw$title,null], null));
}
hnhit.popup.core.items_cursor = reagent.core.cursor(hnhit.popup.core.app_state,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$items], null));
hnhit.popup.core.results_QMARK_ = (function hnhit$popup$core$results_QMARK_(){
return cljs.core.seq((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(hnhit.popup.core.items_cursor) : cljs.core.deref.call(null,hnhit.popup.core.items_cursor)));
});
hnhit.popup.core.no_results_QMARK_ = cljs.core.complement(hnhit.popup.core.results_QMARK_);
hnhit.popup.core.error_QMARK_ = (function hnhit$popup$core$error_QMARK_(){
return cljs.core.some_QMARK_(cljs.core.cst$kw$error.cljs$core$IFn$_invoke$arity$1((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(hnhit.popup.core.app_state) : cljs.core.deref.call(null,hnhit.popup.core.app_state))));
});
hnhit.popup.core.loading_QMARK_ = (function hnhit$popup$core$loading_QMARK_(){
return cljs.core.cst$kw$loading.cljs$core$IFn$_invoke$arity$1((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(hnhit.popup.core.app_state) : cljs.core.deref.call(null,hnhit.popup.core.app_state)));
});
hnhit.popup.core.loading_BANG_ = (function hnhit$popup$core$loading_BANG_(){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$variadic(hnhit.popup.core.app_state,cljs.core.assoc,cljs.core.cst$kw$loading,true,cljs.core.array_seq([cljs.core.cst$kw$error,null], 0));
});
hnhit.popup.core.finished_loading_BANG_ = (function hnhit$popup$core$finished_loading_BANG_(){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(hnhit.popup.core.app_state,cljs.core.assoc,cljs.core.cst$kw$loading,false);
});
hnhit.popup.core.hn_api_search_url = "https://hn.algolia.com/api/v1/search?query=";
hnhit.popup.core.hn_submit_link = "https://news.ycombinator.com/submitlink";
hnhit.popup.core.hn_item_url = "https://news.ycombinator.com/item?id=";
hnhit.popup.core.is_story_QMARK_ = (function hnhit$popup$core$is_story_QMARK_(item){
return (cljs.core.cst$kw$story_id.cljs$core$IFn$_invoke$arity$1(item) == null);
});
hnhit.popup.core.is_comment_QMARK_ = cljs.core.complement(hnhit.popup.core.is_story_QMARK_);
hnhit.popup.core.build_hn_url = (function hnhit$popup$core$build_hn_url(item){
return [cljs.core.str(hnhit.popup.core.hn_item_url),cljs.core.str((function (){var G__37809 = (cljs.core.truth_(hnhit.popup.core.is_story_QMARK_(item))?cljs.core.cst$kw$objectID:cljs.core.cst$kw$story_id);
return (item.cljs$core$IFn$_invoke$arity$1 ? item.cljs$core$IFn$_invoke$arity$1(G__37809) : item.call(null,G__37809));
})())].join('');
});
hnhit.popup.core.transform_response = (function hnhit$popup$core$transform_response(r){

var hits = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(r,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$body,cljs.core.cst$kw$hits], null));
return cljs.core.map.cljs$core$IFn$_invoke$arity$2(((function (hits){
return (function (p1__37810_SHARP_){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__37810_SHARP_,cljs.core.cst$kw$hn_DASH_url,hnhit.popup.core.build_hn_url(p1__37810_SHARP_));
});})(hits))
,hits);
});
/**
 * Queries the HN Api and update the state with results.
 */
hnhit.popup.core.get_topics = (function hnhit$popup$core$get_topics(url){
hnhit.popup.core.loading_BANG_();

var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_37858){
var state_val_37859 = (state_37858[(1)]);
if((state_val_37859 === (1))){
var inst_37842 = [cljs.core.str(hnhit.popup.core.hn_api_search_url),cljs.core.str(url)].join('');
var inst_37843 = cljs_http.client.get(inst_37842);
var state_37858__$1 = state_37858;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_37858__$1,(2),inst_37843);
} else {
if((state_val_37859 === (2))){
var inst_37845 = (state_37858[(7)]);
var inst_37845__$1 = (state_37858[(2)]);
var inst_37846 = cljs.core.cst$kw$status.cljs$core$IFn$_invoke$arity$1(inst_37845__$1);
var inst_37847 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_37846,(200));
var state_37858__$1 = (function (){var statearr_37860 = state_37858;
(statearr_37860[(7)] = inst_37845__$1);

return statearr_37860;
})();
if(inst_37847){
var statearr_37861_37873 = state_37858__$1;
(statearr_37861_37873[(1)] = (3));

} else {
var statearr_37862_37874 = state_37858__$1;
(statearr_37862_37874[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_37859 === (3))){
var inst_37845 = (state_37858[(7)]);
var inst_37849 = hnhit.popup.core.transform_response(inst_37845);
var inst_37850 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(hnhit.popup.core.app_state,cljs.core.assoc,cljs.core.cst$kw$items,inst_37849);
var state_37858__$1 = state_37858;
var statearr_37863_37875 = state_37858__$1;
(statearr_37863_37875[(2)] = inst_37850);

(statearr_37863_37875[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_37859 === (4))){
var inst_37845 = (state_37858[(7)]);
var inst_37852 = cljs.core.cst$kw$status.cljs$core$IFn$_invoke$arity$1(inst_37845);
var inst_37853 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(hnhit.popup.core.app_state,cljs.core.assoc,cljs.core.cst$kw$error,inst_37852);
var state_37858__$1 = state_37858;
var statearr_37864_37876 = state_37858__$1;
(statearr_37864_37876[(2)] = inst_37853);

(statearr_37864_37876[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_37859 === (5))){
var inst_37855 = (state_37858[(2)]);
var inst_37856 = hnhit.popup.core.finished_loading_BANG_();
var state_37858__$1 = (function (){var statearr_37865 = state_37858;
(statearr_37865[(8)] = inst_37855);

return statearr_37865;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_37858__$1,inst_37856);
} else {
return null;
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var hnhit$popup$core$get_topics_$_state_machine__15099__auto__ = null;
var hnhit$popup$core$get_topics_$_state_machine__15099__auto____0 = (function (){
var statearr_37869 = [null,null,null,null,null,null,null,null,null];
(statearr_37869[(0)] = hnhit$popup$core$get_topics_$_state_machine__15099__auto__);

(statearr_37869[(1)] = (1));

return statearr_37869;
});
var hnhit$popup$core$get_topics_$_state_machine__15099__auto____1 = (function (state_37858){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_37858);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e37870){if((e37870 instanceof Object)){
var ex__15102__auto__ = e37870;
var statearr_37871_37877 = state_37858;
(statearr_37871_37877[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_37858);

return cljs.core.cst$kw$recur;
} else {
throw e37870;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__37878 = state_37858;
state_37858 = G__37878;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
hnhit$popup$core$get_topics_$_state_machine__15099__auto__ = function(state_37858){
switch(arguments.length){
case 0:
return hnhit$popup$core$get_topics_$_state_machine__15099__auto____0.call(this);
case 1:
return hnhit$popup$core$get_topics_$_state_machine__15099__auto____1.call(this,state_37858);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
hnhit$popup$core$get_topics_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = hnhit$popup$core$get_topics_$_state_machine__15099__auto____0;
hnhit$popup$core$get_topics_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = hnhit$popup$core$get_topics_$_state_machine__15099__auto____1;
return hnhit$popup$core$get_topics_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_37872 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_37872[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_37872;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});
/**
 * Build a submit link based on the current tab url and title
 */
hnhit.popup.core.build_hn_submit_link = (function hnhit$popup$core$build_hn_submit_link(){
var url = cljs.core.cst$kw$url.cljs$core$IFn$_invoke$arity$1((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(hnhit.popup.core.app_state) : cljs.core.deref.call(null,hnhit.popup.core.app_state)));
var title = cljs.core.cst$kw$title.cljs$core$IFn$_invoke$arity$1((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(hnhit.popup.core.app_state) : cljs.core.deref.call(null,hnhit.popup.core.app_state)));
return [cljs.core.str(hnhit.popup.core.hn_submit_link),cljs.core.str("?u="),cljs.core.str(url),cljs.core.str("&t="),cljs.core.str(title)].join('');
});
/**
 * Remove the http or https term of the url
 */
hnhit.popup.core.build_search_term = (function hnhit$popup$core$build_search_term(url){
return clojure.string.replace(url,/^http(s?):\/\//,"");
});
/**
 * Get the current tab url and update the state
 */
hnhit.popup.core.search_tab_url = (function hnhit$popup$core$search_tab_url(){
var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_37932){
var state_val_37933 = (state_37932[(1)]);
if((state_val_37933 === (1))){
var inst_37913 = chromex.config.get_active_config();
var inst_37914 = chromex.ext.tabs.query_STAR_(inst_37913,({"active": true, "currentWindow": true}));
var state_37932__$1 = state_37932;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_37932__$1,(2),inst_37914);
} else {
if((state_val_37933 === (2))){
var inst_37916 = (state_37932[(7)]);
var inst_37916__$1 = (state_37932[(2)]);
var state_37932__$1 = (function (){var statearr_37934 = state_37932;
(statearr_37934[(7)] = inst_37916__$1);

return statearr_37934;
})();
if(cljs.core.truth_(inst_37916__$1)){
var statearr_37935_37947 = state_37932__$1;
(statearr_37935_37947[(1)] = (3));

} else {
var statearr_37936_37948 = state_37932__$1;
(statearr_37936_37948[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_37933 === (3))){
var inst_37916 = (state_37932[(7)]);
var inst_37921 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_37916,(0),null);
var inst_37922 = cljs.core.first(inst_37921);
var inst_37923 = inst_37922.url;
var inst_37924 = inst_37922.title;
var inst_37925 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$variadic(hnhit.popup.core.app_state,cljs.core.assoc,cljs.core.cst$kw$url,inst_37923,cljs.core.array_seq([cljs.core.cst$kw$title,inst_37924], 0));
var inst_37926 = hnhit.popup.core.build_search_term(inst_37923);
var inst_37927 = hnhit.popup.core.get_topics(inst_37926);
var state_37932__$1 = (function (){var statearr_37937 = state_37932;
(statearr_37937[(8)] = inst_37925);

return statearr_37937;
})();
var statearr_37938_37949 = state_37932__$1;
(statearr_37938_37949[(2)] = inst_37927);

(statearr_37938_37949[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_37933 === (4))){
var state_37932__$1 = state_37932;
var statearr_37939_37950 = state_37932__$1;
(statearr_37939_37950[(2)] = null);

(statearr_37939_37950[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_37933 === (5))){
var inst_37930 = (state_37932[(2)]);
var state_37932__$1 = state_37932;
return cljs.core.async.impl.ioc_helpers.return_chan(state_37932__$1,inst_37930);
} else {
return null;
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var hnhit$popup$core$search_tab_url_$_state_machine__15099__auto__ = null;
var hnhit$popup$core$search_tab_url_$_state_machine__15099__auto____0 = (function (){
var statearr_37943 = [null,null,null,null,null,null,null,null,null];
(statearr_37943[(0)] = hnhit$popup$core$search_tab_url_$_state_machine__15099__auto__);

(statearr_37943[(1)] = (1));

return statearr_37943;
});
var hnhit$popup$core$search_tab_url_$_state_machine__15099__auto____1 = (function (state_37932){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_37932);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e37944){if((e37944 instanceof Object)){
var ex__15102__auto__ = e37944;
var statearr_37945_37951 = state_37932;
(statearr_37945_37951[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_37932);

return cljs.core.cst$kw$recur;
} else {
throw e37944;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__37952 = state_37932;
state_37932 = G__37952;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
hnhit$popup$core$search_tab_url_$_state_machine__15099__auto__ = function(state_37932){
switch(arguments.length){
case 0:
return hnhit$popup$core$search_tab_url_$_state_machine__15099__auto____0.call(this);
case 1:
return hnhit$popup$core$search_tab_url_$_state_machine__15099__auto____1.call(this,state_37932);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
hnhit$popup$core$search_tab_url_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = hnhit$popup$core$search_tab_url_$_state_machine__15099__auto____0;
hnhit$popup$core$search_tab_url_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = hnhit$popup$core$search_tab_url_$_state_machine__15099__auto____1;
return hnhit$popup$core$search_tab_url_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_37946 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_37946[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_37946;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});
/**
 * Return the list of stories ordered by points desc
 */
hnhit.popup.core.stories = (function hnhit$popup$core$stories(){
return cljs.core.sort_by.cljs$core$IFn$_invoke$arity$3(cljs.core.cst$kw$points,cljs.core._GT_,cljs.core.filter.cljs$core$IFn$_invoke$arity$2(hnhit.popup.core.is_story_QMARK_,(cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(hnhit.popup.core.items_cursor) : cljs.core.deref.call(null,hnhit.popup.core.items_cursor))));
});
/**
 * Return the list of items that matched a comment, distinct by story id
 */
hnhit.popup.core.related_stories = (function hnhit$popup$core$related_stories(){
return cljs.core.map.cljs$core$IFn$_invoke$arity$2(cljs.core.first,cljs.core.vals(cljs.core.group_by(cljs.core.cst$kw$story_id,cljs.core.filter.cljs$core$IFn$_invoke$arity$2(hnhit.popup.core.is_comment_QMARK_,(cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(hnhit.popup.core.items_cursor) : cljs.core.deref.call(null,hnhit.popup.core.items_cursor))))));
});
hnhit.popup.core.main_cpt = (function hnhit$popup$core$main_cpt(){
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$size,"auto",cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [(cljs.core.truth_(hnhit.popup.core.error_QMARK_())?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.error_cpt,cljs.core.cst$kw$error.cljs$core$IFn$_invoke$arity$1((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(hnhit.popup.core.app_state) : cljs.core.deref.call(null,hnhit.popup.core.app_state)))], null):(cljs.core.truth_(hnhit.popup.core.loading_QMARK_())?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.loading_cpt], null):(cljs.core.truth_((hnhit.popup.core.no_results_QMARK_.cljs$core$IFn$_invoke$arity$0 ? hnhit.popup.core.no_results_QMARK_.cljs$core$IFn$_invoke$arity$0() : hnhit.popup.core.no_results_QMARK_.call(null)))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.blank_cpt,hnhit.popup.core.build_hn_submit_link()], null):new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.hn_cpt,hnhit.popup.core.stories(),hnhit.popup.core.related_stories()], null))))], null)], null);
});
hnhit.popup.core.frame_cpt = (function hnhit$popup$core$frame_cpt(){
return new cljs.core.PersistentVector(null, 13, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.scroller,cljs.core.cst$kw$v_DASH_scroll,cljs.core.cst$kw$auto,cljs.core.cst$kw$height,"600px",cljs.core.cst$kw$width,"600px",cljs.core.cst$kw$padding,"10px",cljs.core.cst$kw$style,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$background_DASH_color,"#f6f6ef"], null),cljs.core.cst$kw$child,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.core.main_cpt], null)], null);
});
hnhit.popup.core.mountit = (function hnhit$popup$core$mountit(){
return reagent.core.render.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.core.frame_cpt], null),(goog.dom.query("#main")[(0)]));
});
hnhit.popup.core.init_BANG_ = (function hnhit$popup$core$init_BANG_(){
hnhit.popup.core.mountit();

if(cljs.core.truth_((hnhit.popup.core.no_results_QMARK_.cljs$core$IFn$_invoke$arity$0 ? hnhit.popup.core.no_results_QMARK_.cljs$core$IFn$_invoke$arity$0() : hnhit.popup.core.no_results_QMARK_.call(null)))){
return hnhit.popup.core.search_tab_url();
} else {
return null;
}
});

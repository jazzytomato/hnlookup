// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('hnhit.popup.components');
goog.require('cljs.core');
goog.require('chromex.logging');
goog.require('chromex.ext.tabs');
goog.require('re_com.core');
/**
 * Open the [url] in a non active tab
 */
hnhit.popup.components.open_passive_tab = (function hnhit$popup$components$open_passive_tab(url){
return chromex.ext.tabs.create_STAR_(chromex.config.get_active_config(),({"url": url, "active": false}));
});
/**
 * Open all [urls] in new passive tabs
 */
hnhit.popup.components.open_all_tabs = (function hnhit$popup$components$open_all_tabs(urls){
var seq__37764 = cljs.core.seq(urls);
var chunk__37765 = null;
var count__37766 = (0);
var i__37767 = (0);
while(true){
if((i__37767 < count__37766)){
var url = chunk__37765.cljs$core$IIndexed$_nth$arity$2(null,i__37767);
hnhit.popup.components.open_passive_tab(url);

var G__37768 = seq__37764;
var G__37769 = chunk__37765;
var G__37770 = count__37766;
var G__37771 = (i__37767 + (1));
seq__37764 = G__37768;
chunk__37765 = G__37769;
count__37766 = G__37770;
i__37767 = G__37771;
continue;
} else {
var temp__6728__auto__ = cljs.core.seq(seq__37764);
if(temp__6728__auto__){
var seq__37764__$1 = temp__6728__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__37764__$1)){
var c__7842__auto__ = cljs.core.chunk_first(seq__37764__$1);
var G__37772 = cljs.core.chunk_rest(seq__37764__$1);
var G__37773 = c__7842__auto__;
var G__37774 = cljs.core.count(c__7842__auto__);
var G__37775 = (0);
seq__37764 = G__37772;
chunk__37765 = G__37773;
count__37766 = G__37774;
i__37767 = G__37775;
continue;
} else {
var url = cljs.core.first(seq__37764__$1);
hnhit.popup.components.open_passive_tab(url);

var G__37776 = cljs.core.next(seq__37764__$1);
var G__37777 = null;
var G__37778 = (0);
var G__37779 = (0);
seq__37764 = G__37776;
chunk__37765 = G__37777;
count__37766 = G__37778;
i__37767 = G__37779;
continue;
}
} else {
return null;
}
}
break;
}
});
hnhit.popup.components.tab_link_cpt = (function hnhit$popup$components$tab_link_cpt(url,text){
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.hyperlink,cljs.core.cst$kw$label,text,cljs.core.cst$kw$on_DASH_click,(function (){
return hnhit.popup.components.open_passive_tab(url);
})], null);
});
hnhit.popup.components.story_cpt = (function hnhit$popup$components$story_cpt(item){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.tab_link_cpt,cljs.core.cst$kw$hn_DASH_url.cljs$core$IFn$_invoke$arity$1(item),cljs.core.cst$kw$title.cljs$core$IFn$_invoke$arity$1(item)], null),new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.h_box,cljs.core.cst$kw$style,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$font_DASH_size,"0.8em"], null),cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [[cljs.core.str(cljs.core.cst$kw$points.cljs$core$IFn$_invoke$arity$1(item)),cljs.core.str(" points. "),cljs.core.str(cljs.core.cst$kw$num_comments.cljs$core$IFn$_invoke$arity$1(item)),cljs.core.str(" comments")].join('')], null)], null)], null)], null);
});
hnhit.popup.components.comment_cpt = (function hnhit$popup$components$comment_cpt(item){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.tab_link_cpt,cljs.core.cst$kw$hn_DASH_url.cljs$core$IFn$_invoke$arity$1(item),cljs.core.cst$kw$story_title.cljs$core$IFn$_invoke$arity$1(item)], null);
});
hnhit.popup.components.title_open_tab_cpt = (function hnhit$popup$components$title_open_tab_cpt(label,items){
return new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.title,cljs.core.cst$kw$label,new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.h_box,cljs.core.cst$kw$gap,"10px",cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [label,new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.md_icon_button,cljs.core.cst$kw$md_DASH_icon_DASH_name,"zmdi-open-in-new",cljs.core.cst$kw$tooltip,"Open all stories in new tabs",cljs.core.cst$kw$on_DASH_click,(function (){
return hnhit.popup.components.open_all_tabs(cljs.core.map.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$hn_DASH_url,items));
})], null)], null)], null),cljs.core.cst$kw$level,cljs.core.cst$kw$level2,cljs.core.cst$kw$underline_QMARK_,true], null);
});
hnhit.popup.components.stories_cpt = (function hnhit$popup$components$stories_cpt(items){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.title_open_tab_cpt,"Stories",items], null),new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$gap,"5px",cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [(function (){var iter__7793__auto__ = (function hnhit$popup$components$stories_cpt_$_iter__37786(s__37787){
return (new cljs.core.LazySeq(null,(function (){
var s__37787__$1 = s__37787;
while(true){
var temp__6728__auto__ = cljs.core.seq(s__37787__$1);
if(temp__6728__auto__){
var s__37787__$2 = temp__6728__auto__;
if(cljs.core.chunked_seq_QMARK_(s__37787__$2)){
var c__7791__auto__ = cljs.core.chunk_first(s__37787__$2);
var size__7792__auto__ = cljs.core.count(c__7791__auto__);
var b__37789 = cljs.core.chunk_buffer(size__7792__auto__);
if((function (){var i__37788 = (0);
while(true){
if((i__37788 < size__7792__auto__)){
var i = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(c__7791__auto__,i__37788);
cljs.core.chunk_append(b__37789,cljs.core.with_meta(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.story_cpt,i], null),new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$key,i], null)));

var G__37792 = (i__37788 + (1));
i__37788 = G__37792;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__37789),hnhit$popup$components$stories_cpt_$_iter__37786(cljs.core.chunk_rest(s__37787__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__37789),null);
}
} else {
var i = cljs.core.first(s__37787__$2);
return cljs.core.cons(cljs.core.with_meta(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.story_cpt,i], null),new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$key,i], null)),hnhit$popup$components$stories_cpt_$_iter__37786(cljs.core.rest(s__37787__$2)));
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__7793__auto__(items);
})()], null)], null)], null)], null);
});
hnhit.popup.components.related_stories_cpt = (function hnhit$popup$components$related_stories_cpt(items){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.title_open_tab_cpt,"Related",items], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [(function (){var iter__7793__auto__ = (function hnhit$popup$components$related_stories_cpt_$_iter__37799(s__37800){
return (new cljs.core.LazySeq(null,(function (){
var s__37800__$1 = s__37800;
while(true){
var temp__6728__auto__ = cljs.core.seq(s__37800__$1);
if(temp__6728__auto__){
var s__37800__$2 = temp__6728__auto__;
if(cljs.core.chunked_seq_QMARK_(s__37800__$2)){
var c__7791__auto__ = cljs.core.chunk_first(s__37800__$2);
var size__7792__auto__ = cljs.core.count(c__7791__auto__);
var b__37802 = cljs.core.chunk_buffer(size__7792__auto__);
if((function (){var i__37801 = (0);
while(true){
if((i__37801 < size__7792__auto__)){
var i = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(c__7791__auto__,i__37801);
cljs.core.chunk_append(b__37802,cljs.core.with_meta(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.comment_cpt,i], null),new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$key,i], null)));

var G__37805 = (i__37801 + (1));
i__37801 = G__37805;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__37802),hnhit$popup$components$related_stories_cpt_$_iter__37799(cljs.core.chunk_rest(s__37800__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__37802),null);
}
} else {
var i = cljs.core.first(s__37800__$2);
return cljs.core.cons(cljs.core.with_meta(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.comment_cpt,i], null),new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$key,i], null)),hnhit$popup$components$related_stories_cpt_$_iter__37799(cljs.core.rest(s__37800__$2)));
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__7793__auto__(items);
})()], null)], null)], null)], null);
});
hnhit.popup.components.loading_cpt = (function hnhit$popup$components$loading_cpt(){
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.box,cljs.core.cst$kw$align,cljs.core.cst$kw$center,cljs.core.cst$kw$child,new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.throbber,cljs.core.cst$kw$color,"#ff6600",cljs.core.cst$kw$size,cljs.core.cst$kw$large], null)], null);
});
hnhit.popup.components.blank_cpt = (function hnhit$popup$components$blank_cpt(submit_link){
return new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$align,cljs.core.cst$kw$center,cljs.core.cst$kw$gap,"10px",cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.md_icon_button,cljs.core.cst$kw$md_DASH_icon_DASH_name,"zmdi-help-outline"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.tab_link_cpt,submit_link,"No match found. Click to start the discussion!"], null)], null)], null);
});
hnhit.popup.components.error_cpt = (function hnhit$popup$components$error_cpt(http_code){
return new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$align,cljs.core.cst$kw$center,cljs.core.cst$kw$gap,"10px",cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.md_icon_button,cljs.core.cst$kw$md_DASH_icon_DASH_name,"zmdi-alert-polygon"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.label,cljs.core.cst$kw$label,[cljs.core.str("Sorry, an error occured. (http code "),cljs.core.str(http_code),cljs.core.str(")")].join('')], null)], null)], null);
});
hnhit.popup.components.hn_cpt = (function hnhit$popup$components$hn_cpt(stories,related_stories){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.stories_cpt,stories], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hnhit.popup.components.related_stories_cpt,related_stories], null)], null)], null);
});

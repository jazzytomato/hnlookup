// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var args28401 = [];
var len__8118__auto___28407 = arguments.length;
var i__8119__auto___28408 = (0);
while(true){
if((i__8119__auto___28408 < len__8118__auto___28407)){
args28401.push((arguments[i__8119__auto___28408]));

var G__28409 = (i__8119__auto___28408 + (1));
i__8119__auto___28408 = G__28409;
continue;
} else {
}
break;
}

var G__28403 = args28401.length;
switch (G__28403) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28401.length)].join('')));

}
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(f,true);
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if(typeof cljs.core.async.t_cljs$core$async28404 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async28404 = (function (f,blockable,meta28405){
this.f = f;
this.blockable = blockable;
this.meta28405 = meta28405;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async28404.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_28406,meta28405__$1){
var self__ = this;
var _28406__$1 = this;
return (new cljs.core.async.t_cljs$core$async28404(self__.f,self__.blockable,meta28405__$1));
});

cljs.core.async.t_cljs$core$async28404.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_28406){
var self__ = this;
var _28406__$1 = this;
return self__.meta28405;
});

cljs.core.async.t_cljs$core$async28404.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async28404.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async28404.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
});

cljs.core.async.t_cljs$core$async28404.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
});

cljs.core.async.t_cljs$core$async28404.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$blockable,cljs.core.cst$sym$meta28405], null);
});

cljs.core.async.t_cljs$core$async28404.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async28404.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async28404";

cljs.core.async.t_cljs$core$async28404.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async28404");
});

cljs.core.async.__GT_t_cljs$core$async28404 = (function cljs$core$async$__GT_t_cljs$core$async28404(f__$1,blockable__$1,meta28405){
return (new cljs.core.async.t_cljs$core$async28404(f__$1,blockable__$1,meta28405));
});

}

return (new cljs.core.async.t_cljs$core$async28404(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
});

cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2;

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer(n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if(!((buff == null))){
if((false) || (buff.cljs$core$async$impl$protocols$UnblockingBuffer$)){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var args28413 = [];
var len__8118__auto___28416 = arguments.length;
var i__8119__auto___28417 = (0);
while(true){
if((i__8119__auto___28417 < len__8118__auto___28416)){
args28413.push((arguments[i__8119__auto___28417]));

var G__28418 = (i__8119__auto___28417 + (1));
i__8119__auto___28417 = G__28418;
continue;
} else {
}
break;
}

var G__28415 = args28413.length;
switch (G__28415) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28413.length)].join('')));

}
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,xform,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
} else {
}

return cljs.core.async.impl.channels.chan.cljs$core$IFn$_invoke$arity$3(((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer(buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
});

cljs.core.async.chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var args28420 = [];
var len__8118__auto___28423 = arguments.length;
var i__8119__auto___28424 = (0);
while(true){
if((i__8119__auto___28424 < len__8118__auto___28423)){
args28420.push((arguments[i__8119__auto___28424]));

var G__28425 = (i__8119__auto___28424 + (1));
i__8119__auto___28424 = G__28425;
continue;
} else {
}
break;
}

var G__28422 = args28420.length;
switch (G__28422) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28420.length)].join('')));

}
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2(xform,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(cljs.core.async.impl.buffers.promise_buffer(),xform,ex_handler);
});

cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout(msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var args28427 = [];
var len__8118__auto___28430 = arguments.length;
var i__8119__auto___28431 = (0);
while(true){
if((i__8119__auto___28431 < len__8118__auto___28430)){
args28427.push((arguments[i__8119__auto___28431]));

var G__28432 = (i__8119__auto___28431 + (1));
i__8119__auto___28431 = G__28432;
continue;
} else {
}
break;
}

var G__28429 = args28427.length;
switch (G__28429) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28427.length)].join('')));

}
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3(port,fn1,true);
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(ret)){
var val_28434 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret));
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_28434) : fn1.call(null,val_28434));
} else {
cljs.core.async.impl.dispatch.run(((function (val_28434,ret){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_28434) : fn1.call(null,val_28434));
});})(val_28434,ret))
);
}
} else {
}

return null;
});

cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3;

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn0 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn0 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var args28435 = [];
var len__8118__auto___28438 = arguments.length;
var i__8119__auto___28439 = (0);
while(true){
if((i__8119__auto___28439 < len__8118__auto___28438)){
args28435.push((arguments[i__8119__auto___28439]));

var G__28440 = (i__8119__auto___28439 + (1));
i__8119__auto___28439 = G__28440;
continue;
} else {
}
break;
}

var G__28437 = args28435.length;
switch (G__28437) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28435.length)].join('')));

}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__6726__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__6726__auto__)){
var ret = temp__6726__auto__;
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret));
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4(port,val,fn1,true);
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__6726__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(temp__6726__auto__)){
var retb = temp__6726__auto__;
var ret = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(retb) : cljs.core.deref.call(null,retb));
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
} else {
cljs.core.async.impl.dispatch.run(((function (ret,retb,temp__6726__auto__){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
});})(ret,retb,temp__6726__auto__))
);
}

return ret;
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4;

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_(port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__7952__auto___28442 = n;
var x_28443 = (0);
while(true){
if((x_28443 < n__7952__auto___28442)){
(a[x_28443] = (0));

var G__28444 = (x_28443 + (1));
x_28443 = G__28444;
continue;
} else {
}
break;
}

var i = (1);
while(true){
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(i,n)){
return a;
} else {
var j = cljs.core.rand_int(i);
(a[i] = (a[j]));

(a[j] = i);

var G__28445 = (i + (1));
i = G__28445;
continue;
}
break;
}
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(true) : cljs.core.atom.call(null,true));
if(typeof cljs.core.async.t_cljs$core$async28449 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async28449 = (function (alt_flag,flag,meta28450){
this.alt_flag = alt_flag;
this.flag = flag;
this.meta28450 = meta28450;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async28449.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (flag){
return (function (_28451,meta28450__$1){
var self__ = this;
var _28451__$1 = this;
return (new cljs.core.async.t_cljs$core$async28449(self__.alt_flag,self__.flag,meta28450__$1));
});})(flag))
;

cljs.core.async.t_cljs$core$async28449.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (flag){
return (function (_28451){
var self__ = this;
var _28451__$1 = this;
return self__.meta28450;
});})(flag))
;

cljs.core.async.t_cljs$core$async28449.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async28449.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(self__.flag) : cljs.core.deref.call(null,self__.flag));
});})(flag))
;

cljs.core.async.t_cljs$core$async28449.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async28449.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(self__.flag,null) : cljs.core.reset_BANG_.call(null,self__.flag,null));

return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async28449.getBasis = ((function (flag){
return (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$alt_DASH_flag,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$private,true,cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(cljs.core.PersistentVector.EMPTY))], null)),cljs.core.cst$sym$flag,cljs.core.cst$sym$meta28450], null);
});})(flag))
;

cljs.core.async.t_cljs$core$async28449.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async28449.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async28449";

cljs.core.async.t_cljs$core$async28449.cljs$lang$ctorPrWriter = ((function (flag){
return (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async28449");
});})(flag))
;

cljs.core.async.__GT_t_cljs$core$async28449 = ((function (flag){
return (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async28449(alt_flag__$1,flag__$1,meta28450){
return (new cljs.core.async.t_cljs$core$async28449(alt_flag__$1,flag__$1,meta28450));
});})(flag))
;

}

return (new cljs.core.async.t_cljs$core$async28449(cljs$core$async$alt_flag,flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if(typeof cljs.core.async.t_cljs$core$async28455 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async28455 = (function (alt_handler,flag,cb,meta28456){
this.alt_handler = alt_handler;
this.flag = flag;
this.cb = cb;
this.meta28456 = meta28456;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async28455.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_28457,meta28456__$1){
var self__ = this;
var _28457__$1 = this;
return (new cljs.core.async.t_cljs$core$async28455(self__.alt_handler,self__.flag,self__.cb,meta28456__$1));
});

cljs.core.async.t_cljs$core$async28455.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_28457){
var self__ = this;
var _28457__$1 = this;
return self__.meta28456;
});

cljs.core.async.t_cljs$core$async28455.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async28455.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.flag);
});

cljs.core.async.t_cljs$core$async28455.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async28455.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit(self__.flag);

return self__.cb;
});

cljs.core.async.t_cljs$core$async28455.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$alt_DASH_handler,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$private,true,cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$cb], null)))], null)),cljs.core.cst$sym$flag,cljs.core.cst$sym$cb,cljs.core.cst$sym$meta28456], null);
});

cljs.core.async.t_cljs$core$async28455.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async28455.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async28455";

cljs.core.async.t_cljs$core$async28455.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async28455");
});

cljs.core.async.__GT_t_cljs$core$async28455 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async28455(alt_handler__$1,flag__$1,cb__$1,meta28456){
return (new cljs.core.async.t_cljs$core$async28455(alt_handler__$1,flag__$1,cb__$1,meta28456));
});

}

return (new cljs.core.async.t_cljs$core$async28455(cljs$core$async$alt_handler,flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){
var flag = cljs.core.async.alt_flag();
var n = cljs.core.count(ports);
var idxs = cljs.core.async.random_array(n);
var priority = cljs.core.cst$kw$priority.cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ports,idx);
var wport = ((cljs.core.vector_QMARK_(port))?(port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((0)) : port.call(null,(0))):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = (port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((1)) : port.call(null,(1)));
return cljs.core.async.impl.protocols.put_BANG_(wport,val,cljs.core.async.alt_handler(flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__28458_SHARP_){
var G__28462 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__28458_SHARP_,wport], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__28462) : fret.call(null,G__28462));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.alt_handler(flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__28459_SHARP_){
var G__28463 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__28459_SHARP_,port], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__28463) : fret.call(null,G__28463));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(vbox) : cljs.core.deref.call(null,vbox)),(function (){var or__6939__auto__ = wport;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return port;
}
})()], null));
} else {
var G__28464 = (i + (1));
i = G__28464;
continue;
}
} else {
return null;
}
break;
}
})();
var or__6939__auto__ = ret;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
if(cljs.core.contains_QMARK_(opts,cljs.core.cst$kw$default)){
var temp__6728__auto__ = (function (){var and__6927__auto__ = cljs.core.async.impl.protocols.active_QMARK_(flag);
if(cljs.core.truth_(and__6927__auto__)){
return cljs.core.async.impl.protocols.commit(flag);
} else {
return and__6927__auto__;
}
})();
if(cljs.core.truth_(temp__6728__auto__)){
var got = temp__6728__auto__;
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$default.cljs$core$IFn$_invoke$arity$1(opts),cljs.core.cst$kw$default], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___28470 = arguments.length;
var i__8119__auto___28471 = (0);
while(true){
if((i__8119__auto___28471 < len__8118__auto___28470)){
args__8125__auto__.push((arguments[i__8119__auto___28471]));

var G__28472 = (i__8119__auto___28471 + (1));
i__8119__auto___28471 = G__28472;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__28467){
var map__28468 = p__28467;
var map__28468__$1 = ((((!((map__28468 == null)))?((((map__28468.cljs$lang$protocol_mask$partition0$ & (64))) || (map__28468.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__28468):map__28468);
var opts = map__28468__$1;
throw (new Error("alts! used not in (go ...) block"));
});

cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1);

cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq28465){
var G__28466 = cljs.core.first(seq28465);
var seq28465__$1 = cljs.core.next(seq28465);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__28466,seq28465__$1);
});

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret));
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret));
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var args28473 = [];
var len__8118__auto___28523 = arguments.length;
var i__8119__auto___28524 = (0);
while(true){
if((i__8119__auto___28524 < len__8118__auto___28523)){
args28473.push((arguments[i__8119__auto___28524]));

var G__28525 = (i__8119__auto___28524 + (1));
i__8119__auto___28524 = G__28525;
continue;
} else {
}
break;
}

var G__28475 = args28473.length;
switch (G__28475) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28473.length)].join('')));

}
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3(from,to,true);
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__15224__auto___28527 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___28527){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___28527){
return (function (state_28499){
var state_val_28500 = (state_28499[(1)]);
if((state_val_28500 === (7))){
var inst_28495 = (state_28499[(2)]);
var state_28499__$1 = state_28499;
var statearr_28501_28528 = state_28499__$1;
(statearr_28501_28528[(2)] = inst_28495);

(statearr_28501_28528[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28500 === (1))){
var state_28499__$1 = state_28499;
var statearr_28502_28529 = state_28499__$1;
(statearr_28502_28529[(2)] = null);

(statearr_28502_28529[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28500 === (4))){
var inst_28478 = (state_28499[(7)]);
var inst_28478__$1 = (state_28499[(2)]);
var inst_28479 = (inst_28478__$1 == null);
var state_28499__$1 = (function (){var statearr_28503 = state_28499;
(statearr_28503[(7)] = inst_28478__$1);

return statearr_28503;
})();
if(cljs.core.truth_(inst_28479)){
var statearr_28504_28530 = state_28499__$1;
(statearr_28504_28530[(1)] = (5));

} else {
var statearr_28505_28531 = state_28499__$1;
(statearr_28505_28531[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28500 === (13))){
var state_28499__$1 = state_28499;
var statearr_28506_28532 = state_28499__$1;
(statearr_28506_28532[(2)] = null);

(statearr_28506_28532[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28500 === (6))){
var inst_28478 = (state_28499[(7)]);
var state_28499__$1 = state_28499;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28499__$1,(11),to,inst_28478);
} else {
if((state_val_28500 === (3))){
var inst_28497 = (state_28499[(2)]);
var state_28499__$1 = state_28499;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28499__$1,inst_28497);
} else {
if((state_val_28500 === (12))){
var state_28499__$1 = state_28499;
var statearr_28507_28533 = state_28499__$1;
(statearr_28507_28533[(2)] = null);

(statearr_28507_28533[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28500 === (2))){
var state_28499__$1 = state_28499;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28499__$1,(4),from);
} else {
if((state_val_28500 === (11))){
var inst_28488 = (state_28499[(2)]);
var state_28499__$1 = state_28499;
if(cljs.core.truth_(inst_28488)){
var statearr_28508_28534 = state_28499__$1;
(statearr_28508_28534[(1)] = (12));

} else {
var statearr_28509_28535 = state_28499__$1;
(statearr_28509_28535[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28500 === (9))){
var state_28499__$1 = state_28499;
var statearr_28510_28536 = state_28499__$1;
(statearr_28510_28536[(2)] = null);

(statearr_28510_28536[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28500 === (5))){
var state_28499__$1 = state_28499;
if(cljs.core.truth_(close_QMARK_)){
var statearr_28511_28537 = state_28499__$1;
(statearr_28511_28537[(1)] = (8));

} else {
var statearr_28512_28538 = state_28499__$1;
(statearr_28512_28538[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28500 === (14))){
var inst_28493 = (state_28499[(2)]);
var state_28499__$1 = state_28499;
var statearr_28513_28539 = state_28499__$1;
(statearr_28513_28539[(2)] = inst_28493);

(statearr_28513_28539[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28500 === (10))){
var inst_28485 = (state_28499[(2)]);
var state_28499__$1 = state_28499;
var statearr_28514_28540 = state_28499__$1;
(statearr_28514_28540[(2)] = inst_28485);

(statearr_28514_28540[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28500 === (8))){
var inst_28482 = cljs.core.async.close_BANG_(to);
var state_28499__$1 = state_28499;
var statearr_28515_28541 = state_28499__$1;
(statearr_28515_28541[(2)] = inst_28482);

(statearr_28515_28541[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___28527))
;
return ((function (switch__15098__auto__,c__15224__auto___28527){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_28519 = [null,null,null,null,null,null,null,null];
(statearr_28519[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_28519[(1)] = (1));

return statearr_28519;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_28499){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_28499);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e28520){if((e28520 instanceof Object)){
var ex__15102__auto__ = e28520;
var statearr_28521_28542 = state_28499;
(statearr_28521_28542[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28499);

return cljs.core.cst$kw$recur;
} else {
throw e28520;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__28543 = state_28499;
state_28499 = G__28543;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_28499){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_28499);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___28527))
})();
var state__15226__auto__ = (function (){var statearr_28522 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_28522[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___28527);

return statearr_28522;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___28527))
);


return to;
});

cljs.core.async.pipe.cljs$lang$maxFixedArity = 3;

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){

var jobs = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var results = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var process = ((function (jobs,results){
return (function (p__28731){
var vec__28732 = p__28731;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28732,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28732,(1),null);
var job = vec__28732;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((1),xf,ex_handler);
var c__15224__auto___28918 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___28918,res,vec__28732,v,p,job,jobs,results){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___28918,res,vec__28732,v,p,job,jobs,results){
return (function (state_28739){
var state_val_28740 = (state_28739[(1)]);
if((state_val_28740 === (1))){
var state_28739__$1 = state_28739;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28739__$1,(2),res,v);
} else {
if((state_val_28740 === (2))){
var inst_28736 = (state_28739[(2)]);
var inst_28737 = cljs.core.async.close_BANG_(res);
var state_28739__$1 = (function (){var statearr_28741 = state_28739;
(statearr_28741[(7)] = inst_28736);

return statearr_28741;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_28739__$1,inst_28737);
} else {
return null;
}
}
});})(c__15224__auto___28918,res,vec__28732,v,p,job,jobs,results))
;
return ((function (switch__15098__auto__,c__15224__auto___28918,res,vec__28732,v,p,job,jobs,results){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_28745 = [null,null,null,null,null,null,null,null];
(statearr_28745[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__);

(statearr_28745[(1)] = (1));

return statearr_28745;
});
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1 = (function (state_28739){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_28739);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e28746){if((e28746 instanceof Object)){
var ex__15102__auto__ = e28746;
var statearr_28747_28919 = state_28739;
(statearr_28747_28919[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28739);

return cljs.core.cst$kw$recur;
} else {
throw e28746;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__28920 = state_28739;
state_28739 = G__28920;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = function(state_28739){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1.call(this,state_28739);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___28918,res,vec__28732,v,p,job,jobs,results))
})();
var state__15226__auto__ = (function (){var statearr_28748 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_28748[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___28918);

return statearr_28748;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___28918,res,vec__28732,v,p,job,jobs,results))
);


cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results))
;
var async = ((function (jobs,results,process){
return (function (p__28749){
var vec__28750 = p__28749;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28750,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28750,(1),null);
var job = vec__28750;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
(xf.cljs$core$IFn$_invoke$arity$2 ? xf.cljs$core$IFn$_invoke$arity$2(v,res) : xf.call(null,v,res));

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results,process))
;
var n__7952__auto___28921 = n;
var __28922 = (0);
while(true){
if((__28922 < n__7952__auto___28921)){
var G__28753_28923 = (((type instanceof cljs.core.Keyword))?type.fqn:null);
switch (G__28753_28923) {
case "compute":
var c__15224__auto___28925 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__28922,c__15224__auto___28925,G__28753_28923,n__7952__auto___28921,jobs,results,process,async){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (__28922,c__15224__auto___28925,G__28753_28923,n__7952__auto___28921,jobs,results,process,async){
return (function (state_28766){
var state_val_28767 = (state_28766[(1)]);
if((state_val_28767 === (1))){
var state_28766__$1 = state_28766;
var statearr_28768_28926 = state_28766__$1;
(statearr_28768_28926[(2)] = null);

(statearr_28768_28926[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28767 === (2))){
var state_28766__$1 = state_28766;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28766__$1,(4),jobs);
} else {
if((state_val_28767 === (3))){
var inst_28764 = (state_28766[(2)]);
var state_28766__$1 = state_28766;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28766__$1,inst_28764);
} else {
if((state_val_28767 === (4))){
var inst_28756 = (state_28766[(2)]);
var inst_28757 = process(inst_28756);
var state_28766__$1 = state_28766;
if(cljs.core.truth_(inst_28757)){
var statearr_28769_28927 = state_28766__$1;
(statearr_28769_28927[(1)] = (5));

} else {
var statearr_28770_28928 = state_28766__$1;
(statearr_28770_28928[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28767 === (5))){
var state_28766__$1 = state_28766;
var statearr_28771_28929 = state_28766__$1;
(statearr_28771_28929[(2)] = null);

(statearr_28771_28929[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28767 === (6))){
var state_28766__$1 = state_28766;
var statearr_28772_28930 = state_28766__$1;
(statearr_28772_28930[(2)] = null);

(statearr_28772_28930[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28767 === (7))){
var inst_28762 = (state_28766[(2)]);
var state_28766__$1 = state_28766;
var statearr_28773_28931 = state_28766__$1;
(statearr_28773_28931[(2)] = inst_28762);

(statearr_28773_28931[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__28922,c__15224__auto___28925,G__28753_28923,n__7952__auto___28921,jobs,results,process,async))
;
return ((function (__28922,switch__15098__auto__,c__15224__auto___28925,G__28753_28923,n__7952__auto___28921,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_28777 = [null,null,null,null,null,null,null];
(statearr_28777[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__);

(statearr_28777[(1)] = (1));

return statearr_28777;
});
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1 = (function (state_28766){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_28766);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e28778){if((e28778 instanceof Object)){
var ex__15102__auto__ = e28778;
var statearr_28779_28932 = state_28766;
(statearr_28779_28932[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28766);

return cljs.core.cst$kw$recur;
} else {
throw e28778;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__28933 = state_28766;
state_28766 = G__28933;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = function(state_28766){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1.call(this,state_28766);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__;
})()
;})(__28922,switch__15098__auto__,c__15224__auto___28925,G__28753_28923,n__7952__auto___28921,jobs,results,process,async))
})();
var state__15226__auto__ = (function (){var statearr_28780 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_28780[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___28925);

return statearr_28780;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(__28922,c__15224__auto___28925,G__28753_28923,n__7952__auto___28921,jobs,results,process,async))
);


break;
case "async":
var c__15224__auto___28934 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__28922,c__15224__auto___28934,G__28753_28923,n__7952__auto___28921,jobs,results,process,async){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (__28922,c__15224__auto___28934,G__28753_28923,n__7952__auto___28921,jobs,results,process,async){
return (function (state_28793){
var state_val_28794 = (state_28793[(1)]);
if((state_val_28794 === (1))){
var state_28793__$1 = state_28793;
var statearr_28795_28935 = state_28793__$1;
(statearr_28795_28935[(2)] = null);

(statearr_28795_28935[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28794 === (2))){
var state_28793__$1 = state_28793;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28793__$1,(4),jobs);
} else {
if((state_val_28794 === (3))){
var inst_28791 = (state_28793[(2)]);
var state_28793__$1 = state_28793;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28793__$1,inst_28791);
} else {
if((state_val_28794 === (4))){
var inst_28783 = (state_28793[(2)]);
var inst_28784 = async(inst_28783);
var state_28793__$1 = state_28793;
if(cljs.core.truth_(inst_28784)){
var statearr_28796_28936 = state_28793__$1;
(statearr_28796_28936[(1)] = (5));

} else {
var statearr_28797_28937 = state_28793__$1;
(statearr_28797_28937[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28794 === (5))){
var state_28793__$1 = state_28793;
var statearr_28798_28938 = state_28793__$1;
(statearr_28798_28938[(2)] = null);

(statearr_28798_28938[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28794 === (6))){
var state_28793__$1 = state_28793;
var statearr_28799_28939 = state_28793__$1;
(statearr_28799_28939[(2)] = null);

(statearr_28799_28939[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28794 === (7))){
var inst_28789 = (state_28793[(2)]);
var state_28793__$1 = state_28793;
var statearr_28800_28940 = state_28793__$1;
(statearr_28800_28940[(2)] = inst_28789);

(statearr_28800_28940[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__28922,c__15224__auto___28934,G__28753_28923,n__7952__auto___28921,jobs,results,process,async))
;
return ((function (__28922,switch__15098__auto__,c__15224__auto___28934,G__28753_28923,n__7952__auto___28921,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_28804 = [null,null,null,null,null,null,null];
(statearr_28804[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__);

(statearr_28804[(1)] = (1));

return statearr_28804;
});
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1 = (function (state_28793){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_28793);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e28805){if((e28805 instanceof Object)){
var ex__15102__auto__ = e28805;
var statearr_28806_28941 = state_28793;
(statearr_28806_28941[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28793);

return cljs.core.cst$kw$recur;
} else {
throw e28805;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__28942 = state_28793;
state_28793 = G__28942;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = function(state_28793){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1.call(this,state_28793);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__;
})()
;})(__28922,switch__15098__auto__,c__15224__auto___28934,G__28753_28923,n__7952__auto___28921,jobs,results,process,async))
})();
var state__15226__auto__ = (function (){var statearr_28807 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_28807[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___28934);

return statearr_28807;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(__28922,c__15224__auto___28934,G__28753_28923,n__7952__auto___28921,jobs,results,process,async))
);


break;
default:
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(type)].join('')));

}

var G__28943 = (__28922 + (1));
__28922 = G__28943;
continue;
} else {
}
break;
}

var c__15224__auto___28944 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___28944,jobs,results,process,async){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___28944,jobs,results,process,async){
return (function (state_28829){
var state_val_28830 = (state_28829[(1)]);
if((state_val_28830 === (1))){
var state_28829__$1 = state_28829;
var statearr_28831_28945 = state_28829__$1;
(statearr_28831_28945[(2)] = null);

(statearr_28831_28945[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28830 === (2))){
var state_28829__$1 = state_28829;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28829__$1,(4),from);
} else {
if((state_val_28830 === (3))){
var inst_28827 = (state_28829[(2)]);
var state_28829__$1 = state_28829;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28829__$1,inst_28827);
} else {
if((state_val_28830 === (4))){
var inst_28810 = (state_28829[(7)]);
var inst_28810__$1 = (state_28829[(2)]);
var inst_28811 = (inst_28810__$1 == null);
var state_28829__$1 = (function (){var statearr_28832 = state_28829;
(statearr_28832[(7)] = inst_28810__$1);

return statearr_28832;
})();
if(cljs.core.truth_(inst_28811)){
var statearr_28833_28946 = state_28829__$1;
(statearr_28833_28946[(1)] = (5));

} else {
var statearr_28834_28947 = state_28829__$1;
(statearr_28834_28947[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28830 === (5))){
var inst_28813 = cljs.core.async.close_BANG_(jobs);
var state_28829__$1 = state_28829;
var statearr_28835_28948 = state_28829__$1;
(statearr_28835_28948[(2)] = inst_28813);

(statearr_28835_28948[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28830 === (6))){
var inst_28815 = (state_28829[(8)]);
var inst_28810 = (state_28829[(7)]);
var inst_28815__$1 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_28816 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_28817 = [inst_28810,inst_28815__$1];
var inst_28818 = (new cljs.core.PersistentVector(null,2,(5),inst_28816,inst_28817,null));
var state_28829__$1 = (function (){var statearr_28836 = state_28829;
(statearr_28836[(8)] = inst_28815__$1);

return statearr_28836;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28829__$1,(8),jobs,inst_28818);
} else {
if((state_val_28830 === (7))){
var inst_28825 = (state_28829[(2)]);
var state_28829__$1 = state_28829;
var statearr_28837_28949 = state_28829__$1;
(statearr_28837_28949[(2)] = inst_28825);

(statearr_28837_28949[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28830 === (8))){
var inst_28815 = (state_28829[(8)]);
var inst_28820 = (state_28829[(2)]);
var state_28829__$1 = (function (){var statearr_28838 = state_28829;
(statearr_28838[(9)] = inst_28820);

return statearr_28838;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28829__$1,(9),results,inst_28815);
} else {
if((state_val_28830 === (9))){
var inst_28822 = (state_28829[(2)]);
var state_28829__$1 = (function (){var statearr_28839 = state_28829;
(statearr_28839[(10)] = inst_28822);

return statearr_28839;
})();
var statearr_28840_28950 = state_28829__$1;
(statearr_28840_28950[(2)] = null);

(statearr_28840_28950[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___28944,jobs,results,process,async))
;
return ((function (switch__15098__auto__,c__15224__auto___28944,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_28844 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_28844[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__);

(statearr_28844[(1)] = (1));

return statearr_28844;
});
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1 = (function (state_28829){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_28829);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e28845){if((e28845 instanceof Object)){
var ex__15102__auto__ = e28845;
var statearr_28846_28951 = state_28829;
(statearr_28846_28951[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28829);

return cljs.core.cst$kw$recur;
} else {
throw e28845;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__28952 = state_28829;
state_28829 = G__28952;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = function(state_28829){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1.call(this,state_28829);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___28944,jobs,results,process,async))
})();
var state__15226__auto__ = (function (){var statearr_28847 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_28847[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___28944);

return statearr_28847;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___28944,jobs,results,process,async))
);


var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__,jobs,results,process,async){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__,jobs,results,process,async){
return (function (state_28885){
var state_val_28886 = (state_28885[(1)]);
if((state_val_28886 === (7))){
var inst_28881 = (state_28885[(2)]);
var state_28885__$1 = state_28885;
var statearr_28887_28953 = state_28885__$1;
(statearr_28887_28953[(2)] = inst_28881);

(statearr_28887_28953[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (20))){
var state_28885__$1 = state_28885;
var statearr_28888_28954 = state_28885__$1;
(statearr_28888_28954[(2)] = null);

(statearr_28888_28954[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (1))){
var state_28885__$1 = state_28885;
var statearr_28889_28955 = state_28885__$1;
(statearr_28889_28955[(2)] = null);

(statearr_28889_28955[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (4))){
var inst_28850 = (state_28885[(7)]);
var inst_28850__$1 = (state_28885[(2)]);
var inst_28851 = (inst_28850__$1 == null);
var state_28885__$1 = (function (){var statearr_28890 = state_28885;
(statearr_28890[(7)] = inst_28850__$1);

return statearr_28890;
})();
if(cljs.core.truth_(inst_28851)){
var statearr_28891_28956 = state_28885__$1;
(statearr_28891_28956[(1)] = (5));

} else {
var statearr_28892_28957 = state_28885__$1;
(statearr_28892_28957[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (15))){
var inst_28863 = (state_28885[(8)]);
var state_28885__$1 = state_28885;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_28885__$1,(18),to,inst_28863);
} else {
if((state_val_28886 === (21))){
var inst_28876 = (state_28885[(2)]);
var state_28885__$1 = state_28885;
var statearr_28893_28958 = state_28885__$1;
(statearr_28893_28958[(2)] = inst_28876);

(statearr_28893_28958[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (13))){
var inst_28878 = (state_28885[(2)]);
var state_28885__$1 = (function (){var statearr_28894 = state_28885;
(statearr_28894[(9)] = inst_28878);

return statearr_28894;
})();
var statearr_28895_28959 = state_28885__$1;
(statearr_28895_28959[(2)] = null);

(statearr_28895_28959[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (6))){
var inst_28850 = (state_28885[(7)]);
var state_28885__$1 = state_28885;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28885__$1,(11),inst_28850);
} else {
if((state_val_28886 === (17))){
var inst_28871 = (state_28885[(2)]);
var state_28885__$1 = state_28885;
if(cljs.core.truth_(inst_28871)){
var statearr_28896_28960 = state_28885__$1;
(statearr_28896_28960[(1)] = (19));

} else {
var statearr_28897_28961 = state_28885__$1;
(statearr_28897_28961[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (3))){
var inst_28883 = (state_28885[(2)]);
var state_28885__$1 = state_28885;
return cljs.core.async.impl.ioc_helpers.return_chan(state_28885__$1,inst_28883);
} else {
if((state_val_28886 === (12))){
var inst_28860 = (state_28885[(10)]);
var state_28885__$1 = state_28885;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28885__$1,(14),inst_28860);
} else {
if((state_val_28886 === (2))){
var state_28885__$1 = state_28885;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_28885__$1,(4),results);
} else {
if((state_val_28886 === (19))){
var state_28885__$1 = state_28885;
var statearr_28898_28962 = state_28885__$1;
(statearr_28898_28962[(2)] = null);

(statearr_28898_28962[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (11))){
var inst_28860 = (state_28885[(2)]);
var state_28885__$1 = (function (){var statearr_28899 = state_28885;
(statearr_28899[(10)] = inst_28860);

return statearr_28899;
})();
var statearr_28900_28963 = state_28885__$1;
(statearr_28900_28963[(2)] = null);

(statearr_28900_28963[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (9))){
var state_28885__$1 = state_28885;
var statearr_28901_28964 = state_28885__$1;
(statearr_28901_28964[(2)] = null);

(statearr_28901_28964[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (5))){
var state_28885__$1 = state_28885;
if(cljs.core.truth_(close_QMARK_)){
var statearr_28902_28965 = state_28885__$1;
(statearr_28902_28965[(1)] = (8));

} else {
var statearr_28903_28966 = state_28885__$1;
(statearr_28903_28966[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (14))){
var inst_28863 = (state_28885[(8)]);
var inst_28865 = (state_28885[(11)]);
var inst_28863__$1 = (state_28885[(2)]);
var inst_28864 = (inst_28863__$1 == null);
var inst_28865__$1 = cljs.core.not(inst_28864);
var state_28885__$1 = (function (){var statearr_28904 = state_28885;
(statearr_28904[(8)] = inst_28863__$1);

(statearr_28904[(11)] = inst_28865__$1);

return statearr_28904;
})();
if(inst_28865__$1){
var statearr_28905_28967 = state_28885__$1;
(statearr_28905_28967[(1)] = (15));

} else {
var statearr_28906_28968 = state_28885__$1;
(statearr_28906_28968[(1)] = (16));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (16))){
var inst_28865 = (state_28885[(11)]);
var state_28885__$1 = state_28885;
var statearr_28907_28969 = state_28885__$1;
(statearr_28907_28969[(2)] = inst_28865);

(statearr_28907_28969[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (10))){
var inst_28857 = (state_28885[(2)]);
var state_28885__$1 = state_28885;
var statearr_28908_28970 = state_28885__$1;
(statearr_28908_28970[(2)] = inst_28857);

(statearr_28908_28970[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (18))){
var inst_28868 = (state_28885[(2)]);
var state_28885__$1 = state_28885;
var statearr_28909_28971 = state_28885__$1;
(statearr_28909_28971[(2)] = inst_28868);

(statearr_28909_28971[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_28886 === (8))){
var inst_28854 = cljs.core.async.close_BANG_(to);
var state_28885__$1 = state_28885;
var statearr_28910_28972 = state_28885__$1;
(statearr_28910_28972[(2)] = inst_28854);

(statearr_28910_28972[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto__,jobs,results,process,async))
;
return ((function (switch__15098__auto__,c__15224__auto__,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_28914 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_28914[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__);

(statearr_28914[(1)] = (1));

return statearr_28914;
});
var cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1 = (function (state_28885){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_28885);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e28915){if((e28915 instanceof Object)){
var ex__15102__auto__ = e28915;
var statearr_28916_28973 = state_28885;
(statearr_28916_28973[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_28885);

return cljs.core.cst$kw$recur;
} else {
throw e28915;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__28974 = state_28885;
state_28885 = G__28974;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__ = function(state_28885){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1.call(this,state_28885);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__,jobs,results,process,async))
})();
var state__15226__auto__ = (function (){var statearr_28917 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_28917[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_28917;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__,jobs,results,process,async))
);

return c__15224__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var args28975 = [];
var len__8118__auto___28978 = arguments.length;
var i__8119__auto___28979 = (0);
while(true){
if((i__8119__auto___28979 < len__8118__auto___28978)){
args28975.push((arguments[i__8119__auto___28979]));

var G__28980 = (i__8119__auto___28979 + (1));
i__8119__auto___28979 = G__28980;
continue;
} else {
}
break;
}

var G__28977 = args28975.length;
switch (G__28977) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28975.length)].join('')));

}
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5(n,to,af,from,true);
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_(n,to,af,from,close_QMARK_,null,cljs.core.cst$kw$async);
});

cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5;

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var args28982 = [];
var len__8118__auto___28985 = arguments.length;
var i__8119__auto___28986 = (0);
while(true){
if((i__8119__auto___28986 < len__8118__auto___28985)){
args28982.push((arguments[i__8119__auto___28986]));

var G__28987 = (i__8119__auto___28986 + (1));
i__8119__auto___28986 = G__28987;
continue;
} else {
}
break;
}

var G__28984 = args28982.length;
switch (G__28984) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28982.length)].join('')));

}
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5(n,to,xf,from,true);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6(n,to,xf,from,close_QMARK_,null);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,cljs.core.cst$kw$compute);
});

cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6;

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var args28989 = [];
var len__8118__auto___29042 = arguments.length;
var i__8119__auto___29043 = (0);
while(true){
if((i__8119__auto___29043 < len__8118__auto___29042)){
args28989.push((arguments[i__8119__auto___29043]));

var G__29044 = (i__8119__auto___29043 + (1));
i__8119__auto___29043 = G__29044;
continue;
} else {
}
break;
}

var G__28991 = args28989.length;
switch (G__28991) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args28989.length)].join('')));

}
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4(p,ch,null,null);
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(t_buf_or_n);
var fc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(f_buf_or_n);
var c__15224__auto___29046 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___29046,tc,fc){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___29046,tc,fc){
return (function (state_29017){
var state_val_29018 = (state_29017[(1)]);
if((state_val_29018 === (7))){
var inst_29013 = (state_29017[(2)]);
var state_29017__$1 = state_29017;
var statearr_29019_29047 = state_29017__$1;
(statearr_29019_29047[(2)] = inst_29013);

(statearr_29019_29047[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29018 === (1))){
var state_29017__$1 = state_29017;
var statearr_29020_29048 = state_29017__$1;
(statearr_29020_29048[(2)] = null);

(statearr_29020_29048[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29018 === (4))){
var inst_28994 = (state_29017[(7)]);
var inst_28994__$1 = (state_29017[(2)]);
var inst_28995 = (inst_28994__$1 == null);
var state_29017__$1 = (function (){var statearr_29021 = state_29017;
(statearr_29021[(7)] = inst_28994__$1);

return statearr_29021;
})();
if(cljs.core.truth_(inst_28995)){
var statearr_29022_29049 = state_29017__$1;
(statearr_29022_29049[(1)] = (5));

} else {
var statearr_29023_29050 = state_29017__$1;
(statearr_29023_29050[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29018 === (13))){
var state_29017__$1 = state_29017;
var statearr_29024_29051 = state_29017__$1;
(statearr_29024_29051[(2)] = null);

(statearr_29024_29051[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29018 === (6))){
var inst_28994 = (state_29017[(7)]);
var inst_29000 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_28994) : p.call(null,inst_28994));
var state_29017__$1 = state_29017;
if(cljs.core.truth_(inst_29000)){
var statearr_29025_29052 = state_29017__$1;
(statearr_29025_29052[(1)] = (9));

} else {
var statearr_29026_29053 = state_29017__$1;
(statearr_29026_29053[(1)] = (10));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29018 === (3))){
var inst_29015 = (state_29017[(2)]);
var state_29017__$1 = state_29017;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29017__$1,inst_29015);
} else {
if((state_val_29018 === (12))){
var state_29017__$1 = state_29017;
var statearr_29027_29054 = state_29017__$1;
(statearr_29027_29054[(2)] = null);

(statearr_29027_29054[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29018 === (2))){
var state_29017__$1 = state_29017;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29017__$1,(4),ch);
} else {
if((state_val_29018 === (11))){
var inst_28994 = (state_29017[(7)]);
var inst_29004 = (state_29017[(2)]);
var state_29017__$1 = state_29017;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29017__$1,(8),inst_29004,inst_28994);
} else {
if((state_val_29018 === (9))){
var state_29017__$1 = state_29017;
var statearr_29028_29055 = state_29017__$1;
(statearr_29028_29055[(2)] = tc);

(statearr_29028_29055[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29018 === (5))){
var inst_28997 = cljs.core.async.close_BANG_(tc);
var inst_28998 = cljs.core.async.close_BANG_(fc);
var state_29017__$1 = (function (){var statearr_29029 = state_29017;
(statearr_29029[(8)] = inst_28997);

return statearr_29029;
})();
var statearr_29030_29056 = state_29017__$1;
(statearr_29030_29056[(2)] = inst_28998);

(statearr_29030_29056[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29018 === (14))){
var inst_29011 = (state_29017[(2)]);
var state_29017__$1 = state_29017;
var statearr_29031_29057 = state_29017__$1;
(statearr_29031_29057[(2)] = inst_29011);

(statearr_29031_29057[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29018 === (10))){
var state_29017__$1 = state_29017;
var statearr_29032_29058 = state_29017__$1;
(statearr_29032_29058[(2)] = fc);

(statearr_29032_29058[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29018 === (8))){
var inst_29006 = (state_29017[(2)]);
var state_29017__$1 = state_29017;
if(cljs.core.truth_(inst_29006)){
var statearr_29033_29059 = state_29017__$1;
(statearr_29033_29059[(1)] = (12));

} else {
var statearr_29034_29060 = state_29017__$1;
(statearr_29034_29060[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___29046,tc,fc))
;
return ((function (switch__15098__auto__,c__15224__auto___29046,tc,fc){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_29038 = [null,null,null,null,null,null,null,null,null];
(statearr_29038[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_29038[(1)] = (1));

return statearr_29038;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_29017){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_29017);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e29039){if((e29039 instanceof Object)){
var ex__15102__auto__ = e29039;
var statearr_29040_29061 = state_29017;
(statearr_29040_29061[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29017);

return cljs.core.cst$kw$recur;
} else {
throw e29039;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__29062 = state_29017;
state_29017 = G__29062;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_29017){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_29017);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___29046,tc,fc))
})();
var state__15226__auto__ = (function (){var statearr_29041 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_29041[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___29046);

return statearr_29041;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___29046,tc,fc))
);


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
});

cljs.core.async.split.cljs$lang$maxFixedArity = 4;

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_29126){
var state_val_29127 = (state_29126[(1)]);
if((state_val_29127 === (7))){
var inst_29122 = (state_29126[(2)]);
var state_29126__$1 = state_29126;
var statearr_29128_29149 = state_29126__$1;
(statearr_29128_29149[(2)] = inst_29122);

(statearr_29128_29149[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29127 === (1))){
var inst_29106 = init;
var state_29126__$1 = (function (){var statearr_29129 = state_29126;
(statearr_29129[(7)] = inst_29106);

return statearr_29129;
})();
var statearr_29130_29150 = state_29126__$1;
(statearr_29130_29150[(2)] = null);

(statearr_29130_29150[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29127 === (4))){
var inst_29109 = (state_29126[(8)]);
var inst_29109__$1 = (state_29126[(2)]);
var inst_29110 = (inst_29109__$1 == null);
var state_29126__$1 = (function (){var statearr_29131 = state_29126;
(statearr_29131[(8)] = inst_29109__$1);

return statearr_29131;
})();
if(cljs.core.truth_(inst_29110)){
var statearr_29132_29151 = state_29126__$1;
(statearr_29132_29151[(1)] = (5));

} else {
var statearr_29133_29152 = state_29126__$1;
(statearr_29133_29152[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29127 === (6))){
var inst_29109 = (state_29126[(8)]);
var inst_29113 = (state_29126[(9)]);
var inst_29106 = (state_29126[(7)]);
var inst_29113__$1 = (f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(inst_29106,inst_29109) : f.call(null,inst_29106,inst_29109));
var inst_29114 = cljs.core.reduced_QMARK_(inst_29113__$1);
var state_29126__$1 = (function (){var statearr_29134 = state_29126;
(statearr_29134[(9)] = inst_29113__$1);

return statearr_29134;
})();
if(inst_29114){
var statearr_29135_29153 = state_29126__$1;
(statearr_29135_29153[(1)] = (8));

} else {
var statearr_29136_29154 = state_29126__$1;
(statearr_29136_29154[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29127 === (3))){
var inst_29124 = (state_29126[(2)]);
var state_29126__$1 = state_29126;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29126__$1,inst_29124);
} else {
if((state_val_29127 === (2))){
var state_29126__$1 = state_29126;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29126__$1,(4),ch);
} else {
if((state_val_29127 === (9))){
var inst_29113 = (state_29126[(9)]);
var inst_29106 = inst_29113;
var state_29126__$1 = (function (){var statearr_29137 = state_29126;
(statearr_29137[(7)] = inst_29106);

return statearr_29137;
})();
var statearr_29138_29155 = state_29126__$1;
(statearr_29138_29155[(2)] = null);

(statearr_29138_29155[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29127 === (5))){
var inst_29106 = (state_29126[(7)]);
var state_29126__$1 = state_29126;
var statearr_29139_29156 = state_29126__$1;
(statearr_29139_29156[(2)] = inst_29106);

(statearr_29139_29156[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29127 === (10))){
var inst_29120 = (state_29126[(2)]);
var state_29126__$1 = state_29126;
var statearr_29140_29157 = state_29126__$1;
(statearr_29140_29157[(2)] = inst_29120);

(statearr_29140_29157[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29127 === (8))){
var inst_29113 = (state_29126[(9)]);
var inst_29116 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(inst_29113) : cljs.core.deref.call(null,inst_29113));
var state_29126__$1 = state_29126;
var statearr_29141_29158 = state_29126__$1;
(statearr_29141_29158[(2)] = inst_29116);

(statearr_29141_29158[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var cljs$core$async$reduce_$_state_machine__15099__auto__ = null;
var cljs$core$async$reduce_$_state_machine__15099__auto____0 = (function (){
var statearr_29145 = [null,null,null,null,null,null,null,null,null,null];
(statearr_29145[(0)] = cljs$core$async$reduce_$_state_machine__15099__auto__);

(statearr_29145[(1)] = (1));

return statearr_29145;
});
var cljs$core$async$reduce_$_state_machine__15099__auto____1 = (function (state_29126){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_29126);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e29146){if((e29146 instanceof Object)){
var ex__15102__auto__ = e29146;
var statearr_29147_29159 = state_29126;
(statearr_29147_29159[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29126);

return cljs.core.cst$kw$recur;
} else {
throw e29146;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__29160 = state_29126;
state_29126 = G__29160;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__15099__auto__ = function(state_29126){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__15099__auto____1.call(this,state_29126);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__15099__auto____0;
cljs$core$async$reduce_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__15099__auto____1;
return cljs$core$async$reduce_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_29148 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_29148[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_29148;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var args29161 = [];
var len__8118__auto___29213 = arguments.length;
var i__8119__auto___29214 = (0);
while(true){
if((i__8119__auto___29214 < len__8118__auto___29213)){
args29161.push((arguments[i__8119__auto___29214]));

var G__29215 = (i__8119__auto___29214 + (1));
i__8119__auto___29214 = G__29215;
continue;
} else {
}
break;
}

var G__29163 = args29161.length;
switch (G__29163) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args29161.length)].join('')));

}
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3(ch,coll,true);
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_29188){
var state_val_29189 = (state_29188[(1)]);
if((state_val_29189 === (7))){
var inst_29170 = (state_29188[(2)]);
var state_29188__$1 = state_29188;
var statearr_29190_29217 = state_29188__$1;
(statearr_29190_29217[(2)] = inst_29170);

(statearr_29190_29217[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29189 === (1))){
var inst_29164 = cljs.core.seq(coll);
var inst_29165 = inst_29164;
var state_29188__$1 = (function (){var statearr_29191 = state_29188;
(statearr_29191[(7)] = inst_29165);

return statearr_29191;
})();
var statearr_29192_29218 = state_29188__$1;
(statearr_29192_29218[(2)] = null);

(statearr_29192_29218[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29189 === (4))){
var inst_29165 = (state_29188[(7)]);
var inst_29168 = cljs.core.first(inst_29165);
var state_29188__$1 = state_29188;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29188__$1,(7),ch,inst_29168);
} else {
if((state_val_29189 === (13))){
var inst_29182 = (state_29188[(2)]);
var state_29188__$1 = state_29188;
var statearr_29193_29219 = state_29188__$1;
(statearr_29193_29219[(2)] = inst_29182);

(statearr_29193_29219[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29189 === (6))){
var inst_29173 = (state_29188[(2)]);
var state_29188__$1 = state_29188;
if(cljs.core.truth_(inst_29173)){
var statearr_29194_29220 = state_29188__$1;
(statearr_29194_29220[(1)] = (8));

} else {
var statearr_29195_29221 = state_29188__$1;
(statearr_29195_29221[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29189 === (3))){
var inst_29186 = (state_29188[(2)]);
var state_29188__$1 = state_29188;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29188__$1,inst_29186);
} else {
if((state_val_29189 === (12))){
var state_29188__$1 = state_29188;
var statearr_29196_29222 = state_29188__$1;
(statearr_29196_29222[(2)] = null);

(statearr_29196_29222[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29189 === (2))){
var inst_29165 = (state_29188[(7)]);
var state_29188__$1 = state_29188;
if(cljs.core.truth_(inst_29165)){
var statearr_29197_29223 = state_29188__$1;
(statearr_29197_29223[(1)] = (4));

} else {
var statearr_29198_29224 = state_29188__$1;
(statearr_29198_29224[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29189 === (11))){
var inst_29179 = cljs.core.async.close_BANG_(ch);
var state_29188__$1 = state_29188;
var statearr_29199_29225 = state_29188__$1;
(statearr_29199_29225[(2)] = inst_29179);

(statearr_29199_29225[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29189 === (9))){
var state_29188__$1 = state_29188;
if(cljs.core.truth_(close_QMARK_)){
var statearr_29200_29226 = state_29188__$1;
(statearr_29200_29226[(1)] = (11));

} else {
var statearr_29201_29227 = state_29188__$1;
(statearr_29201_29227[(1)] = (12));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29189 === (5))){
var inst_29165 = (state_29188[(7)]);
var state_29188__$1 = state_29188;
var statearr_29202_29228 = state_29188__$1;
(statearr_29202_29228[(2)] = inst_29165);

(statearr_29202_29228[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29189 === (10))){
var inst_29184 = (state_29188[(2)]);
var state_29188__$1 = state_29188;
var statearr_29203_29229 = state_29188__$1;
(statearr_29203_29229[(2)] = inst_29184);

(statearr_29203_29229[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29189 === (8))){
var inst_29165 = (state_29188[(7)]);
var inst_29175 = cljs.core.next(inst_29165);
var inst_29165__$1 = inst_29175;
var state_29188__$1 = (function (){var statearr_29204 = state_29188;
(statearr_29204[(7)] = inst_29165__$1);

return statearr_29204;
})();
var statearr_29205_29230 = state_29188__$1;
(statearr_29205_29230[(2)] = null);

(statearr_29205_29230[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_29209 = [null,null,null,null,null,null,null,null];
(statearr_29209[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_29209[(1)] = (1));

return statearr_29209;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_29188){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_29188);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e29210){if((e29210 instanceof Object)){
var ex__15102__auto__ = e29210;
var statearr_29211_29231 = state_29188;
(statearr_29211_29231[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29188);

return cljs.core.cst$kw$recur;
} else {
throw e29210;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__29232 = state_29188;
state_29188 = G__29232;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_29188){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_29188);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_29212 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_29212[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_29212;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});

cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(cljs.core.bounded_count((100),coll));
cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2(ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((!((_ == null))) && (!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__7652__auto__ = (((_ == null))?null:_);
var m__7653__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__7653__auto__.call(null,_));
} else {
var m__7653__auto____$1 = (cljs.core.async.muxch_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1(_) : m__7653__auto____$1.call(null,_));
} else {
throw cljs.core.missing_protocol("Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((!((m == null))) && (!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$3 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__7653__auto__.call(null,m,ch,close_QMARK_));
} else {
var m__7653__auto____$1 = (cljs.core.async.tap_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$3 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__7653__auto____$1.call(null,m,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto__.call(null,m,ch));
} else {
var m__7653__auto____$1 = (cljs.core.async.untap_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((!((m == null))) && (!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__7653__auto__.call(null,m));
} else {
var m__7653__auto____$1 = (cljs.core.async.untap_all_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1(m) : m__7653__auto____$1.call(null,m));
} else {
throw cljs.core.missing_protocol("Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = (function (){var G__29461 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__29461) : cljs.core.atom.call(null,G__29461));
})();
var m = (function (){
if(typeof cljs.core.async.t_cljs$core$async29462 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async29462 = (function (mult,ch,cs,meta29463){
this.mult = mult;
this.ch = ch;
this.cs = cs;
this.meta29463 = meta29463;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async29462.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs){
return (function (_29464,meta29463__$1){
var self__ = this;
var _29464__$1 = this;
return (new cljs.core.async.t_cljs$core$async29462(self__.mult,self__.ch,self__.cs,meta29463__$1));
});})(cs))
;

cljs.core.async.t_cljs$core$async29462.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs){
return (function (_29464){
var self__ = this;
var _29464__$1 = this;
return self__.meta29463;
});})(cs))
;

cljs.core.async.t_cljs$core$async29462.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async29462.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(cs))
;

cljs.core.async.t_cljs$core$async29462.prototype.cljs$core$async$Mult$ = true;

cljs.core.async.t_cljs$core$async29462.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = ((function (cs){
return (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async29462.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = ((function (cs){
return (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch__$1);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async29462.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
var G__29465_29689 = self__.cs;
var G__29466_29690 = cljs.core.PersistentArrayMap.EMPTY;
(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__29465_29689,G__29466_29690) : cljs.core.reset_BANG_.call(null,G__29465_29689,G__29466_29690));

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async29462.getBasis = ((function (cs){
return (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$mult,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch], null))),cljs.core.cst$kw$doc,"Creates and returns a mult(iple) of the supplied channel. Channels\n  containing copies of the channel can be created with 'tap', and\n  detached with 'untap'.\n\n  Each item is distributed to all taps in parallel and synchronously,\n  i.e. each tap must accept before the next item is distributed. Use\n  buffering/windowing to prevent slow taps from holding up the mult.\n\n  Items received when there are no taps get dropped.\n\n  If a tap puts to a closed channel, it will be removed from the mult."], null)),cljs.core.cst$sym$ch,cljs.core.cst$sym$cs,cljs.core.cst$sym$meta29463], null);
});})(cs))
;

cljs.core.async.t_cljs$core$async29462.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async29462.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async29462";

cljs.core.async.t_cljs$core$async29462.cljs$lang$ctorPrWriter = ((function (cs){
return (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async29462");
});})(cs))
;

cljs.core.async.__GT_t_cljs$core$async29462 = ((function (cs){
return (function cljs$core$async$mult_$___GT_t_cljs$core$async29462(mult__$1,ch__$1,cs__$1,meta29463){
return (new cljs.core.async.t_cljs$core$async29462(mult__$1,ch__$1,cs__$1,meta29463));
});})(cs))
;

}

return (new cljs.core.async.t_cljs$core$async29462(cljs$core$async$mult,ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null) : cljs.core.atom.call(null,null));
var done = ((function (cs,m,dchan,dctr){
return (function (_){
if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,true);
} else {
return null;
}
});})(cs,m,dchan,dctr))
;
var c__15224__auto___29691 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___29691,cs,m,dchan,dctr,done){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___29691,cs,m,dchan,dctr,done){
return (function (state_29601){
var state_val_29602 = (state_29601[(1)]);
if((state_val_29602 === (7))){
var inst_29597 = (state_29601[(2)]);
var state_29601__$1 = state_29601;
var statearr_29603_29692 = state_29601__$1;
(statearr_29603_29692[(2)] = inst_29597);

(statearr_29603_29692[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (20))){
var inst_29500 = (state_29601[(7)]);
var inst_29512 = cljs.core.first(inst_29500);
var inst_29513 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29512,(0),null);
var inst_29514 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29512,(1),null);
var state_29601__$1 = (function (){var statearr_29604 = state_29601;
(statearr_29604[(8)] = inst_29513);

return statearr_29604;
})();
if(cljs.core.truth_(inst_29514)){
var statearr_29605_29693 = state_29601__$1;
(statearr_29605_29693[(1)] = (22));

} else {
var statearr_29606_29694 = state_29601__$1;
(statearr_29606_29694[(1)] = (23));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (27))){
var inst_29549 = (state_29601[(9)]);
var inst_29544 = (state_29601[(10)]);
var inst_29542 = (state_29601[(11)]);
var inst_29469 = (state_29601[(12)]);
var inst_29549__$1 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_29542,inst_29544);
var inst_29550 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_29549__$1,inst_29469,done);
var state_29601__$1 = (function (){var statearr_29607 = state_29601;
(statearr_29607[(9)] = inst_29549__$1);

return statearr_29607;
})();
if(cljs.core.truth_(inst_29550)){
var statearr_29608_29695 = state_29601__$1;
(statearr_29608_29695[(1)] = (30));

} else {
var statearr_29609_29696 = state_29601__$1;
(statearr_29609_29696[(1)] = (31));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (1))){
var state_29601__$1 = state_29601;
var statearr_29610_29697 = state_29601__$1;
(statearr_29610_29697[(2)] = null);

(statearr_29610_29697[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (24))){
var inst_29500 = (state_29601[(7)]);
var inst_29519 = (state_29601[(2)]);
var inst_29520 = cljs.core.next(inst_29500);
var inst_29478 = inst_29520;
var inst_29479 = null;
var inst_29480 = (0);
var inst_29481 = (0);
var state_29601__$1 = (function (){var statearr_29611 = state_29601;
(statearr_29611[(13)] = inst_29479);

(statearr_29611[(14)] = inst_29519);

(statearr_29611[(15)] = inst_29478);

(statearr_29611[(16)] = inst_29480);

(statearr_29611[(17)] = inst_29481);

return statearr_29611;
})();
var statearr_29612_29698 = state_29601__$1;
(statearr_29612_29698[(2)] = null);

(statearr_29612_29698[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (39))){
var state_29601__$1 = state_29601;
var statearr_29616_29699 = state_29601__$1;
(statearr_29616_29699[(2)] = null);

(statearr_29616_29699[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (4))){
var inst_29469 = (state_29601[(12)]);
var inst_29469__$1 = (state_29601[(2)]);
var inst_29470 = (inst_29469__$1 == null);
var state_29601__$1 = (function (){var statearr_29617 = state_29601;
(statearr_29617[(12)] = inst_29469__$1);

return statearr_29617;
})();
if(cljs.core.truth_(inst_29470)){
var statearr_29618_29700 = state_29601__$1;
(statearr_29618_29700[(1)] = (5));

} else {
var statearr_29619_29701 = state_29601__$1;
(statearr_29619_29701[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (15))){
var inst_29479 = (state_29601[(13)]);
var inst_29478 = (state_29601[(15)]);
var inst_29480 = (state_29601[(16)]);
var inst_29481 = (state_29601[(17)]);
var inst_29496 = (state_29601[(2)]);
var inst_29497 = (inst_29481 + (1));
var tmp29613 = inst_29479;
var tmp29614 = inst_29478;
var tmp29615 = inst_29480;
var inst_29478__$1 = tmp29614;
var inst_29479__$1 = tmp29613;
var inst_29480__$1 = tmp29615;
var inst_29481__$1 = inst_29497;
var state_29601__$1 = (function (){var statearr_29620 = state_29601;
(statearr_29620[(13)] = inst_29479__$1);

(statearr_29620[(15)] = inst_29478__$1);

(statearr_29620[(16)] = inst_29480__$1);

(statearr_29620[(18)] = inst_29496);

(statearr_29620[(17)] = inst_29481__$1);

return statearr_29620;
})();
var statearr_29621_29702 = state_29601__$1;
(statearr_29621_29702[(2)] = null);

(statearr_29621_29702[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (21))){
var inst_29523 = (state_29601[(2)]);
var state_29601__$1 = state_29601;
var statearr_29625_29703 = state_29601__$1;
(statearr_29625_29703[(2)] = inst_29523);

(statearr_29625_29703[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (31))){
var inst_29549 = (state_29601[(9)]);
var inst_29553 = done(null);
var inst_29554 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_29549);
var state_29601__$1 = (function (){var statearr_29626 = state_29601;
(statearr_29626[(19)] = inst_29553);

return statearr_29626;
})();
var statearr_29627_29704 = state_29601__$1;
(statearr_29627_29704[(2)] = inst_29554);

(statearr_29627_29704[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (32))){
var inst_29544 = (state_29601[(10)]);
var inst_29542 = (state_29601[(11)]);
var inst_29543 = (state_29601[(20)]);
var inst_29541 = (state_29601[(21)]);
var inst_29556 = (state_29601[(2)]);
var inst_29557 = (inst_29544 + (1));
var tmp29622 = inst_29542;
var tmp29623 = inst_29543;
var tmp29624 = inst_29541;
var inst_29541__$1 = tmp29624;
var inst_29542__$1 = tmp29622;
var inst_29543__$1 = tmp29623;
var inst_29544__$1 = inst_29557;
var state_29601__$1 = (function (){var statearr_29628 = state_29601;
(statearr_29628[(10)] = inst_29544__$1);

(statearr_29628[(11)] = inst_29542__$1);

(statearr_29628[(20)] = inst_29543__$1);

(statearr_29628[(22)] = inst_29556);

(statearr_29628[(21)] = inst_29541__$1);

return statearr_29628;
})();
var statearr_29629_29705 = state_29601__$1;
(statearr_29629_29705[(2)] = null);

(statearr_29629_29705[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (40))){
var inst_29569 = (state_29601[(23)]);
var inst_29573 = done(null);
var inst_29574 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_29569);
var state_29601__$1 = (function (){var statearr_29630 = state_29601;
(statearr_29630[(24)] = inst_29573);

return statearr_29630;
})();
var statearr_29631_29706 = state_29601__$1;
(statearr_29631_29706[(2)] = inst_29574);

(statearr_29631_29706[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (33))){
var inst_29560 = (state_29601[(25)]);
var inst_29562 = cljs.core.chunked_seq_QMARK_(inst_29560);
var state_29601__$1 = state_29601;
if(inst_29562){
var statearr_29632_29707 = state_29601__$1;
(statearr_29632_29707[(1)] = (36));

} else {
var statearr_29633_29708 = state_29601__$1;
(statearr_29633_29708[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (13))){
var inst_29490 = (state_29601[(26)]);
var inst_29493 = cljs.core.async.close_BANG_(inst_29490);
var state_29601__$1 = state_29601;
var statearr_29634_29709 = state_29601__$1;
(statearr_29634_29709[(2)] = inst_29493);

(statearr_29634_29709[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (22))){
var inst_29513 = (state_29601[(8)]);
var inst_29516 = cljs.core.async.close_BANG_(inst_29513);
var state_29601__$1 = state_29601;
var statearr_29635_29710 = state_29601__$1;
(statearr_29635_29710[(2)] = inst_29516);

(statearr_29635_29710[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (36))){
var inst_29560 = (state_29601[(25)]);
var inst_29564 = cljs.core.chunk_first(inst_29560);
var inst_29565 = cljs.core.chunk_rest(inst_29560);
var inst_29566 = cljs.core.count(inst_29564);
var inst_29541 = inst_29565;
var inst_29542 = inst_29564;
var inst_29543 = inst_29566;
var inst_29544 = (0);
var state_29601__$1 = (function (){var statearr_29636 = state_29601;
(statearr_29636[(10)] = inst_29544);

(statearr_29636[(11)] = inst_29542);

(statearr_29636[(20)] = inst_29543);

(statearr_29636[(21)] = inst_29541);

return statearr_29636;
})();
var statearr_29637_29711 = state_29601__$1;
(statearr_29637_29711[(2)] = null);

(statearr_29637_29711[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (41))){
var inst_29560 = (state_29601[(25)]);
var inst_29576 = (state_29601[(2)]);
var inst_29577 = cljs.core.next(inst_29560);
var inst_29541 = inst_29577;
var inst_29542 = null;
var inst_29543 = (0);
var inst_29544 = (0);
var state_29601__$1 = (function (){var statearr_29638 = state_29601;
(statearr_29638[(10)] = inst_29544);

(statearr_29638[(11)] = inst_29542);

(statearr_29638[(20)] = inst_29543);

(statearr_29638[(27)] = inst_29576);

(statearr_29638[(21)] = inst_29541);

return statearr_29638;
})();
var statearr_29639_29712 = state_29601__$1;
(statearr_29639_29712[(2)] = null);

(statearr_29639_29712[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (43))){
var state_29601__$1 = state_29601;
var statearr_29640_29713 = state_29601__$1;
(statearr_29640_29713[(2)] = null);

(statearr_29640_29713[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (29))){
var inst_29585 = (state_29601[(2)]);
var state_29601__$1 = state_29601;
var statearr_29641_29714 = state_29601__$1;
(statearr_29641_29714[(2)] = inst_29585);

(statearr_29641_29714[(1)] = (26));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (44))){
var inst_29594 = (state_29601[(2)]);
var state_29601__$1 = (function (){var statearr_29642 = state_29601;
(statearr_29642[(28)] = inst_29594);

return statearr_29642;
})();
var statearr_29643_29715 = state_29601__$1;
(statearr_29643_29715[(2)] = null);

(statearr_29643_29715[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (6))){
var inst_29533 = (state_29601[(29)]);
var inst_29532 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(cs) : cljs.core.deref.call(null,cs));
var inst_29533__$1 = cljs.core.keys(inst_29532);
var inst_29534 = cljs.core.count(inst_29533__$1);
var inst_29535 = (cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,inst_29534) : cljs.core.reset_BANG_.call(null,dctr,inst_29534));
var inst_29540 = cljs.core.seq(inst_29533__$1);
var inst_29541 = inst_29540;
var inst_29542 = null;
var inst_29543 = (0);
var inst_29544 = (0);
var state_29601__$1 = (function (){var statearr_29644 = state_29601;
(statearr_29644[(10)] = inst_29544);

(statearr_29644[(11)] = inst_29542);

(statearr_29644[(29)] = inst_29533__$1);

(statearr_29644[(20)] = inst_29543);

(statearr_29644[(21)] = inst_29541);

(statearr_29644[(30)] = inst_29535);

return statearr_29644;
})();
var statearr_29645_29716 = state_29601__$1;
(statearr_29645_29716[(2)] = null);

(statearr_29645_29716[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (28))){
var inst_29560 = (state_29601[(25)]);
var inst_29541 = (state_29601[(21)]);
var inst_29560__$1 = cljs.core.seq(inst_29541);
var state_29601__$1 = (function (){var statearr_29646 = state_29601;
(statearr_29646[(25)] = inst_29560__$1);

return statearr_29646;
})();
if(inst_29560__$1){
var statearr_29647_29717 = state_29601__$1;
(statearr_29647_29717[(1)] = (33));

} else {
var statearr_29648_29718 = state_29601__$1;
(statearr_29648_29718[(1)] = (34));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (25))){
var inst_29544 = (state_29601[(10)]);
var inst_29543 = (state_29601[(20)]);
var inst_29546 = (inst_29544 < inst_29543);
var inst_29547 = inst_29546;
var state_29601__$1 = state_29601;
if(cljs.core.truth_(inst_29547)){
var statearr_29649_29719 = state_29601__$1;
(statearr_29649_29719[(1)] = (27));

} else {
var statearr_29650_29720 = state_29601__$1;
(statearr_29650_29720[(1)] = (28));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (34))){
var state_29601__$1 = state_29601;
var statearr_29651_29721 = state_29601__$1;
(statearr_29651_29721[(2)] = null);

(statearr_29651_29721[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (17))){
var state_29601__$1 = state_29601;
var statearr_29652_29722 = state_29601__$1;
(statearr_29652_29722[(2)] = null);

(statearr_29652_29722[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (3))){
var inst_29599 = (state_29601[(2)]);
var state_29601__$1 = state_29601;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29601__$1,inst_29599);
} else {
if((state_val_29602 === (12))){
var inst_29528 = (state_29601[(2)]);
var state_29601__$1 = state_29601;
var statearr_29653_29723 = state_29601__$1;
(statearr_29653_29723[(2)] = inst_29528);

(statearr_29653_29723[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (2))){
var state_29601__$1 = state_29601;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29601__$1,(4),ch);
} else {
if((state_val_29602 === (23))){
var state_29601__$1 = state_29601;
var statearr_29654_29724 = state_29601__$1;
(statearr_29654_29724[(2)] = null);

(statearr_29654_29724[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (35))){
var inst_29583 = (state_29601[(2)]);
var state_29601__$1 = state_29601;
var statearr_29655_29725 = state_29601__$1;
(statearr_29655_29725[(2)] = inst_29583);

(statearr_29655_29725[(1)] = (29));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (19))){
var inst_29500 = (state_29601[(7)]);
var inst_29504 = cljs.core.chunk_first(inst_29500);
var inst_29505 = cljs.core.chunk_rest(inst_29500);
var inst_29506 = cljs.core.count(inst_29504);
var inst_29478 = inst_29505;
var inst_29479 = inst_29504;
var inst_29480 = inst_29506;
var inst_29481 = (0);
var state_29601__$1 = (function (){var statearr_29656 = state_29601;
(statearr_29656[(13)] = inst_29479);

(statearr_29656[(15)] = inst_29478);

(statearr_29656[(16)] = inst_29480);

(statearr_29656[(17)] = inst_29481);

return statearr_29656;
})();
var statearr_29657_29726 = state_29601__$1;
(statearr_29657_29726[(2)] = null);

(statearr_29657_29726[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (11))){
var inst_29500 = (state_29601[(7)]);
var inst_29478 = (state_29601[(15)]);
var inst_29500__$1 = cljs.core.seq(inst_29478);
var state_29601__$1 = (function (){var statearr_29658 = state_29601;
(statearr_29658[(7)] = inst_29500__$1);

return statearr_29658;
})();
if(inst_29500__$1){
var statearr_29659_29727 = state_29601__$1;
(statearr_29659_29727[(1)] = (16));

} else {
var statearr_29660_29728 = state_29601__$1;
(statearr_29660_29728[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (9))){
var inst_29530 = (state_29601[(2)]);
var state_29601__$1 = state_29601;
var statearr_29661_29729 = state_29601__$1;
(statearr_29661_29729[(2)] = inst_29530);

(statearr_29661_29729[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (5))){
var inst_29476 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(cs) : cljs.core.deref.call(null,cs));
var inst_29477 = cljs.core.seq(inst_29476);
var inst_29478 = inst_29477;
var inst_29479 = null;
var inst_29480 = (0);
var inst_29481 = (0);
var state_29601__$1 = (function (){var statearr_29662 = state_29601;
(statearr_29662[(13)] = inst_29479);

(statearr_29662[(15)] = inst_29478);

(statearr_29662[(16)] = inst_29480);

(statearr_29662[(17)] = inst_29481);

return statearr_29662;
})();
var statearr_29663_29730 = state_29601__$1;
(statearr_29663_29730[(2)] = null);

(statearr_29663_29730[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (14))){
var state_29601__$1 = state_29601;
var statearr_29664_29731 = state_29601__$1;
(statearr_29664_29731[(2)] = null);

(statearr_29664_29731[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (45))){
var inst_29591 = (state_29601[(2)]);
var state_29601__$1 = state_29601;
var statearr_29665_29732 = state_29601__$1;
(statearr_29665_29732[(2)] = inst_29591);

(statearr_29665_29732[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (26))){
var inst_29533 = (state_29601[(29)]);
var inst_29587 = (state_29601[(2)]);
var inst_29588 = cljs.core.seq(inst_29533);
var state_29601__$1 = (function (){var statearr_29666 = state_29601;
(statearr_29666[(31)] = inst_29587);

return statearr_29666;
})();
if(inst_29588){
var statearr_29667_29733 = state_29601__$1;
(statearr_29667_29733[(1)] = (42));

} else {
var statearr_29668_29734 = state_29601__$1;
(statearr_29668_29734[(1)] = (43));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (16))){
var inst_29500 = (state_29601[(7)]);
var inst_29502 = cljs.core.chunked_seq_QMARK_(inst_29500);
var state_29601__$1 = state_29601;
if(inst_29502){
var statearr_29669_29735 = state_29601__$1;
(statearr_29669_29735[(1)] = (19));

} else {
var statearr_29670_29736 = state_29601__$1;
(statearr_29670_29736[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (38))){
var inst_29580 = (state_29601[(2)]);
var state_29601__$1 = state_29601;
var statearr_29671_29737 = state_29601__$1;
(statearr_29671_29737[(2)] = inst_29580);

(statearr_29671_29737[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (30))){
var state_29601__$1 = state_29601;
var statearr_29672_29738 = state_29601__$1;
(statearr_29672_29738[(2)] = null);

(statearr_29672_29738[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (10))){
var inst_29479 = (state_29601[(13)]);
var inst_29481 = (state_29601[(17)]);
var inst_29489 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_29479,inst_29481);
var inst_29490 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29489,(0),null);
var inst_29491 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29489,(1),null);
var state_29601__$1 = (function (){var statearr_29673 = state_29601;
(statearr_29673[(26)] = inst_29490);

return statearr_29673;
})();
if(cljs.core.truth_(inst_29491)){
var statearr_29674_29739 = state_29601__$1;
(statearr_29674_29739[(1)] = (13));

} else {
var statearr_29675_29740 = state_29601__$1;
(statearr_29675_29740[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (18))){
var inst_29526 = (state_29601[(2)]);
var state_29601__$1 = state_29601;
var statearr_29676_29741 = state_29601__$1;
(statearr_29676_29741[(2)] = inst_29526);

(statearr_29676_29741[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (42))){
var state_29601__$1 = state_29601;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29601__$1,(45),dchan);
} else {
if((state_val_29602 === (37))){
var inst_29560 = (state_29601[(25)]);
var inst_29469 = (state_29601[(12)]);
var inst_29569 = (state_29601[(23)]);
var inst_29569__$1 = cljs.core.first(inst_29560);
var inst_29570 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_29569__$1,inst_29469,done);
var state_29601__$1 = (function (){var statearr_29677 = state_29601;
(statearr_29677[(23)] = inst_29569__$1);

return statearr_29677;
})();
if(cljs.core.truth_(inst_29570)){
var statearr_29678_29742 = state_29601__$1;
(statearr_29678_29742[(1)] = (39));

} else {
var statearr_29679_29743 = state_29601__$1;
(statearr_29679_29743[(1)] = (40));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29602 === (8))){
var inst_29480 = (state_29601[(16)]);
var inst_29481 = (state_29601[(17)]);
var inst_29483 = (inst_29481 < inst_29480);
var inst_29484 = inst_29483;
var state_29601__$1 = state_29601;
if(cljs.core.truth_(inst_29484)){
var statearr_29680_29744 = state_29601__$1;
(statearr_29680_29744[(1)] = (10));

} else {
var statearr_29681_29745 = state_29601__$1;
(statearr_29681_29745[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___29691,cs,m,dchan,dctr,done))
;
return ((function (switch__15098__auto__,c__15224__auto___29691,cs,m,dchan,dctr,done){
return (function() {
var cljs$core$async$mult_$_state_machine__15099__auto__ = null;
var cljs$core$async$mult_$_state_machine__15099__auto____0 = (function (){
var statearr_29685 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_29685[(0)] = cljs$core$async$mult_$_state_machine__15099__auto__);

(statearr_29685[(1)] = (1));

return statearr_29685;
});
var cljs$core$async$mult_$_state_machine__15099__auto____1 = (function (state_29601){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_29601);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e29686){if((e29686 instanceof Object)){
var ex__15102__auto__ = e29686;
var statearr_29687_29746 = state_29601;
(statearr_29687_29746[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29601);

return cljs.core.cst$kw$recur;
} else {
throw e29686;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__29747 = state_29601;
state_29601 = G__29747;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__15099__auto__ = function(state_29601){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__15099__auto____1.call(this,state_29601);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__15099__auto____0;
cljs$core$async$mult_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__15099__auto____1;
return cljs$core$async$mult_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___29691,cs,m,dchan,dctr,done))
})();
var state__15226__auto__ = (function (){var statearr_29688 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_29688[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___29691);

return statearr_29688;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___29691,cs,m,dchan,dctr,done))
);


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var args29748 = [];
var len__8118__auto___29751 = arguments.length;
var i__8119__auto___29752 = (0);
while(true){
if((i__8119__auto___29752 < len__8118__auto___29751)){
args29748.push((arguments[i__8119__auto___29752]));

var G__29753 = (i__8119__auto___29752 + (1));
i__8119__auto___29752 = G__29753;
continue;
} else {
}
break;
}

var G__29750 = args29748.length;
switch (G__29750) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args29748.length)].join('')));

}
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(mult,ch,true);
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_(mult,ch,close_QMARK_);

return ch;
});

cljs.core.async.tap.cljs$lang$maxFixedArity = 3;

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_(mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_(mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto__.call(null,m,ch));
} else {
var m__7653__auto____$1 = (cljs.core.async.admix_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto__.call(null,m,ch));
} else {
var m__7653__auto____$1 = (cljs.core.async.unmix_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(m,ch) : m__7653__auto____$1.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((!((m == null))) && (!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__7653__auto__.call(null,m));
} else {
var m__7653__auto____$1 = (cljs.core.async.unmix_all_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1(m) : m__7653__auto____$1.call(null,m));
} else {
throw cljs.core.missing_protocol("Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((!((m == null))) && (!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__7653__auto__.call(null,m,state_map));
} else {
var m__7653__auto____$1 = (cljs.core.async.toggle_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__7653__auto____$1.call(null,m,state_map));
} else {
throw cljs.core.missing_protocol("Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((!((m == null))) && (!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__7652__auto__ = (((m == null))?null:m);
var m__7653__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__7653__auto__.call(null,m,mode));
} else {
var m__7653__auto____$1 = (cljs.core.async.solo_mode_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(m,mode) : m__7653__auto____$1.call(null,m,mode));
} else {
throw cljs.core.missing_protocol("Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___29765 = arguments.length;
var i__8119__auto___29766 = (0);
while(true){
if((i__8119__auto___29766 < len__8118__auto___29765)){
args__8125__auto__.push((arguments[i__8119__auto___29766]));

var G__29767 = (i__8119__auto___29766 + (1));
i__8119__auto___29766 = G__29767;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((3) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__8126__auto__);
});

cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__29759){
var map__29760 = p__29759;
var map__29760__$1 = ((((!((map__29760 == null)))?((((map__29760.cljs$lang$protocol_mask$partition0$ & (64))) || (map__29760.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__29760):map__29760);
var opts = map__29760__$1;
var statearr_29762_29768 = state;
(statearr_29762_29768[cljs.core.async.impl.ioc_helpers.STATE_IDX] = cont_block);


var temp__6728__auto__ = cljs.core.async.do_alts(((function (map__29760,map__29760__$1,opts){
return (function (val){
var statearr_29763_29769 = state;
(statearr_29763_29769[cljs.core.async.impl.ioc_helpers.VALUE_IDX] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state);
});})(map__29760,map__29760__$1,opts))
,ports,opts);
if(cljs.core.truth_(temp__6728__auto__)){
var cb = temp__6728__auto__;
var statearr_29764_29770 = state;
(statearr_29764_29770[cljs.core.async.impl.ioc_helpers.VALUE_IDX] = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(cb) : cljs.core.deref.call(null,cb)));


return cljs.core.cst$kw$recur;
} else {
return null;
}
});

cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3);

cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq29755){
var G__29756 = cljs.core.first(seq29755);
var seq29755__$1 = cljs.core.next(seq29755);
var G__29757 = cljs.core.first(seq29755__$1);
var seq29755__$2 = cljs.core.next(seq29755__$1);
var G__29758 = cljs.core.first(seq29755__$2);
var seq29755__$3 = cljs.core.next(seq29755__$2);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__29756,G__29757,G__29758,seq29755__$3);
});

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = (function (){var G__29940 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__29940) : cljs.core.atom.call(null,G__29940));
})();
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$pause,null,cljs.core.cst$kw$mute,null], null), null);
var attrs = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(solo_modes,cljs.core.cst$kw$solo);
var solo_mode = (function (){var G__29941 = cljs.core.cst$kw$mute;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__29941) : cljs.core.atom.call(null,G__29941));
})();
var change = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var changed = ((function (cs,solo_modes,attrs,solo_mode,change){
return (function (){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(change,true);
});})(cs,solo_modes,attrs,solo_mode,change))
;
var pick = ((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (attr,chs){
return cljs.core.reduce_kv(((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (ret,c,v){
if(cljs.core.truth_((attr.cljs$core$IFn$_invoke$arity$1 ? attr.cljs$core$IFn$_invoke$arity$1(v) : attr.call(null,v)))){
return cljs.core.conj.cljs$core$IFn$_invoke$arity$2(ret,c);
} else {
return ret;
}
});})(cs,solo_modes,attrs,solo_mode,change,changed))
,cljs.core.PersistentHashSet.EMPTY,chs);
});})(cs,solo_modes,attrs,solo_mode,change,changed))
;
var calc_state = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick){
return (function (){
var chs = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(cs) : cljs.core.deref.call(null,cs));
var mode = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(solo_mode) : cljs.core.deref.call(null,solo_mode));
var solos = pick(cljs.core.cst$kw$solo,chs);
var pauses = pick(cljs.core.cst$kw$pause,chs);
return new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$solos,solos,cljs.core.cst$kw$mutes,pick(cljs.core.cst$kw$mute,chs),cljs.core.cst$kw$reads,cljs.core.conj.cljs$core$IFn$_invoke$arity$2((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,cljs.core.cst$kw$pause)) && (!(cljs.core.empty_QMARK_(solos))))?cljs.core.vec(solos):cljs.core.vec(cljs.core.remove.cljs$core$IFn$_invoke$arity$2(pauses,cljs.core.keys(chs)))),change)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick))
;
var m = (function (){
if(typeof cljs.core.async.t_cljs$core$async29942 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async29942 = (function (change,mix,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,meta29943){
this.change = change;
this.mix = mix;
this.solo_mode = solo_mode;
this.pick = pick;
this.cs = cs;
this.calc_state = calc_state;
this.out = out;
this.changed = changed;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.meta29943 = meta29943;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async29942.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_29944,meta29943__$1){
var self__ = this;
var _29944__$1 = this;
return (new cljs.core.async.t_cljs$core$async29942(self__.change,self__.mix,self__.solo_mode,self__.pick,self__.cs,self__.calc_state,self__.out,self__.changed,self__.solo_modes,self__.attrs,meta29943__$1));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29942.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_29944){
var self__ = this;
var _29944__$1 = this;
return self__.meta29943;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29942.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async29942.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29942.prototype.cljs$core$async$Mix$ = true;

cljs.core.async.t_cljs$core$async29942.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29942.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29942.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
var G__29945_30109 = self__.cs;
var G__29946_30110 = cljs.core.PersistentArrayMap.EMPTY;
(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__29945_30109,G__29946_30110) : cljs.core.reset_BANG_.call(null,G__29945_30109,G__29946_30110));

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29942.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.partial.cljs$core$IFn$_invoke$arity$2(cljs.core.merge_with,cljs.core.merge),state_map);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29942.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,mode){
var self__ = this;
var ___$1 = this;

(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(self__.solo_mode,mode) : cljs.core.reset_BANG_.call(null,self__.solo_mode,mode));

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29942.getBasis = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (){
return new cljs.core.PersistentVector(null, 11, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$change,cljs.core.with_meta(cljs.core.cst$sym$mix,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$out], null))),cljs.core.cst$kw$doc,"Creates and returns a mix of one or more input channels which will\n  be put on the supplied out channel. Input sources can be added to\n  the mix with 'admix', and removed with 'unmix'. A mix supports\n  soloing, muting and pausing multiple inputs atomically using\n  'toggle', and can solo using either muting or pausing as determined\n  by 'solo-mode'.\n\n  Each channel can have zero or more boolean modes set via 'toggle':\n\n  :solo - when true, only this (ond other soloed) channel(s) will appear\n          in the mix output channel. :mute and :pause states of soloed\n          channels are ignored. If solo-mode is :mute, non-soloed\n          channels are muted, if :pause, non-soloed channels are\n          paused.\n\n  :mute - muted channels will have their contents consumed but not included in the mix\n  :pause - paused channels will not have their contents consumed (and thus also not included in the mix)\n"], null)),cljs.core.cst$sym$solo_DASH_mode,cljs.core.cst$sym$pick,cljs.core.cst$sym$cs,cljs.core.cst$sym$calc_DASH_state,cljs.core.cst$sym$out,cljs.core.cst$sym$changed,cljs.core.cst$sym$solo_DASH_modes,cljs.core.cst$sym$attrs,cljs.core.cst$sym$meta29943], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async29942.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async29942.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async29942";

cljs.core.async.t_cljs$core$async29942.cljs$lang$ctorPrWriter = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async29942");
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.__GT_t_cljs$core$async29942 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function cljs$core$async$mix_$___GT_t_cljs$core$async29942(change__$1,mix__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta29943){
return (new cljs.core.async.t_cljs$core$async29942(change__$1,mix__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta29943));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

}

return (new cljs.core.async.t_cljs$core$async29942(change,cljs$core$async$mix,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__15224__auto___30111 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___30111,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___30111,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (state_30046){
var state_val_30047 = (state_30046[(1)]);
if((state_val_30047 === (7))){
var inst_29962 = (state_30046[(2)]);
var state_30046__$1 = state_30046;
var statearr_30048_30112 = state_30046__$1;
(statearr_30048_30112[(2)] = inst_29962);

(statearr_30048_30112[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (20))){
var inst_29974 = (state_30046[(7)]);
var state_30046__$1 = state_30046;
var statearr_30049_30113 = state_30046__$1;
(statearr_30049_30113[(2)] = inst_29974);

(statearr_30049_30113[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (27))){
var state_30046__$1 = state_30046;
var statearr_30050_30114 = state_30046__$1;
(statearr_30050_30114[(2)] = null);

(statearr_30050_30114[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (1))){
var inst_29950 = (state_30046[(8)]);
var inst_29950__$1 = calc_state();
var inst_29952 = (inst_29950__$1 == null);
var inst_29953 = cljs.core.not(inst_29952);
var state_30046__$1 = (function (){var statearr_30051 = state_30046;
(statearr_30051[(8)] = inst_29950__$1);

return statearr_30051;
})();
if(inst_29953){
var statearr_30052_30115 = state_30046__$1;
(statearr_30052_30115[(1)] = (2));

} else {
var statearr_30053_30116 = state_30046__$1;
(statearr_30053_30116[(1)] = (3));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (24))){
var inst_30020 = (state_30046[(9)]);
var inst_30006 = (state_30046[(10)]);
var inst_29997 = (state_30046[(11)]);
var inst_30020__$1 = (inst_29997.cljs$core$IFn$_invoke$arity$1 ? inst_29997.cljs$core$IFn$_invoke$arity$1(inst_30006) : inst_29997.call(null,inst_30006));
var state_30046__$1 = (function (){var statearr_30054 = state_30046;
(statearr_30054[(9)] = inst_30020__$1);

return statearr_30054;
})();
if(cljs.core.truth_(inst_30020__$1)){
var statearr_30055_30117 = state_30046__$1;
(statearr_30055_30117[(1)] = (29));

} else {
var statearr_30056_30118 = state_30046__$1;
(statearr_30056_30118[(1)] = (30));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (4))){
var inst_29965 = (state_30046[(2)]);
var state_30046__$1 = state_30046;
if(cljs.core.truth_(inst_29965)){
var statearr_30057_30119 = state_30046__$1;
(statearr_30057_30119[(1)] = (8));

} else {
var statearr_30058_30120 = state_30046__$1;
(statearr_30058_30120[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (15))){
var inst_29991 = (state_30046[(2)]);
var state_30046__$1 = state_30046;
if(cljs.core.truth_(inst_29991)){
var statearr_30059_30121 = state_30046__$1;
(statearr_30059_30121[(1)] = (19));

} else {
var statearr_30060_30122 = state_30046__$1;
(statearr_30060_30122[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (21))){
var inst_29996 = (state_30046[(12)]);
var inst_29996__$1 = (state_30046[(2)]);
var inst_29997 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29996__$1,cljs.core.cst$kw$solos);
var inst_29998 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29996__$1,cljs.core.cst$kw$mutes);
var inst_29999 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29996__$1,cljs.core.cst$kw$reads);
var state_30046__$1 = (function (){var statearr_30061 = state_30046;
(statearr_30061[(12)] = inst_29996__$1);

(statearr_30061[(13)] = inst_29998);

(statearr_30061[(11)] = inst_29997);

return statearr_30061;
})();
return cljs.core.async.ioc_alts_BANG_(state_30046__$1,(22),inst_29999);
} else {
if((state_val_30047 === (31))){
var inst_30028 = (state_30046[(2)]);
var state_30046__$1 = state_30046;
if(cljs.core.truth_(inst_30028)){
var statearr_30062_30123 = state_30046__$1;
(statearr_30062_30123[(1)] = (32));

} else {
var statearr_30063_30124 = state_30046__$1;
(statearr_30063_30124[(1)] = (33));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (32))){
var inst_30005 = (state_30046[(14)]);
var state_30046__$1 = state_30046;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30046__$1,(35),out,inst_30005);
} else {
if((state_val_30047 === (33))){
var inst_29996 = (state_30046[(12)]);
var inst_29974 = inst_29996;
var state_30046__$1 = (function (){var statearr_30064 = state_30046;
(statearr_30064[(7)] = inst_29974);

return statearr_30064;
})();
var statearr_30065_30125 = state_30046__$1;
(statearr_30065_30125[(2)] = null);

(statearr_30065_30125[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (13))){
var inst_29974 = (state_30046[(7)]);
var inst_29981 = inst_29974.cljs$lang$protocol_mask$partition0$;
var inst_29982 = (inst_29981 & (64));
var inst_29983 = inst_29974.cljs$core$ISeq$;
var inst_29984 = (inst_29982) || (inst_29983);
var state_30046__$1 = state_30046;
if(cljs.core.truth_(inst_29984)){
var statearr_30066_30126 = state_30046__$1;
(statearr_30066_30126[(1)] = (16));

} else {
var statearr_30067_30127 = state_30046__$1;
(statearr_30067_30127[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (22))){
var inst_30006 = (state_30046[(10)]);
var inst_30005 = (state_30046[(14)]);
var inst_30004 = (state_30046[(2)]);
var inst_30005__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30004,(0),null);
var inst_30006__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30004,(1),null);
var inst_30007 = (inst_30005__$1 == null);
var inst_30008 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_30006__$1,change);
var inst_30009 = (inst_30007) || (inst_30008);
var state_30046__$1 = (function (){var statearr_30068 = state_30046;
(statearr_30068[(10)] = inst_30006__$1);

(statearr_30068[(14)] = inst_30005__$1);

return statearr_30068;
})();
if(cljs.core.truth_(inst_30009)){
var statearr_30069_30128 = state_30046__$1;
(statearr_30069_30128[(1)] = (23));

} else {
var statearr_30070_30129 = state_30046__$1;
(statearr_30070_30129[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (36))){
var inst_29996 = (state_30046[(12)]);
var inst_29974 = inst_29996;
var state_30046__$1 = (function (){var statearr_30071 = state_30046;
(statearr_30071[(7)] = inst_29974);

return statearr_30071;
})();
var statearr_30072_30130 = state_30046__$1;
(statearr_30072_30130[(2)] = null);

(statearr_30072_30130[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (29))){
var inst_30020 = (state_30046[(9)]);
var state_30046__$1 = state_30046;
var statearr_30073_30131 = state_30046__$1;
(statearr_30073_30131[(2)] = inst_30020);

(statearr_30073_30131[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (6))){
var state_30046__$1 = state_30046;
var statearr_30074_30132 = state_30046__$1;
(statearr_30074_30132[(2)] = false);

(statearr_30074_30132[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (28))){
var inst_30016 = (state_30046[(2)]);
var inst_30017 = calc_state();
var inst_29974 = inst_30017;
var state_30046__$1 = (function (){var statearr_30075 = state_30046;
(statearr_30075[(15)] = inst_30016);

(statearr_30075[(7)] = inst_29974);

return statearr_30075;
})();
var statearr_30076_30133 = state_30046__$1;
(statearr_30076_30133[(2)] = null);

(statearr_30076_30133[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (25))){
var inst_30042 = (state_30046[(2)]);
var state_30046__$1 = state_30046;
var statearr_30077_30134 = state_30046__$1;
(statearr_30077_30134[(2)] = inst_30042);

(statearr_30077_30134[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (34))){
var inst_30040 = (state_30046[(2)]);
var state_30046__$1 = state_30046;
var statearr_30078_30135 = state_30046__$1;
(statearr_30078_30135[(2)] = inst_30040);

(statearr_30078_30135[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (17))){
var state_30046__$1 = state_30046;
var statearr_30079_30136 = state_30046__$1;
(statearr_30079_30136[(2)] = false);

(statearr_30079_30136[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (3))){
var state_30046__$1 = state_30046;
var statearr_30080_30137 = state_30046__$1;
(statearr_30080_30137[(2)] = false);

(statearr_30080_30137[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (12))){
var inst_30044 = (state_30046[(2)]);
var state_30046__$1 = state_30046;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30046__$1,inst_30044);
} else {
if((state_val_30047 === (2))){
var inst_29950 = (state_30046[(8)]);
var inst_29955 = inst_29950.cljs$lang$protocol_mask$partition0$;
var inst_29956 = (inst_29955 & (64));
var inst_29957 = inst_29950.cljs$core$ISeq$;
var inst_29958 = (inst_29956) || (inst_29957);
var state_30046__$1 = state_30046;
if(cljs.core.truth_(inst_29958)){
var statearr_30081_30138 = state_30046__$1;
(statearr_30081_30138[(1)] = (5));

} else {
var statearr_30082_30139 = state_30046__$1;
(statearr_30082_30139[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (23))){
var inst_30005 = (state_30046[(14)]);
var inst_30011 = (inst_30005 == null);
var state_30046__$1 = state_30046;
if(cljs.core.truth_(inst_30011)){
var statearr_30083_30140 = state_30046__$1;
(statearr_30083_30140[(1)] = (26));

} else {
var statearr_30084_30141 = state_30046__$1;
(statearr_30084_30141[(1)] = (27));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (35))){
var inst_30031 = (state_30046[(2)]);
var state_30046__$1 = state_30046;
if(cljs.core.truth_(inst_30031)){
var statearr_30085_30142 = state_30046__$1;
(statearr_30085_30142[(1)] = (36));

} else {
var statearr_30086_30143 = state_30046__$1;
(statearr_30086_30143[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (19))){
var inst_29974 = (state_30046[(7)]);
var inst_29993 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_29974);
var state_30046__$1 = state_30046;
var statearr_30087_30144 = state_30046__$1;
(statearr_30087_30144[(2)] = inst_29993);

(statearr_30087_30144[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (11))){
var inst_29974 = (state_30046[(7)]);
var inst_29978 = (inst_29974 == null);
var inst_29979 = cljs.core.not(inst_29978);
var state_30046__$1 = state_30046;
if(inst_29979){
var statearr_30088_30145 = state_30046__$1;
(statearr_30088_30145[(1)] = (13));

} else {
var statearr_30089_30146 = state_30046__$1;
(statearr_30089_30146[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (9))){
var inst_29950 = (state_30046[(8)]);
var state_30046__$1 = state_30046;
var statearr_30090_30147 = state_30046__$1;
(statearr_30090_30147[(2)] = inst_29950);

(statearr_30090_30147[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (5))){
var state_30046__$1 = state_30046;
var statearr_30091_30148 = state_30046__$1;
(statearr_30091_30148[(2)] = true);

(statearr_30091_30148[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (14))){
var state_30046__$1 = state_30046;
var statearr_30092_30149 = state_30046__$1;
(statearr_30092_30149[(2)] = false);

(statearr_30092_30149[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (26))){
var inst_30006 = (state_30046[(10)]);
var inst_30013 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(cs,cljs.core.dissoc,inst_30006);
var state_30046__$1 = state_30046;
var statearr_30093_30150 = state_30046__$1;
(statearr_30093_30150[(2)] = inst_30013);

(statearr_30093_30150[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (16))){
var state_30046__$1 = state_30046;
var statearr_30094_30151 = state_30046__$1;
(statearr_30094_30151[(2)] = true);

(statearr_30094_30151[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (38))){
var inst_30036 = (state_30046[(2)]);
var state_30046__$1 = state_30046;
var statearr_30095_30152 = state_30046__$1;
(statearr_30095_30152[(2)] = inst_30036);

(statearr_30095_30152[(1)] = (34));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (30))){
var inst_30006 = (state_30046[(10)]);
var inst_29998 = (state_30046[(13)]);
var inst_29997 = (state_30046[(11)]);
var inst_30023 = cljs.core.empty_QMARK_(inst_29997);
var inst_30024 = (inst_29998.cljs$core$IFn$_invoke$arity$1 ? inst_29998.cljs$core$IFn$_invoke$arity$1(inst_30006) : inst_29998.call(null,inst_30006));
var inst_30025 = cljs.core.not(inst_30024);
var inst_30026 = (inst_30023) && (inst_30025);
var state_30046__$1 = state_30046;
var statearr_30096_30153 = state_30046__$1;
(statearr_30096_30153[(2)] = inst_30026);

(statearr_30096_30153[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (10))){
var inst_29950 = (state_30046[(8)]);
var inst_29970 = (state_30046[(2)]);
var inst_29971 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29970,cljs.core.cst$kw$solos);
var inst_29972 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29970,cljs.core.cst$kw$mutes);
var inst_29973 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_29970,cljs.core.cst$kw$reads);
var inst_29974 = inst_29950;
var state_30046__$1 = (function (){var statearr_30097 = state_30046;
(statearr_30097[(16)] = inst_29971);

(statearr_30097[(17)] = inst_29972);

(statearr_30097[(7)] = inst_29974);

(statearr_30097[(18)] = inst_29973);

return statearr_30097;
})();
var statearr_30098_30154 = state_30046__$1;
(statearr_30098_30154[(2)] = null);

(statearr_30098_30154[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (18))){
var inst_29988 = (state_30046[(2)]);
var state_30046__$1 = state_30046;
var statearr_30099_30155 = state_30046__$1;
(statearr_30099_30155[(2)] = inst_29988);

(statearr_30099_30155[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (37))){
var state_30046__$1 = state_30046;
var statearr_30100_30156 = state_30046__$1;
(statearr_30100_30156[(2)] = null);

(statearr_30100_30156[(1)] = (38));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30047 === (8))){
var inst_29950 = (state_30046[(8)]);
var inst_29967 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_29950);
var state_30046__$1 = state_30046;
var statearr_30101_30157 = state_30046__$1;
(statearr_30101_30157[(2)] = inst_29967);

(statearr_30101_30157[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___30111,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
;
return ((function (switch__15098__auto__,c__15224__auto___30111,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function() {
var cljs$core$async$mix_$_state_machine__15099__auto__ = null;
var cljs$core$async$mix_$_state_machine__15099__auto____0 = (function (){
var statearr_30105 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_30105[(0)] = cljs$core$async$mix_$_state_machine__15099__auto__);

(statearr_30105[(1)] = (1));

return statearr_30105;
});
var cljs$core$async$mix_$_state_machine__15099__auto____1 = (function (state_30046){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_30046);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e30106){if((e30106 instanceof Object)){
var ex__15102__auto__ = e30106;
var statearr_30107_30158 = state_30046;
(statearr_30107_30158[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30046);

return cljs.core.cst$kw$recur;
} else {
throw e30106;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__30159 = state_30046;
state_30046 = G__30159;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__15099__auto__ = function(state_30046){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__15099__auto____1.call(this,state_30046);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__15099__auto____0;
cljs$core$async$mix_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__15099__auto____1;
return cljs$core$async$mix_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___30111,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
})();
var state__15226__auto__ = (function (){var statearr_30108 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_30108[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___30111);

return statearr_30108;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___30111,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
);


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_(mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_(mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_(mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_(mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_(mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((!((p == null))) && (!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__7652__auto__ = (((p == null))?null:p);
var m__7653__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$4 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__7653__auto__.call(null,p,v,ch,close_QMARK_));
} else {
var m__7653__auto____$1 = (cljs.core.async.sub_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$4 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__7653__auto____$1.call(null,p,v,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__7652__auto__ = (((p == null))?null:p);
var m__7653__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$3 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__7653__auto__.call(null,p,v,ch));
} else {
var m__7653__auto____$1 = (cljs.core.async.unsub_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$3 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__7653__auto____$1.call(null,p,v,ch));
} else {
throw cljs.core.missing_protocol("Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var args30160 = [];
var len__8118__auto___30163 = arguments.length;
var i__8119__auto___30164 = (0);
while(true){
if((i__8119__auto___30164 < len__8118__auto___30163)){
args30160.push((arguments[i__8119__auto___30164]));

var G__30165 = (i__8119__auto___30164 + (1));
i__8119__auto___30164 = G__30165;
continue;
} else {
}
break;
}

var G__30162 = args30160.length;
switch (G__30162) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30160.length)].join('')));

}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__7652__auto__ = (((p == null))?null:p);
var m__7653__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__7653__auto__.call(null,p));
} else {
var m__7653__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$1(p) : m__7653__auto____$1.call(null,p));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__7652__auto__ = (((p == null))?null:p);
var m__7653__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__7652__auto__)]);
if(!((m__7653__auto__ == null))){
return (m__7653__auto__.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__7653__auto__.call(null,p,v));
} else {
var m__7653__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if(!((m__7653__auto____$1 == null))){
return (m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2 ? m__7653__auto____$1.cljs$core$IFn$_invoke$arity$2(p,v) : m__7653__auto____$1.call(null,p,v));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2;


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var args30168 = [];
var len__8118__auto___30296 = arguments.length;
var i__8119__auto___30297 = (0);
while(true){
if((i__8119__auto___30297 < len__8118__auto___30296)){
args30168.push((arguments[i__8119__auto___30297]));

var G__30298 = (i__8119__auto___30297 + (1));
i__8119__auto___30297 = G__30298;
continue;
} else {
}
break;
}

var G__30170 = args30168.length;
switch (G__30170) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30168.length)].join('')));

}
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3(ch,topic_fn,cljs.core.constantly(null));
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = (function (){var G__30171 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(G__30171) : cljs.core.atom.call(null,G__30171));
})();
var ensure_mult = ((function (mults){
return (function (topic){
var or__6939__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(mults) : cljs.core.deref.call(null,mults)),topic);
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(mults,((function (or__6939__auto__,mults){
return (function (p1__30167_SHARP_){
if(cljs.core.truth_((p1__30167_SHARP_.cljs$core$IFn$_invoke$arity$1 ? p1__30167_SHARP_.cljs$core$IFn$_invoke$arity$1(topic) : p1__30167_SHARP_.call(null,topic)))){
return p1__30167_SHARP_;
} else {
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__30167_SHARP_,topic,cljs.core.async.mult(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((buf_fn.cljs$core$IFn$_invoke$arity$1 ? buf_fn.cljs$core$IFn$_invoke$arity$1(topic) : buf_fn.call(null,topic)))));
}
});})(or__6939__auto__,mults))
),topic);
}
});})(mults))
;
var p = (function (){
if(typeof cljs.core.async.t_cljs$core$async30172 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async30172 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta30173){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta30173 = meta30173;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async30172.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (mults,ensure_mult){
return (function (_30174,meta30173__$1){
var self__ = this;
var _30174__$1 = this;
return (new cljs.core.async.t_cljs$core$async30172(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta30173__$1));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async30172.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (mults,ensure_mult){
return (function (_30174){
var self__ = this;
var _30174__$1 = this;
return self__.meta30173;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async30172.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async30172.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async30172.prototype.cljs$core$async$Pub$ = true;

cljs.core.async.t_cljs$core$async30172.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = (self__.ensure_mult.cljs$core$IFn$_invoke$arity$1 ? self__.ensure_mult.cljs$core$IFn$_invoke$arity$1(topic) : self__.ensure_mult.call(null,topic));
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(m,ch__$1,close_QMARK_);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async30172.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__6728__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(self__.mults) : cljs.core.deref.call(null,self__.mults)),topic);
if(cljs.core.truth_(temp__6728__auto__)){
var m = temp__6728__auto__;
return cljs.core.async.untap(m,ch__$1);
} else {
return null;
}
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async30172.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
var G__30175 = self__.mults;
var G__30176 = cljs.core.PersistentArrayMap.EMPTY;
return (cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__30175,G__30176) : cljs.core.reset_BANG_.call(null,G__30175,G__30176));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async30172.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = ((function (mults,ensure_mult){
return (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.mults,cljs.core.dissoc,topic);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async30172.getBasis = ((function (mults,ensure_mult){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$topic_DASH_fn,cljs.core.cst$sym$buf_DASH_fn,cljs.core.cst$sym$mults,cljs.core.cst$sym$ensure_DASH_mult,cljs.core.cst$sym$meta30173], null);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async30172.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async30172.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async30172";

cljs.core.async.t_cljs$core$async30172.cljs$lang$ctorPrWriter = ((function (mults,ensure_mult){
return (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async30172");
});})(mults,ensure_mult))
;

cljs.core.async.__GT_t_cljs$core$async30172 = ((function (mults,ensure_mult){
return (function cljs$core$async$__GT_t_cljs$core$async30172(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta30173){
return (new cljs.core.async.t_cljs$core$async30172(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta30173));
});})(mults,ensure_mult))
;

}

return (new cljs.core.async.t_cljs$core$async30172(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__15224__auto___30300 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___30300,mults,ensure_mult,p){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___30300,mults,ensure_mult,p){
return (function (state_30248){
var state_val_30249 = (state_30248[(1)]);
if((state_val_30249 === (7))){
var inst_30244 = (state_30248[(2)]);
var state_30248__$1 = state_30248;
var statearr_30250_30301 = state_30248__$1;
(statearr_30250_30301[(2)] = inst_30244);

(statearr_30250_30301[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (20))){
var state_30248__$1 = state_30248;
var statearr_30251_30302 = state_30248__$1;
(statearr_30251_30302[(2)] = null);

(statearr_30251_30302[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (1))){
var state_30248__$1 = state_30248;
var statearr_30252_30303 = state_30248__$1;
(statearr_30252_30303[(2)] = null);

(statearr_30252_30303[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (24))){
var inst_30227 = (state_30248[(7)]);
var inst_30236 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(mults,cljs.core.dissoc,inst_30227);
var state_30248__$1 = state_30248;
var statearr_30253_30304 = state_30248__$1;
(statearr_30253_30304[(2)] = inst_30236);

(statearr_30253_30304[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (4))){
var inst_30179 = (state_30248[(8)]);
var inst_30179__$1 = (state_30248[(2)]);
var inst_30180 = (inst_30179__$1 == null);
var state_30248__$1 = (function (){var statearr_30254 = state_30248;
(statearr_30254[(8)] = inst_30179__$1);

return statearr_30254;
})();
if(cljs.core.truth_(inst_30180)){
var statearr_30255_30305 = state_30248__$1;
(statearr_30255_30305[(1)] = (5));

} else {
var statearr_30256_30306 = state_30248__$1;
(statearr_30256_30306[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (15))){
var inst_30221 = (state_30248[(2)]);
var state_30248__$1 = state_30248;
var statearr_30257_30307 = state_30248__$1;
(statearr_30257_30307[(2)] = inst_30221);

(statearr_30257_30307[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (21))){
var inst_30241 = (state_30248[(2)]);
var state_30248__$1 = (function (){var statearr_30258 = state_30248;
(statearr_30258[(9)] = inst_30241);

return statearr_30258;
})();
var statearr_30259_30308 = state_30248__$1;
(statearr_30259_30308[(2)] = null);

(statearr_30259_30308[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (13))){
var inst_30203 = (state_30248[(10)]);
var inst_30205 = cljs.core.chunked_seq_QMARK_(inst_30203);
var state_30248__$1 = state_30248;
if(inst_30205){
var statearr_30260_30309 = state_30248__$1;
(statearr_30260_30309[(1)] = (16));

} else {
var statearr_30261_30310 = state_30248__$1;
(statearr_30261_30310[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (22))){
var inst_30233 = (state_30248[(2)]);
var state_30248__$1 = state_30248;
if(cljs.core.truth_(inst_30233)){
var statearr_30262_30311 = state_30248__$1;
(statearr_30262_30311[(1)] = (23));

} else {
var statearr_30263_30312 = state_30248__$1;
(statearr_30263_30312[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (6))){
var inst_30227 = (state_30248[(7)]);
var inst_30229 = (state_30248[(11)]);
var inst_30179 = (state_30248[(8)]);
var inst_30227__$1 = (topic_fn.cljs$core$IFn$_invoke$arity$1 ? topic_fn.cljs$core$IFn$_invoke$arity$1(inst_30179) : topic_fn.call(null,inst_30179));
var inst_30228 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(mults) : cljs.core.deref.call(null,mults));
var inst_30229__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_30228,inst_30227__$1);
var state_30248__$1 = (function (){var statearr_30264 = state_30248;
(statearr_30264[(7)] = inst_30227__$1);

(statearr_30264[(11)] = inst_30229__$1);

return statearr_30264;
})();
if(cljs.core.truth_(inst_30229__$1)){
var statearr_30265_30313 = state_30248__$1;
(statearr_30265_30313[(1)] = (19));

} else {
var statearr_30266_30314 = state_30248__$1;
(statearr_30266_30314[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (25))){
var inst_30238 = (state_30248[(2)]);
var state_30248__$1 = state_30248;
var statearr_30267_30315 = state_30248__$1;
(statearr_30267_30315[(2)] = inst_30238);

(statearr_30267_30315[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (17))){
var inst_30203 = (state_30248[(10)]);
var inst_30212 = cljs.core.first(inst_30203);
var inst_30213 = cljs.core.async.muxch_STAR_(inst_30212);
var inst_30214 = cljs.core.async.close_BANG_(inst_30213);
var inst_30215 = cljs.core.next(inst_30203);
var inst_30189 = inst_30215;
var inst_30190 = null;
var inst_30191 = (0);
var inst_30192 = (0);
var state_30248__$1 = (function (){var statearr_30268 = state_30248;
(statearr_30268[(12)] = inst_30192);

(statearr_30268[(13)] = inst_30191);

(statearr_30268[(14)] = inst_30214);

(statearr_30268[(15)] = inst_30190);

(statearr_30268[(16)] = inst_30189);

return statearr_30268;
})();
var statearr_30269_30316 = state_30248__$1;
(statearr_30269_30316[(2)] = null);

(statearr_30269_30316[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (3))){
var inst_30246 = (state_30248[(2)]);
var state_30248__$1 = state_30248;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30248__$1,inst_30246);
} else {
if((state_val_30249 === (12))){
var inst_30223 = (state_30248[(2)]);
var state_30248__$1 = state_30248;
var statearr_30270_30317 = state_30248__$1;
(statearr_30270_30317[(2)] = inst_30223);

(statearr_30270_30317[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (2))){
var state_30248__$1 = state_30248;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30248__$1,(4),ch);
} else {
if((state_val_30249 === (23))){
var state_30248__$1 = state_30248;
var statearr_30271_30318 = state_30248__$1;
(statearr_30271_30318[(2)] = null);

(statearr_30271_30318[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (19))){
var inst_30229 = (state_30248[(11)]);
var inst_30179 = (state_30248[(8)]);
var inst_30231 = cljs.core.async.muxch_STAR_(inst_30229);
var state_30248__$1 = state_30248;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30248__$1,(22),inst_30231,inst_30179);
} else {
if((state_val_30249 === (11))){
var inst_30189 = (state_30248[(16)]);
var inst_30203 = (state_30248[(10)]);
var inst_30203__$1 = cljs.core.seq(inst_30189);
var state_30248__$1 = (function (){var statearr_30272 = state_30248;
(statearr_30272[(10)] = inst_30203__$1);

return statearr_30272;
})();
if(inst_30203__$1){
var statearr_30273_30319 = state_30248__$1;
(statearr_30273_30319[(1)] = (13));

} else {
var statearr_30274_30320 = state_30248__$1;
(statearr_30274_30320[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (9))){
var inst_30225 = (state_30248[(2)]);
var state_30248__$1 = state_30248;
var statearr_30275_30321 = state_30248__$1;
(statearr_30275_30321[(2)] = inst_30225);

(statearr_30275_30321[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (5))){
var inst_30186 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(mults) : cljs.core.deref.call(null,mults));
var inst_30187 = cljs.core.vals(inst_30186);
var inst_30188 = cljs.core.seq(inst_30187);
var inst_30189 = inst_30188;
var inst_30190 = null;
var inst_30191 = (0);
var inst_30192 = (0);
var state_30248__$1 = (function (){var statearr_30276 = state_30248;
(statearr_30276[(12)] = inst_30192);

(statearr_30276[(13)] = inst_30191);

(statearr_30276[(15)] = inst_30190);

(statearr_30276[(16)] = inst_30189);

return statearr_30276;
})();
var statearr_30277_30322 = state_30248__$1;
(statearr_30277_30322[(2)] = null);

(statearr_30277_30322[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (14))){
var state_30248__$1 = state_30248;
var statearr_30281_30323 = state_30248__$1;
(statearr_30281_30323[(2)] = null);

(statearr_30281_30323[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (16))){
var inst_30203 = (state_30248[(10)]);
var inst_30207 = cljs.core.chunk_first(inst_30203);
var inst_30208 = cljs.core.chunk_rest(inst_30203);
var inst_30209 = cljs.core.count(inst_30207);
var inst_30189 = inst_30208;
var inst_30190 = inst_30207;
var inst_30191 = inst_30209;
var inst_30192 = (0);
var state_30248__$1 = (function (){var statearr_30282 = state_30248;
(statearr_30282[(12)] = inst_30192);

(statearr_30282[(13)] = inst_30191);

(statearr_30282[(15)] = inst_30190);

(statearr_30282[(16)] = inst_30189);

return statearr_30282;
})();
var statearr_30283_30324 = state_30248__$1;
(statearr_30283_30324[(2)] = null);

(statearr_30283_30324[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (10))){
var inst_30192 = (state_30248[(12)]);
var inst_30191 = (state_30248[(13)]);
var inst_30190 = (state_30248[(15)]);
var inst_30189 = (state_30248[(16)]);
var inst_30197 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_30190,inst_30192);
var inst_30198 = cljs.core.async.muxch_STAR_(inst_30197);
var inst_30199 = cljs.core.async.close_BANG_(inst_30198);
var inst_30200 = (inst_30192 + (1));
var tmp30278 = inst_30191;
var tmp30279 = inst_30190;
var tmp30280 = inst_30189;
var inst_30189__$1 = tmp30280;
var inst_30190__$1 = tmp30279;
var inst_30191__$1 = tmp30278;
var inst_30192__$1 = inst_30200;
var state_30248__$1 = (function (){var statearr_30284 = state_30248;
(statearr_30284[(12)] = inst_30192__$1);

(statearr_30284[(13)] = inst_30191__$1);

(statearr_30284[(15)] = inst_30190__$1);

(statearr_30284[(17)] = inst_30199);

(statearr_30284[(16)] = inst_30189__$1);

return statearr_30284;
})();
var statearr_30285_30325 = state_30248__$1;
(statearr_30285_30325[(2)] = null);

(statearr_30285_30325[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (18))){
var inst_30218 = (state_30248[(2)]);
var state_30248__$1 = state_30248;
var statearr_30286_30326 = state_30248__$1;
(statearr_30286_30326[(2)] = inst_30218);

(statearr_30286_30326[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30249 === (8))){
var inst_30192 = (state_30248[(12)]);
var inst_30191 = (state_30248[(13)]);
var inst_30194 = (inst_30192 < inst_30191);
var inst_30195 = inst_30194;
var state_30248__$1 = state_30248;
if(cljs.core.truth_(inst_30195)){
var statearr_30287_30327 = state_30248__$1;
(statearr_30287_30327[(1)] = (10));

} else {
var statearr_30288_30328 = state_30248__$1;
(statearr_30288_30328[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___30300,mults,ensure_mult,p))
;
return ((function (switch__15098__auto__,c__15224__auto___30300,mults,ensure_mult,p){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_30292 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_30292[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_30292[(1)] = (1));

return statearr_30292;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_30248){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_30248);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e30293){if((e30293 instanceof Object)){
var ex__15102__auto__ = e30293;
var statearr_30294_30329 = state_30248;
(statearr_30294_30329[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30248);

return cljs.core.cst$kw$recur;
} else {
throw e30293;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__30330 = state_30248;
state_30248 = G__30330;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_30248){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_30248);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___30300,mults,ensure_mult,p))
})();
var state__15226__auto__ = (function (){var statearr_30295 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_30295[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___30300);

return statearr_30295;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___30300,mults,ensure_mult,p))
);


return p;
});

cljs.core.async.pub.cljs$lang$maxFixedArity = 3;

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var args30331 = [];
var len__8118__auto___30334 = arguments.length;
var i__8119__auto___30335 = (0);
while(true){
if((i__8119__auto___30335 < len__8118__auto___30334)){
args30331.push((arguments[i__8119__auto___30335]));

var G__30336 = (i__8119__auto___30335 + (1));
i__8119__auto___30335 = G__30336;
continue;
} else {
}
break;
}

var G__30333 = args30331.length;
switch (G__30333) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30331.length)].join('')));

}
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4(p,topic,ch,true);
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_(p,topic,ch,close_QMARK_);
});

cljs.core.async.sub.cljs$lang$maxFixedArity = 4;

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_(p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var args30338 = [];
var len__8118__auto___30341 = arguments.length;
var i__8119__auto___30342 = (0);
while(true){
if((i__8119__auto___30342 < len__8118__auto___30341)){
args30338.push((arguments[i__8119__auto___30342]));

var G__30343 = (i__8119__auto___30342 + (1));
i__8119__auto___30342 = G__30343;
continue;
} else {
}
break;
}

var G__30340 = args30338.length;
switch (G__30340) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30338.length)].join('')));

}
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1(p);
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2(p,topic);
});

cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2;

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var args30345 = [];
var len__8118__auto___30416 = arguments.length;
var i__8119__auto___30417 = (0);
while(true){
if((i__8119__auto___30417 < len__8118__auto___30416)){
args30345.push((arguments[i__8119__auto___30417]));

var G__30418 = (i__8119__auto___30417 + (1));
i__8119__auto___30417 = G__30418;
continue;
} else {
}
break;
}

var G__30347 = args30345.length;
switch (G__30347) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30345.length)].join('')));

}
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3(f,chs,null);
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec(chs);
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var cnt = cljs.core.count(chs__$1);
var rets = cljs.core.object_array.cljs$core$IFn$_invoke$arity$1(cnt);
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = (cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null) : cljs.core.atom.call(null,null));
var done = cljs.core.mapv.cljs$core$IFn$_invoke$arity$2(((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (i){
return ((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,rets.slice((0)));
} else {
return null;
}
});
;})(chs__$1,out,cnt,rets,dchan,dctr))
});})(chs__$1,out,cnt,rets,dchan,dctr))
,cljs.core.range.cljs$core$IFn$_invoke$arity$1(cnt));
var c__15224__auto___30420 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___30420,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___30420,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (state_30386){
var state_val_30387 = (state_30386[(1)]);
if((state_val_30387 === (7))){
var state_30386__$1 = state_30386;
var statearr_30388_30421 = state_30386__$1;
(statearr_30388_30421[(2)] = null);

(statearr_30388_30421[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (1))){
var state_30386__$1 = state_30386;
var statearr_30389_30422 = state_30386__$1;
(statearr_30389_30422[(2)] = null);

(statearr_30389_30422[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (4))){
var inst_30350 = (state_30386[(7)]);
var inst_30352 = (inst_30350 < cnt);
var state_30386__$1 = state_30386;
if(cljs.core.truth_(inst_30352)){
var statearr_30390_30423 = state_30386__$1;
(statearr_30390_30423[(1)] = (6));

} else {
var statearr_30391_30424 = state_30386__$1;
(statearr_30391_30424[(1)] = (7));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (15))){
var inst_30382 = (state_30386[(2)]);
var state_30386__$1 = state_30386;
var statearr_30392_30425 = state_30386__$1;
(statearr_30392_30425[(2)] = inst_30382);

(statearr_30392_30425[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (13))){
var inst_30375 = cljs.core.async.close_BANG_(out);
var state_30386__$1 = state_30386;
var statearr_30393_30426 = state_30386__$1;
(statearr_30393_30426[(2)] = inst_30375);

(statearr_30393_30426[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (6))){
var state_30386__$1 = state_30386;
var statearr_30394_30427 = state_30386__$1;
(statearr_30394_30427[(2)] = null);

(statearr_30394_30427[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (3))){
var inst_30384 = (state_30386[(2)]);
var state_30386__$1 = state_30386;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30386__$1,inst_30384);
} else {
if((state_val_30387 === (12))){
var inst_30372 = (state_30386[(8)]);
var inst_30372__$1 = (state_30386[(2)]);
var inst_30373 = cljs.core.some(cljs.core.nil_QMARK_,inst_30372__$1);
var state_30386__$1 = (function (){var statearr_30395 = state_30386;
(statearr_30395[(8)] = inst_30372__$1);

return statearr_30395;
})();
if(cljs.core.truth_(inst_30373)){
var statearr_30396_30428 = state_30386__$1;
(statearr_30396_30428[(1)] = (13));

} else {
var statearr_30397_30429 = state_30386__$1;
(statearr_30397_30429[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (2))){
var inst_30349 = (cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cnt) : cljs.core.reset_BANG_.call(null,dctr,cnt));
var inst_30350 = (0);
var state_30386__$1 = (function (){var statearr_30398 = state_30386;
(statearr_30398[(7)] = inst_30350);

(statearr_30398[(9)] = inst_30349);

return statearr_30398;
})();
var statearr_30399_30430 = state_30386__$1;
(statearr_30399_30430[(2)] = null);

(statearr_30399_30430[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (11))){
var inst_30350 = (state_30386[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame(state_30386,(10),Object,null,(9));
var inst_30359 = (chs__$1.cljs$core$IFn$_invoke$arity$1 ? chs__$1.cljs$core$IFn$_invoke$arity$1(inst_30350) : chs__$1.call(null,inst_30350));
var inst_30360 = (done.cljs$core$IFn$_invoke$arity$1 ? done.cljs$core$IFn$_invoke$arity$1(inst_30350) : done.call(null,inst_30350));
var inst_30361 = cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2(inst_30359,inst_30360);
var state_30386__$1 = state_30386;
var statearr_30400_30431 = state_30386__$1;
(statearr_30400_30431[(2)] = inst_30361);


cljs.core.async.impl.ioc_helpers.process_exception(state_30386__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (9))){
var inst_30350 = (state_30386[(7)]);
var inst_30363 = (state_30386[(2)]);
var inst_30364 = (inst_30350 + (1));
var inst_30350__$1 = inst_30364;
var state_30386__$1 = (function (){var statearr_30401 = state_30386;
(statearr_30401[(7)] = inst_30350__$1);

(statearr_30401[(10)] = inst_30363);

return statearr_30401;
})();
var statearr_30402_30432 = state_30386__$1;
(statearr_30402_30432[(2)] = null);

(statearr_30402_30432[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (5))){
var inst_30370 = (state_30386[(2)]);
var state_30386__$1 = (function (){var statearr_30403 = state_30386;
(statearr_30403[(11)] = inst_30370);

return statearr_30403;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30386__$1,(12),dchan);
} else {
if((state_val_30387 === (14))){
var inst_30372 = (state_30386[(8)]);
var inst_30377 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(f,inst_30372);
var state_30386__$1 = state_30386;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30386__$1,(16),out,inst_30377);
} else {
if((state_val_30387 === (16))){
var inst_30379 = (state_30386[(2)]);
var state_30386__$1 = (function (){var statearr_30404 = state_30386;
(statearr_30404[(12)] = inst_30379);

return statearr_30404;
})();
var statearr_30405_30433 = state_30386__$1;
(statearr_30405_30433[(2)] = null);

(statearr_30405_30433[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (10))){
var inst_30354 = (state_30386[(2)]);
var inst_30355 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec);
var state_30386__$1 = (function (){var statearr_30406 = state_30386;
(statearr_30406[(13)] = inst_30354);

return statearr_30406;
})();
var statearr_30407_30434 = state_30386__$1;
(statearr_30407_30434[(2)] = inst_30355);


cljs.core.async.impl.ioc_helpers.process_exception(state_30386__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_30387 === (8))){
var inst_30368 = (state_30386[(2)]);
var state_30386__$1 = state_30386;
var statearr_30408_30435 = state_30386__$1;
(statearr_30408_30435[(2)] = inst_30368);

(statearr_30408_30435[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___30420,chs__$1,out,cnt,rets,dchan,dctr,done))
;
return ((function (switch__15098__auto__,c__15224__auto___30420,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_30412 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_30412[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_30412[(1)] = (1));

return statearr_30412;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_30386){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_30386);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e30413){if((e30413 instanceof Object)){
var ex__15102__auto__ = e30413;
var statearr_30414_30436 = state_30386;
(statearr_30414_30436[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30386);

return cljs.core.cst$kw$recur;
} else {
throw e30413;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__30437 = state_30386;
state_30386 = G__30437;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_30386){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_30386);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___30420,chs__$1,out,cnt,rets,dchan,dctr,done))
})();
var state__15226__auto__ = (function (){var statearr_30415 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_30415[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___30420);

return statearr_30415;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___30420,chs__$1,out,cnt,rets,dchan,dctr,done))
);


return out;
});

cljs.core.async.map.cljs$lang$maxFixedArity = 3;

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var args30439 = [];
var len__8118__auto___30497 = arguments.length;
var i__8119__auto___30498 = (0);
while(true){
if((i__8119__auto___30498 < len__8118__auto___30497)){
args30439.push((arguments[i__8119__auto___30498]));

var G__30499 = (i__8119__auto___30498 + (1));
i__8119__auto___30498 = G__30499;
continue;
} else {
}
break;
}

var G__30441 = args30439.length;
switch (G__30441) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30439.length)].join('')));

}
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2(chs,null);
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___30501 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___30501,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___30501,out){
return (function (state_30473){
var state_val_30474 = (state_30473[(1)]);
if((state_val_30474 === (7))){
var inst_30452 = (state_30473[(7)]);
var inst_30453 = (state_30473[(8)]);
var inst_30452__$1 = (state_30473[(2)]);
var inst_30453__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30452__$1,(0),null);
var inst_30454 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_30452__$1,(1),null);
var inst_30455 = (inst_30453__$1 == null);
var state_30473__$1 = (function (){var statearr_30475 = state_30473;
(statearr_30475[(7)] = inst_30452__$1);

(statearr_30475[(8)] = inst_30453__$1);

(statearr_30475[(9)] = inst_30454);

return statearr_30475;
})();
if(cljs.core.truth_(inst_30455)){
var statearr_30476_30502 = state_30473__$1;
(statearr_30476_30502[(1)] = (8));

} else {
var statearr_30477_30503 = state_30473__$1;
(statearr_30477_30503[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30474 === (1))){
var inst_30442 = cljs.core.vec(chs);
var inst_30443 = inst_30442;
var state_30473__$1 = (function (){var statearr_30478 = state_30473;
(statearr_30478[(10)] = inst_30443);

return statearr_30478;
})();
var statearr_30479_30504 = state_30473__$1;
(statearr_30479_30504[(2)] = null);

(statearr_30479_30504[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30474 === (4))){
var inst_30443 = (state_30473[(10)]);
var state_30473__$1 = state_30473;
return cljs.core.async.ioc_alts_BANG_(state_30473__$1,(7),inst_30443);
} else {
if((state_val_30474 === (6))){
var inst_30469 = (state_30473[(2)]);
var state_30473__$1 = state_30473;
var statearr_30480_30505 = state_30473__$1;
(statearr_30480_30505[(2)] = inst_30469);

(statearr_30480_30505[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30474 === (3))){
var inst_30471 = (state_30473[(2)]);
var state_30473__$1 = state_30473;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30473__$1,inst_30471);
} else {
if((state_val_30474 === (2))){
var inst_30443 = (state_30473[(10)]);
var inst_30445 = cljs.core.count(inst_30443);
var inst_30446 = (inst_30445 > (0));
var state_30473__$1 = state_30473;
if(cljs.core.truth_(inst_30446)){
var statearr_30482_30506 = state_30473__$1;
(statearr_30482_30506[(1)] = (4));

} else {
var statearr_30483_30507 = state_30473__$1;
(statearr_30483_30507[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30474 === (11))){
var inst_30443 = (state_30473[(10)]);
var inst_30462 = (state_30473[(2)]);
var tmp30481 = inst_30443;
var inst_30443__$1 = tmp30481;
var state_30473__$1 = (function (){var statearr_30484 = state_30473;
(statearr_30484[(11)] = inst_30462);

(statearr_30484[(10)] = inst_30443__$1);

return statearr_30484;
})();
var statearr_30485_30508 = state_30473__$1;
(statearr_30485_30508[(2)] = null);

(statearr_30485_30508[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30474 === (9))){
var inst_30453 = (state_30473[(8)]);
var state_30473__$1 = state_30473;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30473__$1,(11),out,inst_30453);
} else {
if((state_val_30474 === (5))){
var inst_30467 = cljs.core.async.close_BANG_(out);
var state_30473__$1 = state_30473;
var statearr_30486_30509 = state_30473__$1;
(statearr_30486_30509[(2)] = inst_30467);

(statearr_30486_30509[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30474 === (10))){
var inst_30465 = (state_30473[(2)]);
var state_30473__$1 = state_30473;
var statearr_30487_30510 = state_30473__$1;
(statearr_30487_30510[(2)] = inst_30465);

(statearr_30487_30510[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30474 === (8))){
var inst_30452 = (state_30473[(7)]);
var inst_30453 = (state_30473[(8)]);
var inst_30454 = (state_30473[(9)]);
var inst_30443 = (state_30473[(10)]);
var inst_30457 = (function (){var cs = inst_30443;
var vec__30448 = inst_30452;
var v = inst_30453;
var c = inst_30454;
return ((function (cs,vec__30448,v,c,inst_30452,inst_30453,inst_30454,inst_30443,state_val_30474,c__15224__auto___30501,out){
return (function (p1__30438_SHARP_){
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(c,p1__30438_SHARP_);
});
;})(cs,vec__30448,v,c,inst_30452,inst_30453,inst_30454,inst_30443,state_val_30474,c__15224__auto___30501,out))
})();
var inst_30458 = cljs.core.filterv(inst_30457,inst_30443);
var inst_30443__$1 = inst_30458;
var state_30473__$1 = (function (){var statearr_30488 = state_30473;
(statearr_30488[(10)] = inst_30443__$1);

return statearr_30488;
})();
var statearr_30489_30511 = state_30473__$1;
(statearr_30489_30511[(2)] = null);

(statearr_30489_30511[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___30501,out))
;
return ((function (switch__15098__auto__,c__15224__auto___30501,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_30493 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_30493[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_30493[(1)] = (1));

return statearr_30493;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_30473){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_30473);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e30494){if((e30494 instanceof Object)){
var ex__15102__auto__ = e30494;
var statearr_30495_30512 = state_30473;
(statearr_30495_30512[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30473);

return cljs.core.cst$kw$recur;
} else {
throw e30494;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__30513 = state_30473;
state_30473 = G__30513;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_30473){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_30473);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___30501,out))
})();
var state__15226__auto__ = (function (){var statearr_30496 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_30496[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___30501);

return statearr_30496;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___30501,out))
);


return out;
});

cljs.core.async.merge.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce(cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var args30514 = [];
var len__8118__auto___30563 = arguments.length;
var i__8119__auto___30564 = (0);
while(true){
if((i__8119__auto___30564 < len__8118__auto___30563)){
args30514.push((arguments[i__8119__auto___30564]));

var G__30565 = (i__8119__auto___30564 + (1));
i__8119__auto___30564 = G__30565;
continue;
} else {
}
break;
}

var G__30516 = args30514.length;
switch (G__30516) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30514.length)].join('')));

}
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___30567 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___30567,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___30567,out){
return (function (state_30540){
var state_val_30541 = (state_30540[(1)]);
if((state_val_30541 === (7))){
var inst_30522 = (state_30540[(7)]);
var inst_30522__$1 = (state_30540[(2)]);
var inst_30523 = (inst_30522__$1 == null);
var inst_30524 = cljs.core.not(inst_30523);
var state_30540__$1 = (function (){var statearr_30542 = state_30540;
(statearr_30542[(7)] = inst_30522__$1);

return statearr_30542;
})();
if(inst_30524){
var statearr_30543_30568 = state_30540__$1;
(statearr_30543_30568[(1)] = (8));

} else {
var statearr_30544_30569 = state_30540__$1;
(statearr_30544_30569[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30541 === (1))){
var inst_30517 = (0);
var state_30540__$1 = (function (){var statearr_30545 = state_30540;
(statearr_30545[(8)] = inst_30517);

return statearr_30545;
})();
var statearr_30546_30570 = state_30540__$1;
(statearr_30546_30570[(2)] = null);

(statearr_30546_30570[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30541 === (4))){
var state_30540__$1 = state_30540;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30540__$1,(7),ch);
} else {
if((state_val_30541 === (6))){
var inst_30535 = (state_30540[(2)]);
var state_30540__$1 = state_30540;
var statearr_30547_30571 = state_30540__$1;
(statearr_30547_30571[(2)] = inst_30535);

(statearr_30547_30571[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30541 === (3))){
var inst_30537 = (state_30540[(2)]);
var inst_30538 = cljs.core.async.close_BANG_(out);
var state_30540__$1 = (function (){var statearr_30548 = state_30540;
(statearr_30548[(9)] = inst_30537);

return statearr_30548;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_30540__$1,inst_30538);
} else {
if((state_val_30541 === (2))){
var inst_30517 = (state_30540[(8)]);
var inst_30519 = (inst_30517 < n);
var state_30540__$1 = state_30540;
if(cljs.core.truth_(inst_30519)){
var statearr_30549_30572 = state_30540__$1;
(statearr_30549_30572[(1)] = (4));

} else {
var statearr_30550_30573 = state_30540__$1;
(statearr_30550_30573[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30541 === (11))){
var inst_30517 = (state_30540[(8)]);
var inst_30527 = (state_30540[(2)]);
var inst_30528 = (inst_30517 + (1));
var inst_30517__$1 = inst_30528;
var state_30540__$1 = (function (){var statearr_30551 = state_30540;
(statearr_30551[(8)] = inst_30517__$1);

(statearr_30551[(10)] = inst_30527);

return statearr_30551;
})();
var statearr_30552_30574 = state_30540__$1;
(statearr_30552_30574[(2)] = null);

(statearr_30552_30574[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30541 === (9))){
var state_30540__$1 = state_30540;
var statearr_30553_30575 = state_30540__$1;
(statearr_30553_30575[(2)] = null);

(statearr_30553_30575[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30541 === (5))){
var state_30540__$1 = state_30540;
var statearr_30554_30576 = state_30540__$1;
(statearr_30554_30576[(2)] = null);

(statearr_30554_30576[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30541 === (10))){
var inst_30532 = (state_30540[(2)]);
var state_30540__$1 = state_30540;
var statearr_30555_30577 = state_30540__$1;
(statearr_30555_30577[(2)] = inst_30532);

(statearr_30555_30577[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30541 === (8))){
var inst_30522 = (state_30540[(7)]);
var state_30540__$1 = state_30540;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30540__$1,(11),out,inst_30522);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___30567,out))
;
return ((function (switch__15098__auto__,c__15224__auto___30567,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_30559 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_30559[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_30559[(1)] = (1));

return statearr_30559;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_30540){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_30540);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e30560){if((e30560 instanceof Object)){
var ex__15102__auto__ = e30560;
var statearr_30561_30578 = state_30540;
(statearr_30561_30578[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30540);

return cljs.core.cst$kw$recur;
} else {
throw e30560;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__30579 = state_30540;
state_30540 = G__30579;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_30540){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_30540);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___30567,out))
})();
var state__15226__auto__ = (function (){var statearr_30562 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_30562[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___30567);

return statearr_30562;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___30567,out))
);


return out;
});

cljs.core.async.take.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if(typeof cljs.core.async.t_cljs$core$async30589 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async30589 = (function (map_LT_,f,ch,meta30590){
this.map_LT_ = map_LT_;
this.f = f;
this.ch = ch;
this.meta30590 = meta30590;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async30589.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_30591,meta30590__$1){
var self__ = this;
var _30591__$1 = this;
return (new cljs.core.async.t_cljs$core$async30589(self__.map_LT_,self__.f,self__.ch,meta30590__$1));
});

cljs.core.async.t_cljs$core$async30589.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_30591){
var self__ = this;
var _30591__$1 = this;
return self__.meta30590;
});

cljs.core.async.t_cljs$core$async30589.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async30589.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async30589.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async30589.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async30589.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_(self__.ch,(function (){
if(typeof cljs.core.async.t_cljs$core$async30592 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async30592 = (function (map_LT_,f,ch,meta30590,_,fn1,meta30593){
this.map_LT_ = map_LT_;
this.f = f;
this.ch = ch;
this.meta30590 = meta30590;
this._ = _;
this.fn1 = fn1;
this.meta30593 = meta30593;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async30592.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (___$1){
return (function (_30594,meta30593__$1){
var self__ = this;
var _30594__$1 = this;
return (new cljs.core.async.t_cljs$core$async30592(self__.map_LT_,self__.f,self__.ch,self__.meta30590,self__._,self__.fn1,meta30593__$1));
});})(___$1))
;

cljs.core.async.t_cljs$core$async30592.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (___$1){
return (function (_30594){
var self__ = this;
var _30594__$1 = this;
return self__.meta30593;
});})(___$1))
;

cljs.core.async.t_cljs$core$async30592.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async30592.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.fn1);
});})(___$1))
;

cljs.core.async.t_cljs$core$async30592.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
});})(___$1))
;

cljs.core.async.t_cljs$core$async30592.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit(self__.fn1);
return ((function (f1,___$2,___$1){
return (function (p1__30580_SHARP_){
var G__30595 = (((p1__30580_SHARP_ == null))?null:(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(p1__30580_SHARP_) : self__.f.call(null,p1__30580_SHARP_)));
return (f1.cljs$core$IFn$_invoke$arity$1 ? f1.cljs$core$IFn$_invoke$arity$1(G__30595) : f1.call(null,G__30595));
});
;})(f1,___$2,___$1))
});})(___$1))
;

cljs.core.async.t_cljs$core$async30592.getBasis = ((function (___$1){
return (function (){
return new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$map_LT_,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch], null))),cljs.core.cst$kw$doc,"Deprecated - this function will be removed. Use transducer instead"], null)),cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta30590,cljs.core.with_meta(cljs.core.cst$sym$_,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$tag,cljs.core.cst$sym$cljs$core$async_SLASH_t_cljs$core$async30589], null)),cljs.core.cst$sym$fn1,cljs.core.cst$sym$meta30593], null);
});})(___$1))
;

cljs.core.async.t_cljs$core$async30592.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async30592.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async30592";

cljs.core.async.t_cljs$core$async30592.cljs$lang$ctorPrWriter = ((function (___$1){
return (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async30592");
});})(___$1))
;

cljs.core.async.__GT_t_cljs$core$async30592 = ((function (___$1){
return (function cljs$core$async$map_LT__$___GT_t_cljs$core$async30592(map_LT___$1,f__$1,ch__$1,meta30590__$1,___$2,fn1__$1,meta30593){
return (new cljs.core.async.t_cljs$core$async30592(map_LT___$1,f__$1,ch__$1,meta30590__$1,___$2,fn1__$1,meta30593));
});})(___$1))
;

}

return (new cljs.core.async.t_cljs$core$async30592(self__.map_LT_,self__.f,self__.ch,self__.meta30590,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__6927__auto__ = ret;
if(cljs.core.truth_(and__6927__auto__)){
return !(((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret)) == null));
} else {
return and__6927__auto__;
}
})())){
return cljs.core.async.impl.channels.box((function (){var G__30596 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(ret) : cljs.core.deref.call(null,ret));
return (self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(G__30596) : self__.f.call(null,G__30596));
})());
} else {
return ret;
}
});

cljs.core.async.t_cljs$core$async30589.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async30589.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
});

cljs.core.async.t_cljs$core$async30589.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$map_LT_,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch], null))),cljs.core.cst$kw$doc,"Deprecated - this function will be removed. Use transducer instead"], null)),cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta30590], null);
});

cljs.core.async.t_cljs$core$async30589.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async30589.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async30589";

cljs.core.async.t_cljs$core$async30589.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async30589");
});

cljs.core.async.__GT_t_cljs$core$async30589 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async30589(map_LT___$1,f__$1,ch__$1,meta30590){
return (new cljs.core.async.t_cljs$core$async30589(map_LT___$1,f__$1,ch__$1,meta30590));
});

}

return (new cljs.core.async.t_cljs$core$async30589(cljs$core$async$map_LT_,f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if(typeof cljs.core.async.t_cljs$core$async30600 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async30600 = (function (map_GT_,f,ch,meta30601){
this.map_GT_ = map_GT_;
this.f = f;
this.ch = ch;
this.meta30601 = meta30601;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async30600.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_30602,meta30601__$1){
var self__ = this;
var _30602__$1 = this;
return (new cljs.core.async.t_cljs$core$async30600(self__.map_GT_,self__.f,self__.ch,meta30601__$1));
});

cljs.core.async.t_cljs$core$async30600.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_30602){
var self__ = this;
var _30602__$1 = this;
return self__.meta30601;
});

cljs.core.async.t_cljs$core$async30600.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async30600.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async30600.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async30600.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async30600.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async30600.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(val) : self__.f.call(null,val)),fn1);
});

cljs.core.async.t_cljs$core$async30600.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$map_GT_,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch], null))),cljs.core.cst$kw$doc,"Deprecated - this function will be removed. Use transducer instead"], null)),cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta30601], null);
});

cljs.core.async.t_cljs$core$async30600.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async30600.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async30600";

cljs.core.async.t_cljs$core$async30600.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async30600");
});

cljs.core.async.__GT_t_cljs$core$async30600 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async30600(map_GT___$1,f__$1,ch__$1,meta30601){
return (new cljs.core.async.t_cljs$core$async30600(map_GT___$1,f__$1,ch__$1,meta30601));
});

}

return (new cljs.core.async.t_cljs$core$async30600(cljs$core$async$map_GT_,f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if(typeof cljs.core.async.t_cljs$core$async30606 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async30606 = (function (filter_GT_,p,ch,meta30607){
this.filter_GT_ = filter_GT_;
this.p = p;
this.ch = ch;
this.meta30607 = meta30607;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async30606.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_30608,meta30607__$1){
var self__ = this;
var _30608__$1 = this;
return (new cljs.core.async.t_cljs$core$async30606(self__.filter_GT_,self__.p,self__.ch,meta30607__$1));
});

cljs.core.async.t_cljs$core$async30606.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_30608){
var self__ = this;
var _30608__$1 = this;
return self__.meta30607;
});

cljs.core.async.t_cljs$core$async30606.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async30606.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async30606.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async30606.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async30606.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async30606.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async30606.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_((self__.p.cljs$core$IFn$_invoke$arity$1 ? self__.p.cljs$core$IFn$_invoke$arity$1(val) : self__.p.call(null,val)))){
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box(cljs.core.not(cljs.core.async.impl.protocols.closed_QMARK_(self__.ch)));
}
});

cljs.core.async.t_cljs$core$async30606.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(cljs.core.cst$sym$filter_GT_,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$arglists,cljs.core.list(cljs.core.cst$sym$quote,cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$p,cljs.core.cst$sym$ch], null))),cljs.core.cst$kw$doc,"Deprecated - this function will be removed. Use transducer instead"], null)),cljs.core.cst$sym$p,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta30607], null);
});

cljs.core.async.t_cljs$core$async30606.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async30606.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async30606";

cljs.core.async.t_cljs$core$async30606.cljs$lang$ctorPrWriter = (function (this__7591__auto__,writer__7592__auto__,opt__7593__auto__){
return cljs.core._write(writer__7592__auto__,"cljs.core.async/t_cljs$core$async30606");
});

cljs.core.async.__GT_t_cljs$core$async30606 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async30606(filter_GT___$1,p__$1,ch__$1,meta30607){
return (new cljs.core.async.t_cljs$core$async30606(filter_GT___$1,p__$1,ch__$1,meta30607));
});

}

return (new cljs.core.async.t_cljs$core$async30606(cljs$core$async$filter_GT_,p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_(cljs.core.complement(p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var args30609 = [];
var len__8118__auto___30653 = arguments.length;
var i__8119__auto___30654 = (0);
while(true){
if((i__8119__auto___30654 < len__8118__auto___30653)){
args30609.push((arguments[i__8119__auto___30654]));

var G__30655 = (i__8119__auto___30654 + (1));
i__8119__auto___30654 = G__30655;
continue;
} else {
}
break;
}

var G__30611 = args30609.length;
switch (G__30611) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30609.length)].join('')));

}
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___30657 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___30657,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___30657,out){
return (function (state_30632){
var state_val_30633 = (state_30632[(1)]);
if((state_val_30633 === (7))){
var inst_30628 = (state_30632[(2)]);
var state_30632__$1 = state_30632;
var statearr_30634_30658 = state_30632__$1;
(statearr_30634_30658[(2)] = inst_30628);

(statearr_30634_30658[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30633 === (1))){
var state_30632__$1 = state_30632;
var statearr_30635_30659 = state_30632__$1;
(statearr_30635_30659[(2)] = null);

(statearr_30635_30659[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30633 === (4))){
var inst_30614 = (state_30632[(7)]);
var inst_30614__$1 = (state_30632[(2)]);
var inst_30615 = (inst_30614__$1 == null);
var state_30632__$1 = (function (){var statearr_30636 = state_30632;
(statearr_30636[(7)] = inst_30614__$1);

return statearr_30636;
})();
if(cljs.core.truth_(inst_30615)){
var statearr_30637_30660 = state_30632__$1;
(statearr_30637_30660[(1)] = (5));

} else {
var statearr_30638_30661 = state_30632__$1;
(statearr_30638_30661[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30633 === (6))){
var inst_30614 = (state_30632[(7)]);
var inst_30619 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_30614) : p.call(null,inst_30614));
var state_30632__$1 = state_30632;
if(cljs.core.truth_(inst_30619)){
var statearr_30639_30662 = state_30632__$1;
(statearr_30639_30662[(1)] = (8));

} else {
var statearr_30640_30663 = state_30632__$1;
(statearr_30640_30663[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30633 === (3))){
var inst_30630 = (state_30632[(2)]);
var state_30632__$1 = state_30632;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30632__$1,inst_30630);
} else {
if((state_val_30633 === (2))){
var state_30632__$1 = state_30632;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30632__$1,(4),ch);
} else {
if((state_val_30633 === (11))){
var inst_30622 = (state_30632[(2)]);
var state_30632__$1 = state_30632;
var statearr_30641_30664 = state_30632__$1;
(statearr_30641_30664[(2)] = inst_30622);

(statearr_30641_30664[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30633 === (9))){
var state_30632__$1 = state_30632;
var statearr_30642_30665 = state_30632__$1;
(statearr_30642_30665[(2)] = null);

(statearr_30642_30665[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30633 === (5))){
var inst_30617 = cljs.core.async.close_BANG_(out);
var state_30632__$1 = state_30632;
var statearr_30643_30666 = state_30632__$1;
(statearr_30643_30666[(2)] = inst_30617);

(statearr_30643_30666[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30633 === (10))){
var inst_30625 = (state_30632[(2)]);
var state_30632__$1 = (function (){var statearr_30644 = state_30632;
(statearr_30644[(8)] = inst_30625);

return statearr_30644;
})();
var statearr_30645_30667 = state_30632__$1;
(statearr_30645_30667[(2)] = null);

(statearr_30645_30667[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30633 === (8))){
var inst_30614 = (state_30632[(7)]);
var state_30632__$1 = state_30632;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30632__$1,(11),out,inst_30614);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___30657,out))
;
return ((function (switch__15098__auto__,c__15224__auto___30657,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_30649 = [null,null,null,null,null,null,null,null,null];
(statearr_30649[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_30649[(1)] = (1));

return statearr_30649;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_30632){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_30632);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e30650){if((e30650 instanceof Object)){
var ex__15102__auto__ = e30650;
var statearr_30651_30668 = state_30632;
(statearr_30651_30668[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30632);

return cljs.core.cst$kw$recur;
} else {
throw e30650;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__30669 = state_30632;
state_30632 = G__30669;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_30632){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_30632);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___30657,out))
})();
var state__15226__auto__ = (function (){var statearr_30652 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_30652[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___30657);

return statearr_30652;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___30657,out))
);


return out;
});

cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var args30670 = [];
var len__8118__auto___30673 = arguments.length;
var i__8119__auto___30674 = (0);
while(true){
if((i__8119__auto___30674 < len__8118__auto___30673)){
args30670.push((arguments[i__8119__auto___30674]));

var G__30675 = (i__8119__auto___30674 + (1));
i__8119__auto___30674 = G__30675;
continue;
} else {
}
break;
}

var G__30672 = args30670.length;
switch (G__30672) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30670.length)].join('')));

}
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(cljs.core.complement(p),ch,buf_or_n);
});

cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3;

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_30842){
var state_val_30843 = (state_30842[(1)]);
if((state_val_30843 === (7))){
var inst_30838 = (state_30842[(2)]);
var state_30842__$1 = state_30842;
var statearr_30844_30885 = state_30842__$1;
(statearr_30844_30885[(2)] = inst_30838);

(statearr_30844_30885[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (20))){
var inst_30808 = (state_30842[(7)]);
var inst_30819 = (state_30842[(2)]);
var inst_30820 = cljs.core.next(inst_30808);
var inst_30794 = inst_30820;
var inst_30795 = null;
var inst_30796 = (0);
var inst_30797 = (0);
var state_30842__$1 = (function (){var statearr_30845 = state_30842;
(statearr_30845[(8)] = inst_30797);

(statearr_30845[(9)] = inst_30794);

(statearr_30845[(10)] = inst_30819);

(statearr_30845[(11)] = inst_30795);

(statearr_30845[(12)] = inst_30796);

return statearr_30845;
})();
var statearr_30846_30886 = state_30842__$1;
(statearr_30846_30886[(2)] = null);

(statearr_30846_30886[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (1))){
var state_30842__$1 = state_30842;
var statearr_30847_30887 = state_30842__$1;
(statearr_30847_30887[(2)] = null);

(statearr_30847_30887[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (4))){
var inst_30783 = (state_30842[(13)]);
var inst_30783__$1 = (state_30842[(2)]);
var inst_30784 = (inst_30783__$1 == null);
var state_30842__$1 = (function (){var statearr_30848 = state_30842;
(statearr_30848[(13)] = inst_30783__$1);

return statearr_30848;
})();
if(cljs.core.truth_(inst_30784)){
var statearr_30849_30888 = state_30842__$1;
(statearr_30849_30888[(1)] = (5));

} else {
var statearr_30850_30889 = state_30842__$1;
(statearr_30850_30889[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (15))){
var state_30842__$1 = state_30842;
var statearr_30854_30890 = state_30842__$1;
(statearr_30854_30890[(2)] = null);

(statearr_30854_30890[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (21))){
var state_30842__$1 = state_30842;
var statearr_30855_30891 = state_30842__$1;
(statearr_30855_30891[(2)] = null);

(statearr_30855_30891[(1)] = (23));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (13))){
var inst_30797 = (state_30842[(8)]);
var inst_30794 = (state_30842[(9)]);
var inst_30795 = (state_30842[(11)]);
var inst_30796 = (state_30842[(12)]);
var inst_30804 = (state_30842[(2)]);
var inst_30805 = (inst_30797 + (1));
var tmp30851 = inst_30794;
var tmp30852 = inst_30795;
var tmp30853 = inst_30796;
var inst_30794__$1 = tmp30851;
var inst_30795__$1 = tmp30852;
var inst_30796__$1 = tmp30853;
var inst_30797__$1 = inst_30805;
var state_30842__$1 = (function (){var statearr_30856 = state_30842;
(statearr_30856[(8)] = inst_30797__$1);

(statearr_30856[(9)] = inst_30794__$1);

(statearr_30856[(14)] = inst_30804);

(statearr_30856[(11)] = inst_30795__$1);

(statearr_30856[(12)] = inst_30796__$1);

return statearr_30856;
})();
var statearr_30857_30892 = state_30842__$1;
(statearr_30857_30892[(2)] = null);

(statearr_30857_30892[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (22))){
var state_30842__$1 = state_30842;
var statearr_30858_30893 = state_30842__$1;
(statearr_30858_30893[(2)] = null);

(statearr_30858_30893[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (6))){
var inst_30783 = (state_30842[(13)]);
var inst_30792 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_30783) : f.call(null,inst_30783));
var inst_30793 = cljs.core.seq(inst_30792);
var inst_30794 = inst_30793;
var inst_30795 = null;
var inst_30796 = (0);
var inst_30797 = (0);
var state_30842__$1 = (function (){var statearr_30859 = state_30842;
(statearr_30859[(8)] = inst_30797);

(statearr_30859[(9)] = inst_30794);

(statearr_30859[(11)] = inst_30795);

(statearr_30859[(12)] = inst_30796);

return statearr_30859;
})();
var statearr_30860_30894 = state_30842__$1;
(statearr_30860_30894[(2)] = null);

(statearr_30860_30894[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (17))){
var inst_30808 = (state_30842[(7)]);
var inst_30812 = cljs.core.chunk_first(inst_30808);
var inst_30813 = cljs.core.chunk_rest(inst_30808);
var inst_30814 = cljs.core.count(inst_30812);
var inst_30794 = inst_30813;
var inst_30795 = inst_30812;
var inst_30796 = inst_30814;
var inst_30797 = (0);
var state_30842__$1 = (function (){var statearr_30861 = state_30842;
(statearr_30861[(8)] = inst_30797);

(statearr_30861[(9)] = inst_30794);

(statearr_30861[(11)] = inst_30795);

(statearr_30861[(12)] = inst_30796);

return statearr_30861;
})();
var statearr_30862_30895 = state_30842__$1;
(statearr_30862_30895[(2)] = null);

(statearr_30862_30895[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (3))){
var inst_30840 = (state_30842[(2)]);
var state_30842__$1 = state_30842;
return cljs.core.async.impl.ioc_helpers.return_chan(state_30842__$1,inst_30840);
} else {
if((state_val_30843 === (12))){
var inst_30828 = (state_30842[(2)]);
var state_30842__$1 = state_30842;
var statearr_30863_30896 = state_30842__$1;
(statearr_30863_30896[(2)] = inst_30828);

(statearr_30863_30896[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (2))){
var state_30842__$1 = state_30842;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30842__$1,(4),in$);
} else {
if((state_val_30843 === (23))){
var inst_30836 = (state_30842[(2)]);
var state_30842__$1 = state_30842;
var statearr_30864_30897 = state_30842__$1;
(statearr_30864_30897[(2)] = inst_30836);

(statearr_30864_30897[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (19))){
var inst_30823 = (state_30842[(2)]);
var state_30842__$1 = state_30842;
var statearr_30865_30898 = state_30842__$1;
(statearr_30865_30898[(2)] = inst_30823);

(statearr_30865_30898[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (11))){
var inst_30808 = (state_30842[(7)]);
var inst_30794 = (state_30842[(9)]);
var inst_30808__$1 = cljs.core.seq(inst_30794);
var state_30842__$1 = (function (){var statearr_30866 = state_30842;
(statearr_30866[(7)] = inst_30808__$1);

return statearr_30866;
})();
if(inst_30808__$1){
var statearr_30867_30899 = state_30842__$1;
(statearr_30867_30899[(1)] = (14));

} else {
var statearr_30868_30900 = state_30842__$1;
(statearr_30868_30900[(1)] = (15));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (9))){
var inst_30830 = (state_30842[(2)]);
var inst_30831 = cljs.core.async.impl.protocols.closed_QMARK_(out);
var state_30842__$1 = (function (){var statearr_30869 = state_30842;
(statearr_30869[(15)] = inst_30830);

return statearr_30869;
})();
if(cljs.core.truth_(inst_30831)){
var statearr_30870_30901 = state_30842__$1;
(statearr_30870_30901[(1)] = (21));

} else {
var statearr_30871_30902 = state_30842__$1;
(statearr_30871_30902[(1)] = (22));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (5))){
var inst_30786 = cljs.core.async.close_BANG_(out);
var state_30842__$1 = state_30842;
var statearr_30872_30903 = state_30842__$1;
(statearr_30872_30903[(2)] = inst_30786);

(statearr_30872_30903[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (14))){
var inst_30808 = (state_30842[(7)]);
var inst_30810 = cljs.core.chunked_seq_QMARK_(inst_30808);
var state_30842__$1 = state_30842;
if(inst_30810){
var statearr_30873_30904 = state_30842__$1;
(statearr_30873_30904[(1)] = (17));

} else {
var statearr_30874_30905 = state_30842__$1;
(statearr_30874_30905[(1)] = (18));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (16))){
var inst_30826 = (state_30842[(2)]);
var state_30842__$1 = state_30842;
var statearr_30875_30906 = state_30842__$1;
(statearr_30875_30906[(2)] = inst_30826);

(statearr_30875_30906[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30843 === (10))){
var inst_30797 = (state_30842[(8)]);
var inst_30795 = (state_30842[(11)]);
var inst_30802 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_30795,inst_30797);
var state_30842__$1 = state_30842;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30842__$1,(13),out,inst_30802);
} else {
if((state_val_30843 === (18))){
var inst_30808 = (state_30842[(7)]);
var inst_30817 = cljs.core.first(inst_30808);
var state_30842__$1 = state_30842;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30842__$1,(20),out,inst_30817);
} else {
if((state_val_30843 === (8))){
var inst_30797 = (state_30842[(8)]);
var inst_30796 = (state_30842[(12)]);
var inst_30799 = (inst_30797 < inst_30796);
var inst_30800 = inst_30799;
var state_30842__$1 = state_30842;
if(cljs.core.truth_(inst_30800)){
var statearr_30876_30907 = state_30842__$1;
(statearr_30876_30907[(1)] = (10));

} else {
var statearr_30877_30908 = state_30842__$1;
(statearr_30877_30908[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____0 = (function (){
var statearr_30881 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_30881[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__);

(statearr_30881[(1)] = (1));

return statearr_30881;
});
var cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____1 = (function (state_30842){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_30842);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e30882){if((e30882 instanceof Object)){
var ex__15102__auto__ = e30882;
var statearr_30883_30909 = state_30842;
(statearr_30883_30909[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30842);

return cljs.core.cst$kw$recur;
} else {
throw e30882;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__30910 = state_30842;
state_30842 = G__30910;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__ = function(state_30842){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____1.call(this,state_30842);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__15099__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_30884 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_30884[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_30884;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var args30911 = [];
var len__8118__auto___30914 = arguments.length;
var i__8119__auto___30915 = (0);
while(true){
if((i__8119__auto___30915 < len__8118__auto___30914)){
args30911.push((arguments[i__8119__auto___30915]));

var G__30916 = (i__8119__auto___30915 + (1));
i__8119__auto___30915 = G__30916;
continue;
} else {
}
break;
}

var G__30913 = args30911.length;
switch (G__30913) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30911.length)].join('')));

}
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3(f,in$,null);
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return out;
});

cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var args30918 = [];
var len__8118__auto___30921 = arguments.length;
var i__8119__auto___30922 = (0);
while(true){
if((i__8119__auto___30922 < len__8118__auto___30921)){
args30918.push((arguments[i__8119__auto___30922]));

var G__30923 = (i__8119__auto___30922 + (1));
i__8119__auto___30922 = G__30923;
continue;
} else {
}
break;
}

var G__30920 = args30918.length;
switch (G__30920) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30918.length)].join('')));

}
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3(f,out,null);
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return in$;
});

cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var args30925 = [];
var len__8118__auto___30976 = arguments.length;
var i__8119__auto___30977 = (0);
while(true){
if((i__8119__auto___30977 < len__8118__auto___30976)){
args30925.push((arguments[i__8119__auto___30977]));

var G__30978 = (i__8119__auto___30977 + (1));
i__8119__auto___30977 = G__30978;
continue;
} else {
}
break;
}

var G__30927 = args30925.length;
switch (G__30927) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30925.length)].join('')));

}
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2(ch,null);
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___30980 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___30980,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___30980,out){
return (function (state_30951){
var state_val_30952 = (state_30951[(1)]);
if((state_val_30952 === (7))){
var inst_30946 = (state_30951[(2)]);
var state_30951__$1 = state_30951;
var statearr_30953_30981 = state_30951__$1;
(statearr_30953_30981[(2)] = inst_30946);

(statearr_30953_30981[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30952 === (1))){
var inst_30928 = null;
var state_30951__$1 = (function (){var statearr_30954 = state_30951;
(statearr_30954[(7)] = inst_30928);

return statearr_30954;
})();
var statearr_30955_30982 = state_30951__$1;
(statearr_30955_30982[(2)] = null);

(statearr_30955_30982[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30952 === (4))){
var inst_30931 = (state_30951[(8)]);
var inst_30931__$1 = (state_30951[(2)]);
var inst_30932 = (inst_30931__$1 == null);
var inst_30933 = cljs.core.not(inst_30932);
var state_30951__$1 = (function (){var statearr_30956 = state_30951;
(statearr_30956[(8)] = inst_30931__$1);

return statearr_30956;
})();
if(inst_30933){
var statearr_30957_30983 = state_30951__$1;
(statearr_30957_30983[(1)] = (5));

} else {
var statearr_30958_30984 = state_30951__$1;
(statearr_30958_30984[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30952 === (6))){
var state_30951__$1 = state_30951;
var statearr_30959_30985 = state_30951__$1;
(statearr_30959_30985[(2)] = null);

(statearr_30959_30985[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30952 === (3))){
var inst_30948 = (state_30951[(2)]);
var inst_30949 = cljs.core.async.close_BANG_(out);
var state_30951__$1 = (function (){var statearr_30960 = state_30951;
(statearr_30960[(9)] = inst_30948);

return statearr_30960;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_30951__$1,inst_30949);
} else {
if((state_val_30952 === (2))){
var state_30951__$1 = state_30951;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_30951__$1,(4),ch);
} else {
if((state_val_30952 === (11))){
var inst_30931 = (state_30951[(8)]);
var inst_30940 = (state_30951[(2)]);
var inst_30928 = inst_30931;
var state_30951__$1 = (function (){var statearr_30961 = state_30951;
(statearr_30961[(7)] = inst_30928);

(statearr_30961[(10)] = inst_30940);

return statearr_30961;
})();
var statearr_30962_30986 = state_30951__$1;
(statearr_30962_30986[(2)] = null);

(statearr_30962_30986[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30952 === (9))){
var inst_30931 = (state_30951[(8)]);
var state_30951__$1 = state_30951;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_30951__$1,(11),out,inst_30931);
} else {
if((state_val_30952 === (5))){
var inst_30931 = (state_30951[(8)]);
var inst_30928 = (state_30951[(7)]);
var inst_30935 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_30931,inst_30928);
var state_30951__$1 = state_30951;
if(inst_30935){
var statearr_30964_30987 = state_30951__$1;
(statearr_30964_30987[(1)] = (8));

} else {
var statearr_30965_30988 = state_30951__$1;
(statearr_30965_30988[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_30952 === (10))){
var inst_30943 = (state_30951[(2)]);
var state_30951__$1 = state_30951;
var statearr_30966_30989 = state_30951__$1;
(statearr_30966_30989[(2)] = inst_30943);

(statearr_30966_30989[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_30952 === (8))){
var inst_30928 = (state_30951[(7)]);
var tmp30963 = inst_30928;
var inst_30928__$1 = tmp30963;
var state_30951__$1 = (function (){var statearr_30967 = state_30951;
(statearr_30967[(7)] = inst_30928__$1);

return statearr_30967;
})();
var statearr_30968_30990 = state_30951__$1;
(statearr_30968_30990[(2)] = null);

(statearr_30968_30990[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___30980,out))
;
return ((function (switch__15098__auto__,c__15224__auto___30980,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_30972 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_30972[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_30972[(1)] = (1));

return statearr_30972;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_30951){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_30951);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e30973){if((e30973 instanceof Object)){
var ex__15102__auto__ = e30973;
var statearr_30974_30991 = state_30951;
(statearr_30974_30991[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_30951);

return cljs.core.cst$kw$recur;
} else {
throw e30973;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__30992 = state_30951;
state_30951 = G__30992;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_30951){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_30951);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___30980,out))
})();
var state__15226__auto__ = (function (){var statearr_30975 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_30975[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___30980);

return statearr_30975;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___30980,out))
);


return out;
});

cljs.core.async.unique.cljs$lang$maxFixedArity = 2;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var args30993 = [];
var len__8118__auto___31063 = arguments.length;
var i__8119__auto___31064 = (0);
while(true){
if((i__8119__auto___31064 < len__8118__auto___31063)){
args30993.push((arguments[i__8119__auto___31064]));

var G__31065 = (i__8119__auto___31064 + (1));
i__8119__auto___31064 = G__31065;
continue;
} else {
}
break;
}

var G__30995 = args30993.length;
switch (G__30995) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args30993.length)].join('')));

}
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___31067 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___31067,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___31067,out){
return (function (state_31033){
var state_val_31034 = (state_31033[(1)]);
if((state_val_31034 === (7))){
var inst_31029 = (state_31033[(2)]);
var state_31033__$1 = state_31033;
var statearr_31035_31068 = state_31033__$1;
(statearr_31035_31068[(2)] = inst_31029);

(statearr_31035_31068[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31034 === (1))){
var inst_30996 = (new Array(n));
var inst_30997 = inst_30996;
var inst_30998 = (0);
var state_31033__$1 = (function (){var statearr_31036 = state_31033;
(statearr_31036[(7)] = inst_30997);

(statearr_31036[(8)] = inst_30998);

return statearr_31036;
})();
var statearr_31037_31069 = state_31033__$1;
(statearr_31037_31069[(2)] = null);

(statearr_31037_31069[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31034 === (4))){
var inst_31001 = (state_31033[(9)]);
var inst_31001__$1 = (state_31033[(2)]);
var inst_31002 = (inst_31001__$1 == null);
var inst_31003 = cljs.core.not(inst_31002);
var state_31033__$1 = (function (){var statearr_31038 = state_31033;
(statearr_31038[(9)] = inst_31001__$1);

return statearr_31038;
})();
if(inst_31003){
var statearr_31039_31070 = state_31033__$1;
(statearr_31039_31070[(1)] = (5));

} else {
var statearr_31040_31071 = state_31033__$1;
(statearr_31040_31071[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31034 === (15))){
var inst_31023 = (state_31033[(2)]);
var state_31033__$1 = state_31033;
var statearr_31041_31072 = state_31033__$1;
(statearr_31041_31072[(2)] = inst_31023);

(statearr_31041_31072[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31034 === (13))){
var state_31033__$1 = state_31033;
var statearr_31042_31073 = state_31033__$1;
(statearr_31042_31073[(2)] = null);

(statearr_31042_31073[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31034 === (6))){
var inst_30998 = (state_31033[(8)]);
var inst_31019 = (inst_30998 > (0));
var state_31033__$1 = state_31033;
if(cljs.core.truth_(inst_31019)){
var statearr_31043_31074 = state_31033__$1;
(statearr_31043_31074[(1)] = (12));

} else {
var statearr_31044_31075 = state_31033__$1;
(statearr_31044_31075[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31034 === (3))){
var inst_31031 = (state_31033[(2)]);
var state_31033__$1 = state_31033;
return cljs.core.async.impl.ioc_helpers.return_chan(state_31033__$1,inst_31031);
} else {
if((state_val_31034 === (12))){
var inst_30997 = (state_31033[(7)]);
var inst_31021 = cljs.core.vec(inst_30997);
var state_31033__$1 = state_31033;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31033__$1,(15),out,inst_31021);
} else {
if((state_val_31034 === (2))){
var state_31033__$1 = state_31033;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_31033__$1,(4),ch);
} else {
if((state_val_31034 === (11))){
var inst_31013 = (state_31033[(2)]);
var inst_31014 = (new Array(n));
var inst_30997 = inst_31014;
var inst_30998 = (0);
var state_31033__$1 = (function (){var statearr_31045 = state_31033;
(statearr_31045[(7)] = inst_30997);

(statearr_31045[(10)] = inst_31013);

(statearr_31045[(8)] = inst_30998);

return statearr_31045;
})();
var statearr_31046_31076 = state_31033__$1;
(statearr_31046_31076[(2)] = null);

(statearr_31046_31076[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31034 === (9))){
var inst_30997 = (state_31033[(7)]);
var inst_31011 = cljs.core.vec(inst_30997);
var state_31033__$1 = state_31033;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31033__$1,(11),out,inst_31011);
} else {
if((state_val_31034 === (5))){
var inst_30997 = (state_31033[(7)]);
var inst_31006 = (state_31033[(11)]);
var inst_30998 = (state_31033[(8)]);
var inst_31001 = (state_31033[(9)]);
var inst_31005 = (inst_30997[inst_30998] = inst_31001);
var inst_31006__$1 = (inst_30998 + (1));
var inst_31007 = (inst_31006__$1 < n);
var state_31033__$1 = (function (){var statearr_31047 = state_31033;
(statearr_31047[(12)] = inst_31005);

(statearr_31047[(11)] = inst_31006__$1);

return statearr_31047;
})();
if(cljs.core.truth_(inst_31007)){
var statearr_31048_31077 = state_31033__$1;
(statearr_31048_31077[(1)] = (8));

} else {
var statearr_31049_31078 = state_31033__$1;
(statearr_31049_31078[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31034 === (14))){
var inst_31026 = (state_31033[(2)]);
var inst_31027 = cljs.core.async.close_BANG_(out);
var state_31033__$1 = (function (){var statearr_31051 = state_31033;
(statearr_31051[(13)] = inst_31026);

return statearr_31051;
})();
var statearr_31052_31079 = state_31033__$1;
(statearr_31052_31079[(2)] = inst_31027);

(statearr_31052_31079[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31034 === (10))){
var inst_31017 = (state_31033[(2)]);
var state_31033__$1 = state_31033;
var statearr_31053_31080 = state_31033__$1;
(statearr_31053_31080[(2)] = inst_31017);

(statearr_31053_31080[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31034 === (8))){
var inst_30997 = (state_31033[(7)]);
var inst_31006 = (state_31033[(11)]);
var tmp31050 = inst_30997;
var inst_30997__$1 = tmp31050;
var inst_30998 = inst_31006;
var state_31033__$1 = (function (){var statearr_31054 = state_31033;
(statearr_31054[(7)] = inst_30997__$1);

(statearr_31054[(8)] = inst_30998);

return statearr_31054;
})();
var statearr_31055_31081 = state_31033__$1;
(statearr_31055_31081[(2)] = null);

(statearr_31055_31081[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___31067,out))
;
return ((function (switch__15098__auto__,c__15224__auto___31067,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_31059 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_31059[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_31059[(1)] = (1));

return statearr_31059;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_31033){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_31033);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e31060){if((e31060 instanceof Object)){
var ex__15102__auto__ = e31060;
var statearr_31061_31082 = state_31033;
(statearr_31061_31082[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_31033);

return cljs.core.cst$kw$recur;
} else {
throw e31060;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__31083 = state_31033;
state_31033 = G__31083;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_31033){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_31033);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___31067,out))
})();
var state__15226__auto__ = (function (){var statearr_31062 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_31062[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___31067);

return statearr_31062;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___31067,out))
);


return out;
});

cljs.core.async.partition.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var args31084 = [];
var len__8118__auto___31158 = arguments.length;
var i__8119__auto___31159 = (0);
while(true){
if((i__8119__auto___31159 < len__8118__auto___31158)){
args31084.push((arguments[i__8119__auto___31159]));

var G__31160 = (i__8119__auto___31159 + (1));
i__8119__auto___31159 = G__31160;
continue;
} else {
}
break;
}

var G__31086 = args31084.length;
switch (G__31086) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args31084.length)].join('')));

}
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3(f,ch,null);
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__15224__auto___31162 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___31162,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___31162,out){
return (function (state_31128){
var state_val_31129 = (state_31128[(1)]);
if((state_val_31129 === (7))){
var inst_31124 = (state_31128[(2)]);
var state_31128__$1 = state_31128;
var statearr_31130_31163 = state_31128__$1;
(statearr_31130_31163[(2)] = inst_31124);

(statearr_31130_31163[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31129 === (1))){
var inst_31087 = [];
var inst_31088 = inst_31087;
var inst_31089 = cljs.core.cst$kw$cljs$core$async_SLASH_nothing;
var state_31128__$1 = (function (){var statearr_31131 = state_31128;
(statearr_31131[(7)] = inst_31089);

(statearr_31131[(8)] = inst_31088);

return statearr_31131;
})();
var statearr_31132_31164 = state_31128__$1;
(statearr_31132_31164[(2)] = null);

(statearr_31132_31164[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31129 === (4))){
var inst_31092 = (state_31128[(9)]);
var inst_31092__$1 = (state_31128[(2)]);
var inst_31093 = (inst_31092__$1 == null);
var inst_31094 = cljs.core.not(inst_31093);
var state_31128__$1 = (function (){var statearr_31133 = state_31128;
(statearr_31133[(9)] = inst_31092__$1);

return statearr_31133;
})();
if(inst_31094){
var statearr_31134_31165 = state_31128__$1;
(statearr_31134_31165[(1)] = (5));

} else {
var statearr_31135_31166 = state_31128__$1;
(statearr_31135_31166[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31129 === (15))){
var inst_31118 = (state_31128[(2)]);
var state_31128__$1 = state_31128;
var statearr_31136_31167 = state_31128__$1;
(statearr_31136_31167[(2)] = inst_31118);

(statearr_31136_31167[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31129 === (13))){
var state_31128__$1 = state_31128;
var statearr_31137_31168 = state_31128__$1;
(statearr_31137_31168[(2)] = null);

(statearr_31137_31168[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31129 === (6))){
var inst_31088 = (state_31128[(8)]);
var inst_31113 = inst_31088.length;
var inst_31114 = (inst_31113 > (0));
var state_31128__$1 = state_31128;
if(cljs.core.truth_(inst_31114)){
var statearr_31138_31169 = state_31128__$1;
(statearr_31138_31169[(1)] = (12));

} else {
var statearr_31139_31170 = state_31128__$1;
(statearr_31139_31170[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31129 === (3))){
var inst_31126 = (state_31128[(2)]);
var state_31128__$1 = state_31128;
return cljs.core.async.impl.ioc_helpers.return_chan(state_31128__$1,inst_31126);
} else {
if((state_val_31129 === (12))){
var inst_31088 = (state_31128[(8)]);
var inst_31116 = cljs.core.vec(inst_31088);
var state_31128__$1 = state_31128;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31128__$1,(15),out,inst_31116);
} else {
if((state_val_31129 === (2))){
var state_31128__$1 = state_31128;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_31128__$1,(4),ch);
} else {
if((state_val_31129 === (11))){
var inst_31092 = (state_31128[(9)]);
var inst_31096 = (state_31128[(10)]);
var inst_31106 = (state_31128[(2)]);
var inst_31107 = [];
var inst_31108 = inst_31107.push(inst_31092);
var inst_31088 = inst_31107;
var inst_31089 = inst_31096;
var state_31128__$1 = (function (){var statearr_31140 = state_31128;
(statearr_31140[(7)] = inst_31089);

(statearr_31140[(8)] = inst_31088);

(statearr_31140[(11)] = inst_31106);

(statearr_31140[(12)] = inst_31108);

return statearr_31140;
})();
var statearr_31141_31171 = state_31128__$1;
(statearr_31141_31171[(2)] = null);

(statearr_31141_31171[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31129 === (9))){
var inst_31088 = (state_31128[(8)]);
var inst_31104 = cljs.core.vec(inst_31088);
var state_31128__$1 = state_31128;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_31128__$1,(11),out,inst_31104);
} else {
if((state_val_31129 === (5))){
var inst_31092 = (state_31128[(9)]);
var inst_31096 = (state_31128[(10)]);
var inst_31089 = (state_31128[(7)]);
var inst_31096__$1 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_31092) : f.call(null,inst_31092));
var inst_31097 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_31096__$1,inst_31089);
var inst_31098 = cljs.core.keyword_identical_QMARK_(inst_31089,cljs.core.cst$kw$cljs$core$async_SLASH_nothing);
var inst_31099 = (inst_31097) || (inst_31098);
var state_31128__$1 = (function (){var statearr_31142 = state_31128;
(statearr_31142[(10)] = inst_31096__$1);

return statearr_31142;
})();
if(cljs.core.truth_(inst_31099)){
var statearr_31143_31172 = state_31128__$1;
(statearr_31143_31172[(1)] = (8));

} else {
var statearr_31144_31173 = state_31128__$1;
(statearr_31144_31173[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_31129 === (14))){
var inst_31121 = (state_31128[(2)]);
var inst_31122 = cljs.core.async.close_BANG_(out);
var state_31128__$1 = (function (){var statearr_31146 = state_31128;
(statearr_31146[(13)] = inst_31121);

return statearr_31146;
})();
var statearr_31147_31174 = state_31128__$1;
(statearr_31147_31174[(2)] = inst_31122);

(statearr_31147_31174[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31129 === (10))){
var inst_31111 = (state_31128[(2)]);
var state_31128__$1 = state_31128;
var statearr_31148_31175 = state_31128__$1;
(statearr_31148_31175[(2)] = inst_31111);

(statearr_31148_31175[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_31129 === (8))){
var inst_31092 = (state_31128[(9)]);
var inst_31096 = (state_31128[(10)]);
var inst_31088 = (state_31128[(8)]);
var inst_31101 = inst_31088.push(inst_31092);
var tmp31145 = inst_31088;
var inst_31088__$1 = tmp31145;
var inst_31089 = inst_31096;
var state_31128__$1 = (function (){var statearr_31149 = state_31128;
(statearr_31149[(14)] = inst_31101);

(statearr_31149[(7)] = inst_31089);

(statearr_31149[(8)] = inst_31088__$1);

return statearr_31149;
})();
var statearr_31150_31176 = state_31128__$1;
(statearr_31150_31176[(2)] = null);

(statearr_31150_31176[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___31162,out))
;
return ((function (switch__15098__auto__,c__15224__auto___31162,out){
return (function() {
var cljs$core$async$state_machine__15099__auto__ = null;
var cljs$core$async$state_machine__15099__auto____0 = (function (){
var statearr_31154 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_31154[(0)] = cljs$core$async$state_machine__15099__auto__);

(statearr_31154[(1)] = (1));

return statearr_31154;
});
var cljs$core$async$state_machine__15099__auto____1 = (function (state_31128){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_31128);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e31155){if((e31155 instanceof Object)){
var ex__15102__auto__ = e31155;
var statearr_31156_31177 = state_31128;
(statearr_31156_31177[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_31128);

return cljs.core.cst$kw$recur;
} else {
throw e31155;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__31178 = state_31128;
state_31128 = G__31178;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs$core$async$state_machine__15099__auto__ = function(state_31128){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__15099__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__15099__auto____1.call(this,state_31128);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__15099__auto____0;
cljs$core$async$state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__15099__auto____1;
return cljs$core$async$state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___31162,out))
})();
var state__15226__auto__ = (function (){var statearr_31157 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_31157[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___31162);

return statearr_31157;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___31162,out))
);


return out;
});

cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3;


// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.tabs');
goog.require('cljs.core');
goog.require('chromex.core');
chromex.ext.tabs.tab_id_none_STAR_ = (function chromex$ext$tabs$tab_id_none_STAR_(config){
var result_36493 = (function (){var final_args_array_36494 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.tabs.TAB_ID_NONE");
var ns_36495 = (function (){var target_obj_36497 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36498 = goog.object.get(target_obj_36497,"chrome");
var next_obj_36499 = goog.object.get(next_obj_36498,"tabs");
return next_obj_36499;
})();


var target_36496 = (function (){var target_obj_36500 = ns_36495;
var next_obj_36501 = goog.object.get(target_obj_36500,"TAB_ID_NONE");
if(!((next_obj_36501 == null))){
return next_obj_36501;
} else {
return null;
}
})();
return target_36496;
})();
return result_36493;
});
chromex.ext.tabs.get_STAR_ = (function chromex$ext$tabs$get_STAR_(config,tab_id){
var callback_chan_36519 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_36521_36536 = (function (){var omit_test_36526 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_36526,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36526;
}
})();
var marshalled_callback_36522_36537 = ((function (marshalled_tab_id_36521_36536,callback_chan_36519){
return (function (cb_tab_36527){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__36528 = config__13447__auto__;
var G__36529 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get,cljs.core.cst$kw$name,"get",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36530 = callback_chan_36519;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__36528,G__36529,G__36530) : handler__13449__auto__.call(null,G__36528,G__36529,G__36530));
})().call(null,cb_tab_36527);
});})(marshalled_tab_id_36521_36536,callback_chan_36519))
;
var result_36520_36538 = (function (){var final_args_array_36523 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_36521_36536,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36522_36537,"callback",null], null)], null),"chrome.tabs.get");
var ns_36524 = (function (){var target_obj_36531 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36532 = goog.object.get(target_obj_36531,"chrome");
var next_obj_36533 = goog.object.get(next_obj_36532,"tabs");
return next_obj_36533;
})();
var config__13480__auto___36539 = config;
var api_check_fn__13481__auto___36540 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36539);

(api_check_fn__13481__auto___36540.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36540.cljs$core$IFn$_invoke$arity$3("chrome.tabs.get",ns_36524,"get") : api_check_fn__13481__auto___36540.call(null,"chrome.tabs.get",ns_36524,"get"));


var target_36525 = (function (){var target_obj_36534 = ns_36524;
var next_obj_36535 = goog.object.get(target_obj_36534,"get");
if(!((next_obj_36535 == null))){
return next_obj_36535;
} else {
return null;
}
})();
return target_36525.apply(ns_36524,final_args_array_36523);
})();

return callback_chan_36519;
});
chromex.ext.tabs.get_current_STAR_ = (function chromex$ext$tabs$get_current_STAR_(config){
var callback_chan_36556 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_36558_36571 = ((function (callback_chan_36556){
return (function (cb_tab_36562){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__36563 = config__13447__auto__;
var G__36564 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_current,cljs.core.cst$kw$name,"getCurrent",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36565 = callback_chan_36556;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__36563,G__36564,G__36565) : handler__13449__auto__.call(null,G__36563,G__36564,G__36565));
})().call(null,cb_tab_36562);
});})(callback_chan_36556))
;
var result_36557_36572 = (function (){var final_args_array_36559 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36558_36571,"callback",null], null)], null),"chrome.tabs.getCurrent");
var ns_36560 = (function (){var target_obj_36566 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36567 = goog.object.get(target_obj_36566,"chrome");
var next_obj_36568 = goog.object.get(next_obj_36567,"tabs");
return next_obj_36568;
})();
var config__13480__auto___36573 = config;
var api_check_fn__13481__auto___36574 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36573);

(api_check_fn__13481__auto___36574.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36574.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getCurrent",ns_36560,"getCurrent") : api_check_fn__13481__auto___36574.call(null,"chrome.tabs.getCurrent",ns_36560,"getCurrent"));


var target_36561 = (function (){var target_obj_36569 = ns_36560;
var next_obj_36570 = goog.object.get(target_obj_36569,"getCurrent");
if(!((next_obj_36570 == null))){
return next_obj_36570;
} else {
return null;
}
})();
return target_36561.apply(ns_36560,final_args_array_36559);
})();

return callback_chan_36556;
});
chromex.ext.tabs.connect_STAR_ = (function chromex$ext$tabs$connect_STAR_(config,tab_id,connect_info){
var marshalled_tab_id_36589 = (function (){var omit_test_36594 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_36594,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36594;
}
})();
var marshalled_connect_info_36590 = (function (){var omit_test_36595 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_36595,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36595;
}
})();
var result_36588 = (function (){var final_args_array_36591 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_36589,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_36590,"connect-info",true], null)], null),"chrome.tabs.connect");
var ns_36592 = (function (){var target_obj_36596 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36597 = goog.object.get(target_obj_36596,"chrome");
var next_obj_36598 = goog.object.get(next_obj_36597,"tabs");
return next_obj_36598;
})();
var config__13480__auto___36601 = config;
var api_check_fn__13481__auto___36602 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36601);

(api_check_fn__13481__auto___36602.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36602.cljs$core$IFn$_invoke$arity$3("chrome.tabs.connect",ns_36592,"connect") : api_check_fn__13481__auto___36602.call(null,"chrome.tabs.connect",ns_36592,"connect"));


var target_36593 = (function (){var target_obj_36599 = ns_36592;
var next_obj_36600 = goog.object.get(target_obj_36599,"connect");
if(!((next_obj_36600 == null))){
return next_obj_36600;
} else {
return null;
}
})();
return target_36593.apply(ns_36592,final_args_array_36591);
})();
return chromex.marshalling.from_native_chrome_port(config,result_36588);
});
chromex.ext.tabs.send_request_STAR_ = (function chromex$ext$tabs$send_request_STAR_(config,tab_id,request){
var callback_chan_36622 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_36624_36641 = (function (){var omit_test_36630 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_36630,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36630;
}
})();
var marshalled_request_36625_36642 = (function (){var omit_test_36631 = request;
if(cljs.core.keyword_identical_QMARK_(omit_test_36631,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36631;
}
})();
var marshalled_response_callback_36626_36643 = ((function (marshalled_tab_id_36624_36641,marshalled_request_36625_36642,callback_chan_36622){
return (function (cb_response_36632){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__36633 = config__13447__auto__;
var G__36634 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_send_DASH_request,cljs.core.cst$kw$name,"sendRequest",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'runtime.sendMessage'.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"request",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36635 = callback_chan_36622;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__36633,G__36634,G__36635) : handler__13449__auto__.call(null,G__36633,G__36634,G__36635));
})().call(null,cb_response_36632);
});})(marshalled_tab_id_36624_36641,marshalled_request_36625_36642,callback_chan_36622))
;
var result_36623_36644 = (function (){var final_args_array_36627 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_36624_36641,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_request_36625_36642,"request",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_36626_36643,"response-callback",true], null)], null),"chrome.tabs.sendRequest");
var ns_36628 = (function (){var target_obj_36636 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36637 = goog.object.get(target_obj_36636,"chrome");
var next_obj_36638 = goog.object.get(next_obj_36637,"tabs");
return next_obj_36638;
})();
var config__13480__auto___36645 = config;
var api_check_fn__13481__auto___36646 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36645);

(api_check_fn__13481__auto___36646.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36646.cljs$core$IFn$_invoke$arity$3("chrome.tabs.sendRequest",ns_36628,"sendRequest") : api_check_fn__13481__auto___36646.call(null,"chrome.tabs.sendRequest",ns_36628,"sendRequest"));


var target_36629 = (function (){var target_obj_36639 = ns_36628;
var next_obj_36640 = goog.object.get(target_obj_36639,"sendRequest");
if(!((next_obj_36640 == null))){
return next_obj_36640;
} else {
return null;
}
})();
return target_36629.apply(ns_36628,final_args_array_36627);
})();

return callback_chan_36622;
});
chromex.ext.tabs.send_message_STAR_ = (function chromex$ext$tabs$send_message_STAR_(config,tab_id,message,options){
var callback_chan_36668 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_36670_36689 = (function (){var omit_test_36677 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_36677,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36677;
}
})();
var marshalled_message_36671_36690 = (function (){var omit_test_36678 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_36678,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36678;
}
})();
var marshalled_options_36672_36691 = (function (){var omit_test_36679 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_36679,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36679;
}
})();
var marshalled_response_callback_36673_36692 = ((function (marshalled_tab_id_36670_36689,marshalled_message_36671_36690,marshalled_options_36672_36691,callback_chan_36668){
return (function (cb_response_36680){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__36681 = config__13447__auto__;
var G__36682 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$since,"20",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36683 = callback_chan_36668;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__36681,G__36682,G__36683) : handler__13449__auto__.call(null,G__36681,G__36682,G__36683));
})().call(null,cb_response_36680);
});})(marshalled_tab_id_36670_36689,marshalled_message_36671_36690,marshalled_options_36672_36691,callback_chan_36668))
;
var result_36669_36693 = (function (){var final_args_array_36674 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_36670_36689,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_36671_36690,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_36672_36691,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_36673_36692,"response-callback",true], null)], null),"chrome.tabs.sendMessage");
var ns_36675 = (function (){var target_obj_36684 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36685 = goog.object.get(target_obj_36684,"chrome");
var next_obj_36686 = goog.object.get(next_obj_36685,"tabs");
return next_obj_36686;
})();
var config__13480__auto___36694 = config;
var api_check_fn__13481__auto___36695 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36694);

(api_check_fn__13481__auto___36695.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36695.cljs$core$IFn$_invoke$arity$3("chrome.tabs.sendMessage",ns_36675,"sendMessage") : api_check_fn__13481__auto___36695.call(null,"chrome.tabs.sendMessage",ns_36675,"sendMessage"));


var target_36676 = (function (){var target_obj_36687 = ns_36675;
var next_obj_36688 = goog.object.get(target_obj_36687,"sendMessage");
if(!((next_obj_36688 == null))){
return next_obj_36688;
} else {
return null;
}
})();
return target_36676.apply(ns_36675,final_args_array_36674);
})();

return callback_chan_36668;
});
chromex.ext.tabs.get_selected_STAR_ = (function chromex$ext$tabs$get_selected_STAR_(config,window_id){
var callback_chan_36713 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_window_id_36715_36730 = (function (){var omit_test_36720 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_36720,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36720;
}
})();
var marshalled_callback_36716_36731 = ((function (marshalled_window_id_36715_36730,callback_chan_36713){
return (function (cb_tab_36721){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__36722 = config__13447__auto__;
var G__36723 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_selected,cljs.core.cst$kw$name,"getSelected",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'tabs.query' {active: true}.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36724 = callback_chan_36713;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__36722,G__36723,G__36724) : handler__13449__auto__.call(null,G__36722,G__36723,G__36724));
})().call(null,cb_tab_36721);
});})(marshalled_window_id_36715_36730,callback_chan_36713))
;
var result_36714_36732 = (function (){var final_args_array_36717 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_36715_36730,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36716_36731,"callback",null], null)], null),"chrome.tabs.getSelected");
var ns_36718 = (function (){var target_obj_36725 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36726 = goog.object.get(target_obj_36725,"chrome");
var next_obj_36727 = goog.object.get(next_obj_36726,"tabs");
return next_obj_36727;
})();
var config__13480__auto___36733 = config;
var api_check_fn__13481__auto___36734 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36733);

(api_check_fn__13481__auto___36734.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36734.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getSelected",ns_36718,"getSelected") : api_check_fn__13481__auto___36734.call(null,"chrome.tabs.getSelected",ns_36718,"getSelected"));


var target_36719 = (function (){var target_obj_36728 = ns_36718;
var next_obj_36729 = goog.object.get(target_obj_36728,"getSelected");
if(!((next_obj_36729 == null))){
return next_obj_36729;
} else {
return null;
}
})();
return target_36719.apply(ns_36718,final_args_array_36717);
})();

return callback_chan_36713;
});
chromex.ext.tabs.get_all_in_window_STAR_ = (function chromex$ext$tabs$get_all_in_window_STAR_(config,window_id){
var callback_chan_36752 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_window_id_36754_36769 = (function (){var omit_test_36759 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_36759,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36759;
}
})();
var marshalled_callback_36755_36770 = ((function (marshalled_window_id_36754_36769,callback_chan_36752){
return (function (cb_tabs_36760){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__36761 = config__13447__auto__;
var G__36762 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_all_DASH_in_DASH_window,cljs.core.cst$kw$name,"getAllInWindow",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'tabs.query' {windowId: windowId}.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tabs",cljs.core.cst$kw$type,"[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36763 = callback_chan_36752;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__36761,G__36762,G__36763) : handler__13449__auto__.call(null,G__36761,G__36762,G__36763));
})().call(null,cb_tabs_36760);
});})(marshalled_window_id_36754_36769,callback_chan_36752))
;
var result_36753_36771 = (function (){var final_args_array_36756 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_36754_36769,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36755_36770,"callback",null], null)], null),"chrome.tabs.getAllInWindow");
var ns_36757 = (function (){var target_obj_36764 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36765 = goog.object.get(target_obj_36764,"chrome");
var next_obj_36766 = goog.object.get(next_obj_36765,"tabs");
return next_obj_36766;
})();
var config__13480__auto___36772 = config;
var api_check_fn__13481__auto___36773 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36772);

(api_check_fn__13481__auto___36773.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36773.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getAllInWindow",ns_36757,"getAllInWindow") : api_check_fn__13481__auto___36773.call(null,"chrome.tabs.getAllInWindow",ns_36757,"getAllInWindow"));


var target_36758 = (function (){var target_obj_36767 = ns_36757;
var next_obj_36768 = goog.object.get(target_obj_36767,"getAllInWindow");
if(!((next_obj_36768 == null))){
return next_obj_36768;
} else {
return null;
}
})();
return target_36758.apply(ns_36757,final_args_array_36756);
})();

return callback_chan_36752;
});
chromex.ext.tabs.create_STAR_ = (function chromex$ext$tabs$create_STAR_(config,create_properties){
var callback_chan_36791 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_create_properties_36793_36808 = (function (){var omit_test_36798 = create_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_36798,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36798;
}
})();
var marshalled_callback_36794_36809 = ((function (marshalled_create_properties_36793_36808,callback_chan_36791){
return (function (cb_tab_36799){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__36800 = config__13447__auto__;
var G__36801 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_create,cljs.core.cst$kw$name,"create",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"create-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36802 = callback_chan_36791;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__36800,G__36801,G__36802) : handler__13449__auto__.call(null,G__36800,G__36801,G__36802));
})().call(null,cb_tab_36799);
});})(marshalled_create_properties_36793_36808,callback_chan_36791))
;
var result_36792_36810 = (function (){var final_args_array_36795 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_create_properties_36793_36808,"create-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36794_36809,"callback",true], null)], null),"chrome.tabs.create");
var ns_36796 = (function (){var target_obj_36803 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36804 = goog.object.get(target_obj_36803,"chrome");
var next_obj_36805 = goog.object.get(next_obj_36804,"tabs");
return next_obj_36805;
})();
var config__13480__auto___36811 = config;
var api_check_fn__13481__auto___36812 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36811);

(api_check_fn__13481__auto___36812.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36812.cljs$core$IFn$_invoke$arity$3("chrome.tabs.create",ns_36796,"create") : api_check_fn__13481__auto___36812.call(null,"chrome.tabs.create",ns_36796,"create"));


var target_36797 = (function (){var target_obj_36806 = ns_36796;
var next_obj_36807 = goog.object.get(target_obj_36806,"create");
if(!((next_obj_36807 == null))){
return next_obj_36807;
} else {
return null;
}
})();
return target_36797.apply(ns_36796,final_args_array_36795);
})();

return callback_chan_36791;
});
chromex.ext.tabs.duplicate_STAR_ = (function chromex$ext$tabs$duplicate_STAR_(config,tab_id){
var callback_chan_36830 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_36832_36847 = (function (){var omit_test_36837 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_36837,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36837;
}
})();
var marshalled_callback_36833_36848 = ((function (marshalled_tab_id_36832_36847,callback_chan_36830){
return (function (cb_tab_36838){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__36839 = config__13447__auto__;
var G__36840 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_duplicate,cljs.core.cst$kw$name,"duplicate",cljs.core.cst$kw$since,"23",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36841 = callback_chan_36830;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__36839,G__36840,G__36841) : handler__13449__auto__.call(null,G__36839,G__36840,G__36841));
})().call(null,cb_tab_36838);
});})(marshalled_tab_id_36832_36847,callback_chan_36830))
;
var result_36831_36849 = (function (){var final_args_array_36834 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_36832_36847,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36833_36848,"callback",true], null)], null),"chrome.tabs.duplicate");
var ns_36835 = (function (){var target_obj_36842 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36843 = goog.object.get(target_obj_36842,"chrome");
var next_obj_36844 = goog.object.get(next_obj_36843,"tabs");
return next_obj_36844;
})();
var config__13480__auto___36850 = config;
var api_check_fn__13481__auto___36851 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36850);

(api_check_fn__13481__auto___36851.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36851.cljs$core$IFn$_invoke$arity$3("chrome.tabs.duplicate",ns_36835,"duplicate") : api_check_fn__13481__auto___36851.call(null,"chrome.tabs.duplicate",ns_36835,"duplicate"));


var target_36836 = (function (){var target_obj_36845 = ns_36835;
var next_obj_36846 = goog.object.get(target_obj_36845,"duplicate");
if(!((next_obj_36846 == null))){
return next_obj_36846;
} else {
return null;
}
})();
return target_36836.apply(ns_36835,final_args_array_36834);
})();

return callback_chan_36830;
});
chromex.ext.tabs.query_STAR_ = (function chromex$ext$tabs$query_STAR_(config,query_info){
var callback_chan_36869 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_query_info_36871_36886 = (function (){var omit_test_36876 = query_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_36876,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36876;
}
})();
var marshalled_callback_36872_36887 = ((function (marshalled_query_info_36871_36886,callback_chan_36869){
return (function (cb_result_36877){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__36878 = config__13447__auto__;
var G__36879 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_query,cljs.core.cst$kw$name,"query",cljs.core.cst$kw$since,"16",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"query-info",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36880 = callback_chan_36869;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__36878,G__36879,G__36880) : handler__13449__auto__.call(null,G__36878,G__36879,G__36880));
})().call(null,cb_result_36877);
});})(marshalled_query_info_36871_36886,callback_chan_36869))
;
var result_36870_36888 = (function (){var final_args_array_36873 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_query_info_36871_36886,"query-info",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36872_36887,"callback",null], null)], null),"chrome.tabs.query");
var ns_36874 = (function (){var target_obj_36881 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36882 = goog.object.get(target_obj_36881,"chrome");
var next_obj_36883 = goog.object.get(next_obj_36882,"tabs");
return next_obj_36883;
})();
var config__13480__auto___36889 = config;
var api_check_fn__13481__auto___36890 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36889);

(api_check_fn__13481__auto___36890.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36890.cljs$core$IFn$_invoke$arity$3("chrome.tabs.query",ns_36874,"query") : api_check_fn__13481__auto___36890.call(null,"chrome.tabs.query",ns_36874,"query"));


var target_36875 = (function (){var target_obj_36884 = ns_36874;
var next_obj_36885 = goog.object.get(target_obj_36884,"query");
if(!((next_obj_36885 == null))){
return next_obj_36885;
} else {
return null;
}
})();
return target_36875.apply(ns_36874,final_args_array_36873);
})();

return callback_chan_36869;
});
chromex.ext.tabs.highlight_STAR_ = (function chromex$ext$tabs$highlight_STAR_(config,highlight_info){
var callback_chan_36908 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_highlight_info_36910_36925 = (function (){var omit_test_36915 = highlight_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_36915,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36915;
}
})();
var marshalled_callback_36911_36926 = ((function (marshalled_highlight_info_36910_36925,callback_chan_36908){
return (function (cb_window_36916){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__36917 = config__13447__auto__;
var G__36918 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_highlight,cljs.core.cst$kw$name,"highlight",cljs.core.cst$kw$since,"16",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"highlight-info",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"window",cljs.core.cst$kw$type,"windows.Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36919 = callback_chan_36908;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__36917,G__36918,G__36919) : handler__13449__auto__.call(null,G__36917,G__36918,G__36919));
})().call(null,cb_window_36916);
});})(marshalled_highlight_info_36910_36925,callback_chan_36908))
;
var result_36909_36927 = (function (){var final_args_array_36912 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_highlight_info_36910_36925,"highlight-info",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36911_36926,"callback",true], null)], null),"chrome.tabs.highlight");
var ns_36913 = (function (){var target_obj_36920 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36921 = goog.object.get(target_obj_36920,"chrome");
var next_obj_36922 = goog.object.get(next_obj_36921,"tabs");
return next_obj_36922;
})();
var config__13480__auto___36928 = config;
var api_check_fn__13481__auto___36929 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36928);

(api_check_fn__13481__auto___36929.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36929.cljs$core$IFn$_invoke$arity$3("chrome.tabs.highlight",ns_36913,"highlight") : api_check_fn__13481__auto___36929.call(null,"chrome.tabs.highlight",ns_36913,"highlight"));


var target_36914 = (function (){var target_obj_36923 = ns_36913;
var next_obj_36924 = goog.object.get(target_obj_36923,"highlight");
if(!((next_obj_36924 == null))){
return next_obj_36924;
} else {
return null;
}
})();
return target_36914.apply(ns_36913,final_args_array_36912);
})();

return callback_chan_36908;
});
chromex.ext.tabs.update_STAR_ = (function chromex$ext$tabs$update_STAR_(config,tab_id,update_properties){
var callback_chan_36949 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_36951_36968 = (function (){var omit_test_36957 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_36957,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36957;
}
})();
var marshalled_update_properties_36952_36969 = (function (){var omit_test_36958 = update_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_36958,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_36958;
}
})();
var marshalled_callback_36953_36970 = ((function (marshalled_tab_id_36951_36968,marshalled_update_properties_36952_36969,callback_chan_36949){
return (function (cb_tab_36959){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__36960 = config__13447__auto__;
var G__36961 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_update,cljs.core.cst$kw$name,"update",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"update-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__36962 = callback_chan_36949;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__36960,G__36961,G__36962) : handler__13449__auto__.call(null,G__36960,G__36961,G__36962));
})().call(null,cb_tab_36959);
});})(marshalled_tab_id_36951_36968,marshalled_update_properties_36952_36969,callback_chan_36949))
;
var result_36950_36971 = (function (){var final_args_array_36954 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_36951_36968,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_update_properties_36952_36969,"update-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36953_36970,"callback",true], null)], null),"chrome.tabs.update");
var ns_36955 = (function (){var target_obj_36963 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_36964 = goog.object.get(target_obj_36963,"chrome");
var next_obj_36965 = goog.object.get(next_obj_36964,"tabs");
return next_obj_36965;
})();
var config__13480__auto___36972 = config;
var api_check_fn__13481__auto___36973 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___36972);

(api_check_fn__13481__auto___36973.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___36973.cljs$core$IFn$_invoke$arity$3("chrome.tabs.update",ns_36955,"update") : api_check_fn__13481__auto___36973.call(null,"chrome.tabs.update",ns_36955,"update"));


var target_36956 = (function (){var target_obj_36966 = ns_36955;
var next_obj_36967 = goog.object.get(target_obj_36966,"update");
if(!((next_obj_36967 == null))){
return next_obj_36967;
} else {
return null;
}
})();
return target_36956.apply(ns_36955,final_args_array_36954);
})();

return callback_chan_36949;
});
chromex.ext.tabs.move_STAR_ = (function chromex$ext$tabs$move_STAR_(config,tab_ids,move_properties){
var callback_chan_36993 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_ids_36995_37012 = (function (){var omit_test_37001 = tab_ids;
if(cljs.core.keyword_identical_QMARK_(omit_test_37001,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37001;
}
})();
var marshalled_move_properties_36996_37013 = (function (){var omit_test_37002 = move_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_37002,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37002;
}
})();
var marshalled_callback_36997_37014 = ((function (marshalled_tab_ids_36995_37012,marshalled_move_properties_36996_37013,callback_chan_36993){
return (function (cb_tabs_37003){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37004 = config__13447__auto__;
var G__37005 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_move,cljs.core.cst$kw$name,"move",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-ids",cljs.core.cst$kw$type,"integer-or-[array-of-integers]"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"move-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tabs",cljs.core.cst$kw$type,"tabs.Tab-or-[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37006 = callback_chan_36993;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37004,G__37005,G__37006) : handler__13449__auto__.call(null,G__37004,G__37005,G__37006));
})().call(null,cb_tabs_37003);
});})(marshalled_tab_ids_36995_37012,marshalled_move_properties_36996_37013,callback_chan_36993))
;
var result_36994_37015 = (function (){var final_args_array_36998 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_ids_36995_37012,"tab-ids",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_move_properties_36996_37013,"move-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_36997_37014,"callback",true], null)], null),"chrome.tabs.move");
var ns_36999 = (function (){var target_obj_37007 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37008 = goog.object.get(target_obj_37007,"chrome");
var next_obj_37009 = goog.object.get(next_obj_37008,"tabs");
return next_obj_37009;
})();
var config__13480__auto___37016 = config;
var api_check_fn__13481__auto___37017 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37016);

(api_check_fn__13481__auto___37017.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37017.cljs$core$IFn$_invoke$arity$3("chrome.tabs.move",ns_36999,"move") : api_check_fn__13481__auto___37017.call(null,"chrome.tabs.move",ns_36999,"move"));


var target_37000 = (function (){var target_obj_37010 = ns_36999;
var next_obj_37011 = goog.object.get(target_obj_37010,"move");
if(!((next_obj_37011 == null))){
return next_obj_37011;
} else {
return null;
}
})();
return target_37000.apply(ns_36999,final_args_array_36998);
})();

return callback_chan_36993;
});
chromex.ext.tabs.reload_STAR_ = (function chromex$ext$tabs$reload_STAR_(config,tab_id,reload_properties){
var callback_chan_37036 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_37038_37054 = (function (){var omit_test_37044 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_37044,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37044;
}
})();
var marshalled_reload_properties_37039_37055 = (function (){var omit_test_37045 = reload_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_37045,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37045;
}
})();
var marshalled_callback_37040_37056 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37046 = config__13447__auto__;
var G__37047 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_reload,cljs.core.cst$kw$name,"reload",cljs.core.cst$kw$since,"16",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"reload-properties",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37048 = callback_chan_37036;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37046,G__37047,G__37048) : handler__13449__auto__.call(null,G__37046,G__37047,G__37048));
})();
var result_37037_37057 = (function (){var final_args_array_37041 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_37038_37054,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_reload_properties_37039_37055,"reload-properties",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_37040_37056,"callback",true], null)], null),"chrome.tabs.reload");
var ns_37042 = (function (){var target_obj_37049 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37050 = goog.object.get(target_obj_37049,"chrome");
var next_obj_37051 = goog.object.get(next_obj_37050,"tabs");
return next_obj_37051;
})();
var config__13480__auto___37058 = config;
var api_check_fn__13481__auto___37059 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37058);

(api_check_fn__13481__auto___37059.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37059.cljs$core$IFn$_invoke$arity$3("chrome.tabs.reload",ns_37042,"reload") : api_check_fn__13481__auto___37059.call(null,"chrome.tabs.reload",ns_37042,"reload"));


var target_37043 = (function (){var target_obj_37052 = ns_37042;
var next_obj_37053 = goog.object.get(target_obj_37052,"reload");
if(!((next_obj_37053 == null))){
return next_obj_37053;
} else {
return null;
}
})();
return target_37043.apply(ns_37042,final_args_array_37041);
})();

return callback_chan_37036;
});
chromex.ext.tabs.remove_STAR_ = (function chromex$ext$tabs$remove_STAR_(config,tab_ids){
var callback_chan_37076 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_ids_37078_37092 = (function (){var omit_test_37083 = tab_ids;
if(cljs.core.keyword_identical_QMARK_(omit_test_37083,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37083;
}
})();
var marshalled_callback_37079_37093 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37084 = config__13447__auto__;
var G__37085 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_remove,cljs.core.cst$kw$name,"remove",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-ids",cljs.core.cst$kw$type,"integer-or-[array-of-integers]"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37086 = callback_chan_37076;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37084,G__37085,G__37086) : handler__13449__auto__.call(null,G__37084,G__37085,G__37086));
})();
var result_37077_37094 = (function (){var final_args_array_37080 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_ids_37078_37092,"tab-ids",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_37079_37093,"callback",true], null)], null),"chrome.tabs.remove");
var ns_37081 = (function (){var target_obj_37087 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37088 = goog.object.get(target_obj_37087,"chrome");
var next_obj_37089 = goog.object.get(next_obj_37088,"tabs");
return next_obj_37089;
})();
var config__13480__auto___37095 = config;
var api_check_fn__13481__auto___37096 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37095);

(api_check_fn__13481__auto___37096.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37096.cljs$core$IFn$_invoke$arity$3("chrome.tabs.remove",ns_37081,"remove") : api_check_fn__13481__auto___37096.call(null,"chrome.tabs.remove",ns_37081,"remove"));


var target_37082 = (function (){var target_obj_37090 = ns_37081;
var next_obj_37091 = goog.object.get(target_obj_37090,"remove");
if(!((next_obj_37091 == null))){
return next_obj_37091;
} else {
return null;
}
})();
return target_37082.apply(ns_37081,final_args_array_37080);
})();

return callback_chan_37076;
});
chromex.ext.tabs.detect_language_STAR_ = (function chromex$ext$tabs$detect_language_STAR_(config,tab_id){
var callback_chan_37114 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_37116_37131 = (function (){var omit_test_37121 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_37121,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37121;
}
})();
var marshalled_callback_37117_37132 = ((function (marshalled_tab_id_37116_37131,callback_chan_37114){
return (function (cb_language_37122){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37123 = config__13447__auto__;
var G__37124 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_detect_DASH_language,cljs.core.cst$kw$name,"detectLanguage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"language",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37125 = callback_chan_37114;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37123,G__37124,G__37125) : handler__13449__auto__.call(null,G__37123,G__37124,G__37125));
})().call(null,cb_language_37122);
});})(marshalled_tab_id_37116_37131,callback_chan_37114))
;
var result_37115_37133 = (function (){var final_args_array_37118 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_37116_37131,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_37117_37132,"callback",null], null)], null),"chrome.tabs.detectLanguage");
var ns_37119 = (function (){var target_obj_37126 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37127 = goog.object.get(target_obj_37126,"chrome");
var next_obj_37128 = goog.object.get(next_obj_37127,"tabs");
return next_obj_37128;
})();
var config__13480__auto___37134 = config;
var api_check_fn__13481__auto___37135 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37134);

(api_check_fn__13481__auto___37135.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37135.cljs$core$IFn$_invoke$arity$3("chrome.tabs.detectLanguage",ns_37119,"detectLanguage") : api_check_fn__13481__auto___37135.call(null,"chrome.tabs.detectLanguage",ns_37119,"detectLanguage"));


var target_37120 = (function (){var target_obj_37129 = ns_37119;
var next_obj_37130 = goog.object.get(target_obj_37129,"detectLanguage");
if(!((next_obj_37130 == null))){
return next_obj_37130;
} else {
return null;
}
})();
return target_37120.apply(ns_37119,final_args_array_37118);
})();

return callback_chan_37114;
});
chromex.ext.tabs.capture_visible_tab_STAR_ = (function chromex$ext$tabs$capture_visible_tab_STAR_(config,window_id,options){
var callback_chan_37155 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_window_id_37157_37174 = (function (){var omit_test_37163 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_37163,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37163;
}
})();
var marshalled_options_37158_37175 = (function (){var omit_test_37164 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_37164,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37164;
}
})();
var marshalled_callback_37159_37176 = ((function (marshalled_window_id_37157_37174,marshalled_options_37158_37175,callback_chan_37155){
return (function (cb_data_url_37165){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37166 = config__13447__auto__;
var G__37167 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_capture_DASH_visible_DASH_tab,cljs.core.cst$kw$name,"captureVisibleTab",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"data-url",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37168 = callback_chan_37155;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37166,G__37167,G__37168) : handler__13449__auto__.call(null,G__37166,G__37167,G__37168));
})().call(null,cb_data_url_37165);
});})(marshalled_window_id_37157_37174,marshalled_options_37158_37175,callback_chan_37155))
;
var result_37156_37177 = (function (){var final_args_array_37160 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_37157_37174,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_37158_37175,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_37159_37176,"callback",null], null)], null),"chrome.tabs.captureVisibleTab");
var ns_37161 = (function (){var target_obj_37169 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37170 = goog.object.get(target_obj_37169,"chrome");
var next_obj_37171 = goog.object.get(next_obj_37170,"tabs");
return next_obj_37171;
})();
var config__13480__auto___37178 = config;
var api_check_fn__13481__auto___37179 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37178);

(api_check_fn__13481__auto___37179.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37179.cljs$core$IFn$_invoke$arity$3("chrome.tabs.captureVisibleTab",ns_37161,"captureVisibleTab") : api_check_fn__13481__auto___37179.call(null,"chrome.tabs.captureVisibleTab",ns_37161,"captureVisibleTab"));


var target_37162 = (function (){var target_obj_37172 = ns_37161;
var next_obj_37173 = goog.object.get(target_obj_37172,"captureVisibleTab");
if(!((next_obj_37173 == null))){
return next_obj_37173;
} else {
return null;
}
})();
return target_37162.apply(ns_37161,final_args_array_37160);
})();

return callback_chan_37155;
});
chromex.ext.tabs.execute_script_STAR_ = (function chromex$ext$tabs$execute_script_STAR_(config,tab_id,details){
var callback_chan_37199 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_37201_37218 = (function (){var omit_test_37207 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_37207,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37207;
}
})();
var marshalled_details_37202_37219 = (function (){var omit_test_37208 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_37208,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37208;
}
})();
var marshalled_callback_37203_37220 = ((function (marshalled_tab_id_37201_37218,marshalled_details_37202_37219,callback_chan_37199){
return (function (cb_result_37209){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37210 = config__13447__auto__;
var G__37211 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_execute_DASH_script,cljs.core.cst$kw$name,"executeScript",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"[array-of-anys]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37212 = callback_chan_37199;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37210,G__37211,G__37212) : handler__13449__auto__.call(null,G__37210,G__37211,G__37212));
})().call(null,cb_result_37209);
});})(marshalled_tab_id_37201_37218,marshalled_details_37202_37219,callback_chan_37199))
;
var result_37200_37221 = (function (){var final_args_array_37204 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_37201_37218,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_37202_37219,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_37203_37220,"callback",true], null)], null),"chrome.tabs.executeScript");
var ns_37205 = (function (){var target_obj_37213 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37214 = goog.object.get(target_obj_37213,"chrome");
var next_obj_37215 = goog.object.get(next_obj_37214,"tabs");
return next_obj_37215;
})();
var config__13480__auto___37222 = config;
var api_check_fn__13481__auto___37223 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37222);

(api_check_fn__13481__auto___37223.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37223.cljs$core$IFn$_invoke$arity$3("chrome.tabs.executeScript",ns_37205,"executeScript") : api_check_fn__13481__auto___37223.call(null,"chrome.tabs.executeScript",ns_37205,"executeScript"));


var target_37206 = (function (){var target_obj_37216 = ns_37205;
var next_obj_37217 = goog.object.get(target_obj_37216,"executeScript");
if(!((next_obj_37217 == null))){
return next_obj_37217;
} else {
return null;
}
})();
return target_37206.apply(ns_37205,final_args_array_37204);
})();

return callback_chan_37199;
});
chromex.ext.tabs.insert_css_STAR_ = (function chromex$ext$tabs$insert_css_STAR_(config,tab_id,details){
var callback_chan_37242 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_37244_37260 = (function (){var omit_test_37250 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_37250,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37250;
}
})();
var marshalled_details_37245_37261 = (function (){var omit_test_37251 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_37251,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37251;
}
})();
var marshalled_callback_37246_37262 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37252 = config__13447__auto__;
var G__37253 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_insert_DASH_css,cljs.core.cst$kw$name,"insertCSS",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37254 = callback_chan_37242;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37252,G__37253,G__37254) : handler__13449__auto__.call(null,G__37252,G__37253,G__37254));
})();
var result_37243_37263 = (function (){var final_args_array_37247 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_37244_37260,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_37245_37261,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_37246_37262,"callback",true], null)], null),"chrome.tabs.insertCSS");
var ns_37248 = (function (){var target_obj_37255 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37256 = goog.object.get(target_obj_37255,"chrome");
var next_obj_37257 = goog.object.get(next_obj_37256,"tabs");
return next_obj_37257;
})();
var config__13480__auto___37264 = config;
var api_check_fn__13481__auto___37265 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37264);

(api_check_fn__13481__auto___37265.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37265.cljs$core$IFn$_invoke$arity$3("chrome.tabs.insertCSS",ns_37248,"insertCSS") : api_check_fn__13481__auto___37265.call(null,"chrome.tabs.insertCSS",ns_37248,"insertCSS"));


var target_37249 = (function (){var target_obj_37258 = ns_37248;
var next_obj_37259 = goog.object.get(target_obj_37258,"insertCSS");
if(!((next_obj_37259 == null))){
return next_obj_37259;
} else {
return null;
}
})();
return target_37249.apply(ns_37248,final_args_array_37247);
})();

return callback_chan_37242;
});
chromex.ext.tabs.set_zoom_STAR_ = (function chromex$ext$tabs$set_zoom_STAR_(config,tab_id,zoom_factor){
var callback_chan_37284 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_37286_37302 = (function (){var omit_test_37292 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_37292,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37292;
}
})();
var marshalled_zoom_factor_37287_37303 = (function (){var omit_test_37293 = zoom_factor;
if(cljs.core.keyword_identical_QMARK_(omit_test_37293,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37293;
}
})();
var marshalled_callback_37288_37304 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37294 = config__13447__auto__;
var G__37295 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_set_DASH_zoom,cljs.core.cst$kw$name,"setZoom",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-factor",cljs.core.cst$kw$type,"double"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37296 = callback_chan_37284;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37294,G__37295,G__37296) : handler__13449__auto__.call(null,G__37294,G__37295,G__37296));
})();
var result_37285_37305 = (function (){var final_args_array_37289 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_37286_37302,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_zoom_factor_37287_37303,"zoom-factor",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_37288_37304,"callback",true], null)], null),"chrome.tabs.setZoom");
var ns_37290 = (function (){var target_obj_37297 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37298 = goog.object.get(target_obj_37297,"chrome");
var next_obj_37299 = goog.object.get(next_obj_37298,"tabs");
return next_obj_37299;
})();
var config__13480__auto___37306 = config;
var api_check_fn__13481__auto___37307 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37306);

(api_check_fn__13481__auto___37307.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37307.cljs$core$IFn$_invoke$arity$3("chrome.tabs.setZoom",ns_37290,"setZoom") : api_check_fn__13481__auto___37307.call(null,"chrome.tabs.setZoom",ns_37290,"setZoom"));


var target_37291 = (function (){var target_obj_37300 = ns_37290;
var next_obj_37301 = goog.object.get(target_obj_37300,"setZoom");
if(!((next_obj_37301 == null))){
return next_obj_37301;
} else {
return null;
}
})();
return target_37291.apply(ns_37290,final_args_array_37289);
})();

return callback_chan_37284;
});
chromex.ext.tabs.get_zoom_STAR_ = (function chromex$ext$tabs$get_zoom_STAR_(config,tab_id){
var callback_chan_37325 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_37327_37342 = (function (){var omit_test_37332 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_37332,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37332;
}
})();
var marshalled_callback_37328_37343 = ((function (marshalled_tab_id_37327_37342,callback_chan_37325){
return (function (cb_zoom_factor_37333){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37334 = config__13447__auto__;
var G__37335 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_zoom,cljs.core.cst$kw$name,"getZoom",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-factor",cljs.core.cst$kw$type,"double"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37336 = callback_chan_37325;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37334,G__37335,G__37336) : handler__13449__auto__.call(null,G__37334,G__37335,G__37336));
})().call(null,cb_zoom_factor_37333);
});})(marshalled_tab_id_37327_37342,callback_chan_37325))
;
var result_37326_37344 = (function (){var final_args_array_37329 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_37327_37342,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_37328_37343,"callback",null], null)], null),"chrome.tabs.getZoom");
var ns_37330 = (function (){var target_obj_37337 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37338 = goog.object.get(target_obj_37337,"chrome");
var next_obj_37339 = goog.object.get(next_obj_37338,"tabs");
return next_obj_37339;
})();
var config__13480__auto___37345 = config;
var api_check_fn__13481__auto___37346 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37345);

(api_check_fn__13481__auto___37346.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37346.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getZoom",ns_37330,"getZoom") : api_check_fn__13481__auto___37346.call(null,"chrome.tabs.getZoom",ns_37330,"getZoom"));


var target_37331 = (function (){var target_obj_37340 = ns_37330;
var next_obj_37341 = goog.object.get(target_obj_37340,"getZoom");
if(!((next_obj_37341 == null))){
return next_obj_37341;
} else {
return null;
}
})();
return target_37331.apply(ns_37330,final_args_array_37329);
})();

return callback_chan_37325;
});
chromex.ext.tabs.set_zoom_settings_STAR_ = (function chromex$ext$tabs$set_zoom_settings_STAR_(config,tab_id,zoom_settings){
var callback_chan_37365 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_37367_37383 = (function (){var omit_test_37373 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_37373,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37373;
}
})();
var marshalled_zoom_settings_37368_37384 = (function (){var omit_test_37374 = zoom_settings;
if(cljs.core.keyword_identical_QMARK_(omit_test_37374,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37374;
}
})();
var marshalled_callback_37369_37385 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37375 = config__13447__auto__;
var G__37376 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_set_DASH_zoom_DASH_settings,cljs.core.cst$kw$name,"setZoomSettings",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-settings",cljs.core.cst$kw$type,"tabs.ZoomSettings"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37377 = callback_chan_37365;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37375,G__37376,G__37377) : handler__13449__auto__.call(null,G__37375,G__37376,G__37377));
})();
var result_37366_37386 = (function (){var final_args_array_37370 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_37367_37383,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_zoom_settings_37368_37384,"zoom-settings",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_37369_37385,"callback",true], null)], null),"chrome.tabs.setZoomSettings");
var ns_37371 = (function (){var target_obj_37378 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37379 = goog.object.get(target_obj_37378,"chrome");
var next_obj_37380 = goog.object.get(next_obj_37379,"tabs");
return next_obj_37380;
})();
var config__13480__auto___37387 = config;
var api_check_fn__13481__auto___37388 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37387);

(api_check_fn__13481__auto___37388.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37388.cljs$core$IFn$_invoke$arity$3("chrome.tabs.setZoomSettings",ns_37371,"setZoomSettings") : api_check_fn__13481__auto___37388.call(null,"chrome.tabs.setZoomSettings",ns_37371,"setZoomSettings"));


var target_37372 = (function (){var target_obj_37381 = ns_37371;
var next_obj_37382 = goog.object.get(target_obj_37381,"setZoomSettings");
if(!((next_obj_37382 == null))){
return next_obj_37382;
} else {
return null;
}
})();
return target_37372.apply(ns_37371,final_args_array_37370);
})();

return callback_chan_37365;
});
chromex.ext.tabs.get_zoom_settings_STAR_ = (function chromex$ext$tabs$get_zoom_settings_STAR_(config,tab_id){
var callback_chan_37406 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_37408_37423 = (function (){var omit_test_37413 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_37413,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37413;
}
})();
var marshalled_callback_37409_37424 = ((function (marshalled_tab_id_37408_37423,callback_chan_37406){
return (function (cb_zoom_settings_37414){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37415 = config__13447__auto__;
var G__37416 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_zoom_DASH_settings,cljs.core.cst$kw$name,"getZoomSettings",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-settings",cljs.core.cst$kw$type,"tabs.ZoomSettings"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37417 = callback_chan_37406;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37415,G__37416,G__37417) : handler__13449__auto__.call(null,G__37415,G__37416,G__37417));
})().call(null,cb_zoom_settings_37414);
});})(marshalled_tab_id_37408_37423,callback_chan_37406))
;
var result_37407_37425 = (function (){var final_args_array_37410 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_37408_37423,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_37409_37424,"callback",null], null)], null),"chrome.tabs.getZoomSettings");
var ns_37411 = (function (){var target_obj_37418 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37419 = goog.object.get(target_obj_37418,"chrome");
var next_obj_37420 = goog.object.get(next_obj_37419,"tabs");
return next_obj_37420;
})();
var config__13480__auto___37426 = config;
var api_check_fn__13481__auto___37427 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37426);

(api_check_fn__13481__auto___37427.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37427.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getZoomSettings",ns_37411,"getZoomSettings") : api_check_fn__13481__auto___37427.call(null,"chrome.tabs.getZoomSettings",ns_37411,"getZoomSettings"));


var target_37412 = (function (){var target_obj_37421 = ns_37411;
var next_obj_37422 = goog.object.get(target_obj_37421,"getZoomSettings");
if(!((next_obj_37422 == null))){
return next_obj_37422;
} else {
return null;
}
})();
return target_37412.apply(ns_37411,final_args_array_37410);
})();

return callback_chan_37406;
});
chromex.ext.tabs.discard_STAR_ = (function chromex$ext$tabs$discard_STAR_(config,tab_id){
var callback_chan_37445 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_tab_id_37447_37462 = (function (){var omit_test_37452 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_37452,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_37452;
}
})();
var marshalled_callback_37448_37463 = ((function (marshalled_tab_id_37447_37462,callback_chan_37445){
return (function (cb_tab_37453){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37454 = config__13447__auto__;
var G__37455 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_discard,cljs.core.cst$kw$name,"discard",cljs.core.cst$kw$since,"54",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__37456 = callback_chan_37445;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37454,G__37455,G__37456) : handler__13449__auto__.call(null,G__37454,G__37455,G__37456));
})().call(null,cb_tab_37453);
});})(marshalled_tab_id_37447_37462,callback_chan_37445))
;
var result_37446_37464 = (function (){var final_args_array_37449 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_37447_37462,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_37448_37463,"callback",true], null)], null),"chrome.tabs.discard");
var ns_37450 = (function (){var target_obj_37457 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37458 = goog.object.get(target_obj_37457,"chrome");
var next_obj_37459 = goog.object.get(next_obj_37458,"tabs");
return next_obj_37459;
})();
var config__13480__auto___37465 = config;
var api_check_fn__13481__auto___37466 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37465);

(api_check_fn__13481__auto___37466.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37466.cljs$core$IFn$_invoke$arity$3("chrome.tabs.discard",ns_37450,"discard") : api_check_fn__13481__auto___37466.call(null,"chrome.tabs.discard",ns_37450,"discard"));


var target_37451 = (function (){var target_obj_37460 = ns_37450;
var next_obj_37461 = goog.object.get(target_obj_37460,"discard");
if(!((next_obj_37461 == null))){
return next_obj_37461;
} else {
return null;
}
})();
return target_37451.apply(ns_37450,final_args_array_37449);
})();

return callback_chan_37445;
});
chromex.ext.tabs.on_created_STAR_ = (function chromex$ext$tabs$on_created_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37483 = arguments.length;
var i__8119__auto___37484 = (0);
while(true){
if((i__8119__auto___37484 < len__8118__auto___37483)){
args__8125__auto__.push((arguments[i__8119__auto___37484]));

var G__37485 = (i__8119__auto___37484 + (1));
i__8119__auto___37484 = G__37485;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37470 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37475 = config__13447__auto__;
var G__37476 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_created;
var G__37477 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37475,G__37476,G__37477) : handler__13449__auto__.call(null,G__37475,G__37476,G__37477));
})();
var handler_fn_37471 = ((function (event_fn_37470){
return (function (cb_tab_37473){
return (event_fn_37470.cljs$core$IFn$_invoke$arity$1 ? event_fn_37470.cljs$core$IFn$_invoke$arity$1(cb_tab_37473) : event_fn_37470.call(null,cb_tab_37473));
});})(event_fn_37470))
;
var logging_fn__20428__auto__ = ((function (event_fn_37470,handler_fn_37471){
return (function (cb_param_tab_37474){

return handler_fn_37471(cb_param_tab_37474);
});})(event_fn_37470,handler_fn_37471))
;
var ns_obj_37472 = (function (){var target_obj_37478 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37479 = goog.object.get(target_obj_37478,"chrome");
var next_obj_37480 = goog.object.get(next_obj_37479,"tabs");
return next_obj_37480;
})();
var config__13480__auto___37486 = config;
var api_check_fn__13481__auto___37487 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37486);

(api_check_fn__13481__auto___37487.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37487.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onCreated",ns_obj_37472,"onCreated") : api_check_fn__13481__auto___37487.call(null,"chrome.tabs.onCreated",ns_obj_37472,"onCreated"));

var event_obj__20429__auto__ = (function (){var target_obj_37481 = ns_obj_37472;
var next_obj_37482 = goog.object.get(target_obj_37481,"onCreated");
return next_obj_37482;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_created_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_created_STAR_.cljs$lang$applyTo = (function (seq37467){
var G__37468 = cljs.core.first(seq37467);
var seq37467__$1 = cljs.core.next(seq37467);
var G__37469 = cljs.core.first(seq37467__$1);
var seq37467__$2 = cljs.core.next(seq37467__$1);
return chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37468,G__37469,seq37467__$2);
});

chromex.ext.tabs.on_updated_STAR_ = (function chromex$ext$tabs$on_updated_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37508 = arguments.length;
var i__8119__auto___37509 = (0);
while(true){
if((i__8119__auto___37509 < len__8118__auto___37508)){
args__8125__auto__.push((arguments[i__8119__auto___37509]));

var G__37510 = (i__8119__auto___37509 + (1));
i__8119__auto___37509 = G__37510;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37491 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37500 = config__13447__auto__;
var G__37501 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_updated;
var G__37502 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37500,G__37501,G__37502) : handler__13449__auto__.call(null,G__37500,G__37501,G__37502));
})();
var handler_fn_37492 = ((function (event_fn_37491){
return (function (cb_tab_id_37494,cb_change_info_37495,cb_tab_37496){
return (event_fn_37491.cljs$core$IFn$_invoke$arity$3 ? event_fn_37491.cljs$core$IFn$_invoke$arity$3(cb_tab_id_37494,cb_change_info_37495,cb_tab_37496) : event_fn_37491.call(null,cb_tab_id_37494,cb_change_info_37495,cb_tab_37496));
});})(event_fn_37491))
;
var logging_fn__20428__auto__ = ((function (event_fn_37491,handler_fn_37492){
return (function (cb_param_tab_id_37497,cb_param_change_info_37498,cb_param_tab_37499){

return handler_fn_37492(cb_param_tab_id_37497,cb_param_change_info_37498,cb_param_tab_37499);
});})(event_fn_37491,handler_fn_37492))
;
var ns_obj_37493 = (function (){var target_obj_37503 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37504 = goog.object.get(target_obj_37503,"chrome");
var next_obj_37505 = goog.object.get(next_obj_37504,"tabs");
return next_obj_37505;
})();
var config__13480__auto___37511 = config;
var api_check_fn__13481__auto___37512 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37511);

(api_check_fn__13481__auto___37512.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37512.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onUpdated",ns_obj_37493,"onUpdated") : api_check_fn__13481__auto___37512.call(null,"chrome.tabs.onUpdated",ns_obj_37493,"onUpdated"));

var event_obj__20429__auto__ = (function (){var target_obj_37506 = ns_obj_37493;
var next_obj_37507 = goog.object.get(target_obj_37506,"onUpdated");
return next_obj_37507;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_updated_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_updated_STAR_.cljs$lang$applyTo = (function (seq37488){
var G__37489 = cljs.core.first(seq37488);
var seq37488__$1 = cljs.core.next(seq37488);
var G__37490 = cljs.core.first(seq37488__$1);
var seq37488__$2 = cljs.core.next(seq37488__$1);
return chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37489,G__37490,seq37488__$2);
});

chromex.ext.tabs.on_moved_STAR_ = (function chromex$ext$tabs$on_moved_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37531 = arguments.length;
var i__8119__auto___37532 = (0);
while(true){
if((i__8119__auto___37532 < len__8118__auto___37531)){
args__8125__auto__.push((arguments[i__8119__auto___37532]));

var G__37533 = (i__8119__auto___37532 + (1));
i__8119__auto___37532 = G__37533;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37516 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37523 = config__13447__auto__;
var G__37524 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_moved;
var G__37525 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37523,G__37524,G__37525) : handler__13449__auto__.call(null,G__37523,G__37524,G__37525));
})();
var handler_fn_37517 = ((function (event_fn_37516){
return (function (cb_tab_id_37519,cb_move_info_37520){
return (event_fn_37516.cljs$core$IFn$_invoke$arity$2 ? event_fn_37516.cljs$core$IFn$_invoke$arity$2(cb_tab_id_37519,cb_move_info_37520) : event_fn_37516.call(null,cb_tab_id_37519,cb_move_info_37520));
});})(event_fn_37516))
;
var logging_fn__20428__auto__ = ((function (event_fn_37516,handler_fn_37517){
return (function (cb_param_tab_id_37521,cb_param_move_info_37522){

return handler_fn_37517(cb_param_tab_id_37521,cb_param_move_info_37522);
});})(event_fn_37516,handler_fn_37517))
;
var ns_obj_37518 = (function (){var target_obj_37526 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37527 = goog.object.get(target_obj_37526,"chrome");
var next_obj_37528 = goog.object.get(next_obj_37527,"tabs");
return next_obj_37528;
})();
var config__13480__auto___37534 = config;
var api_check_fn__13481__auto___37535 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37534);

(api_check_fn__13481__auto___37535.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37535.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onMoved",ns_obj_37518,"onMoved") : api_check_fn__13481__auto___37535.call(null,"chrome.tabs.onMoved",ns_obj_37518,"onMoved"));

var event_obj__20429__auto__ = (function (){var target_obj_37529 = ns_obj_37518;
var next_obj_37530 = goog.object.get(target_obj_37529,"onMoved");
return next_obj_37530;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_moved_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_moved_STAR_.cljs$lang$applyTo = (function (seq37513){
var G__37514 = cljs.core.first(seq37513);
var seq37513__$1 = cljs.core.next(seq37513);
var G__37515 = cljs.core.first(seq37513__$1);
var seq37513__$2 = cljs.core.next(seq37513__$1);
return chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37514,G__37515,seq37513__$2);
});

chromex.ext.tabs.on_selection_changed_STAR_ = (function chromex$ext$tabs$on_selection_changed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37554 = arguments.length;
var i__8119__auto___37555 = (0);
while(true){
if((i__8119__auto___37555 < len__8118__auto___37554)){
args__8125__auto__.push((arguments[i__8119__auto___37555]));

var G__37556 = (i__8119__auto___37555 + (1));
i__8119__auto___37555 = G__37556;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37539 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37546 = config__13447__auto__;
var G__37547 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_selection_DASH_changed;
var G__37548 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37546,G__37547,G__37548) : handler__13449__auto__.call(null,G__37546,G__37547,G__37548));
})();
var handler_fn_37540 = ((function (event_fn_37539){
return (function (cb_tab_id_37542,cb_select_info_37543){
return (event_fn_37539.cljs$core$IFn$_invoke$arity$2 ? event_fn_37539.cljs$core$IFn$_invoke$arity$2(cb_tab_id_37542,cb_select_info_37543) : event_fn_37539.call(null,cb_tab_id_37542,cb_select_info_37543));
});})(event_fn_37539))
;
var logging_fn__20428__auto__ = ((function (event_fn_37539,handler_fn_37540){
return (function (cb_param_tab_id_37544,cb_param_select_info_37545){

return handler_fn_37540(cb_param_tab_id_37544,cb_param_select_info_37545);
});})(event_fn_37539,handler_fn_37540))
;
var ns_obj_37541 = (function (){var target_obj_37549 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37550 = goog.object.get(target_obj_37549,"chrome");
var next_obj_37551 = goog.object.get(next_obj_37550,"tabs");
return next_obj_37551;
})();
var config__13480__auto___37557 = config;
var api_check_fn__13481__auto___37558 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37557);

(api_check_fn__13481__auto___37558.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37558.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onSelectionChanged",ns_obj_37541,"onSelectionChanged") : api_check_fn__13481__auto___37558.call(null,"chrome.tabs.onSelectionChanged",ns_obj_37541,"onSelectionChanged"));

var event_obj__20429__auto__ = (function (){var target_obj_37552 = ns_obj_37541;
var next_obj_37553 = goog.object.get(target_obj_37552,"onSelectionChanged");
return next_obj_37553;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_selection_changed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_selection_changed_STAR_.cljs$lang$applyTo = (function (seq37536){
var G__37537 = cljs.core.first(seq37536);
var seq37536__$1 = cljs.core.next(seq37536);
var G__37538 = cljs.core.first(seq37536__$1);
var seq37536__$2 = cljs.core.next(seq37536__$1);
return chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37537,G__37538,seq37536__$2);
});

chromex.ext.tabs.on_active_changed_STAR_ = (function chromex$ext$tabs$on_active_changed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37577 = arguments.length;
var i__8119__auto___37578 = (0);
while(true){
if((i__8119__auto___37578 < len__8118__auto___37577)){
args__8125__auto__.push((arguments[i__8119__auto___37578]));

var G__37579 = (i__8119__auto___37578 + (1));
i__8119__auto___37578 = G__37579;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37562 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37569 = config__13447__auto__;
var G__37570 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_active_DASH_changed;
var G__37571 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37569,G__37570,G__37571) : handler__13449__auto__.call(null,G__37569,G__37570,G__37571));
})();
var handler_fn_37563 = ((function (event_fn_37562){
return (function (cb_tab_id_37565,cb_select_info_37566){
return (event_fn_37562.cljs$core$IFn$_invoke$arity$2 ? event_fn_37562.cljs$core$IFn$_invoke$arity$2(cb_tab_id_37565,cb_select_info_37566) : event_fn_37562.call(null,cb_tab_id_37565,cb_select_info_37566));
});})(event_fn_37562))
;
var logging_fn__20428__auto__ = ((function (event_fn_37562,handler_fn_37563){
return (function (cb_param_tab_id_37567,cb_param_select_info_37568){

return handler_fn_37563(cb_param_tab_id_37567,cb_param_select_info_37568);
});})(event_fn_37562,handler_fn_37563))
;
var ns_obj_37564 = (function (){var target_obj_37572 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37573 = goog.object.get(target_obj_37572,"chrome");
var next_obj_37574 = goog.object.get(next_obj_37573,"tabs");
return next_obj_37574;
})();
var config__13480__auto___37580 = config;
var api_check_fn__13481__auto___37581 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37580);

(api_check_fn__13481__auto___37581.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37581.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onActiveChanged",ns_obj_37564,"onActiveChanged") : api_check_fn__13481__auto___37581.call(null,"chrome.tabs.onActiveChanged",ns_obj_37564,"onActiveChanged"));

var event_obj__20429__auto__ = (function (){var target_obj_37575 = ns_obj_37564;
var next_obj_37576 = goog.object.get(target_obj_37575,"onActiveChanged");
return next_obj_37576;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_active_changed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_active_changed_STAR_.cljs$lang$applyTo = (function (seq37559){
var G__37560 = cljs.core.first(seq37559);
var seq37559__$1 = cljs.core.next(seq37559);
var G__37561 = cljs.core.first(seq37559__$1);
var seq37559__$2 = cljs.core.next(seq37559__$1);
return chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37560,G__37561,seq37559__$2);
});

chromex.ext.tabs.on_activated_STAR_ = (function chromex$ext$tabs$on_activated_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37598 = arguments.length;
var i__8119__auto___37599 = (0);
while(true){
if((i__8119__auto___37599 < len__8118__auto___37598)){
args__8125__auto__.push((arguments[i__8119__auto___37599]));

var G__37600 = (i__8119__auto___37599 + (1));
i__8119__auto___37599 = G__37600;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37585 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37590 = config__13447__auto__;
var G__37591 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_activated;
var G__37592 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37590,G__37591,G__37592) : handler__13449__auto__.call(null,G__37590,G__37591,G__37592));
})();
var handler_fn_37586 = ((function (event_fn_37585){
return (function (cb_active_info_37588){
return (event_fn_37585.cljs$core$IFn$_invoke$arity$1 ? event_fn_37585.cljs$core$IFn$_invoke$arity$1(cb_active_info_37588) : event_fn_37585.call(null,cb_active_info_37588));
});})(event_fn_37585))
;
var logging_fn__20428__auto__ = ((function (event_fn_37585,handler_fn_37586){
return (function (cb_param_active_info_37589){

return handler_fn_37586(cb_param_active_info_37589);
});})(event_fn_37585,handler_fn_37586))
;
var ns_obj_37587 = (function (){var target_obj_37593 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37594 = goog.object.get(target_obj_37593,"chrome");
var next_obj_37595 = goog.object.get(next_obj_37594,"tabs");
return next_obj_37595;
})();
var config__13480__auto___37601 = config;
var api_check_fn__13481__auto___37602 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37601);

(api_check_fn__13481__auto___37602.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37602.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onActivated",ns_obj_37587,"onActivated") : api_check_fn__13481__auto___37602.call(null,"chrome.tabs.onActivated",ns_obj_37587,"onActivated"));

var event_obj__20429__auto__ = (function (){var target_obj_37596 = ns_obj_37587;
var next_obj_37597 = goog.object.get(target_obj_37596,"onActivated");
return next_obj_37597;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_activated_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_activated_STAR_.cljs$lang$applyTo = (function (seq37582){
var G__37583 = cljs.core.first(seq37582);
var seq37582__$1 = cljs.core.next(seq37582);
var G__37584 = cljs.core.first(seq37582__$1);
var seq37582__$2 = cljs.core.next(seq37582__$1);
return chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37583,G__37584,seq37582__$2);
});

chromex.ext.tabs.on_highlight_changed_STAR_ = (function chromex$ext$tabs$on_highlight_changed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37619 = arguments.length;
var i__8119__auto___37620 = (0);
while(true){
if((i__8119__auto___37620 < len__8118__auto___37619)){
args__8125__auto__.push((arguments[i__8119__auto___37620]));

var G__37621 = (i__8119__auto___37620 + (1));
i__8119__auto___37620 = G__37621;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37606 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37611 = config__13447__auto__;
var G__37612 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_highlight_DASH_changed;
var G__37613 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37611,G__37612,G__37613) : handler__13449__auto__.call(null,G__37611,G__37612,G__37613));
})();
var handler_fn_37607 = ((function (event_fn_37606){
return (function (cb_select_info_37609){
return (event_fn_37606.cljs$core$IFn$_invoke$arity$1 ? event_fn_37606.cljs$core$IFn$_invoke$arity$1(cb_select_info_37609) : event_fn_37606.call(null,cb_select_info_37609));
});})(event_fn_37606))
;
var logging_fn__20428__auto__ = ((function (event_fn_37606,handler_fn_37607){
return (function (cb_param_select_info_37610){

return handler_fn_37607(cb_param_select_info_37610);
});})(event_fn_37606,handler_fn_37607))
;
var ns_obj_37608 = (function (){var target_obj_37614 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37615 = goog.object.get(target_obj_37614,"chrome");
var next_obj_37616 = goog.object.get(next_obj_37615,"tabs");
return next_obj_37616;
})();
var config__13480__auto___37622 = config;
var api_check_fn__13481__auto___37623 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37622);

(api_check_fn__13481__auto___37623.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37623.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onHighlightChanged",ns_obj_37608,"onHighlightChanged") : api_check_fn__13481__auto___37623.call(null,"chrome.tabs.onHighlightChanged",ns_obj_37608,"onHighlightChanged"));

var event_obj__20429__auto__ = (function (){var target_obj_37617 = ns_obj_37608;
var next_obj_37618 = goog.object.get(target_obj_37617,"onHighlightChanged");
return next_obj_37618;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_highlight_changed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_highlight_changed_STAR_.cljs$lang$applyTo = (function (seq37603){
var G__37604 = cljs.core.first(seq37603);
var seq37603__$1 = cljs.core.next(seq37603);
var G__37605 = cljs.core.first(seq37603__$1);
var seq37603__$2 = cljs.core.next(seq37603__$1);
return chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37604,G__37605,seq37603__$2);
});

chromex.ext.tabs.on_highlighted_STAR_ = (function chromex$ext$tabs$on_highlighted_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37640 = arguments.length;
var i__8119__auto___37641 = (0);
while(true){
if((i__8119__auto___37641 < len__8118__auto___37640)){
args__8125__auto__.push((arguments[i__8119__auto___37641]));

var G__37642 = (i__8119__auto___37641 + (1));
i__8119__auto___37641 = G__37642;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37627 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37632 = config__13447__auto__;
var G__37633 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_highlighted;
var G__37634 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37632,G__37633,G__37634) : handler__13449__auto__.call(null,G__37632,G__37633,G__37634));
})();
var handler_fn_37628 = ((function (event_fn_37627){
return (function (cb_highlight_info_37630){
return (event_fn_37627.cljs$core$IFn$_invoke$arity$1 ? event_fn_37627.cljs$core$IFn$_invoke$arity$1(cb_highlight_info_37630) : event_fn_37627.call(null,cb_highlight_info_37630));
});})(event_fn_37627))
;
var logging_fn__20428__auto__ = ((function (event_fn_37627,handler_fn_37628){
return (function (cb_param_highlight_info_37631){

return handler_fn_37628(cb_param_highlight_info_37631);
});})(event_fn_37627,handler_fn_37628))
;
var ns_obj_37629 = (function (){var target_obj_37635 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37636 = goog.object.get(target_obj_37635,"chrome");
var next_obj_37637 = goog.object.get(next_obj_37636,"tabs");
return next_obj_37637;
})();
var config__13480__auto___37643 = config;
var api_check_fn__13481__auto___37644 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37643);

(api_check_fn__13481__auto___37644.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37644.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onHighlighted",ns_obj_37629,"onHighlighted") : api_check_fn__13481__auto___37644.call(null,"chrome.tabs.onHighlighted",ns_obj_37629,"onHighlighted"));

var event_obj__20429__auto__ = (function (){var target_obj_37638 = ns_obj_37629;
var next_obj_37639 = goog.object.get(target_obj_37638,"onHighlighted");
return next_obj_37639;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_highlighted_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_highlighted_STAR_.cljs$lang$applyTo = (function (seq37624){
var G__37625 = cljs.core.first(seq37624);
var seq37624__$1 = cljs.core.next(seq37624);
var G__37626 = cljs.core.first(seq37624__$1);
var seq37624__$2 = cljs.core.next(seq37624__$1);
return chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37625,G__37626,seq37624__$2);
});

chromex.ext.tabs.on_detached_STAR_ = (function chromex$ext$tabs$on_detached_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37663 = arguments.length;
var i__8119__auto___37664 = (0);
while(true){
if((i__8119__auto___37664 < len__8118__auto___37663)){
args__8125__auto__.push((arguments[i__8119__auto___37664]));

var G__37665 = (i__8119__auto___37664 + (1));
i__8119__auto___37664 = G__37665;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37648 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37655 = config__13447__auto__;
var G__37656 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_detached;
var G__37657 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37655,G__37656,G__37657) : handler__13449__auto__.call(null,G__37655,G__37656,G__37657));
})();
var handler_fn_37649 = ((function (event_fn_37648){
return (function (cb_tab_id_37651,cb_detach_info_37652){
return (event_fn_37648.cljs$core$IFn$_invoke$arity$2 ? event_fn_37648.cljs$core$IFn$_invoke$arity$2(cb_tab_id_37651,cb_detach_info_37652) : event_fn_37648.call(null,cb_tab_id_37651,cb_detach_info_37652));
});})(event_fn_37648))
;
var logging_fn__20428__auto__ = ((function (event_fn_37648,handler_fn_37649){
return (function (cb_param_tab_id_37653,cb_param_detach_info_37654){

return handler_fn_37649(cb_param_tab_id_37653,cb_param_detach_info_37654);
});})(event_fn_37648,handler_fn_37649))
;
var ns_obj_37650 = (function (){var target_obj_37658 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37659 = goog.object.get(target_obj_37658,"chrome");
var next_obj_37660 = goog.object.get(next_obj_37659,"tabs");
return next_obj_37660;
})();
var config__13480__auto___37666 = config;
var api_check_fn__13481__auto___37667 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37666);

(api_check_fn__13481__auto___37667.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37667.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onDetached",ns_obj_37650,"onDetached") : api_check_fn__13481__auto___37667.call(null,"chrome.tabs.onDetached",ns_obj_37650,"onDetached"));

var event_obj__20429__auto__ = (function (){var target_obj_37661 = ns_obj_37650;
var next_obj_37662 = goog.object.get(target_obj_37661,"onDetached");
return next_obj_37662;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_detached_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_detached_STAR_.cljs$lang$applyTo = (function (seq37645){
var G__37646 = cljs.core.first(seq37645);
var seq37645__$1 = cljs.core.next(seq37645);
var G__37647 = cljs.core.first(seq37645__$1);
var seq37645__$2 = cljs.core.next(seq37645__$1);
return chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37646,G__37647,seq37645__$2);
});

chromex.ext.tabs.on_attached_STAR_ = (function chromex$ext$tabs$on_attached_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37686 = arguments.length;
var i__8119__auto___37687 = (0);
while(true){
if((i__8119__auto___37687 < len__8118__auto___37686)){
args__8125__auto__.push((arguments[i__8119__auto___37687]));

var G__37688 = (i__8119__auto___37687 + (1));
i__8119__auto___37687 = G__37688;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37671 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37678 = config__13447__auto__;
var G__37679 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_attached;
var G__37680 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37678,G__37679,G__37680) : handler__13449__auto__.call(null,G__37678,G__37679,G__37680));
})();
var handler_fn_37672 = ((function (event_fn_37671){
return (function (cb_tab_id_37674,cb_attach_info_37675){
return (event_fn_37671.cljs$core$IFn$_invoke$arity$2 ? event_fn_37671.cljs$core$IFn$_invoke$arity$2(cb_tab_id_37674,cb_attach_info_37675) : event_fn_37671.call(null,cb_tab_id_37674,cb_attach_info_37675));
});})(event_fn_37671))
;
var logging_fn__20428__auto__ = ((function (event_fn_37671,handler_fn_37672){
return (function (cb_param_tab_id_37676,cb_param_attach_info_37677){

return handler_fn_37672(cb_param_tab_id_37676,cb_param_attach_info_37677);
});})(event_fn_37671,handler_fn_37672))
;
var ns_obj_37673 = (function (){var target_obj_37681 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37682 = goog.object.get(target_obj_37681,"chrome");
var next_obj_37683 = goog.object.get(next_obj_37682,"tabs");
return next_obj_37683;
})();
var config__13480__auto___37689 = config;
var api_check_fn__13481__auto___37690 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37689);

(api_check_fn__13481__auto___37690.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37690.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onAttached",ns_obj_37673,"onAttached") : api_check_fn__13481__auto___37690.call(null,"chrome.tabs.onAttached",ns_obj_37673,"onAttached"));

var event_obj__20429__auto__ = (function (){var target_obj_37684 = ns_obj_37673;
var next_obj_37685 = goog.object.get(target_obj_37684,"onAttached");
return next_obj_37685;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_attached_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_attached_STAR_.cljs$lang$applyTo = (function (seq37668){
var G__37669 = cljs.core.first(seq37668);
var seq37668__$1 = cljs.core.next(seq37668);
var G__37670 = cljs.core.first(seq37668__$1);
var seq37668__$2 = cljs.core.next(seq37668__$1);
return chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37669,G__37670,seq37668__$2);
});

chromex.ext.tabs.on_removed_STAR_ = (function chromex$ext$tabs$on_removed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37709 = arguments.length;
var i__8119__auto___37710 = (0);
while(true){
if((i__8119__auto___37710 < len__8118__auto___37709)){
args__8125__auto__.push((arguments[i__8119__auto___37710]));

var G__37711 = (i__8119__auto___37710 + (1));
i__8119__auto___37710 = G__37711;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37694 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37701 = config__13447__auto__;
var G__37702 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_removed;
var G__37703 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37701,G__37702,G__37703) : handler__13449__auto__.call(null,G__37701,G__37702,G__37703));
})();
var handler_fn_37695 = ((function (event_fn_37694){
return (function (cb_tab_id_37697,cb_remove_info_37698){
return (event_fn_37694.cljs$core$IFn$_invoke$arity$2 ? event_fn_37694.cljs$core$IFn$_invoke$arity$2(cb_tab_id_37697,cb_remove_info_37698) : event_fn_37694.call(null,cb_tab_id_37697,cb_remove_info_37698));
});})(event_fn_37694))
;
var logging_fn__20428__auto__ = ((function (event_fn_37694,handler_fn_37695){
return (function (cb_param_tab_id_37699,cb_param_remove_info_37700){

return handler_fn_37695(cb_param_tab_id_37699,cb_param_remove_info_37700);
});})(event_fn_37694,handler_fn_37695))
;
var ns_obj_37696 = (function (){var target_obj_37704 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37705 = goog.object.get(target_obj_37704,"chrome");
var next_obj_37706 = goog.object.get(next_obj_37705,"tabs");
return next_obj_37706;
})();
var config__13480__auto___37712 = config;
var api_check_fn__13481__auto___37713 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37712);

(api_check_fn__13481__auto___37713.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37713.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onRemoved",ns_obj_37696,"onRemoved") : api_check_fn__13481__auto___37713.call(null,"chrome.tabs.onRemoved",ns_obj_37696,"onRemoved"));

var event_obj__20429__auto__ = (function (){var target_obj_37707 = ns_obj_37696;
var next_obj_37708 = goog.object.get(target_obj_37707,"onRemoved");
return next_obj_37708;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_removed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_removed_STAR_.cljs$lang$applyTo = (function (seq37691){
var G__37692 = cljs.core.first(seq37691);
var seq37691__$1 = cljs.core.next(seq37691);
var G__37693 = cljs.core.first(seq37691__$1);
var seq37691__$2 = cljs.core.next(seq37691__$1);
return chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37692,G__37693,seq37691__$2);
});

chromex.ext.tabs.on_replaced_STAR_ = (function chromex$ext$tabs$on_replaced_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37732 = arguments.length;
var i__8119__auto___37733 = (0);
while(true){
if((i__8119__auto___37733 < len__8118__auto___37732)){
args__8125__auto__.push((arguments[i__8119__auto___37733]));

var G__37734 = (i__8119__auto___37733 + (1));
i__8119__auto___37733 = G__37734;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37717 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37724 = config__13447__auto__;
var G__37725 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_replaced;
var G__37726 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37724,G__37725,G__37726) : handler__13449__auto__.call(null,G__37724,G__37725,G__37726));
})();
var handler_fn_37718 = ((function (event_fn_37717){
return (function (cb_added_tab_id_37720,cb_removed_tab_id_37721){
return (event_fn_37717.cljs$core$IFn$_invoke$arity$2 ? event_fn_37717.cljs$core$IFn$_invoke$arity$2(cb_added_tab_id_37720,cb_removed_tab_id_37721) : event_fn_37717.call(null,cb_added_tab_id_37720,cb_removed_tab_id_37721));
});})(event_fn_37717))
;
var logging_fn__20428__auto__ = ((function (event_fn_37717,handler_fn_37718){
return (function (cb_param_added_tab_id_37722,cb_param_removed_tab_id_37723){

return handler_fn_37718(cb_param_added_tab_id_37722,cb_param_removed_tab_id_37723);
});})(event_fn_37717,handler_fn_37718))
;
var ns_obj_37719 = (function (){var target_obj_37727 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37728 = goog.object.get(target_obj_37727,"chrome");
var next_obj_37729 = goog.object.get(next_obj_37728,"tabs");
return next_obj_37729;
})();
var config__13480__auto___37735 = config;
var api_check_fn__13481__auto___37736 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37735);

(api_check_fn__13481__auto___37736.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37736.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onReplaced",ns_obj_37719,"onReplaced") : api_check_fn__13481__auto___37736.call(null,"chrome.tabs.onReplaced",ns_obj_37719,"onReplaced"));

var event_obj__20429__auto__ = (function (){var target_obj_37730 = ns_obj_37719;
var next_obj_37731 = goog.object.get(target_obj_37730,"onReplaced");
return next_obj_37731;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_replaced_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_replaced_STAR_.cljs$lang$applyTo = (function (seq37714){
var G__37715 = cljs.core.first(seq37714);
var seq37714__$1 = cljs.core.next(seq37714);
var G__37716 = cljs.core.first(seq37714__$1);
var seq37714__$2 = cljs.core.next(seq37714__$1);
return chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37715,G__37716,seq37714__$2);
});

chromex.ext.tabs.on_zoom_change_STAR_ = (function chromex$ext$tabs$on_zoom_change_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___37753 = arguments.length;
var i__8119__auto___37754 = (0);
while(true){
if((i__8119__auto___37754 < len__8118__auto___37753)){
args__8125__auto__.push((arguments[i__8119__auto___37754]));

var G__37755 = (i__8119__auto___37754 + (1));
i__8119__auto___37754 = G__37755;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_37740 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__37745 = config__13447__auto__;
var G__37746 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_zoom_DASH_change;
var G__37747 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__37745,G__37746,G__37747) : handler__13449__auto__.call(null,G__37745,G__37746,G__37747));
})();
var handler_fn_37741 = ((function (event_fn_37740){
return (function (cb_zoom_change_info_37743){
return (event_fn_37740.cljs$core$IFn$_invoke$arity$1 ? event_fn_37740.cljs$core$IFn$_invoke$arity$1(cb_zoom_change_info_37743) : event_fn_37740.call(null,cb_zoom_change_info_37743));
});})(event_fn_37740))
;
var logging_fn__20428__auto__ = ((function (event_fn_37740,handler_fn_37741){
return (function (cb_param_zoom_change_info_37744){

return handler_fn_37741(cb_param_zoom_change_info_37744);
});})(event_fn_37740,handler_fn_37741))
;
var ns_obj_37742 = (function (){var target_obj_37748 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_37749 = goog.object.get(target_obj_37748,"chrome");
var next_obj_37750 = goog.object.get(next_obj_37749,"tabs");
return next_obj_37750;
})();
var config__13480__auto___37756 = config;
var api_check_fn__13481__auto___37757 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___37756);

(api_check_fn__13481__auto___37757.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___37757.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onZoomChange",ns_obj_37742,"onZoomChange") : api_check_fn__13481__auto___37757.call(null,"chrome.tabs.onZoomChange",ns_obj_37742,"onZoomChange"));

var event_obj__20429__auto__ = (function (){var target_obj_37751 = ns_obj_37742;
var next_obj_37752 = goog.object.get(target_obj_37751,"onZoomChange");
return next_obj_37752;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.tabs.on_zoom_change_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.tabs.on_zoom_change_STAR_.cljs$lang$applyTo = (function (seq37737){
var G__37738 = cljs.core.first(seq37737);
var seq37737__$1 = cljs.core.next(seq37737);
var G__37739 = cljs.core.first(seq37737__$1);
var seq37737__$2 = cljs.core.next(seq37737__$1);
return chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__37738,G__37739,seq37737__$2);
});


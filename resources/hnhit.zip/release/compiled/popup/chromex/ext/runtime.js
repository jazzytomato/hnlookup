// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.runtime');
goog.require('cljs.core');
goog.require('chromex.core');
chromex.ext.runtime.last_error_STAR_ = (function chromex$ext$runtime$last_error_STAR_(config){
var result_32605 = (function (){var final_args_array_32606 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.lastError");
var ns_32607 = (function (){var target_obj_32609 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32610 = goog.object.get(target_obj_32609,"chrome");
var next_obj_32611 = goog.object.get(next_obj_32610,"runtime");
return next_obj_32611;
})();


var target_32608 = (function (){var target_obj_32612 = ns_32607;
var next_obj_32613 = goog.object.get(target_obj_32612,"lastError");
if(!((next_obj_32613 == null))){
return next_obj_32613;
} else {
return null;
}
})();
return target_32608;
})();
return result_32605;
});
chromex.ext.runtime.id_STAR_ = (function chromex$ext$runtime$id_STAR_(config){
var result_32623 = (function (){var final_args_array_32624 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.id");
var ns_32625 = (function (){var target_obj_32627 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32628 = goog.object.get(target_obj_32627,"chrome");
var next_obj_32629 = goog.object.get(next_obj_32628,"runtime");
return next_obj_32629;
})();


var target_32626 = (function (){var target_obj_32630 = ns_32625;
var next_obj_32631 = goog.object.get(target_obj_32630,"id");
if(!((next_obj_32631 == null))){
return next_obj_32631;
} else {
return null;
}
})();
return target_32626;
})();
return result_32623;
});
chromex.ext.runtime.get_background_page_STAR_ = (function chromex$ext$runtime$get_background_page_STAR_(config){
var callback_chan_32647 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_32649_32662 = ((function (callback_chan_32647){
return (function (cb_background_page_32653){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__32654 = config__13447__auto__;
var G__32655 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_background_DASH_page,cljs.core.cst$kw$name,"getBackgroundPage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"background-page",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__32656 = callback_chan_32647;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__32654,G__32655,G__32656) : handler__13449__auto__.call(null,G__32654,G__32655,G__32656));
})().call(null,cb_background_page_32653);
});})(callback_chan_32647))
;
var result_32648_32663 = (function (){var final_args_array_32650 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_32649_32662,"callback",null], null)], null),"chrome.runtime.getBackgroundPage");
var ns_32651 = (function (){var target_obj_32657 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32658 = goog.object.get(target_obj_32657,"chrome");
var next_obj_32659 = goog.object.get(next_obj_32658,"runtime");
return next_obj_32659;
})();
var config__13480__auto___32664 = config;
var api_check_fn__13481__auto___32665 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32664);

(api_check_fn__13481__auto___32665.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32665.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getBackgroundPage",ns_32651,"getBackgroundPage") : api_check_fn__13481__auto___32665.call(null,"chrome.runtime.getBackgroundPage",ns_32651,"getBackgroundPage"));


var target_32652 = (function (){var target_obj_32660 = ns_32651;
var next_obj_32661 = goog.object.get(target_obj_32660,"getBackgroundPage");
if(!((next_obj_32661 == null))){
return next_obj_32661;
} else {
return null;
}
})();
return target_32652.apply(ns_32651,final_args_array_32650);
})();

return callback_chan_32647;
});
chromex.ext.runtime.open_options_page_STAR_ = (function chromex$ext$runtime$open_options_page_STAR_(config){
var callback_chan_32680 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_32682_32694 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__32686 = config__13447__auto__;
var G__32687 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_open_DASH_options_DASH_page,cljs.core.cst$kw$name,"openOptionsPage",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__32688 = callback_chan_32680;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__32686,G__32687,G__32688) : handler__13449__auto__.call(null,G__32686,G__32687,G__32688));
})();
var result_32681_32695 = (function (){var final_args_array_32683 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_32682_32694,"callback",true], null)], null),"chrome.runtime.openOptionsPage");
var ns_32684 = (function (){var target_obj_32689 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32690 = goog.object.get(target_obj_32689,"chrome");
var next_obj_32691 = goog.object.get(next_obj_32690,"runtime");
return next_obj_32691;
})();
var config__13480__auto___32696 = config;
var api_check_fn__13481__auto___32697 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32696);

(api_check_fn__13481__auto___32697.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32697.cljs$core$IFn$_invoke$arity$3("chrome.runtime.openOptionsPage",ns_32684,"openOptionsPage") : api_check_fn__13481__auto___32697.call(null,"chrome.runtime.openOptionsPage",ns_32684,"openOptionsPage"));


var target_32685 = (function (){var target_obj_32692 = ns_32684;
var next_obj_32693 = goog.object.get(target_obj_32692,"openOptionsPage");
if(!((next_obj_32693 == null))){
return next_obj_32693;
} else {
return null;
}
})();
return target_32685.apply(ns_32684,final_args_array_32683);
})();

return callback_chan_32680;
});
chromex.ext.runtime.get_manifest_STAR_ = (function chromex$ext$runtime$get_manifest_STAR_(config){
var result_32707 = (function (){var final_args_array_32708 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.getManifest");
var ns_32709 = (function (){var target_obj_32711 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32712 = goog.object.get(target_obj_32711,"chrome");
var next_obj_32713 = goog.object.get(next_obj_32712,"runtime");
return next_obj_32713;
})();
var config__13480__auto___32716 = config;
var api_check_fn__13481__auto___32717 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32716);

(api_check_fn__13481__auto___32717.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32717.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getManifest",ns_32709,"getManifest") : api_check_fn__13481__auto___32717.call(null,"chrome.runtime.getManifest",ns_32709,"getManifest"));


var target_32710 = (function (){var target_obj_32714 = ns_32709;
var next_obj_32715 = goog.object.get(target_obj_32714,"getManifest");
if(!((next_obj_32715 == null))){
return next_obj_32715;
} else {
return null;
}
})();
return target_32710.apply(ns_32709,final_args_array_32708);
})();
return result_32707;
});
chromex.ext.runtime.get_url_STAR_ = (function chromex$ext$runtime$get_url_STAR_(config,path){
var marshalled_path_32730 = (function (){var omit_test_32734 = path;
if(cljs.core.keyword_identical_QMARK_(omit_test_32734,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_32734;
}
})();
var result_32729 = (function (){var final_args_array_32731 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_path_32730,"path",null], null)], null),"chrome.runtime.getURL");
var ns_32732 = (function (){var target_obj_32735 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32736 = goog.object.get(target_obj_32735,"chrome");
var next_obj_32737 = goog.object.get(next_obj_32736,"runtime");
return next_obj_32737;
})();
var config__13480__auto___32740 = config;
var api_check_fn__13481__auto___32741 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32740);

(api_check_fn__13481__auto___32741.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32741.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getURL",ns_32732,"getURL") : api_check_fn__13481__auto___32741.call(null,"chrome.runtime.getURL",ns_32732,"getURL"));


var target_32733 = (function (){var target_obj_32738 = ns_32732;
var next_obj_32739 = goog.object.get(target_obj_32738,"getURL");
if(!((next_obj_32739 == null))){
return next_obj_32739;
} else {
return null;
}
})();
return target_32733.apply(ns_32732,final_args_array_32731);
})();
return result_32729;
});
chromex.ext.runtime.set_uninstall_url_STAR_ = (function chromex$ext$runtime$set_uninstall_url_STAR_(config,url){
var callback_chan_32758 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_url_32760_32774 = (function (){var omit_test_32765 = url;
if(cljs.core.keyword_identical_QMARK_(omit_test_32765,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_32765;
}
})();
var marshalled_callback_32761_32775 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__32766 = config__13447__auto__;
var G__32767 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_set_DASH_uninstall_DASH_url,cljs.core.cst$kw$name,"setUninstallURL",cljs.core.cst$kw$since,"41",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"url",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__32768 = callback_chan_32758;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__32766,G__32767,G__32768) : handler__13449__auto__.call(null,G__32766,G__32767,G__32768));
})();
var result_32759_32776 = (function (){var final_args_array_32762 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_url_32760_32774,"url",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_32761_32775,"callback",true], null)], null),"chrome.runtime.setUninstallURL");
var ns_32763 = (function (){var target_obj_32769 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32770 = goog.object.get(target_obj_32769,"chrome");
var next_obj_32771 = goog.object.get(next_obj_32770,"runtime");
return next_obj_32771;
})();
var config__13480__auto___32777 = config;
var api_check_fn__13481__auto___32778 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32777);

(api_check_fn__13481__auto___32778.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32778.cljs$core$IFn$_invoke$arity$3("chrome.runtime.setUninstallURL",ns_32763,"setUninstallURL") : api_check_fn__13481__auto___32778.call(null,"chrome.runtime.setUninstallURL",ns_32763,"setUninstallURL"));


var target_32764 = (function (){var target_obj_32772 = ns_32763;
var next_obj_32773 = goog.object.get(target_obj_32772,"setUninstallURL");
if(!((next_obj_32773 == null))){
return next_obj_32773;
} else {
return null;
}
})();
return target_32764.apply(ns_32763,final_args_array_32762);
})();

return callback_chan_32758;
});
chromex.ext.runtime.reload_STAR_ = (function chromex$ext$runtime$reload_STAR_(config){
var result_32788 = (function (){var final_args_array_32789 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.reload");
var ns_32790 = (function (){var target_obj_32792 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32793 = goog.object.get(target_obj_32792,"chrome");
var next_obj_32794 = goog.object.get(next_obj_32793,"runtime");
return next_obj_32794;
})();
var config__13480__auto___32797 = config;
var api_check_fn__13481__auto___32798 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32797);

(api_check_fn__13481__auto___32798.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32798.cljs$core$IFn$_invoke$arity$3("chrome.runtime.reload",ns_32790,"reload") : api_check_fn__13481__auto___32798.call(null,"chrome.runtime.reload",ns_32790,"reload"));


var target_32791 = (function (){var target_obj_32795 = ns_32790;
var next_obj_32796 = goog.object.get(target_obj_32795,"reload");
if(!((next_obj_32796 == null))){
return next_obj_32796;
} else {
return null;
}
})();
return target_32791.apply(ns_32790,final_args_array_32789);
})();
return result_32788;
});
chromex.ext.runtime.request_update_check_STAR_ = (function chromex$ext$runtime$request_update_check_STAR_(config){
var callback_chan_32815 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_32817_32831 = ((function (callback_chan_32815){
return (function (cb_status_32821,cb_details_32822){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__32823 = config__13447__auto__;
var G__32824 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_request_DASH_update_DASH_check,cljs.core.cst$kw$name,"requestUpdateCheck",cljs.core.cst$kw$since,"25",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"status",cljs.core.cst$kw$type,"runtime.RequestUpdateCheckStatus"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__32825 = callback_chan_32815;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__32823,G__32824,G__32825) : handler__13449__auto__.call(null,G__32823,G__32824,G__32825));
})().call(null,cb_status_32821,cb_details_32822);
});})(callback_chan_32815))
;
var result_32816_32832 = (function (){var final_args_array_32818 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_32817_32831,"callback",null], null)], null),"chrome.runtime.requestUpdateCheck");
var ns_32819 = (function (){var target_obj_32826 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32827 = goog.object.get(target_obj_32826,"chrome");
var next_obj_32828 = goog.object.get(next_obj_32827,"runtime");
return next_obj_32828;
})();
var config__13480__auto___32833 = config;
var api_check_fn__13481__auto___32834 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32833);

(api_check_fn__13481__auto___32834.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32834.cljs$core$IFn$_invoke$arity$3("chrome.runtime.requestUpdateCheck",ns_32819,"requestUpdateCheck") : api_check_fn__13481__auto___32834.call(null,"chrome.runtime.requestUpdateCheck",ns_32819,"requestUpdateCheck"));


var target_32820 = (function (){var target_obj_32829 = ns_32819;
var next_obj_32830 = goog.object.get(target_obj_32829,"requestUpdateCheck");
if(!((next_obj_32830 == null))){
return next_obj_32830;
} else {
return null;
}
})();
return target_32820.apply(ns_32819,final_args_array_32818);
})();

return callback_chan_32815;
});
chromex.ext.runtime.restart_STAR_ = (function chromex$ext$runtime$restart_STAR_(config){
var result_32844 = (function (){var final_args_array_32845 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.restart");
var ns_32846 = (function (){var target_obj_32848 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32849 = goog.object.get(target_obj_32848,"chrome");
var next_obj_32850 = goog.object.get(next_obj_32849,"runtime");
return next_obj_32850;
})();
var config__13480__auto___32853 = config;
var api_check_fn__13481__auto___32854 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32853);

(api_check_fn__13481__auto___32854.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32854.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restart",ns_32846,"restart") : api_check_fn__13481__auto___32854.call(null,"chrome.runtime.restart",ns_32846,"restart"));


var target_32847 = (function (){var target_obj_32851 = ns_32846;
var next_obj_32852 = goog.object.get(target_obj_32851,"restart");
if(!((next_obj_32852 == null))){
return next_obj_32852;
} else {
return null;
}
})();
return target_32847.apply(ns_32846,final_args_array_32845);
})();
return result_32844;
});
chromex.ext.runtime.restart_after_delay_STAR_ = (function chromex$ext$runtime$restart_after_delay_STAR_(config,seconds){
var callback_chan_32871 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_seconds_32873_32887 = (function (){var omit_test_32878 = seconds;
if(cljs.core.keyword_identical_QMARK_(omit_test_32878,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_32878;
}
})();
var marshalled_callback_32874_32888 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__32879 = config__13447__auto__;
var G__32880 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_restart_DASH_after_DASH_delay,cljs.core.cst$kw$name,"restartAfterDelay",cljs.core.cst$kw$since,"53",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"seconds",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__32881 = callback_chan_32871;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__32879,G__32880,G__32881) : handler__13449__auto__.call(null,G__32879,G__32880,G__32881));
})();
var result_32872_32889 = (function (){var final_args_array_32875 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_seconds_32873_32887,"seconds",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_32874_32888,"callback",true], null)], null),"chrome.runtime.restartAfterDelay");
var ns_32876 = (function (){var target_obj_32882 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32883 = goog.object.get(target_obj_32882,"chrome");
var next_obj_32884 = goog.object.get(next_obj_32883,"runtime");
return next_obj_32884;
})();
var config__13480__auto___32890 = config;
var api_check_fn__13481__auto___32891 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32890);

(api_check_fn__13481__auto___32891.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32891.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restartAfterDelay",ns_32876,"restartAfterDelay") : api_check_fn__13481__auto___32891.call(null,"chrome.runtime.restartAfterDelay",ns_32876,"restartAfterDelay"));


var target_32877 = (function (){var target_obj_32885 = ns_32876;
var next_obj_32886 = goog.object.get(target_obj_32885,"restartAfterDelay");
if(!((next_obj_32886 == null))){
return next_obj_32886;
} else {
return null;
}
})();
return target_32877.apply(ns_32876,final_args_array_32875);
})();

return callback_chan_32871;
});
chromex.ext.runtime.connect_STAR_ = (function chromex$ext$runtime$connect_STAR_(config,extension_id,connect_info){
var marshalled_extension_id_32906 = (function (){var omit_test_32911 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_32911,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_32911;
}
})();
var marshalled_connect_info_32907 = (function (){var omit_test_32912 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_32912,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_32912;
}
})();
var result_32905 = (function (){var final_args_array_32908 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_32906,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_32907,"connect-info",true], null)], null),"chrome.runtime.connect");
var ns_32909 = (function (){var target_obj_32913 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32914 = goog.object.get(target_obj_32913,"chrome");
var next_obj_32915 = goog.object.get(next_obj_32914,"runtime");
return next_obj_32915;
})();
var config__13480__auto___32918 = config;
var api_check_fn__13481__auto___32919 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32918);

(api_check_fn__13481__auto___32919.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32919.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connect",ns_32909,"connect") : api_check_fn__13481__auto___32919.call(null,"chrome.runtime.connect",ns_32909,"connect"));


var target_32910 = (function (){var target_obj_32916 = ns_32909;
var next_obj_32917 = goog.object.get(target_obj_32916,"connect");
if(!((next_obj_32917 == null))){
return next_obj_32917;
} else {
return null;
}
})();
return target_32910.apply(ns_32909,final_args_array_32908);
})();
return chromex.marshalling.from_native_chrome_port(config,result_32905);
});
chromex.ext.runtime.connect_native_STAR_ = (function chromex$ext$runtime$connect_native_STAR_(config,application){
var marshalled_application_32932 = (function (){var omit_test_32936 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_32936,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_32936;
}
})();
var result_32931 = (function (){var final_args_array_32933 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_32932,"application",null], null)], null),"chrome.runtime.connectNative");
var ns_32934 = (function (){var target_obj_32937 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32938 = goog.object.get(target_obj_32937,"chrome");
var next_obj_32939 = goog.object.get(next_obj_32938,"runtime");
return next_obj_32939;
})();
var config__13480__auto___32942 = config;
var api_check_fn__13481__auto___32943 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32942);

(api_check_fn__13481__auto___32943.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32943.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connectNative",ns_32934,"connectNative") : api_check_fn__13481__auto___32943.call(null,"chrome.runtime.connectNative",ns_32934,"connectNative"));


var target_32935 = (function (){var target_obj_32940 = ns_32934;
var next_obj_32941 = goog.object.get(target_obj_32940,"connectNative");
if(!((next_obj_32941 == null))){
return next_obj_32941;
} else {
return null;
}
})();
return target_32935.apply(ns_32934,final_args_array_32933);
})();
return chromex.marshalling.from_native_chrome_port(config,result_32931);
});
chromex.ext.runtime.send_message_STAR_ = (function chromex$ext$runtime$send_message_STAR_(config,extension_id,message,options){
var callback_chan_32965 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_extension_id_32967_32986 = (function (){var omit_test_32974 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_32974,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_32974;
}
})();
var marshalled_message_32968_32987 = (function (){var omit_test_32975 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_32975,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_32975;
}
})();
var marshalled_options_32969_32988 = (function (){var omit_test_32976 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_32976,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_32976;
}
})();
var marshalled_response_callback_32970_32989 = ((function (marshalled_extension_id_32967_32986,marshalled_message_32968_32987,marshalled_options_32969_32988,callback_chan_32965){
return (function (cb_response_32977){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__32978 = config__13447__auto__;
var G__32979 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$since,"26",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"extension-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__32980 = callback_chan_32965;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__32978,G__32979,G__32980) : handler__13449__auto__.call(null,G__32978,G__32979,G__32980));
})().call(null,cb_response_32977);
});})(marshalled_extension_id_32967_32986,marshalled_message_32968_32987,marshalled_options_32969_32988,callback_chan_32965))
;
var result_32966_32990 = (function (){var final_args_array_32971 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_32967_32986,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_32968_32987,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_32969_32988,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_32970_32989,"response-callback",true], null)], null),"chrome.runtime.sendMessage");
var ns_32972 = (function (){var target_obj_32981 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32982 = goog.object.get(target_obj_32981,"chrome");
var next_obj_32983 = goog.object.get(next_obj_32982,"runtime");
return next_obj_32983;
})();
var config__13480__auto___32991 = config;
var api_check_fn__13481__auto___32992 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___32991);

(api_check_fn__13481__auto___32992.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___32992.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendMessage",ns_32972,"sendMessage") : api_check_fn__13481__auto___32992.call(null,"chrome.runtime.sendMessage",ns_32972,"sendMessage"));


var target_32973 = (function (){var target_obj_32984 = ns_32972;
var next_obj_32985 = goog.object.get(target_obj_32984,"sendMessage");
if(!((next_obj_32985 == null))){
return next_obj_32985;
} else {
return null;
}
})();
return target_32973.apply(ns_32972,final_args_array_32971);
})();

return callback_chan_32965;
});
chromex.ext.runtime.send_native_message_STAR_ = (function chromex$ext$runtime$send_native_message_STAR_(config,application,message){
var callback_chan_33012 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_application_33014_33031 = (function (){var omit_test_33020 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_33020,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_33020;
}
})();
var marshalled_message_33015_33032 = (function (){var omit_test_33021 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_33021,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_33021;
}
})();
var marshalled_response_callback_33016_33033 = ((function (marshalled_application_33014_33031,marshalled_message_33015_33032,callback_chan_33012){
return (function (cb_response_33022){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33023 = config__13447__auto__;
var G__33024 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_native_DASH_message,cljs.core.cst$kw$name,"sendNativeMessage",cljs.core.cst$kw$since,"28",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"application",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__33025 = callback_chan_33012;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33023,G__33024,G__33025) : handler__13449__auto__.call(null,G__33023,G__33024,G__33025));
})().call(null,cb_response_33022);
});})(marshalled_application_33014_33031,marshalled_message_33015_33032,callback_chan_33012))
;
var result_33013_33034 = (function (){var final_args_array_33017 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_33014_33031,"application",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_33015_33032,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_33016_33033,"response-callback",true], null)], null),"chrome.runtime.sendNativeMessage");
var ns_33018 = (function (){var target_obj_33026 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33027 = goog.object.get(target_obj_33026,"chrome");
var next_obj_33028 = goog.object.get(next_obj_33027,"runtime");
return next_obj_33028;
})();
var config__13480__auto___33035 = config;
var api_check_fn__13481__auto___33036 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33035);

(api_check_fn__13481__auto___33036.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33036.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendNativeMessage",ns_33018,"sendNativeMessage") : api_check_fn__13481__auto___33036.call(null,"chrome.runtime.sendNativeMessage",ns_33018,"sendNativeMessage"));


var target_33019 = (function (){var target_obj_33029 = ns_33018;
var next_obj_33030 = goog.object.get(target_obj_33029,"sendNativeMessage");
if(!((next_obj_33030 == null))){
return next_obj_33030;
} else {
return null;
}
})();
return target_33019.apply(ns_33018,final_args_array_33017);
})();

return callback_chan_33012;
});
chromex.ext.runtime.get_platform_info_STAR_ = (function chromex$ext$runtime$get_platform_info_STAR_(config){
var callback_chan_33052 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_33054_33067 = ((function (callback_chan_33052){
return (function (cb_platform_info_33058){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33059 = config__13447__auto__;
var G__33060 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_platform_DASH_info,cljs.core.cst$kw$name,"getPlatformInfo",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"platform-info",cljs.core.cst$kw$type,"runtime.PlatformInfo"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__33061 = callback_chan_33052;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33059,G__33060,G__33061) : handler__13449__auto__.call(null,G__33059,G__33060,G__33061));
})().call(null,cb_platform_info_33058);
});})(callback_chan_33052))
;
var result_33053_33068 = (function (){var final_args_array_33055 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_33054_33067,"callback",null], null)], null),"chrome.runtime.getPlatformInfo");
var ns_33056 = (function (){var target_obj_33062 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33063 = goog.object.get(target_obj_33062,"chrome");
var next_obj_33064 = goog.object.get(next_obj_33063,"runtime");
return next_obj_33064;
})();
var config__13480__auto___33069 = config;
var api_check_fn__13481__auto___33070 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33069);

(api_check_fn__13481__auto___33070.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33070.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPlatformInfo",ns_33056,"getPlatformInfo") : api_check_fn__13481__auto___33070.call(null,"chrome.runtime.getPlatformInfo",ns_33056,"getPlatformInfo"));


var target_33057 = (function (){var target_obj_33065 = ns_33056;
var next_obj_33066 = goog.object.get(target_obj_33065,"getPlatformInfo");
if(!((next_obj_33066 == null))){
return next_obj_33066;
} else {
return null;
}
})();
return target_33057.apply(ns_33056,final_args_array_33055);
})();

return callback_chan_33052;
});
chromex.ext.runtime.get_package_directory_entry_STAR_ = (function chromex$ext$runtime$get_package_directory_entry_STAR_(config){
var callback_chan_33086 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler__13449__auto__.call(null,config__13447__auto__));
})();
var marshalled_callback_33088_33101 = ((function (callback_chan_33086){
return (function (cb_directory_entry_33092){
return (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33093 = config__13447__auto__;
var G__33094 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_package_DASH_directory_DASH_entry,cljs.core.cst$kw$name,"getPackageDirectoryEntry",cljs.core.cst$kw$since,"29",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"directory-entry",cljs.core.cst$kw$type,"DirectoryEntry"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__33095 = callback_chan_33086;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33093,G__33094,G__33095) : handler__13449__auto__.call(null,G__33093,G__33094,G__33095));
})().call(null,cb_directory_entry_33092);
});})(callback_chan_33086))
;
var result_33087_33102 = (function (){var final_args_array_33089 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_33088_33101,"callback",null], null)], null),"chrome.runtime.getPackageDirectoryEntry");
var ns_33090 = (function (){var target_obj_33096 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33097 = goog.object.get(target_obj_33096,"chrome");
var next_obj_33098 = goog.object.get(next_obj_33097,"runtime");
return next_obj_33098;
})();
var config__13480__auto___33103 = config;
var api_check_fn__13481__auto___33104 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33103);

(api_check_fn__13481__auto___33104.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33104.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPackageDirectoryEntry",ns_33090,"getPackageDirectoryEntry") : api_check_fn__13481__auto___33104.call(null,"chrome.runtime.getPackageDirectoryEntry",ns_33090,"getPackageDirectoryEntry"));


var target_33091 = (function (){var target_obj_33099 = ns_33090;
var next_obj_33100 = goog.object.get(target_obj_33099,"getPackageDirectoryEntry");
if(!((next_obj_33100 == null))){
return next_obj_33100;
} else {
return null;
}
})();
return target_33091.apply(ns_33090,final_args_array_33089);
})();

return callback_chan_33086;
});
chromex.ext.runtime.on_startup_STAR_ = (function chromex$ext$runtime$on_startup_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___33119 = arguments.length;
var i__8119__auto___33120 = (0);
while(true){
if((i__8119__auto___33120 < len__8118__auto___33119)){
args__8125__auto__.push((arguments[i__8119__auto___33120]));

var G__33121 = (i__8119__auto___33120 + (1));
i__8119__auto___33120 = G__33121;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_33108 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33111 = config__13447__auto__;
var G__33112 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_startup;
var G__33113 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33111,G__33112,G__33113) : handler__13449__auto__.call(null,G__33111,G__33112,G__33113));
})();
var handler_fn_33109 = event_fn_33108;
var logging_fn__20428__auto__ = ((function (event_fn_33108,handler_fn_33109){
return (function (){

return (handler_fn_33109.cljs$core$IFn$_invoke$arity$0 ? handler_fn_33109.cljs$core$IFn$_invoke$arity$0() : handler_fn_33109.call(null));
});})(event_fn_33108,handler_fn_33109))
;
var ns_obj_33110 = (function (){var target_obj_33114 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33115 = goog.object.get(target_obj_33114,"chrome");
var next_obj_33116 = goog.object.get(next_obj_33115,"runtime");
return next_obj_33116;
})();
var config__13480__auto___33122 = config;
var api_check_fn__13481__auto___33123 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33122);

(api_check_fn__13481__auto___33123.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33123.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onStartup",ns_obj_33110,"onStartup") : api_check_fn__13481__auto___33123.call(null,"chrome.runtime.onStartup",ns_obj_33110,"onStartup"));

var event_obj__20429__auto__ = (function (){var target_obj_33117 = ns_obj_33110;
var next_obj_33118 = goog.object.get(target_obj_33117,"onStartup");
return next_obj_33118;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_startup_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_startup_STAR_.cljs$lang$applyTo = (function (seq33105){
var G__33106 = cljs.core.first(seq33105);
var seq33105__$1 = cljs.core.next(seq33105);
var G__33107 = cljs.core.first(seq33105__$1);
var seq33105__$2 = cljs.core.next(seq33105__$1);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__33106,G__33107,seq33105__$2);
});

chromex.ext.runtime.on_installed_STAR_ = (function chromex$ext$runtime$on_installed_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___33140 = arguments.length;
var i__8119__auto___33141 = (0);
while(true){
if((i__8119__auto___33141 < len__8118__auto___33140)){
args__8125__auto__.push((arguments[i__8119__auto___33141]));

var G__33142 = (i__8119__auto___33141 + (1));
i__8119__auto___33141 = G__33142;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_33127 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33132 = config__13447__auto__;
var G__33133 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_installed;
var G__33134 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33132,G__33133,G__33134) : handler__13449__auto__.call(null,G__33132,G__33133,G__33134));
})();
var handler_fn_33128 = ((function (event_fn_33127){
return (function (cb_details_33130){
return (event_fn_33127.cljs$core$IFn$_invoke$arity$1 ? event_fn_33127.cljs$core$IFn$_invoke$arity$1(cb_details_33130) : event_fn_33127.call(null,cb_details_33130));
});})(event_fn_33127))
;
var logging_fn__20428__auto__ = ((function (event_fn_33127,handler_fn_33128){
return (function (cb_param_details_33131){

return handler_fn_33128(cb_param_details_33131);
});})(event_fn_33127,handler_fn_33128))
;
var ns_obj_33129 = (function (){var target_obj_33135 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33136 = goog.object.get(target_obj_33135,"chrome");
var next_obj_33137 = goog.object.get(next_obj_33136,"runtime");
return next_obj_33137;
})();
var config__13480__auto___33143 = config;
var api_check_fn__13481__auto___33144 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33143);

(api_check_fn__13481__auto___33144.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33144.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onInstalled",ns_obj_33129,"onInstalled") : api_check_fn__13481__auto___33144.call(null,"chrome.runtime.onInstalled",ns_obj_33129,"onInstalled"));

var event_obj__20429__auto__ = (function (){var target_obj_33138 = ns_obj_33129;
var next_obj_33139 = goog.object.get(target_obj_33138,"onInstalled");
return next_obj_33139;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_installed_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_installed_STAR_.cljs$lang$applyTo = (function (seq33124){
var G__33125 = cljs.core.first(seq33124);
var seq33124__$1 = cljs.core.next(seq33124);
var G__33126 = cljs.core.first(seq33124__$1);
var seq33124__$2 = cljs.core.next(seq33124__$1);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__33125,G__33126,seq33124__$2);
});

chromex.ext.runtime.on_suspend_STAR_ = (function chromex$ext$runtime$on_suspend_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___33159 = arguments.length;
var i__8119__auto___33160 = (0);
while(true){
if((i__8119__auto___33160 < len__8118__auto___33159)){
args__8125__auto__.push((arguments[i__8119__auto___33160]));

var G__33161 = (i__8119__auto___33160 + (1));
i__8119__auto___33160 = G__33161;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_33148 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33151 = config__13447__auto__;
var G__33152 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend;
var G__33153 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33151,G__33152,G__33153) : handler__13449__auto__.call(null,G__33151,G__33152,G__33153));
})();
var handler_fn_33149 = event_fn_33148;
var logging_fn__20428__auto__ = ((function (event_fn_33148,handler_fn_33149){
return (function (){

return (handler_fn_33149.cljs$core$IFn$_invoke$arity$0 ? handler_fn_33149.cljs$core$IFn$_invoke$arity$0() : handler_fn_33149.call(null));
});})(event_fn_33148,handler_fn_33149))
;
var ns_obj_33150 = (function (){var target_obj_33154 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33155 = goog.object.get(target_obj_33154,"chrome");
var next_obj_33156 = goog.object.get(next_obj_33155,"runtime");
return next_obj_33156;
})();
var config__13480__auto___33162 = config;
var api_check_fn__13481__auto___33163 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33162);

(api_check_fn__13481__auto___33163.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33163.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspend",ns_obj_33150,"onSuspend") : api_check_fn__13481__auto___33163.call(null,"chrome.runtime.onSuspend",ns_obj_33150,"onSuspend"));

var event_obj__20429__auto__ = (function (){var target_obj_33157 = ns_obj_33150;
var next_obj_33158 = goog.object.get(target_obj_33157,"onSuspend");
return next_obj_33158;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_suspend_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_suspend_STAR_.cljs$lang$applyTo = (function (seq33145){
var G__33146 = cljs.core.first(seq33145);
var seq33145__$1 = cljs.core.next(seq33145);
var G__33147 = cljs.core.first(seq33145__$1);
var seq33145__$2 = cljs.core.next(seq33145__$1);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__33146,G__33147,seq33145__$2);
});

chromex.ext.runtime.on_suspend_canceled_STAR_ = (function chromex$ext$runtime$on_suspend_canceled_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___33178 = arguments.length;
var i__8119__auto___33179 = (0);
while(true){
if((i__8119__auto___33179 < len__8118__auto___33178)){
args__8125__auto__.push((arguments[i__8119__auto___33179]));

var G__33180 = (i__8119__auto___33179 + (1));
i__8119__auto___33179 = G__33180;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_33167 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33170 = config__13447__auto__;
var G__33171 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend_DASH_canceled;
var G__33172 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33170,G__33171,G__33172) : handler__13449__auto__.call(null,G__33170,G__33171,G__33172));
})();
var handler_fn_33168 = event_fn_33167;
var logging_fn__20428__auto__ = ((function (event_fn_33167,handler_fn_33168){
return (function (){

return (handler_fn_33168.cljs$core$IFn$_invoke$arity$0 ? handler_fn_33168.cljs$core$IFn$_invoke$arity$0() : handler_fn_33168.call(null));
});})(event_fn_33167,handler_fn_33168))
;
var ns_obj_33169 = (function (){var target_obj_33173 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33174 = goog.object.get(target_obj_33173,"chrome");
var next_obj_33175 = goog.object.get(next_obj_33174,"runtime");
return next_obj_33175;
})();
var config__13480__auto___33181 = config;
var api_check_fn__13481__auto___33182 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33181);

(api_check_fn__13481__auto___33182.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33182.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspendCanceled",ns_obj_33169,"onSuspendCanceled") : api_check_fn__13481__auto___33182.call(null,"chrome.runtime.onSuspendCanceled",ns_obj_33169,"onSuspendCanceled"));

var event_obj__20429__auto__ = (function (){var target_obj_33176 = ns_obj_33169;
var next_obj_33177 = goog.object.get(target_obj_33176,"onSuspendCanceled");
return next_obj_33177;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$applyTo = (function (seq33164){
var G__33165 = cljs.core.first(seq33164);
var seq33164__$1 = cljs.core.next(seq33164);
var G__33166 = cljs.core.first(seq33164__$1);
var seq33164__$2 = cljs.core.next(seq33164__$1);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__33165,G__33166,seq33164__$2);
});

chromex.ext.runtime.on_update_available_STAR_ = (function chromex$ext$runtime$on_update_available_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___33199 = arguments.length;
var i__8119__auto___33200 = (0);
while(true){
if((i__8119__auto___33200 < len__8118__auto___33199)){
args__8125__auto__.push((arguments[i__8119__auto___33200]));

var G__33201 = (i__8119__auto___33200 + (1));
i__8119__auto___33200 = G__33201;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_33186 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33191 = config__13447__auto__;
var G__33192 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_update_DASH_available;
var G__33193 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33191,G__33192,G__33193) : handler__13449__auto__.call(null,G__33191,G__33192,G__33193));
})();
var handler_fn_33187 = ((function (event_fn_33186){
return (function (cb_details_33189){
return (event_fn_33186.cljs$core$IFn$_invoke$arity$1 ? event_fn_33186.cljs$core$IFn$_invoke$arity$1(cb_details_33189) : event_fn_33186.call(null,cb_details_33189));
});})(event_fn_33186))
;
var logging_fn__20428__auto__ = ((function (event_fn_33186,handler_fn_33187){
return (function (cb_param_details_33190){

return handler_fn_33187(cb_param_details_33190);
});})(event_fn_33186,handler_fn_33187))
;
var ns_obj_33188 = (function (){var target_obj_33194 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33195 = goog.object.get(target_obj_33194,"chrome");
var next_obj_33196 = goog.object.get(next_obj_33195,"runtime");
return next_obj_33196;
})();
var config__13480__auto___33202 = config;
var api_check_fn__13481__auto___33203 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33202);

(api_check_fn__13481__auto___33203.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33203.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onUpdateAvailable",ns_obj_33188,"onUpdateAvailable") : api_check_fn__13481__auto___33203.call(null,"chrome.runtime.onUpdateAvailable",ns_obj_33188,"onUpdateAvailable"));

var event_obj__20429__auto__ = (function (){var target_obj_33197 = ns_obj_33188;
var next_obj_33198 = goog.object.get(target_obj_33197,"onUpdateAvailable");
return next_obj_33198;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_update_available_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_update_available_STAR_.cljs$lang$applyTo = (function (seq33183){
var G__33184 = cljs.core.first(seq33183);
var seq33183__$1 = cljs.core.next(seq33183);
var G__33185 = cljs.core.first(seq33183__$1);
var seq33183__$2 = cljs.core.next(seq33183__$1);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__33184,G__33185,seq33183__$2);
});

chromex.ext.runtime.on_browser_update_available_STAR_ = (function chromex$ext$runtime$on_browser_update_available_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___33218 = arguments.length;
var i__8119__auto___33219 = (0);
while(true){
if((i__8119__auto___33219 < len__8118__auto___33218)){
args__8125__auto__.push((arguments[i__8119__auto___33219]));

var G__33220 = (i__8119__auto___33219 + (1));
i__8119__auto___33219 = G__33220;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_33207 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33210 = config__13447__auto__;
var G__33211 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_browser_DASH_update_DASH_available;
var G__33212 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33210,G__33211,G__33212) : handler__13449__auto__.call(null,G__33210,G__33211,G__33212));
})();
var handler_fn_33208 = event_fn_33207;
var logging_fn__20428__auto__ = ((function (event_fn_33207,handler_fn_33208){
return (function (){

return (handler_fn_33208.cljs$core$IFn$_invoke$arity$0 ? handler_fn_33208.cljs$core$IFn$_invoke$arity$0() : handler_fn_33208.call(null));
});})(event_fn_33207,handler_fn_33208))
;
var ns_obj_33209 = (function (){var target_obj_33213 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33214 = goog.object.get(target_obj_33213,"chrome");
var next_obj_33215 = goog.object.get(next_obj_33214,"runtime");
return next_obj_33215;
})();
var config__13480__auto___33221 = config;
var api_check_fn__13481__auto___33222 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33221);

(api_check_fn__13481__auto___33222.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33222.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onBrowserUpdateAvailable",ns_obj_33209,"onBrowserUpdateAvailable") : api_check_fn__13481__auto___33222.call(null,"chrome.runtime.onBrowserUpdateAvailable",ns_obj_33209,"onBrowserUpdateAvailable"));

var event_obj__20429__auto__ = (function (){var target_obj_33216 = ns_obj_33209;
var next_obj_33217 = goog.object.get(target_obj_33216,"onBrowserUpdateAvailable");
return next_obj_33217;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$applyTo = (function (seq33204){
var G__33205 = cljs.core.first(seq33204);
var seq33204__$1 = cljs.core.next(seq33204);
var G__33206 = cljs.core.first(seq33204__$1);
var seq33204__$2 = cljs.core.next(seq33204__$1);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__33205,G__33206,seq33204__$2);
});

chromex.ext.runtime.on_connect_STAR_ = (function chromex$ext$runtime$on_connect_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___33240 = arguments.length;
var i__8119__auto___33241 = (0);
while(true){
if((i__8119__auto___33241 < len__8118__auto___33240)){
args__8125__auto__.push((arguments[i__8119__auto___33241]));

var G__33242 = (i__8119__auto___33241 + (1));
i__8119__auto___33241 = G__33242;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_33226 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33231 = config__13447__auto__;
var G__33232 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect;
var G__33233 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33231,G__33232,G__33233) : handler__13449__auto__.call(null,G__33231,G__33232,G__33233));
})();
var handler_fn_33227 = ((function (event_fn_33226){
return (function (cb_port_33229){
var G__33234 = chromex.marshalling.from_native_chrome_port(config,cb_port_33229);
return (event_fn_33226.cljs$core$IFn$_invoke$arity$1 ? event_fn_33226.cljs$core$IFn$_invoke$arity$1(G__33234) : event_fn_33226.call(null,G__33234));
});})(event_fn_33226))
;
var logging_fn__20428__auto__ = ((function (event_fn_33226,handler_fn_33227){
return (function (cb_param_port_33230){

return handler_fn_33227(cb_param_port_33230);
});})(event_fn_33226,handler_fn_33227))
;
var ns_obj_33228 = (function (){var target_obj_33235 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33236 = goog.object.get(target_obj_33235,"chrome");
var next_obj_33237 = goog.object.get(next_obj_33236,"runtime");
return next_obj_33237;
})();
var config__13480__auto___33243 = config;
var api_check_fn__13481__auto___33244 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33243);

(api_check_fn__13481__auto___33244.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33244.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnect",ns_obj_33228,"onConnect") : api_check_fn__13481__auto___33244.call(null,"chrome.runtime.onConnect",ns_obj_33228,"onConnect"));

var event_obj__20429__auto__ = (function (){var target_obj_33238 = ns_obj_33228;
var next_obj_33239 = goog.object.get(target_obj_33238,"onConnect");
return next_obj_33239;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_connect_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_connect_STAR_.cljs$lang$applyTo = (function (seq33223){
var G__33224 = cljs.core.first(seq33223);
var seq33223__$1 = cljs.core.next(seq33223);
var G__33225 = cljs.core.first(seq33223__$1);
var seq33223__$2 = cljs.core.next(seq33223__$1);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__33224,G__33225,seq33223__$2);
});

chromex.ext.runtime.on_connect_external_STAR_ = (function chromex$ext$runtime$on_connect_external_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___33262 = arguments.length;
var i__8119__auto___33263 = (0);
while(true){
if((i__8119__auto___33263 < len__8118__auto___33262)){
args__8125__auto__.push((arguments[i__8119__auto___33263]));

var G__33264 = (i__8119__auto___33263 + (1));
i__8119__auto___33263 = G__33264;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_33248 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33253 = config__13447__auto__;
var G__33254 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_external;
var G__33255 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33253,G__33254,G__33255) : handler__13449__auto__.call(null,G__33253,G__33254,G__33255));
})();
var handler_fn_33249 = ((function (event_fn_33248){
return (function (cb_port_33251){
var G__33256 = chromex.marshalling.from_native_chrome_port(config,cb_port_33251);
return (event_fn_33248.cljs$core$IFn$_invoke$arity$1 ? event_fn_33248.cljs$core$IFn$_invoke$arity$1(G__33256) : event_fn_33248.call(null,G__33256));
});})(event_fn_33248))
;
var logging_fn__20428__auto__ = ((function (event_fn_33248,handler_fn_33249){
return (function (cb_param_port_33252){

return handler_fn_33249(cb_param_port_33252);
});})(event_fn_33248,handler_fn_33249))
;
var ns_obj_33250 = (function (){var target_obj_33257 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33258 = goog.object.get(target_obj_33257,"chrome");
var next_obj_33259 = goog.object.get(next_obj_33258,"runtime");
return next_obj_33259;
})();
var config__13480__auto___33265 = config;
var api_check_fn__13481__auto___33266 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33265);

(api_check_fn__13481__auto___33266.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33266.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectExternal",ns_obj_33250,"onConnectExternal") : api_check_fn__13481__auto___33266.call(null,"chrome.runtime.onConnectExternal",ns_obj_33250,"onConnectExternal"));

var event_obj__20429__auto__ = (function (){var target_obj_33260 = ns_obj_33250;
var next_obj_33261 = goog.object.get(target_obj_33260,"onConnectExternal");
return next_obj_33261;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$applyTo = (function (seq33245){
var G__33246 = cljs.core.first(seq33245);
var seq33245__$1 = cljs.core.next(seq33245);
var G__33247 = cljs.core.first(seq33245__$1);
var seq33245__$2 = cljs.core.next(seq33245__$1);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__33246,G__33247,seq33245__$2);
});

chromex.ext.runtime.on_message_STAR_ = (function chromex$ext$runtime$on_message_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___33287 = arguments.length;
var i__8119__auto___33288 = (0);
while(true){
if((i__8119__auto___33288 < len__8118__auto___33287)){
args__8125__auto__.push((arguments[i__8119__auto___33288]));

var G__33289 = (i__8119__auto___33288 + (1));
i__8119__auto___33288 = G__33289;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_33270 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33279 = config__13447__auto__;
var G__33280 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message;
var G__33281 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33279,G__33280,G__33281) : handler__13449__auto__.call(null,G__33279,G__33280,G__33281));
})();
var handler_fn_33271 = ((function (event_fn_33270){
return (function (cb_message_33273,cb_sender_33274,cb_send_response_33275){
return (event_fn_33270.cljs$core$IFn$_invoke$arity$3 ? event_fn_33270.cljs$core$IFn$_invoke$arity$3(cb_message_33273,cb_sender_33274,cb_send_response_33275) : event_fn_33270.call(null,cb_message_33273,cb_sender_33274,cb_send_response_33275));
});})(event_fn_33270))
;
var logging_fn__20428__auto__ = ((function (event_fn_33270,handler_fn_33271){
return (function (cb_param_message_33276,cb_param_sender_33277,cb_param_send_response_33278){

return handler_fn_33271(cb_param_message_33276,cb_param_sender_33277,cb_param_send_response_33278);
});})(event_fn_33270,handler_fn_33271))
;
var ns_obj_33272 = (function (){var target_obj_33282 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33283 = goog.object.get(target_obj_33282,"chrome");
var next_obj_33284 = goog.object.get(next_obj_33283,"runtime");
return next_obj_33284;
})();
var config__13480__auto___33290 = config;
var api_check_fn__13481__auto___33291 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33290);

(api_check_fn__13481__auto___33291.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33291.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessage",ns_obj_33272,"onMessage") : api_check_fn__13481__auto___33291.call(null,"chrome.runtime.onMessage",ns_obj_33272,"onMessage"));

var event_obj__20429__auto__ = (function (){var target_obj_33285 = ns_obj_33272;
var next_obj_33286 = goog.object.get(target_obj_33285,"onMessage");
return next_obj_33286;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_message_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_message_STAR_.cljs$lang$applyTo = (function (seq33267){
var G__33268 = cljs.core.first(seq33267);
var seq33267__$1 = cljs.core.next(seq33267);
var G__33269 = cljs.core.first(seq33267__$1);
var seq33267__$2 = cljs.core.next(seq33267__$1);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__33268,G__33269,seq33267__$2);
});

chromex.ext.runtime.on_message_external_STAR_ = (function chromex$ext$runtime$on_message_external_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___33312 = arguments.length;
var i__8119__auto___33313 = (0);
while(true){
if((i__8119__auto___33313 < len__8118__auto___33312)){
args__8125__auto__.push((arguments[i__8119__auto___33313]));

var G__33314 = (i__8119__auto___33313 + (1));
i__8119__auto___33313 = G__33314;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_33295 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33304 = config__13447__auto__;
var G__33305 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message_DASH_external;
var G__33306 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33304,G__33305,G__33306) : handler__13449__auto__.call(null,G__33304,G__33305,G__33306));
})();
var handler_fn_33296 = ((function (event_fn_33295){
return (function (cb_message_33298,cb_sender_33299,cb_send_response_33300){
return (event_fn_33295.cljs$core$IFn$_invoke$arity$3 ? event_fn_33295.cljs$core$IFn$_invoke$arity$3(cb_message_33298,cb_sender_33299,cb_send_response_33300) : event_fn_33295.call(null,cb_message_33298,cb_sender_33299,cb_send_response_33300));
});})(event_fn_33295))
;
var logging_fn__20428__auto__ = ((function (event_fn_33295,handler_fn_33296){
return (function (cb_param_message_33301,cb_param_sender_33302,cb_param_send_response_33303){

return handler_fn_33296(cb_param_message_33301,cb_param_sender_33302,cb_param_send_response_33303);
});})(event_fn_33295,handler_fn_33296))
;
var ns_obj_33297 = (function (){var target_obj_33307 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33308 = goog.object.get(target_obj_33307,"chrome");
var next_obj_33309 = goog.object.get(next_obj_33308,"runtime");
return next_obj_33309;
})();
var config__13480__auto___33315 = config;
var api_check_fn__13481__auto___33316 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33315);

(api_check_fn__13481__auto___33316.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33316.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessageExternal",ns_obj_33297,"onMessageExternal") : api_check_fn__13481__auto___33316.call(null,"chrome.runtime.onMessageExternal",ns_obj_33297,"onMessageExternal"));

var event_obj__20429__auto__ = (function (){var target_obj_33310 = ns_obj_33297;
var next_obj_33311 = goog.object.get(target_obj_33310,"onMessageExternal");
return next_obj_33311;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_message_external_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_message_external_STAR_.cljs$lang$applyTo = (function (seq33292){
var G__33293 = cljs.core.first(seq33292);
var seq33292__$1 = cljs.core.next(seq33292);
var G__33294 = cljs.core.first(seq33292__$1);
var seq33292__$2 = cljs.core.next(seq33292__$1);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__33293,G__33294,seq33292__$2);
});

chromex.ext.runtime.on_restart_required_STAR_ = (function chromex$ext$runtime$on_restart_required_STAR_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___33333 = arguments.length;
var i__8119__auto___33334 = (0);
while(true){
if((i__8119__auto___33334 < len__8118__auto___33333)){
args__8125__auto__.push((arguments[i__8119__auto___33334]));

var G__33335 = (i__8119__auto___33334 + (1));
i__8119__auto___33334 = G__33335;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((2) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__8126__auto__);
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_33320 = (function (){var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

var G__33325 = config__13447__auto__;
var G__33326 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_restart_DASH_required;
var G__33327 = channel;
return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$3(G__33325,G__33326,G__33327) : handler__13449__auto__.call(null,G__33325,G__33326,G__33327));
})();
var handler_fn_33321 = ((function (event_fn_33320){
return (function (cb_reason_33323){
return (event_fn_33320.cljs$core$IFn$_invoke$arity$1 ? event_fn_33320.cljs$core$IFn$_invoke$arity$1(cb_reason_33323) : event_fn_33320.call(null,cb_reason_33323));
});})(event_fn_33320))
;
var logging_fn__20428__auto__ = ((function (event_fn_33320,handler_fn_33321){
return (function (cb_param_reason_33324){

return handler_fn_33321(cb_param_reason_33324);
});})(event_fn_33320,handler_fn_33321))
;
var ns_obj_33322 = (function (){var target_obj_33328 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_33329 = goog.object.get(target_obj_33328,"chrome");
var next_obj_33330 = goog.object.get(next_obj_33329,"runtime");
return next_obj_33330;
})();
var config__13480__auto___33336 = config;
var api_check_fn__13481__auto___33337 = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__13480__auto___33336);

(api_check_fn__13481__auto___33337.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__13481__auto___33337.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onRestartRequired",ns_obj_33322,"onRestartRequired") : api_check_fn__13481__auto___33337.call(null,"chrome.runtime.onRestartRequired",ns_obj_33322,"onRestartRequired"));

var event_obj__20429__auto__ = (function (){var target_obj_33331 = ns_obj_33322;
var next_obj_33332 = goog.object.get(target_obj_33331,"onRestartRequired");
return next_obj_33332;
})();
var result__20430__auto__ = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj__20429__auto__,logging_fn__20428__auto__,channel);
chromex.protocols.subscribe_BANG_.cljs$core$IFn$_invoke$arity$2(result__20430__auto__,args);

return result__20430__auto__;
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$maxFixedArity = (2);

chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$applyTo = (function (seq33317){
var G__33318 = cljs.core.first(seq33317);
var seq33317__$1 = cljs.core.next(seq33317);
var G__33319 = cljs.core.first(seq33317__$1);
var seq33317__$2 = cljs.core.next(seq33317__$1);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic(G__33318,G__33319,seq33317__$2);
});


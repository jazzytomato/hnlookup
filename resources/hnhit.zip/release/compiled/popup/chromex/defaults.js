// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.defaults');
goog.require('cljs.core');
goog.require('cljs.core.async');
goog.require('chromex.support');
goog.require('oops.core');
goog.require('goog.object');
goog.require('chromex.error');
goog.require('chromex.protocols');
chromex.defaults.log_prefix = "[chromex]";
chromex.defaults.console_log = (function chromex$defaults$console_log(var_args){
var args__8125__auto__ = [];
var len__8118__auto___32519 = arguments.length;
var i__8119__auto___32520 = (0);
while(true){
if((i__8119__auto___32520 < len__8118__auto___32519)){
args__8125__auto__.push((arguments[i__8119__auto___32520]));

var G__32521 = (i__8119__auto___32520 + (1));
i__8119__auto___32520 = G__32521;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.log.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(args));
});

chromex.defaults.console_log.cljs$lang$maxFixedArity = (0);

chromex.defaults.console_log.cljs$lang$applyTo = (function (seq32518){
return chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq32518));
});

chromex.defaults.console_error = (function chromex$defaults$console_error(var_args){
var args__8125__auto__ = [];
var len__8118__auto___32523 = arguments.length;
var i__8119__auto___32524 = (0);
while(true){
if((i__8119__auto___32524 < len__8118__auto___32523)){
args__8125__auto__.push((arguments[i__8119__auto___32524]));

var G__32525 = (i__8119__auto___32524 + (1));
i__8119__auto___32524 = G__32525;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.error.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(args));
});

chromex.defaults.console_error.cljs$lang$maxFixedArity = (0);

chromex.defaults.console_error.cljs$lang$applyTo = (function (seq32522){
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq32522));
});

chromex.defaults.default_logger = (function chromex$defaults$default_logger(var_args){
var args__8125__auto__ = [];
var len__8118__auto___32527 = arguments.length;
var i__8119__auto___32528 = (0);
while(true){
if((i__8119__auto___32528 < len__8118__auto___32527)){
args__8125__auto__.push((arguments[i__8119__auto___32528]));

var G__32529 = (i__8119__auto___32528 + (1));
i__8119__auto___32528 = G__32529;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return cljs.core.apply.cljs$core$IFn$_invoke$arity$3(chromex.defaults.console_log,chromex.defaults.log_prefix,args);
});

chromex.defaults.default_logger.cljs$lang$maxFixedArity = (0);

chromex.defaults.default_logger.cljs$lang$applyTo = (function (seq32526){
return chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq32526));
});

chromex.defaults.default_callback_error_reporter = (function chromex$defaults$default_callback_error_reporter(descriptor,error){
var function$ = (function (){var or__6939__auto__ = [cljs.core.str(cljs.core.namespace(cljs.core.cst$kw$id.cljs$core$IFn$_invoke$arity$1(descriptor))),cljs.core.str("/"),cljs.core.str(cljs.core.name(cljs.core.cst$kw$id.cljs$core$IFn$_invoke$arity$1(descriptor)))].join('');
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return "an unknown function";
}
})();
var explanation = (function (){var target_obj_32532 = error;
var next_obj_32533 = goog.object.get(target_obj_32532,"message");
return next_obj_32533;
})();
var message = [cljs.core.str("an error occured during the call to "),cljs.core.str(function$),cljs.core.str((cljs.core.truth_(explanation)?[cljs.core.str(": "),cljs.core.str(explanation)].join(''):null))].join('');
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([chromex.defaults.log_prefix,message,"Details:",error], 0));
});
chromex.defaults.report_error_if_needed_BANG_ = (function chromex$defaults$report_error_if_needed_BANG_(config,descriptor,error){
var temp__6728__auto__ = cljs.core.cst$kw$callback_DASH_error_DASH_reporter.cljs$core$IFn$_invoke$arity$1(config);
if(cljs.core.truth_(temp__6728__auto__)){
var error_reporter = temp__6728__auto__;

return (error_reporter.cljs$core$IFn$_invoke$arity$2 ? error_reporter.cljs$core$IFn$_invoke$arity$2(descriptor,error) : error_reporter.call(null,descriptor,error));
} else {
return null;
}
});
chromex.defaults.default_callback_fn_factory = (function chromex$defaults$default_callback_fn_factory(config,descriptor,chan){
return (function() { 
var G__32540__delegate = function (args){
var temp__6726__auto___32541 = (function (){var target_obj_32537 = chrome;
var next_obj_32538 = goog.object.get(target_obj_32537,"runtime");
var next_obj_32539 = goog.object.get(next_obj_32538,"lastError");
if(!((next_obj_32539 == null))){
return next_obj_32539;
} else {
return null;
}
})();
if(cljs.core.truth_(temp__6726__auto___32541)){
var error_32542 = temp__6726__auto___32541;
chromex.error.set_last_error_BANG_(error_32542);

chromex.defaults.report_error_if_needed_BANG_(config,descriptor,error_32542);
} else {
chromex.error.set_last_error_BANG_(null);

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,cljs.core.vec(args));
}

return cljs.core.async.close_BANG_(chan);
};
var G__32540 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__32543__i = 0, G__32543__a = new Array(arguments.length -  0);
while (G__32543__i < G__32543__a.length) {G__32543__a[G__32543__i] = arguments[G__32543__i + 0]; ++G__32543__i;}
  args = new cljs.core.IndexedSeq(G__32543__a,0);
} 
return G__32540__delegate.call(this,args);};
G__32540.cljs$lang$maxFixedArity = 0;
G__32540.cljs$lang$applyTo = (function (arglist__32544){
var args = cljs.core.seq(arglist__32544);
return G__32540__delegate(args);
});
G__32540.cljs$core$IFn$_invoke$arity$variadic = G__32540__delegate;
return G__32540;
})()
;
});
chromex.defaults.default_callback_channel_factory = (function chromex$defaults$default_callback_channel_factory(_config){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_event_listener_factory = (function chromex$defaults$default_event_listener_factory(_config,event_id,chan){
return (function() { 
var G__32545__delegate = function (args){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [event_id,cljs.core.vec(args)], null));
};
var G__32545 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__32546__i = 0, G__32546__a = new Array(arguments.length -  0);
while (G__32546__i < G__32546__a.length) {G__32546__a[G__32546__i] = arguments[G__32546__i + 0]; ++G__32546__i;}
  args = new cljs.core.IndexedSeq(G__32546__a,0);
} 
return G__32545__delegate.call(this,args);};
G__32545.cljs$lang$maxFixedArity = 0;
G__32545.cljs$lang$applyTo = (function (arglist__32547){
var args = cljs.core.seq(arglist__32547);
return G__32545__delegate(args);
});
G__32545.cljs$core$IFn$_invoke$arity$variadic = G__32545__delegate;
return G__32545;
})()
;
});
chromex.defaults.default_missing_api_check = (function chromex$defaults$default_missing_api_check(api,obj,key){
if(cljs.core.not(goog.object.containsKey(obj,key))){
throw (new Error([cljs.core.str("Chromex library tried to access a missing Chrome API object '"),cljs.core.str(api),cljs.core.str("'.\n"),cljs.core.str("Your Chrome version might be too old or too recent for running this extension.\n"),cljs.core.str("This is a failure which probably requires a software update.")].join('')));
} else {
return null;
}
});
chromex.defaults.default_chrome_storage_area_callback_fn_factory = (function chromex$defaults$default_chrome_storage_area_callback_fn_factory(config,chan){
return (function() { 
var G__32556__delegate = function (args){
var last_error = (function (){var target_obj_32552 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_32553 = goog.object.get(target_obj_32552,"chrome");
var next_obj_32554 = goog.object.get(next_obj_32553,"runtime");
var next_obj_32555 = goog.object.get(next_obj_32554,"lastError");
if(!((next_obj_32555 == null))){
return next_obj_32555;
} else {
return null;
}
})();
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vec(args),last_error], null));
};
var G__32556 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__32557__i = 0, G__32557__a = new Array(arguments.length -  0);
while (G__32557__i < G__32557__a.length) {G__32557__a[G__32557__i] = arguments[G__32557__i + 0]; ++G__32557__i;}
  args = new cljs.core.IndexedSeq(G__32557__a,0);
} 
return G__32556__delegate.call(this,args);};
G__32556.cljs$lang$maxFixedArity = 0;
G__32556.cljs$lang$applyTo = (function (arglist__32558){
var args = cljs.core.seq(arglist__32558);
return G__32556__delegate(args);
});
G__32556.cljs$core$IFn$_invoke$arity$variadic = G__32556__delegate;
return G__32556;
})()
;
});
chromex.defaults.default_chrome_storage_area_callback_channel_factory = (function chromex$defaults$default_chrome_storage_area_callback_channel_factory(_config){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_port_channel_factory = (function chromex$defaults$default_chrome_port_channel_factory(_config){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_port_on_message_fn_factory = (function chromex$defaults$default_chrome_port_on_message_fn_factory(config,chrome_port){
return (function (message){
if((message == null)){
var config__13447__auto__ = config;
var handler_key__13448__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_received_DASH_nil_DASH_message;
var handler__13449__auto__ = (handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1 ? handler_key__13448__auto__.cljs$core$IFn$_invoke$arity$1(config__13447__auto__) : handler_key__13448__auto__.call(null,config__13447__auto__));

return (handler__13449__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__13449__auto__.cljs$core$IFn$_invoke$arity$2(config__13447__auto__,chrome_port) : handler__13449__auto__.call(null,config__13447__auto__,chrome_port));
} else {
chromex.protocols.put_message_BANG_(chrome_port,message);

return null;
}
});
});
chromex.defaults.default_chrome_port_on_disconnect_fn_factory = (function chromex$defaults$default_chrome_port_on_disconnect_fn_factory(_config,chrome_port){
return (function (){
chromex.protocols.close_resources_BANG_(chrome_port);

chromex.protocols.set_connected_BANG_(chrome_port,false);

return null;
});
});
chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_disconnect_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_post_message_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_disconnect_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_message_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_post_message_called_with_nil = (function chromex$defaults$default_chrome_port_post_message_called_with_nil(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_received_nil_message = (function chromex$defaults$default_chrome_port_received_nil_message(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_put_message_called_on_disconnected_port(_config,_chrome_port,message){
return null;
});
chromex.defaults.default_config = cljs.core.PersistentHashMap.fromArrays([cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_put_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_channel_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_with_DASH_nil,cljs.core.cst$kw$chrome_DASH_port_DASH_channel_DASH_factory,cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn,cljs.core.cst$kw$chrome_DASH_port_DASH_received_DASH_nil_DASH_message,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$root,cljs.core.cst$kw$event_DASH_listener_DASH_factory,cljs.core.cst$kw$callback_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_fn_DASH_factory,cljs.core.cst$kw$callback_DASH_error_DASH_reporter,cljs.core.cst$kw$callback_DASH_channel_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_fn_DASH_factory],[chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port,chromex.defaults.default_chrome_storage_area_callback_channel_factory,chromex.defaults.default_chrome_port_post_message_called_with_nil,chromex.defaults.default_chrome_port_channel_factory,chromex.defaults.default_missing_api_check,chromex.defaults.default_chrome_port_received_nil_message,chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_message_fn_factory,chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port,goog.global,chromex.defaults.default_event_listener_factory,chromex.defaults.default_callback_fn_factory,chromex.defaults.default_chrome_storage_area_callback_fn_factory,chromex.defaults.default_callback_error_reporter,chromex.defaults.default_callback_channel_factory,chromex.defaults.default_chrome_port_on_disconnect_fn_factory]);

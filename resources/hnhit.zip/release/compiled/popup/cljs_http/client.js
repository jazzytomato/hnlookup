// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('cljs_http.client');
goog.require('cljs.core');
goog.require('goog.Uri');
goog.require('cljs_http.core');
goog.require('no.en.core');
goog.require('cljs_http.util');
goog.require('cljs.core.async');
goog.require('clojure.string');
goog.require('cljs.reader');
cljs_http.client.if_pos = (function cljs_http$client$if_pos(v){
if(cljs.core.truth_((function (){var and__6927__auto__ = v;
if(cljs.core.truth_(and__6927__auto__)){
return (v > (0));
} else {
return and__6927__auto__;
}
})())){
return v;
} else {
return null;
}
});
/**
 * Parse `s` as query params and return a hash map.
 */
cljs_http.client.parse_query_params = (function cljs_http$client$parse_query_params(s){
if(!(clojure.string.blank_QMARK_(s))){
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3((function (p1__36251_SHARP_,p2__36250_SHARP_){
var vec__36255 = clojure.string.split.cljs$core$IFn$_invoke$arity$2(p2__36250_SHARP_,/=/);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36255,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36255,(1),null);
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__36251_SHARP_,cljs.core.keyword.cljs$core$IFn$_invoke$arity$1(no.en.core.url_decode(k)),no.en.core.url_decode(v));
}),cljs.core.PersistentArrayMap.EMPTY,clojure.string.split.cljs$core$IFn$_invoke$arity$2([cljs.core.str(s)].join(''),/&/));
} else {
return null;
}
});
/**
 * Parse `url` into a hash map.
 */
cljs_http.client.parse_url = (function cljs_http$client$parse_url(url){
if(!(clojure.string.blank_QMARK_(url))){
var uri = goog.Uri.parse(url);
var query_data = uri.getQueryData();
return new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$scheme,cljs.core.keyword.cljs$core$IFn$_invoke$arity$1(uri.getScheme()),cljs.core.cst$kw$server_DASH_name,uri.getDomain(),cljs.core.cst$kw$server_DASH_port,cljs_http.client.if_pos(uri.getPort()),cljs.core.cst$kw$uri,uri.getPath(),cljs.core.cst$kw$query_DASH_string,((cljs.core.not(query_data.isEmpty()))?[cljs.core.str(query_data)].join(''):null),cljs.core.cst$kw$query_DASH_params,((cljs.core.not(query_data.isEmpty()))?cljs_http.client.parse_query_params([cljs.core.str(query_data)].join('')):null)], null);
} else {
return null;
}
});
cljs_http.client.unexceptional_status_QMARK_ = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 13, [(205),null,(206),null,(300),null,(204),null,(307),null,(303),null,(301),null,(201),null,(302),null,(202),null,(200),null,(203),null,(207),null], null), null);
cljs_http.client.generate_query_string = (function cljs_http$client$generate_query_string(params){
return clojure.string.join.cljs$core$IFn$_invoke$arity$2("&",cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p__36262){
var vec__36263 = p__36262;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36263,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36263,(1),null);
return [cljs.core.str(no.en.core.url_encode(cljs.core.name(k))),cljs.core.str("="),cljs.core.str(no.en.core.url_encode([cljs.core.str(v)].join('')))].join('');
}),params));
});
/**
 * Decocde the :body of `response` with `decode-fn` if the content type matches.
 */
cljs_http.client.decode_body = (function cljs_http$client$decode_body(response,decode_fn,content_type){
if(cljs.core.truth_(cljs.core.re_find(cljs.core.re_pattern([cljs.core.str("(?i)"),cljs.core.str(content_type)].join('')),[cljs.core.str(cljs.core.get.cljs$core$IFn$_invoke$arity$3(cljs.core.cst$kw$headers.cljs$core$IFn$_invoke$arity$1(response),"content-type",""))].join('')))){
return cljs.core.update_in.cljs$core$IFn$_invoke$arity$3(response,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$body], null),decode_fn);
} else {
return response;
}
});
/**
 * Encode :edn-params in the `request` :body and set the appropriate
 *   Content Type header.
 */
cljs_http.client.wrap_edn_params = (function cljs_http$client$wrap_edn_params(client){
return (function (request){
var temp__6726__auto__ = cljs.core.cst$kw$edn_DASH_params.cljs$core$IFn$_invoke$arity$1(request);
if(cljs.core.truth_(temp__6726__auto__)){
var params = temp__6726__auto__;
var G__36267 = cljs.core.assoc_in(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(request,cljs.core.cst$kw$edn_DASH_params),cljs.core.cst$kw$body,cljs.core.pr_str.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([params], 0))),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"content-type"], null),"application/edn");
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__36267) : client.call(null,G__36267));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
}
});
});
/**
 * Decode application/edn responses.
 */
cljs_http.client.wrap_edn_response = (function cljs_http$client$wrap_edn_response(client){
return (function (request){
var channel = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__15224__auto___36302 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___36302,channel){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___36302,channel){
return (function (state_36292){
var state_val_36293 = (state_36292[(1)]);
if((state_val_36293 === (1))){
var inst_36285 = (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
var state_36292__$1 = state_36292;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_36292__$1,(2),inst_36285);
} else {
if((state_val_36293 === (2))){
var inst_36287 = (state_36292[(2)]);
var inst_36288 = cljs_http.client.decode_body(inst_36287,cljs.reader.read_string,"application/edn");
var inst_36289 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(channel,inst_36288);
var inst_36290 = cljs.core.async.close_BANG_(channel);
var state_36292__$1 = (function (){var statearr_36294 = state_36292;
(statearr_36294[(7)] = inst_36289);

return statearr_36294;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_36292__$1,inst_36290);
} else {
return null;
}
}
});})(c__15224__auto___36302,channel))
;
return ((function (switch__15098__auto__,c__15224__auto___36302,channel){
return (function() {
var cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__ = null;
var cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____0 = (function (){
var statearr_36298 = [null,null,null,null,null,null,null,null];
(statearr_36298[(0)] = cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__);

(statearr_36298[(1)] = (1));

return statearr_36298;
});
var cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____1 = (function (state_36292){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_36292);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e36299){if((e36299 instanceof Object)){
var ex__15102__auto__ = e36299;
var statearr_36300_36303 = state_36292;
(statearr_36300_36303[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_36292);

return cljs.core.cst$kw$recur;
} else {
throw e36299;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__36304 = state_36292;
state_36292 = G__36304;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__ = function(state_36292){
switch(arguments.length){
case 0:
return cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____0.call(this);
case 1:
return cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____1.call(this,state_36292);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____0;
cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs_http$client$wrap_edn_response_$_state_machine__15099__auto____1;
return cljs_http$client$wrap_edn_response_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___36302,channel))
})();
var state__15226__auto__ = (function (){var statearr_36301 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_36301[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___36302);

return statearr_36301;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___36302,channel))
);


return channel;
});
});
cljs_http.client.wrap_accept = (function cljs_http$client$wrap_accept(var_args){
var args__8125__auto__ = [];
var len__8118__auto___36312 = arguments.length;
var i__8119__auto___36313 = (0);
while(true){
if((i__8119__auto___36313 < len__8118__auto___36312)){
args__8125__auto__.push((arguments[i__8119__auto___36313]));

var G__36314 = (i__8119__auto___36313 + (1));
i__8119__auto___36313 = G__36314;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.wrap_accept.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.wrap_accept.cljs$core$IFn$_invoke$arity$variadic = (function (client,p__36307){
var vec__36308 = p__36307;
var accept = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36308,(0),null);
return ((function (vec__36308,accept){
return (function (request){
var temp__6726__auto__ = (function (){var or__6939__auto__ = cljs.core.cst$kw$accept.cljs$core$IFn$_invoke$arity$1(request);
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return accept;
}
})();
if(cljs.core.truth_(temp__6726__auto__)){
var accept__$1 = temp__6726__auto__;
var G__36311 = cljs.core.assoc_in(request,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"accept"], null),accept__$1);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__36311) : client.call(null,G__36311));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
}
});
;})(vec__36308,accept))
});

cljs_http.client.wrap_accept.cljs$lang$maxFixedArity = (1);

cljs_http.client.wrap_accept.cljs$lang$applyTo = (function (seq36305){
var G__36306 = cljs.core.first(seq36305);
var seq36305__$1 = cljs.core.next(seq36305);
return cljs_http.client.wrap_accept.cljs$core$IFn$_invoke$arity$variadic(G__36306,seq36305__$1);
});

cljs_http.client.wrap_content_type = (function cljs_http$client$wrap_content_type(var_args){
var args__8125__auto__ = [];
var len__8118__auto___36322 = arguments.length;
var i__8119__auto___36323 = (0);
while(true){
if((i__8119__auto___36323 < len__8118__auto___36322)){
args__8125__auto__.push((arguments[i__8119__auto___36323]));

var G__36324 = (i__8119__auto___36323 + (1));
i__8119__auto___36323 = G__36324;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.wrap_content_type.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.wrap_content_type.cljs$core$IFn$_invoke$arity$variadic = (function (client,p__36317){
var vec__36318 = p__36317;
var content_type = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36318,(0),null);
return ((function (vec__36318,content_type){
return (function (request){
var temp__6726__auto__ = (function (){var or__6939__auto__ = cljs.core.cst$kw$content_DASH_type.cljs$core$IFn$_invoke$arity$1(request);
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return content_type;
}
})();
if(cljs.core.truth_(temp__6726__auto__)){
var content_type__$1 = temp__6726__auto__;
var G__36321 = cljs.core.assoc_in(request,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"content-type"], null),content_type__$1);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__36321) : client.call(null,G__36321));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
}
});
;})(vec__36318,content_type))
});

cljs_http.client.wrap_content_type.cljs$lang$maxFixedArity = (1);

cljs_http.client.wrap_content_type.cljs$lang$applyTo = (function (seq36315){
var G__36316 = cljs.core.first(seq36315);
var seq36315__$1 = cljs.core.next(seq36315);
return cljs_http.client.wrap_content_type.cljs$core$IFn$_invoke$arity$variadic(G__36316,seq36315__$1);
});

/**
 * Encode :json-params in the `request` :body and set the appropriate
 *   Content Type header.
 */
cljs_http.client.wrap_json_params = (function cljs_http$client$wrap_json_params(client){
return (function (request){
var temp__6726__auto__ = cljs.core.cst$kw$json_DASH_params.cljs$core$IFn$_invoke$arity$1(request);
if(cljs.core.truth_(temp__6726__auto__)){
var params = temp__6726__auto__;
var G__36326 = cljs.core.assoc_in(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(request,cljs.core.cst$kw$json_DASH_params),cljs.core.cst$kw$body,cljs_http.util.json_encode(params)),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"content-type"], null),"application/json");
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__36326) : client.call(null,G__36326));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
}
});
});
/**
 * Decode application/json responses.
 */
cljs_http.client.wrap_json_response = (function cljs_http$client$wrap_json_response(client){
return (function (request){
var channel = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__15224__auto___36361 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___36361,channel){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___36361,channel){
return (function (state_36351){
var state_val_36352 = (state_36351[(1)]);
if((state_val_36352 === (1))){
var inst_36344 = (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(request) : client.call(null,request));
var state_36351__$1 = state_36351;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_36351__$1,(2),inst_36344);
} else {
if((state_val_36352 === (2))){
var inst_36346 = (state_36351[(2)]);
var inst_36347 = cljs_http.client.decode_body(inst_36346,cljs_http.util.json_decode,"application/json");
var inst_36348 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(channel,inst_36347);
var inst_36349 = cljs.core.async.close_BANG_(channel);
var state_36351__$1 = (function (){var statearr_36353 = state_36351;
(statearr_36353[(7)] = inst_36348);

return statearr_36353;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_36351__$1,inst_36349);
} else {
return null;
}
}
});})(c__15224__auto___36361,channel))
;
return ((function (switch__15098__auto__,c__15224__auto___36361,channel){
return (function() {
var cljs_http$client$wrap_json_response_$_state_machine__15099__auto__ = null;
var cljs_http$client$wrap_json_response_$_state_machine__15099__auto____0 = (function (){
var statearr_36357 = [null,null,null,null,null,null,null,null];
(statearr_36357[(0)] = cljs_http$client$wrap_json_response_$_state_machine__15099__auto__);

(statearr_36357[(1)] = (1));

return statearr_36357;
});
var cljs_http$client$wrap_json_response_$_state_machine__15099__auto____1 = (function (state_36351){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_36351);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e36358){if((e36358 instanceof Object)){
var ex__15102__auto__ = e36358;
var statearr_36359_36362 = state_36351;
(statearr_36359_36362[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_36351);

return cljs.core.cst$kw$recur;
} else {
throw e36358;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__36363 = state_36351;
state_36351 = G__36363;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
cljs_http$client$wrap_json_response_$_state_machine__15099__auto__ = function(state_36351){
switch(arguments.length){
case 0:
return cljs_http$client$wrap_json_response_$_state_machine__15099__auto____0.call(this);
case 1:
return cljs_http$client$wrap_json_response_$_state_machine__15099__auto____1.call(this,state_36351);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs_http$client$wrap_json_response_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = cljs_http$client$wrap_json_response_$_state_machine__15099__auto____0;
cljs_http$client$wrap_json_response_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = cljs_http$client$wrap_json_response_$_state_machine__15099__auto____1;
return cljs_http$client$wrap_json_response_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___36361,channel))
})();
var state__15226__auto__ = (function (){var statearr_36360 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_36360[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___36361);

return statearr_36360;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___36361,channel))
);


return channel;
});
});
cljs_http.client.wrap_query_params = (function cljs_http$client$wrap_query_params(client){
return (function (p__36368){
var map__36369 = p__36368;
var map__36369__$1 = ((((!((map__36369 == null)))?((((map__36369.cljs$lang$protocol_mask$partition0$ & (64))) || (map__36369.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36369):map__36369);
var req = map__36369__$1;
var query_params = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36369__$1,cljs.core.cst$kw$query_DASH_params);
if(cljs.core.truth_(query_params)){
var G__36371 = cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(req,cljs.core.cst$kw$query_DASH_params),cljs.core.cst$kw$query_DASH_string,cljs_http.client.generate_query_string(query_params));
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__36371) : client.call(null,G__36371));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(req) : client.call(null,req));
}
});
});
cljs_http.client.wrap_android_cors_bugfix = (function cljs_http$client$wrap_android_cors_bugfix(client){
return (function (request){
var G__36373 = (cljs.core.truth_(cljs_http.util.android_QMARK_())?cljs.core.assoc_in(request,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$query_DASH_params,cljs.core.cst$kw$android], null),Math.random()):request);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__36373) : client.call(null,G__36373));
});
});
cljs_http.client.wrap_method = (function cljs_http$client$wrap_method(client){
return (function (req){
var temp__6726__auto__ = cljs.core.cst$kw$method.cljs$core$IFn$_invoke$arity$1(req);
if(cljs.core.truth_(temp__6726__auto__)){
var m = temp__6726__auto__;
var G__36375 = cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(req,cljs.core.cst$kw$method),cljs.core.cst$kw$request_DASH_method,m);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__36375) : client.call(null,G__36375));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(req) : client.call(null,req));
}
});
});
cljs_http.client.wrap_server_name = (function cljs_http$client$wrap_server_name(client,server_name){
return (function (p1__36376_SHARP_){
var G__36378 = cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__36376_SHARP_,cljs.core.cst$kw$server_DASH_name,server_name);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__36378) : client.call(null,G__36378));
});
});
cljs_http.client.wrap_url = (function cljs_http$client$wrap_url(client){
return (function (p__36384){
var map__36385 = p__36384;
var map__36385__$1 = ((((!((map__36385 == null)))?((((map__36385.cljs$lang$protocol_mask$partition0$ & (64))) || (map__36385.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__36385):map__36385);
var req = map__36385__$1;
var query_params = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__36385__$1,cljs.core.cst$kw$query_DASH_params);
var temp__6726__auto__ = cljs_http.client.parse_url(cljs.core.cst$kw$url.cljs$core$IFn$_invoke$arity$1(req));
if(cljs.core.truth_(temp__6726__auto__)){
var spec = temp__6726__auto__;
var G__36387 = cljs.core.update_in.cljs$core$IFn$_invoke$arity$3(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,spec], 0)),cljs.core.cst$kw$url),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$query_DASH_params], null),((function (spec,temp__6726__auto__,map__36385,map__36385__$1,req,query_params){
return (function (p1__36379_SHARP_){
return cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([p1__36379_SHARP_,query_params], 0));
});})(spec,temp__6726__auto__,map__36385,map__36385__$1,req,query_params))
);
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__36387) : client.call(null,G__36387));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(req) : client.call(null,req));
}
});
});
/**
 * Middleware converting the :basic-auth option or `credentials` into
 *   an Authorization header.
 */
cljs_http.client.wrap_basic_auth = (function cljs_http$client$wrap_basic_auth(var_args){
var args__8125__auto__ = [];
var len__8118__auto___36395 = arguments.length;
var i__8119__auto___36396 = (0);
while(true){
if((i__8119__auto___36396 < len__8118__auto___36395)){
args__8125__auto__.push((arguments[i__8119__auto___36396]));

var G__36397 = (i__8119__auto___36396 + (1));
i__8119__auto___36396 = G__36397;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.wrap_basic_auth.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.wrap_basic_auth.cljs$core$IFn$_invoke$arity$variadic = (function (client,p__36390){
var vec__36391 = p__36390;
var credentials = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36391,(0),null);
return ((function (vec__36391,credentials){
return (function (req){
var credentials__$1 = (function (){var or__6939__auto__ = cljs.core.cst$kw$basic_DASH_auth.cljs$core$IFn$_invoke$arity$1(req);
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return credentials;
}
})();
if(!(cljs.core.empty_QMARK_(credentials__$1))){
var G__36394 = cljs.core.assoc_in(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(req,cljs.core.cst$kw$basic_DASH_auth),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"authorization"], null),cljs_http.util.basic_auth(credentials__$1));
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__36394) : client.call(null,G__36394));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(req) : client.call(null,req));
}
});
;})(vec__36391,credentials))
});

cljs_http.client.wrap_basic_auth.cljs$lang$maxFixedArity = (1);

cljs_http.client.wrap_basic_auth.cljs$lang$applyTo = (function (seq36388){
var G__36389 = cljs.core.first(seq36388);
var seq36388__$1 = cljs.core.next(seq36388);
return cljs_http.client.wrap_basic_auth.cljs$core$IFn$_invoke$arity$variadic(G__36389,seq36388__$1);
});

/**
 * Middleware converting the :oauth-token option into an Authorization header.
 */
cljs_http.client.wrap_oauth = (function cljs_http$client$wrap_oauth(client){
return (function (req){
var temp__6726__auto__ = cljs.core.cst$kw$oauth_DASH_token.cljs$core$IFn$_invoke$arity$1(req);
if(cljs.core.truth_(temp__6726__auto__)){
var oauth_token = temp__6726__auto__;
var G__36399 = cljs.core.assoc_in(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(req,cljs.core.cst$kw$oauth_DASH_token),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$headers,"authorization"], null),[cljs.core.str("Bearer "),cljs.core.str(oauth_token)].join(''));
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(G__36399) : client.call(null,G__36399));
} else {
return (client.cljs$core$IFn$_invoke$arity$1 ? client.cljs$core$IFn$_invoke$arity$1(req) : client.call(null,req));
}
});
});
/**
 * Returns a battaries-included HTTP request function coresponding to the given
 * core client. See client/client.
 */
cljs_http.client.wrap_request = (function cljs_http$client$wrap_request(request){
return cljs_http.client.wrap_url(cljs_http.client.wrap_method(cljs_http.client.wrap_android_cors_bugfix(cljs_http.client.wrap_oauth(cljs_http.client.wrap_basic_auth(cljs_http.client.wrap_query_params(cljs_http.client.wrap_json_response(cljs_http.client.wrap_json_params(cljs_http.client.wrap_edn_response(cljs_http.client.wrap_edn_params(request))))))))));
});
/**
 * Executes the HTTP request corresponding to the given map and returns the
 * response map for corresponding to the resulting HTTP response.
 * 
 * In addition to the standard Ring request keys, the following keys are also
 * recognized:
 * * :url
 * * :method
 * * :query-params
 */
cljs_http.client.request = cljs_http.client.wrap_request(cljs_http.core.request);
/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.delete$ = (function cljs_http$client$delete(var_args){
var args__8125__auto__ = [];
var len__8118__auto___36407 = arguments.length;
var i__8119__auto___36408 = (0);
while(true){
if((i__8119__auto___36408 < len__8118__auto___36407)){
args__8125__auto__.push((arguments[i__8119__auto___36408]));

var G__36409 = (i__8119__auto___36408 + (1));
i__8119__auto___36408 = G__36409;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.delete$.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.delete$.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__36402){
var vec__36403 = p__36402;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36403,(0),null);
var G__36406 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$delete,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__36406) : cljs_http.client.request.call(null,G__36406));
});

cljs_http.client.delete$.cljs$lang$maxFixedArity = (1);

cljs_http.client.delete$.cljs$lang$applyTo = (function (seq36400){
var G__36401 = cljs.core.first(seq36400);
var seq36400__$1 = cljs.core.next(seq36400);
return cljs_http.client.delete$.cljs$core$IFn$_invoke$arity$variadic(G__36401,seq36400__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.get = (function cljs_http$client$get(var_args){
var args__8125__auto__ = [];
var len__8118__auto___36417 = arguments.length;
var i__8119__auto___36418 = (0);
while(true){
if((i__8119__auto___36418 < len__8118__auto___36417)){
args__8125__auto__.push((arguments[i__8119__auto___36418]));

var G__36419 = (i__8119__auto___36418 + (1));
i__8119__auto___36418 = G__36419;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.get.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.get.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__36412){
var vec__36413 = p__36412;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36413,(0),null);
var G__36416 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$get,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__36416) : cljs_http.client.request.call(null,G__36416));
});

cljs_http.client.get.cljs$lang$maxFixedArity = (1);

cljs_http.client.get.cljs$lang$applyTo = (function (seq36410){
var G__36411 = cljs.core.first(seq36410);
var seq36410__$1 = cljs.core.next(seq36410);
return cljs_http.client.get.cljs$core$IFn$_invoke$arity$variadic(G__36411,seq36410__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.head = (function cljs_http$client$head(var_args){
var args__8125__auto__ = [];
var len__8118__auto___36427 = arguments.length;
var i__8119__auto___36428 = (0);
while(true){
if((i__8119__auto___36428 < len__8118__auto___36427)){
args__8125__auto__.push((arguments[i__8119__auto___36428]));

var G__36429 = (i__8119__auto___36428 + (1));
i__8119__auto___36428 = G__36429;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.head.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.head.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__36422){
var vec__36423 = p__36422;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36423,(0),null);
var G__36426 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$head,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__36426) : cljs_http.client.request.call(null,G__36426));
});

cljs_http.client.head.cljs$lang$maxFixedArity = (1);

cljs_http.client.head.cljs$lang$applyTo = (function (seq36420){
var G__36421 = cljs.core.first(seq36420);
var seq36420__$1 = cljs.core.next(seq36420);
return cljs_http.client.head.cljs$core$IFn$_invoke$arity$variadic(G__36421,seq36420__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.move = (function cljs_http$client$move(var_args){
var args__8125__auto__ = [];
var len__8118__auto___36437 = arguments.length;
var i__8119__auto___36438 = (0);
while(true){
if((i__8119__auto___36438 < len__8118__auto___36437)){
args__8125__auto__.push((arguments[i__8119__auto___36438]));

var G__36439 = (i__8119__auto___36438 + (1));
i__8119__auto___36438 = G__36439;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.move.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.move.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__36432){
var vec__36433 = p__36432;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36433,(0),null);
var G__36436 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$move,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__36436) : cljs_http.client.request.call(null,G__36436));
});

cljs_http.client.move.cljs$lang$maxFixedArity = (1);

cljs_http.client.move.cljs$lang$applyTo = (function (seq36430){
var G__36431 = cljs.core.first(seq36430);
var seq36430__$1 = cljs.core.next(seq36430);
return cljs_http.client.move.cljs$core$IFn$_invoke$arity$variadic(G__36431,seq36430__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.options = (function cljs_http$client$options(var_args){
var args__8125__auto__ = [];
var len__8118__auto___36447 = arguments.length;
var i__8119__auto___36448 = (0);
while(true){
if((i__8119__auto___36448 < len__8118__auto___36447)){
args__8125__auto__.push((arguments[i__8119__auto___36448]));

var G__36449 = (i__8119__auto___36448 + (1));
i__8119__auto___36448 = G__36449;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.options.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.options.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__36442){
var vec__36443 = p__36442;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36443,(0),null);
var G__36446 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$options,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__36446) : cljs_http.client.request.call(null,G__36446));
});

cljs_http.client.options.cljs$lang$maxFixedArity = (1);

cljs_http.client.options.cljs$lang$applyTo = (function (seq36440){
var G__36441 = cljs.core.first(seq36440);
var seq36440__$1 = cljs.core.next(seq36440);
return cljs_http.client.options.cljs$core$IFn$_invoke$arity$variadic(G__36441,seq36440__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.patch = (function cljs_http$client$patch(var_args){
var args__8125__auto__ = [];
var len__8118__auto___36457 = arguments.length;
var i__8119__auto___36458 = (0);
while(true){
if((i__8119__auto___36458 < len__8118__auto___36457)){
args__8125__auto__.push((arguments[i__8119__auto___36458]));

var G__36459 = (i__8119__auto___36458 + (1));
i__8119__auto___36458 = G__36459;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.patch.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.patch.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__36452){
var vec__36453 = p__36452;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36453,(0),null);
var G__36456 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$patch,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__36456) : cljs_http.client.request.call(null,G__36456));
});

cljs_http.client.patch.cljs$lang$maxFixedArity = (1);

cljs_http.client.patch.cljs$lang$applyTo = (function (seq36450){
var G__36451 = cljs.core.first(seq36450);
var seq36450__$1 = cljs.core.next(seq36450);
return cljs_http.client.patch.cljs$core$IFn$_invoke$arity$variadic(G__36451,seq36450__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.post = (function cljs_http$client$post(var_args){
var args__8125__auto__ = [];
var len__8118__auto___36467 = arguments.length;
var i__8119__auto___36468 = (0);
while(true){
if((i__8119__auto___36468 < len__8118__auto___36467)){
args__8125__auto__.push((arguments[i__8119__auto___36468]));

var G__36469 = (i__8119__auto___36468 + (1));
i__8119__auto___36468 = G__36469;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.post.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.post.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__36462){
var vec__36463 = p__36462;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36463,(0),null);
var G__36466 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$post,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__36466) : cljs_http.client.request.call(null,G__36466));
});

cljs_http.client.post.cljs$lang$maxFixedArity = (1);

cljs_http.client.post.cljs$lang$applyTo = (function (seq36460){
var G__36461 = cljs.core.first(seq36460);
var seq36460__$1 = cljs.core.next(seq36460);
return cljs_http.client.post.cljs$core$IFn$_invoke$arity$variadic(G__36461,seq36460__$1);
});

/**
 * Like #'request, but sets the :method and :url as appropriate.
 */
cljs_http.client.put = (function cljs_http$client$put(var_args){
var args__8125__auto__ = [];
var len__8118__auto___36477 = arguments.length;
var i__8119__auto___36478 = (0);
while(true){
if((i__8119__auto___36478 < len__8118__auto___36477)){
args__8125__auto__.push((arguments[i__8119__auto___36478]));

var G__36479 = (i__8119__auto___36478 + (1));
i__8119__auto___36478 = G__36479;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return cljs_http.client.put.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

cljs_http.client.put.cljs$core$IFn$_invoke$arity$variadic = (function (url,p__36472){
var vec__36473 = p__36472;
var req = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36473,(0),null);
var G__36476 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([req,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$method,cljs.core.cst$kw$put,cljs.core.cst$kw$url,url], null)], 0));
return (cljs_http.client.request.cljs$core$IFn$_invoke$arity$1 ? cljs_http.client.request.cljs$core$IFn$_invoke$arity$1(G__36476) : cljs_http.client.request.call(null,G__36476));
});

cljs_http.client.put.cljs$lang$maxFixedArity = (1);

cljs_http.client.put.cljs$lang$applyTo = (function (seq36470){
var G__36471 = cljs.core.first(seq36470);
var seq36470__$1 = cljs.core.next(seq36470);
return cljs_http.client.put.cljs$core$IFn$_invoke$arity$variadic(G__36471,seq36470__$1);
});


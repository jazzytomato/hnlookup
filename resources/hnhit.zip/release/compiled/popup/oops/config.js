// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.config');
goog.require('cljs.core');
oops.config.get_initial_runtime_config = (function oops$config$get_initial_runtime_config(){
return cljs.core.PersistentHashMap.fromArrays([cljs.core.cst$kw$warning_DASH_reporting,cljs.core.cst$kw$empty_DASH_selector_DASH_access,cljs.core.cst$kw$error_DASH_reporting,cljs.core.cst$kw$expected_DASH_function_DASH_value,cljs.core.cst$kw$child_DASH_factory,cljs.core.cst$kw$invalid_DASH_selector,cljs.core.cst$kw$throw_DASH_errors_DASH_from_DASH_macro_DASH_call_DASH_sites,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.cst$kw$missing_DASH_object_DASH_key],[cljs.core.cst$kw$console,cljs.core.cst$kw$warn,cljs.core.cst$kw$throw,cljs.core.cst$kw$error,cljs.core.cst$kw$js_DASH_obj,cljs.core.cst$kw$error,true,cljs.core.cst$kw$error,cljs.core.cst$kw$error]);
});
oops.config._STAR_runtime_config_STAR_ = oops.config.get_initial_runtime_config();
oops.config.set_current_runtime_config_BANG_ = (function oops$config$set_current_runtime_config_BANG_(new_config){

oops.config._STAR_runtime_config_STAR_ = new_config;

return new_config;
});
oops.config.get_current_runtime_config = (function oops$config$get_current_runtime_config(){
return oops.config._STAR_runtime_config_STAR_;
});
oops.config.update_current_runtime_config_BANG_ = (function oops$config$update_current_runtime_config_BANG_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___28201 = arguments.length;
var i__8119__auto___28202 = (0);
while(true){
if((i__8119__auto___28202 < len__8118__auto___28201)){
args__8125__auto__.push((arguments[i__8119__auto___28202]));

var G__28203 = (i__8119__auto___28202 + (1));
i__8119__auto___28202 = G__28203;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (f_or_map,args){
if(cljs.core.map_QMARK_(f_or_map)){
return oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic(cljs.core.merge,cljs.core.array_seq([f_or_map], 0));
} else {
return oops.config.set_current_runtime_config_BANG_(cljs.core.apply.cljs$core$IFn$_invoke$arity$3(f_or_map,oops.config.get_current_runtime_config(),args));
}
});

oops.config.update_current_runtime_config_BANG_.cljs$lang$maxFixedArity = (1);

oops.config.update_current_runtime_config_BANG_.cljs$lang$applyTo = (function (seq28199){
var G__28200 = cljs.core.first(seq28199);
var seq28199__$1 = cljs.core.next(seq28199);
return oops.config.update_current_runtime_config_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__28200,seq28199__$1);
});

oops.config.get_config_key = (function oops$config$get_config_key(var_args){
var args__8125__auto__ = [];
var len__8118__auto___28211 = arguments.length;
var i__8119__auto___28212 = (0);
while(true){
if((i__8119__auto___28212 < len__8118__auto___28211)){
args__8125__auto__.push((arguments[i__8119__auto___28212]));

var G__28213 = (i__8119__auto___28212 + (1));
i__8119__auto___28212 = G__28213;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic = (function (key,p__28206){
var vec__28207 = p__28206;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28207,(0),null);
var G__28210 = (function (){var or__6939__auto__ = config;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return oops.config.get_current_runtime_config();
}
})();
return (key.cljs$core$IFn$_invoke$arity$1 ? key.cljs$core$IFn$_invoke$arity$1(G__28210) : key.call(null,G__28210));
});

oops.config.get_config_key.cljs$lang$maxFixedArity = (1);

oops.config.get_config_key.cljs$lang$applyTo = (function (seq28204){
var G__28205 = cljs.core.first(seq28204);
var seq28204__$1 = cljs.core.next(seq28204);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(G__28205,seq28204__$1);
});

oops.config.has_config_key_QMARK_ = (function oops$config$has_config_key_QMARK_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___28220 = arguments.length;
var i__8119__auto___28221 = (0);
while(true){
if((i__8119__auto___28221 < len__8118__auto___28220)){
args__8125__auto__.push((arguments[i__8119__auto___28221]));

var G__28222 = (i__8119__auto___28221 + (1));
i__8119__auto___28221 = G__28222;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return oops.config.has_config_key_QMARK_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

oops.config.has_config_key_QMARK_.cljs$core$IFn$_invoke$arity$variadic = (function (key,p__28216){
var vec__28217 = p__28216;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28217,(0),null);
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$oops$config_SLASH_not_DASH_found,cljs.core.get.cljs$core$IFn$_invoke$arity$3((function (){var or__6939__auto__ = config;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return oops.config.get_current_runtime_config();
}
})(),key,cljs.core.cst$kw$oops$config_SLASH_not_DASH_found));
});

oops.config.has_config_key_QMARK_.cljs$lang$maxFixedArity = (1);

oops.config.has_config_key_QMARK_.cljs$lang$applyTo = (function (seq28214){
var G__28215 = cljs.core.first(seq28214);
var seq28214__$1 = cljs.core.next(seq28214);
return oops.config.has_config_key_QMARK_.cljs$core$IFn$_invoke$arity$variadic(G__28215,seq28214__$1);
});

oops.config.get_error_reporting = (function oops$config$get_error_reporting(var_args){
var args__8125__auto__ = [];
var len__8118__auto___28228 = arguments.length;
var i__8119__auto___28229 = (0);
while(true){
if((i__8119__auto___28229 < len__8118__auto___28228)){
args__8125__auto__.push((arguments[i__8119__auto___28229]));

var G__28230 = (i__8119__auto___28229 + (1));
i__8119__auto___28229 = G__28230;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_error_reporting.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_error_reporting.cljs$core$IFn$_invoke$arity$variadic = (function (p__28224){
var vec__28225 = p__28224;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28225,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$error_DASH_reporting,cljs.core.array_seq([config], 0));
});

oops.config.get_error_reporting.cljs$lang$maxFixedArity = (0);

oops.config.get_error_reporting.cljs$lang$applyTo = (function (seq28223){
return oops.config.get_error_reporting.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq28223));
});

oops.config.get_warning_reporting = (function oops$config$get_warning_reporting(var_args){
var args__8125__auto__ = [];
var len__8118__auto___28236 = arguments.length;
var i__8119__auto___28237 = (0);
while(true){
if((i__8119__auto___28237 < len__8118__auto___28236)){
args__8125__auto__.push((arguments[i__8119__auto___28237]));

var G__28238 = (i__8119__auto___28237 + (1));
i__8119__auto___28237 = G__28238;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_warning_reporting.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_warning_reporting.cljs$core$IFn$_invoke$arity$variadic = (function (p__28232){
var vec__28233 = p__28232;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28233,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$warning_DASH_reporting,cljs.core.array_seq([config], 0));
});

oops.config.get_warning_reporting.cljs$lang$maxFixedArity = (0);

oops.config.get_warning_reporting.cljs$lang$applyTo = (function (seq28231){
return oops.config.get_warning_reporting.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq28231));
});

oops.config.get_suppress_reporting = (function oops$config$get_suppress_reporting(var_args){
var args__8125__auto__ = [];
var len__8118__auto___28244 = arguments.length;
var i__8119__auto___28245 = (0);
while(true){
if((i__8119__auto___28245 < len__8118__auto___28244)){
args__8125__auto__.push((arguments[i__8119__auto___28245]));

var G__28246 = (i__8119__auto___28245 + (1));
i__8119__auto___28245 = G__28246;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_suppress_reporting.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_suppress_reporting.cljs$core$IFn$_invoke$arity$variadic = (function (p__28240){
var vec__28241 = p__28240;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28241,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$suppress_DASH_reporting,cljs.core.array_seq([config], 0));
});

oops.config.get_suppress_reporting.cljs$lang$maxFixedArity = (0);

oops.config.get_suppress_reporting.cljs$lang$applyTo = (function (seq28239){
return oops.config.get_suppress_reporting.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq28239));
});

oops.config.get_child_factory = (function oops$config$get_child_factory(var_args){
var args__8125__auto__ = [];
var len__8118__auto___28252 = arguments.length;
var i__8119__auto___28253 = (0);
while(true){
if((i__8119__auto___28253 < len__8118__auto___28252)){
args__8125__auto__.push((arguments[i__8119__auto___28253]));

var G__28254 = (i__8119__auto___28253 + (1));
i__8119__auto___28253 = G__28254;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.get_child_factory.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.get_child_factory.cljs$core$IFn$_invoke$arity$variadic = (function (p__28248){
var vec__28249 = p__28248;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28249,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$child_DASH_factory,cljs.core.array_seq([config], 0));
});

oops.config.get_child_factory.cljs$lang$maxFixedArity = (0);

oops.config.get_child_factory.cljs$lang$applyTo = (function (seq28247){
return oops.config.get_child_factory.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq28247));
});

oops.config.set_child_factory_BANG_ = (function oops$config$set_child_factory_BANG_(new_factory_fn){
return oops.config.update_current_runtime_config_BANG_(new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$child_DASH_factory,new_factory_fn], null));
});
oops.config.throw_errors_from_macro_call_sites_QMARK_ = (function oops$config$throw_errors_from_macro_call_sites_QMARK_(var_args){
var args__8125__auto__ = [];
var len__8118__auto___28260 = arguments.length;
var i__8119__auto___28261 = (0);
while(true){
if((i__8119__auto___28261 < len__8118__auto___28260)){
args__8125__auto__.push((arguments[i__8119__auto___28261]));

var G__28262 = (i__8119__auto___28261 + (1));
i__8119__auto___28261 = G__28262;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$core$IFn$_invoke$arity$variadic = (function (p__28256){
var vec__28257 = p__28256;
var config = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__28257,(0),null);
return oops.config.get_config_key.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$throw_DASH_errors_DASH_from_DASH_macro_DASH_call_DASH_sites,cljs.core.array_seq([config], 0)) === true;
});

oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$lang$maxFixedArity = (0);

oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$lang$applyTo = (function (seq28255){
return oops.config.throw_errors_from_macro_call_sites_QMARK_.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq28255));
});


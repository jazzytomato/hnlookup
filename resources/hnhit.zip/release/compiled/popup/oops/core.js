// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.core');
goog.require('cljs.core');
goog.require('cljs.spec');
goog.require('goog.object');
goog.require('oops.sdefs');
goog.require('oops.state');
goog.require('oops.config');
goog.require('oops.messages');
goog.require('oops.helpers');
goog.require('oops.schema');
oops.core.report_runtime_error = (function oops$core$report_runtime_error(msg,data){
if(oops.state.was_error_reported_QMARK_()){
return null;
} else {
oops.state.mark_error_reported_BANG_();

var G__32360 = oops.config.get_error_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__32360)){
throw oops.state.prepare_error_from_call_site(msg,(function (){var data__19812__auto__ = data;
var or__6939__auto__ = (function (){var temp__6726__auto__ = (window["devtools"]);
if(cljs.core.truth_(temp__6726__auto__)){
var devtools__19813__auto__ = temp__6726__auto__;
var temp__6726__auto____$1 = (devtools__19813__auto__["toolbox"]);
if(cljs.core.truth_(temp__6726__auto____$1)){
var toolbox__19814__auto__ = temp__6726__auto____$1;
var temp__6726__auto____$2 = (toolbox__19814__auto__["envelope"]);
if(cljs.core.truth_(temp__6726__auto____$2)){
var envelope__19815__auto__ = temp__6726__auto____$2;
if(cljs.core.fn_QMARK_(envelope__19815__auto__)){
return (envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2 ? envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2(data__19812__auto__,"details") : envelope__19815__auto__.call(null,data__19812__auto__,"details"));
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
})();
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return data__19812__auto__;
}
})());
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__32360)){
return oops.state.get_console_reporter().call(null,(console["error"]),msg,(function (){var data__19812__auto__ = data;
var or__6939__auto__ = (function (){var temp__6726__auto__ = (window["devtools"]);
if(cljs.core.truth_(temp__6726__auto__)){
var devtools__19813__auto__ = temp__6726__auto__;
var temp__6726__auto____$1 = (devtools__19813__auto__["toolbox"]);
if(cljs.core.truth_(temp__6726__auto____$1)){
var toolbox__19814__auto__ = temp__6726__auto____$1;
var temp__6726__auto____$2 = (toolbox__19814__auto__["envelope"]);
if(cljs.core.truth_(temp__6726__auto____$2)){
var envelope__19815__auto__ = temp__6726__auto____$2;
if(cljs.core.fn_QMARK_(envelope__19815__auto__)){
return (envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2 ? envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2(data__19812__auto__,"details") : envelope__19815__auto__.call(null,data__19812__auto__,"details"));
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
})();
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return data__19812__auto__;
}
})());
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__32360)){
return null;
} else {
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(oops.config.get_error_reporting())].join('')));

}
}
}
}
});
oops.core.report_runtime_warning = (function oops$core$report_runtime_warning(msg,data){
var G__32362 = oops.config.get_warning_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__32362)){
throw oops.state.prepare_error_from_call_site(msg,(function (){var data__19812__auto__ = data;
var or__6939__auto__ = (function (){var temp__6726__auto__ = (window["devtools"]);
if(cljs.core.truth_(temp__6726__auto__)){
var devtools__19813__auto__ = temp__6726__auto__;
var temp__6726__auto____$1 = (devtools__19813__auto__["toolbox"]);
if(cljs.core.truth_(temp__6726__auto____$1)){
var toolbox__19814__auto__ = temp__6726__auto____$1;
var temp__6726__auto____$2 = (toolbox__19814__auto__["envelope"]);
if(cljs.core.truth_(temp__6726__auto____$2)){
var envelope__19815__auto__ = temp__6726__auto____$2;
if(cljs.core.fn_QMARK_(envelope__19815__auto__)){
return (envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2 ? envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2(data__19812__auto__,"details") : envelope__19815__auto__.call(null,data__19812__auto__,"details"));
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
})();
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return data__19812__auto__;
}
})());
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__32362)){
return oops.state.get_console_reporter().call(null,(console["warn"]),msg,(function (){var data__19812__auto__ = data;
var or__6939__auto__ = (function (){var temp__6726__auto__ = (window["devtools"]);
if(cljs.core.truth_(temp__6726__auto__)){
var devtools__19813__auto__ = temp__6726__auto__;
var temp__6726__auto____$1 = (devtools__19813__auto__["toolbox"]);
if(cljs.core.truth_(temp__6726__auto____$1)){
var toolbox__19814__auto__ = temp__6726__auto____$1;
var temp__6726__auto____$2 = (toolbox__19814__auto__["envelope"]);
if(cljs.core.truth_(temp__6726__auto____$2)){
var envelope__19815__auto__ = temp__6726__auto____$2;
if(cljs.core.fn_QMARK_(envelope__19815__auto__)){
return (envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2 ? envelope__19815__auto__.cljs$core$IFn$_invoke$arity$2(data__19812__auto__,"details") : envelope__19815__auto__.call(null,data__19812__auto__,"details"));
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
} else {
return null;
}
})();
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return data__19812__auto__;
}
})());
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__32362)){
return null;
} else {
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(oops.config.get_warning_reporting())].join('')));

}
}
}
});
oops.core.report_if_needed_dynamically = (function oops$core$report_if_needed_dynamically(var_args){
var args__8125__auto__ = [];
var len__8118__auto___32369 = arguments.length;
var i__8119__auto___32370 = (0);
while(true){
if((i__8119__auto___32370 < len__8118__auto___32369)){
args__8125__auto__.push((arguments[i__8119__auto___32370]));

var G__32371 = (i__8119__auto___32370 + (1));
i__8119__auto___32370 = G__32371;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((1) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((1)),(0),null)):null);
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__8126__auto__);
});

oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic = (function (msg_id,p__32365){
var vec__32366 = p__32365;
var info = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32366,(0),null);
return null;
});

oops.core.report_if_needed_dynamically.cljs$lang$maxFixedArity = (1);

oops.core.report_if_needed_dynamically.cljs$lang$applyTo = (function (seq32363){
var G__32364 = cljs.core.first(seq32363);
var seq32363__$1 = cljs.core.next(seq32363);
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(G__32364,seq32363__$1);
});

oops.core.punch_key_dynamically_BANG_ = (function oops$core$punch_key_dynamically_BANG_(obj,key){
var child_factory_32378 = oops.config.get_child_factory();
var child_factory_32378__$1 = (function (){var G__32379 = (((child_factory_32378 instanceof cljs.core.Keyword))?child_factory_32378.fqn:null);
switch (G__32379) {
case "js-obj":
return ((function (G__32379,child_factory_32378){
return (function (){
return {};
});
;})(G__32379,child_factory_32378))

break;
case "js-array":
return ((function (G__32379,child_factory_32378){
return (function (){
return [];
});
;})(G__32379,child_factory_32378))

break;
default:
return child_factory_32378;

}
})();

var child_obj_32377 = (child_factory_32378__$1.cljs$core$IFn$_invoke$arity$2 ? child_factory_32378__$1.cljs$core$IFn$_invoke$arity$2(obj,key) : child_factory_32378__$1.call(null,obj,key));
goog.object.set(obj,key,child_obj_32377);

return child_obj_32377;
});
oops.core.validate_object_access_dynamically = (function oops$core$validate_object_access_dynamically(obj,mode,key,check_key_QMARK_){
if(cljs.core.truth_((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((void 0 === obj)))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"undefined",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((obj == null)))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"nil",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(goog.isBoolean(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"boolean",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(goog.isNumber(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"number",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(goog.isString(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"string",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):((cljs.core.not(goog.isObject(obj)))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"non-object",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(goog.isDateLike(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"date-like",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(oops.helpers.cljs_type_QMARK_(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs type",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):(cljs.core.truth_(oops.helpers.cljs_instance_QMARK_(obj))?oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs instance",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0)):true
))))))))))){
oops.state.add_key_to_current_path_BANG_(key);

oops.state.set_last_access_modifier_BANG_(mode);

if(cljs.core.truth_(check_key_QMARK_)){
if((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && (cljs.core.not(goog.object.containsKey(obj,key)))){
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$missing_DASH_object_DASH_key,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0));
} else {
return true;
}
} else {
return true;
}
} else {
return null;
}
});
oops.core.validate_fn_call_dynamically = (function oops$core$validate_fn_call_dynamically(fn,mode){
if((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1))) && ((fn == null))){
return true;
} else {
if(cljs.core.truth_(goog.isFunction(fn))){
return true;
} else {
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic(cljs.core.cst$kw$expected_DASH_function_DASH_value,cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$soft_QMARK_,cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1)),cljs.core.cst$kw$fn,fn,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)], 0));

}
}
});
oops.core.build_path_dynamically = (function oops$core$build_path_dynamically(selector){
if((typeof selector === 'string') || ((selector instanceof cljs.core.Keyword))){
var selector_path_32385 = [];
oops.schema.coerce_key_dynamically_BANG_(selector,selector_path_32385);

return selector_path_32385;
} else {
var selector_path_32386 = [];
oops.schema.collect_coerced_keys_into_array_BANG_(selector,selector_path_32386);

return selector_path_32386;

}
});
oops.core.get_key_dynamically = (function oops$core$get_key_dynamically(obj,key,mode){
return goog.object.get(obj,key);
});
oops.core.set_key_dynamically = (function oops$core$set_key_dynamically(obj,key,val,mode){
return goog.object.set(obj,key,val);
});
oops.core.get_selector_dynamically = (function oops$core$get_selector_dynamically(obj,selector){
var path_32397 = (function (){var path_32396 = oops.core.build_path_dynamically(selector);

return path_32396;
})();
var len_32398 = path_32397.length;
var i_32399 = (0);
var obj_32400 = obj;
while(true){
if((i_32399 < len_32398)){
var mode_32401 = (path_32397[i_32399]);
var key_32402 = (path_32397[(i_32399 + (1))]);
var next_obj_32403 = oops.core.get_key_dynamically(obj_32400,key_32402,mode_32401);
var G__32404 = mode_32401;
switch (G__32404) {
case (0):
var G__32406 = (i_32399 + (2));
var G__32407 = next_obj_32403;
i_32399 = G__32406;
obj_32400 = G__32407;
continue;

break;
case (1):
if(!((next_obj_32403 == null))){
var G__32408 = (i_32399 + (2));
var G__32409 = next_obj_32403;
i_32399 = G__32408;
obj_32400 = G__32409;
continue;
} else {
return null;
}

break;
case (2):
if(!((next_obj_32403 == null))){
var G__32410 = (i_32399 + (2));
var G__32411 = next_obj_32403;
i_32399 = G__32410;
obj_32400 = G__32411;
continue;
} else {
var G__32412 = (i_32399 + (2));
var G__32413 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_32400,key_32402) : oops.core.punch_key_dynamically_BANG_.call(null,obj_32400,key_32402));
i_32399 = G__32412;
obj_32400 = G__32413;
continue;
}

break;
default:
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(mode_32401)].join('')));

}
} else {
return obj_32400;
}
break;
}
});
oops.core.set_selector_dynamically = (function oops$core$set_selector_dynamically(obj,selector,val){
var path_32430 = (function (){var path_32429 = oops.core.build_path_dynamically(selector);

return path_32429;
})();
var len_32433 = path_32430.length;
var parent_obj_path_32434 = path_32430.slice((0),(len_32433 - (2)));
var key_32431 = (path_32430[(len_32433 - (1))]);
var mode_32432 = (path_32430[(len_32433 - (2))]);
var parent_obj_32435 = (function (){var path_32436 = parent_obj_path_32434;
var len_32437 = path_32436.length;
var i_32438 = (0);
var obj_32439 = obj;
while(true){
if((i_32438 < len_32437)){
var mode_32440 = (path_32436[i_32438]);
var key_32441 = (path_32436[(i_32438 + (1))]);
var next_obj_32442 = oops.core.get_key_dynamically(obj_32439,key_32441,mode_32440);
var G__32443 = mode_32440;
switch (G__32443) {
case (0):
var G__32445 = (i_32438 + (2));
var G__32446 = next_obj_32442;
i_32438 = G__32445;
obj_32439 = G__32446;
continue;

break;
case (1):
if(!((next_obj_32442 == null))){
var G__32447 = (i_32438 + (2));
var G__32448 = next_obj_32442;
i_32438 = G__32447;
obj_32439 = G__32448;
continue;
} else {
return null;
}

break;
case (2):
if(!((next_obj_32442 == null))){
var G__32449 = (i_32438 + (2));
var G__32450 = next_obj_32442;
i_32438 = G__32449;
obj_32439 = G__32450;
continue;
} else {
var G__32451 = (i_32438 + (2));
var G__32452 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_32439,key_32441) : oops.core.punch_key_dynamically_BANG_.call(null,obj_32439,key_32441));
i_32438 = G__32451;
obj_32439 = G__32452;
continue;
}

break;
default:
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(mode_32440)].join('')));

}
} else {
return obj_32439;
}
break;
}
})();
return oops.core.set_key_dynamically(parent_obj_32435,key_32431,val,mode_32432);
});

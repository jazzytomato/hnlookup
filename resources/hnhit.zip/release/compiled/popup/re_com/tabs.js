// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('re_com.tabs');
goog.require('cljs.core');
goog.require('re_com.util');
goog.require('re_com.box');
goog.require('re_com.validate');
re_com.tabs.tabs_args_desc = new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$tabs,cljs.core.cst$kw$required,true,cljs.core.cst$kw$type,"vector of tabs | atom",cljs.core.cst$kw$validate_DASH_fn,re_com.validate.vector_of_maps_QMARK_,cljs.core.cst$kw$description,"one element in the vector for each tab. Typically, each element is a map with :id and :label keys"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,cljs.core.cst$kw$model,cljs.core.cst$kw$required,true,cljs.core.cst$kw$type,"unique-id | atom",cljs.core.cst$kw$description,"the unique identifier of the currently selected tab"], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$on_DASH_change,cljs.core.cst$kw$required,true,cljs.core.cst$kw$type,"unique-id -> nil",cljs.core.cst$kw$validate_DASH_fn,cljs.core.fn_QMARK_,cljs.core.cst$kw$description,"called when user alters the selection. Passed the unique identifier of the selection"], null),new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$name,cljs.core.cst$kw$id_DASH_fn,cljs.core.cst$kw$required,false,cljs.core.cst$kw$default,cljs.core.cst$kw$id,cljs.core.cst$kw$type,"tab -> anything",cljs.core.cst$kw$validate_DASH_fn,cljs.core.ifn_QMARK_,cljs.core.cst$kw$description,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$span,"given an element of ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":tabs"], null),", returns its unique identifier (aka id)"], null)], null),new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$name,cljs.core.cst$kw$label_DASH_fn,cljs.core.cst$kw$required,false,cljs.core.cst$kw$default,cljs.core.cst$kw$label,cljs.core.cst$kw$type,"tab -> string | hiccup",cljs.core.cst$kw$validate_DASH_fn,cljs.core.ifn_QMARK_,cljs.core.cst$kw$description,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$span,"given an element of ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":tabs"], null),", returns its displayable label"], null)], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$style,cljs.core.cst$kw$required,false,cljs.core.cst$kw$type,"CSS style map",cljs.core.cst$kw$validate_DASH_fn,re_com.validate.css_style_QMARK_,cljs.core.cst$kw$description,"CSS styles to add or override (for each individual tab rather than the container)"], null)], null);
re_com.tabs.horizontal_tabs = (function re_com$tabs$horizontal_tabs(var_args){
var args__8125__auto__ = [];
var len__8118__auto___35127 = arguments.length;
var i__8119__auto___35128 = (0);
while(true){
if((i__8119__auto___35128 < len__8118__auto___35127)){
args__8125__auto__.push((arguments[i__8119__auto___35128]));

var G__35129 = (i__8119__auto___35128 + (1));
i__8119__auto___35128 = G__35129;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return re_com.tabs.horizontal_tabs.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

re_com.tabs.horizontal_tabs.cljs$core$IFn$_invoke$arity$variadic = (function (p__35118){
var map__35119 = p__35118;
var map__35119__$1 = ((((!((map__35119 == null)))?((((map__35119.cljs$lang$protocol_mask$partition0$ & (64))) || (map__35119.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__35119):map__35119);
var args = map__35119__$1;
var model = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35119__$1,cljs.core.cst$kw$model);
var tabs = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35119__$1,cljs.core.cst$kw$tabs);
var on_change = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35119__$1,cljs.core.cst$kw$on_DASH_change);
var id_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$3(map__35119__$1,cljs.core.cst$kw$id_DASH_fn,cljs.core.cst$kw$id);
var label_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$3(map__35119__$1,cljs.core.cst$kw$label_DASH_fn,cljs.core.cst$kw$label);
var style = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35119__$1,cljs.core.cst$kw$style);

var current = re_com.util.deref_or_value(model);
var tabs__$1 = re_com.util.deref_or_value(tabs);
var _ = null;
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$ul,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$class,"rc-tabs nav nav-tabs noselect",cljs.core.cst$kw$style,re_com.box.flex_child_style("none")], null),(function (){var iter__7793__auto__ = ((function (current,tabs__$1,_,map__35119,map__35119__$1,args,model,tabs,on_change,id_fn,label_fn,style){
return (function re_com$tabs$iter__35121(s__35122){
return (new cljs.core.LazySeq(null,((function (current,tabs__$1,_,map__35119,map__35119__$1,args,model,tabs,on_change,id_fn,label_fn,style){
return (function (){
var s__35122__$1 = s__35122;
while(true){
var temp__6728__auto__ = cljs.core.seq(s__35122__$1);
if(temp__6728__auto__){
var s__35122__$2 = temp__6728__auto__;
if(cljs.core.chunked_seq_QMARK_(s__35122__$2)){
var c__7791__auto__ = cljs.core.chunk_first(s__35122__$2);
var size__7792__auto__ = cljs.core.count(c__7791__auto__);
var b__35124 = cljs.core.chunk_buffer(size__7792__auto__);
if((function (){var i__35123 = (0);
while(true){
if((i__35123 < size__7792__auto__)){
var t = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(c__7791__auto__,i__35123);
cljs.core.chunk_append(b__35124,(function (){var id = (id_fn.cljs$core$IFn$_invoke$arity$1 ? id_fn.cljs$core$IFn$_invoke$arity$1(t) : id_fn.call(null,t));
var label = (label_fn.cljs$core$IFn$_invoke$arity$1 ? label_fn.cljs$core$IFn$_invoke$arity$1(t) : label_fn.call(null,t));
var selected_QMARK_ = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(id,current);
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$li,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$class,((selected_QMARK_)?"active":null),cljs.core.cst$kw$key,[cljs.core.str(id)].join('')], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$style,cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$cursor,"pointer"], null),style], 0)),cljs.core.cst$kw$on_DASH_click,(cljs.core.truth_(on_change)?((function (i__35123,id,label,selected_QMARK_,t,c__7791__auto__,size__7792__auto__,b__35124,s__35122__$2,temp__6728__auto__,current,tabs__$1,_,map__35119,map__35119__$1,args,model,tabs,on_change,id_fn,label_fn,style){
return (function (event){
(on_change.cljs$core$IFn$_invoke$arity$1 ? on_change.cljs$core$IFn$_invoke$arity$1(id) : on_change.call(null,id));

return null;
});})(i__35123,id,label,selected_QMARK_,t,c__7791__auto__,size__7792__auto__,b__35124,s__35122__$2,temp__6728__auto__,current,tabs__$1,_,map__35119,map__35119__$1,args,model,tabs,on_change,id_fn,label_fn,style))
:null)], null),label], null)], null);
})());

var G__35130 = (i__35123 + (1));
i__35123 = G__35130;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__35124),re_com$tabs$iter__35121(cljs.core.chunk_rest(s__35122__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__35124),null);
}
} else {
var t = cljs.core.first(s__35122__$2);
return cljs.core.cons((function (){var id = (id_fn.cljs$core$IFn$_invoke$arity$1 ? id_fn.cljs$core$IFn$_invoke$arity$1(t) : id_fn.call(null,t));
var label = (label_fn.cljs$core$IFn$_invoke$arity$1 ? label_fn.cljs$core$IFn$_invoke$arity$1(t) : label_fn.call(null,t));
var selected_QMARK_ = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(id,current);
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$li,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$class,((selected_QMARK_)?"active":null),cljs.core.cst$kw$key,[cljs.core.str(id)].join('')], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$style,cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$cursor,"pointer"], null),style], 0)),cljs.core.cst$kw$on_DASH_click,(cljs.core.truth_(on_change)?((function (id,label,selected_QMARK_,t,s__35122__$2,temp__6728__auto__,current,tabs__$1,_,map__35119,map__35119__$1,args,model,tabs,on_change,id_fn,label_fn,style){
return (function (event){
(on_change.cljs$core$IFn$_invoke$arity$1 ? on_change.cljs$core$IFn$_invoke$arity$1(id) : on_change.call(null,id));

return null;
});})(id,label,selected_QMARK_,t,s__35122__$2,temp__6728__auto__,current,tabs__$1,_,map__35119,map__35119__$1,args,model,tabs,on_change,id_fn,label_fn,style))
:null)], null),label], null)], null);
})(),re_com$tabs$iter__35121(cljs.core.rest(s__35122__$2)));
}
} else {
return null;
}
break;
}
});})(current,tabs__$1,_,map__35119,map__35119__$1,args,model,tabs,on_change,id_fn,label_fn,style))
,null,null));
});})(current,tabs__$1,_,map__35119,map__35119__$1,args,model,tabs,on_change,id_fn,label_fn,style))
;
return iter__7793__auto__(tabs__$1);
})()], null);
});

re_com.tabs.horizontal_tabs.cljs$lang$maxFixedArity = (0);

re_com.tabs.horizontal_tabs.cljs$lang$applyTo = (function (seq35117){
return re_com.tabs.horizontal_tabs.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq35117));
});

re_com.tabs.bar_tabs = (function re_com$tabs$bar_tabs(var_args){
var args__8125__auto__ = [];
var len__8118__auto___35142 = arguments.length;
var i__8119__auto___35143 = (0);
while(true){
if((i__8119__auto___35143 < len__8118__auto___35142)){
args__8125__auto__.push((arguments[i__8119__auto___35143]));

var G__35144 = (i__8119__auto___35143 + (1));
i__8119__auto___35143 = G__35144;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return re_com.tabs.bar_tabs.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

re_com.tabs.bar_tabs.cljs$core$IFn$_invoke$arity$variadic = (function (p__35133){
var map__35134 = p__35133;
var map__35134__$1 = ((((!((map__35134 == null)))?((((map__35134.cljs$lang$protocol_mask$partition0$ & (64))) || (map__35134.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__35134):map__35134);
var model = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35134__$1,cljs.core.cst$kw$model);
var tabs = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35134__$1,cljs.core.cst$kw$tabs);
var on_change = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35134__$1,cljs.core.cst$kw$on_DASH_change);
var id_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35134__$1,cljs.core.cst$kw$id_DASH_fn);
var label_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35134__$1,cljs.core.cst$kw$label_DASH_fn);
var style = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35134__$1,cljs.core.cst$kw$style);
var vertical_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35134__$1,cljs.core.cst$kw$vertical_QMARK_);
var current = re_com.util.deref_or_value(model);
var tabs__$1 = re_com.util.deref_or_value(tabs);
var _ = null;
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$class,[cljs.core.str("rc-tabs noselect btn-group"),cljs.core.str((cljs.core.truth_(vertical_QMARK_)?"-vertical":null))].join(''),cljs.core.cst$kw$style,re_com.box.flex_child_style("none")], null),(function (){var iter__7793__auto__ = ((function (current,tabs__$1,_,map__35134,map__35134__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_){
return (function re_com$tabs$iter__35136(s__35137){
return (new cljs.core.LazySeq(null,((function (current,tabs__$1,_,map__35134,map__35134__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_){
return (function (){
var s__35137__$1 = s__35137;
while(true){
var temp__6728__auto__ = cljs.core.seq(s__35137__$1);
if(temp__6728__auto__){
var s__35137__$2 = temp__6728__auto__;
if(cljs.core.chunked_seq_QMARK_(s__35137__$2)){
var c__7791__auto__ = cljs.core.chunk_first(s__35137__$2);
var size__7792__auto__ = cljs.core.count(c__7791__auto__);
var b__35139 = cljs.core.chunk_buffer(size__7792__auto__);
if((function (){var i__35138 = (0);
while(true){
if((i__35138 < size__7792__auto__)){
var t = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(c__7791__auto__,i__35138);
cljs.core.chunk_append(b__35139,(function (){var id = (id_fn.cljs$core$IFn$_invoke$arity$1 ? id_fn.cljs$core$IFn$_invoke$arity$1(t) : id_fn.call(null,t));
var label = (label_fn.cljs$core$IFn$_invoke$arity$1 ? label_fn.cljs$core$IFn$_invoke$arity$1(t) : label_fn.call(null,t));
var selected_QMARK_ = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(id,current);
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$button,new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$type,"button",cljs.core.cst$kw$key,[cljs.core.str(id)].join(''),cljs.core.cst$kw$class,[cljs.core.str("btn btn-default "),cljs.core.str(((selected_QMARK_)?"active":null))].join(''),cljs.core.cst$kw$style,style,cljs.core.cst$kw$on_DASH_click,(cljs.core.truth_(on_change)?((function (i__35138,id,label,selected_QMARK_,t,c__7791__auto__,size__7792__auto__,b__35139,s__35137__$2,temp__6728__auto__,current,tabs__$1,_,map__35134,map__35134__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_){
return (function (event){
(on_change.cljs$core$IFn$_invoke$arity$1 ? on_change.cljs$core$IFn$_invoke$arity$1(id) : on_change.call(null,id));

return null;
});})(i__35138,id,label,selected_QMARK_,t,c__7791__auto__,size__7792__auto__,b__35139,s__35137__$2,temp__6728__auto__,current,tabs__$1,_,map__35134,map__35134__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_))
:null)], null),label], null);
})());

var G__35145 = (i__35138 + (1));
i__35138 = G__35145;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__35139),re_com$tabs$iter__35136(cljs.core.chunk_rest(s__35137__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__35139),null);
}
} else {
var t = cljs.core.first(s__35137__$2);
return cljs.core.cons((function (){var id = (id_fn.cljs$core$IFn$_invoke$arity$1 ? id_fn.cljs$core$IFn$_invoke$arity$1(t) : id_fn.call(null,t));
var label = (label_fn.cljs$core$IFn$_invoke$arity$1 ? label_fn.cljs$core$IFn$_invoke$arity$1(t) : label_fn.call(null,t));
var selected_QMARK_ = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(id,current);
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$button,new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$type,"button",cljs.core.cst$kw$key,[cljs.core.str(id)].join(''),cljs.core.cst$kw$class,[cljs.core.str("btn btn-default "),cljs.core.str(((selected_QMARK_)?"active":null))].join(''),cljs.core.cst$kw$style,style,cljs.core.cst$kw$on_DASH_click,(cljs.core.truth_(on_change)?((function (id,label,selected_QMARK_,t,s__35137__$2,temp__6728__auto__,current,tabs__$1,_,map__35134,map__35134__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_){
return (function (event){
(on_change.cljs$core$IFn$_invoke$arity$1 ? on_change.cljs$core$IFn$_invoke$arity$1(id) : on_change.call(null,id));

return null;
});})(id,label,selected_QMARK_,t,s__35137__$2,temp__6728__auto__,current,tabs__$1,_,map__35134,map__35134__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_))
:null)], null),label], null);
})(),re_com$tabs$iter__35136(cljs.core.rest(s__35137__$2)));
}
} else {
return null;
}
break;
}
});})(current,tabs__$1,_,map__35134,map__35134__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_))
,null,null));
});})(current,tabs__$1,_,map__35134,map__35134__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_))
;
return iter__7793__auto__(tabs__$1);
})()], null);
});

re_com.tabs.bar_tabs.cljs$lang$maxFixedArity = (0);

re_com.tabs.bar_tabs.cljs$lang$applyTo = (function (seq35132){
return re_com.tabs.bar_tabs.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq35132));
});

re_com.tabs.horizontal_bar_tabs = (function re_com$tabs$horizontal_bar_tabs(var_args){
var args__8125__auto__ = [];
var len__8118__auto___35150 = arguments.length;
var i__8119__auto___35151 = (0);
while(true){
if((i__8119__auto___35151 < len__8118__auto___35150)){
args__8125__auto__.push((arguments[i__8119__auto___35151]));

var G__35152 = (i__8119__auto___35151 + (1));
i__8119__auto___35151 = G__35152;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return re_com.tabs.horizontal_bar_tabs.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

re_com.tabs.horizontal_bar_tabs.cljs$core$IFn$_invoke$arity$variadic = (function (p__35147){
var map__35148 = p__35147;
var map__35148__$1 = ((((!((map__35148 == null)))?((((map__35148.cljs$lang$protocol_mask$partition0$ & (64))) || (map__35148.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__35148):map__35148);
var args = map__35148__$1;
var model = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35148__$1,cljs.core.cst$kw$model);
var tabs = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35148__$1,cljs.core.cst$kw$tabs);
var on_change = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35148__$1,cljs.core.cst$kw$on_DASH_change);
var id_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$3(map__35148__$1,cljs.core.cst$kw$id_DASH_fn,cljs.core.cst$kw$id);
var label_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$3(map__35148__$1,cljs.core.cst$kw$label_DASH_fn,cljs.core.cst$kw$label);
var style = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35148__$1,cljs.core.cst$kw$style);

return re_com.tabs.bar_tabs.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([cljs.core.cst$kw$model,model,cljs.core.cst$kw$tabs,tabs,cljs.core.cst$kw$on_DASH_change,on_change,cljs.core.cst$kw$style,style,cljs.core.cst$kw$id_DASH_fn,id_fn,cljs.core.cst$kw$label_DASH_fn,label_fn,cljs.core.cst$kw$vertical_QMARK_,false], 0));
});

re_com.tabs.horizontal_bar_tabs.cljs$lang$maxFixedArity = (0);

re_com.tabs.horizontal_bar_tabs.cljs$lang$applyTo = (function (seq35146){
return re_com.tabs.horizontal_bar_tabs.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq35146));
});

re_com.tabs.vertical_bar_tabs = (function re_com$tabs$vertical_bar_tabs(var_args){
var args__8125__auto__ = [];
var len__8118__auto___35157 = arguments.length;
var i__8119__auto___35158 = (0);
while(true){
if((i__8119__auto___35158 < len__8118__auto___35157)){
args__8125__auto__.push((arguments[i__8119__auto___35158]));

var G__35159 = (i__8119__auto___35158 + (1));
i__8119__auto___35158 = G__35159;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return re_com.tabs.vertical_bar_tabs.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

re_com.tabs.vertical_bar_tabs.cljs$core$IFn$_invoke$arity$variadic = (function (p__35154){
var map__35155 = p__35154;
var map__35155__$1 = ((((!((map__35155 == null)))?((((map__35155.cljs$lang$protocol_mask$partition0$ & (64))) || (map__35155.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__35155):map__35155);
var args = map__35155__$1;
var model = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35155__$1,cljs.core.cst$kw$model);
var tabs = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35155__$1,cljs.core.cst$kw$tabs);
var on_change = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35155__$1,cljs.core.cst$kw$on_DASH_change);
var id_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$3(map__35155__$1,cljs.core.cst$kw$id_DASH_fn,cljs.core.cst$kw$id);
var label_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$3(map__35155__$1,cljs.core.cst$kw$label_DASH_fn,cljs.core.cst$kw$label);
var style = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35155__$1,cljs.core.cst$kw$style);

return re_com.tabs.bar_tabs.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([cljs.core.cst$kw$model,model,cljs.core.cst$kw$tabs,tabs,cljs.core.cst$kw$on_DASH_change,on_change,cljs.core.cst$kw$style,style,cljs.core.cst$kw$id_DASH_fn,id_fn,cljs.core.cst$kw$label_DASH_fn,label_fn,cljs.core.cst$kw$vertical_QMARK_,true], 0));
});

re_com.tabs.vertical_bar_tabs.cljs$lang$maxFixedArity = (0);

re_com.tabs.vertical_bar_tabs.cljs$lang$applyTo = (function (seq35153){
return re_com.tabs.vertical_bar_tabs.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq35153));
});

re_com.tabs.pill_tabs = (function re_com$tabs$pill_tabs(var_args){
var args__8125__auto__ = [];
var len__8118__auto___35171 = arguments.length;
var i__8119__auto___35172 = (0);
while(true){
if((i__8119__auto___35172 < len__8118__auto___35171)){
args__8125__auto__.push((arguments[i__8119__auto___35172]));

var G__35173 = (i__8119__auto___35172 + (1));
i__8119__auto___35172 = G__35173;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return re_com.tabs.pill_tabs.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

re_com.tabs.pill_tabs.cljs$core$IFn$_invoke$arity$variadic = (function (p__35162){
var map__35163 = p__35162;
var map__35163__$1 = ((((!((map__35163 == null)))?((((map__35163.cljs$lang$protocol_mask$partition0$ & (64))) || (map__35163.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__35163):map__35163);
var model = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35163__$1,cljs.core.cst$kw$model);
var tabs = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35163__$1,cljs.core.cst$kw$tabs);
var on_change = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35163__$1,cljs.core.cst$kw$on_DASH_change);
var id_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35163__$1,cljs.core.cst$kw$id_DASH_fn);
var label_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35163__$1,cljs.core.cst$kw$label_DASH_fn);
var style = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35163__$1,cljs.core.cst$kw$style);
var vertical_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35163__$1,cljs.core.cst$kw$vertical_QMARK_);
var current = re_com.util.deref_or_value(model);
var tabs__$1 = re_com.util.deref_or_value(tabs);
var _ = null;
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$ul,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$class,[cljs.core.str("rc-tabs noselect nav nav-pills"),cljs.core.str((cljs.core.truth_(vertical_QMARK_)?" nav-stacked":null))].join(''),cljs.core.cst$kw$style,re_com.box.flex_child_style("none"),cljs.core.cst$kw$role,"tabslist"], null),(function (){var iter__7793__auto__ = ((function (current,tabs__$1,_,map__35163,map__35163__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_){
return (function re_com$tabs$iter__35165(s__35166){
return (new cljs.core.LazySeq(null,((function (current,tabs__$1,_,map__35163,map__35163__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_){
return (function (){
var s__35166__$1 = s__35166;
while(true){
var temp__6728__auto__ = cljs.core.seq(s__35166__$1);
if(temp__6728__auto__){
var s__35166__$2 = temp__6728__auto__;
if(cljs.core.chunked_seq_QMARK_(s__35166__$2)){
var c__7791__auto__ = cljs.core.chunk_first(s__35166__$2);
var size__7792__auto__ = cljs.core.count(c__7791__auto__);
var b__35168 = cljs.core.chunk_buffer(size__7792__auto__);
if((function (){var i__35167 = (0);
while(true){
if((i__35167 < size__7792__auto__)){
var t = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(c__7791__auto__,i__35167);
cljs.core.chunk_append(b__35168,(function (){var id = (id_fn.cljs$core$IFn$_invoke$arity$1 ? id_fn.cljs$core$IFn$_invoke$arity$1(t) : id_fn.call(null,t));
var label = (label_fn.cljs$core$IFn$_invoke$arity$1 ? label_fn.cljs$core$IFn$_invoke$arity$1(t) : label_fn.call(null,t));
var selected_QMARK_ = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(id,current);
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$li,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$class,((selected_QMARK_)?"active":""),cljs.core.cst$kw$key,[cljs.core.str(id)].join('')], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$style,cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$cursor,"pointer"], null),style], 0)),cljs.core.cst$kw$on_DASH_click,(cljs.core.truth_(on_change)?((function (i__35167,id,label,selected_QMARK_,t,c__7791__auto__,size__7792__auto__,b__35168,s__35166__$2,temp__6728__auto__,current,tabs__$1,_,map__35163,map__35163__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_){
return (function (event){
(on_change.cljs$core$IFn$_invoke$arity$1 ? on_change.cljs$core$IFn$_invoke$arity$1(id) : on_change.call(null,id));

return null;
});})(i__35167,id,label,selected_QMARK_,t,c__7791__auto__,size__7792__auto__,b__35168,s__35166__$2,temp__6728__auto__,current,tabs__$1,_,map__35163,map__35163__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_))
:null)], null),label], null)], null);
})());

var G__35174 = (i__35167 + (1));
i__35167 = G__35174;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__35168),re_com$tabs$iter__35165(cljs.core.chunk_rest(s__35166__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__35168),null);
}
} else {
var t = cljs.core.first(s__35166__$2);
return cljs.core.cons((function (){var id = (id_fn.cljs$core$IFn$_invoke$arity$1 ? id_fn.cljs$core$IFn$_invoke$arity$1(t) : id_fn.call(null,t));
var label = (label_fn.cljs$core$IFn$_invoke$arity$1 ? label_fn.cljs$core$IFn$_invoke$arity$1(t) : label_fn.call(null,t));
var selected_QMARK_ = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(id,current);
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$li,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$class,((selected_QMARK_)?"active":""),cljs.core.cst$kw$key,[cljs.core.str(id)].join('')], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$style,cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$cursor,"pointer"], null),style], 0)),cljs.core.cst$kw$on_DASH_click,(cljs.core.truth_(on_change)?((function (id,label,selected_QMARK_,t,s__35166__$2,temp__6728__auto__,current,tabs__$1,_,map__35163,map__35163__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_){
return (function (event){
(on_change.cljs$core$IFn$_invoke$arity$1 ? on_change.cljs$core$IFn$_invoke$arity$1(id) : on_change.call(null,id));

return null;
});})(id,label,selected_QMARK_,t,s__35166__$2,temp__6728__auto__,current,tabs__$1,_,map__35163,map__35163__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_))
:null)], null),label], null)], null);
})(),re_com$tabs$iter__35165(cljs.core.rest(s__35166__$2)));
}
} else {
return null;
}
break;
}
});})(current,tabs__$1,_,map__35163,map__35163__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_))
,null,null));
});})(current,tabs__$1,_,map__35163,map__35163__$1,model,tabs,on_change,id_fn,label_fn,style,vertical_QMARK_))
;
return iter__7793__auto__(tabs__$1);
})()], null);
});

re_com.tabs.pill_tabs.cljs$lang$maxFixedArity = (0);

re_com.tabs.pill_tabs.cljs$lang$applyTo = (function (seq35161){
return re_com.tabs.pill_tabs.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq35161));
});

re_com.tabs.horizontal_pill_tabs = (function re_com$tabs$horizontal_pill_tabs(var_args){
var args__8125__auto__ = [];
var len__8118__auto___35179 = arguments.length;
var i__8119__auto___35180 = (0);
while(true){
if((i__8119__auto___35180 < len__8118__auto___35179)){
args__8125__auto__.push((arguments[i__8119__auto___35180]));

var G__35181 = (i__8119__auto___35180 + (1));
i__8119__auto___35180 = G__35181;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return re_com.tabs.horizontal_pill_tabs.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

re_com.tabs.horizontal_pill_tabs.cljs$core$IFn$_invoke$arity$variadic = (function (p__35176){
var map__35177 = p__35176;
var map__35177__$1 = ((((!((map__35177 == null)))?((((map__35177.cljs$lang$protocol_mask$partition0$ & (64))) || (map__35177.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__35177):map__35177);
var args = map__35177__$1;
var model = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35177__$1,cljs.core.cst$kw$model);
var tabs = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35177__$1,cljs.core.cst$kw$tabs);
var on_change = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35177__$1,cljs.core.cst$kw$on_DASH_change);
var id_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$3(map__35177__$1,cljs.core.cst$kw$id_DASH_fn,cljs.core.cst$kw$id);
var style = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35177__$1,cljs.core.cst$kw$style);
var label_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$3(map__35177__$1,cljs.core.cst$kw$label_DASH_fn,cljs.core.cst$kw$label);

return re_com.tabs.pill_tabs.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([cljs.core.cst$kw$model,model,cljs.core.cst$kw$tabs,tabs,cljs.core.cst$kw$on_DASH_change,on_change,cljs.core.cst$kw$style,style,cljs.core.cst$kw$id_DASH_fn,id_fn,cljs.core.cst$kw$label_DASH_fn,label_fn,cljs.core.cst$kw$vertical_QMARK_,false], 0));
});

re_com.tabs.horizontal_pill_tabs.cljs$lang$maxFixedArity = (0);

re_com.tabs.horizontal_pill_tabs.cljs$lang$applyTo = (function (seq35175){
return re_com.tabs.horizontal_pill_tabs.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq35175));
});

re_com.tabs.vertical_pill_tabs = (function re_com$tabs$vertical_pill_tabs(var_args){
var args__8125__auto__ = [];
var len__8118__auto___35186 = arguments.length;
var i__8119__auto___35187 = (0);
while(true){
if((i__8119__auto___35187 < len__8118__auto___35186)){
args__8125__auto__.push((arguments[i__8119__auto___35187]));

var G__35188 = (i__8119__auto___35187 + (1));
i__8119__auto___35187 = G__35188;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return re_com.tabs.vertical_pill_tabs.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

re_com.tabs.vertical_pill_tabs.cljs$core$IFn$_invoke$arity$variadic = (function (p__35183){
var map__35184 = p__35183;
var map__35184__$1 = ((((!((map__35184 == null)))?((((map__35184.cljs$lang$protocol_mask$partition0$ & (64))) || (map__35184.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__35184):map__35184);
var args = map__35184__$1;
var model = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35184__$1,cljs.core.cst$kw$model);
var tabs = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35184__$1,cljs.core.cst$kw$tabs);
var on_change = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35184__$1,cljs.core.cst$kw$on_DASH_change);
var id_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$3(map__35184__$1,cljs.core.cst$kw$id_DASH_fn,cljs.core.cst$kw$id);
var style = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35184__$1,cljs.core.cst$kw$style);
var label_fn = cljs.core.get.cljs$core$IFn$_invoke$arity$3(map__35184__$1,cljs.core.cst$kw$label_DASH_fn,cljs.core.cst$kw$label);

return re_com.tabs.pill_tabs.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([cljs.core.cst$kw$model,model,cljs.core.cst$kw$tabs,tabs,cljs.core.cst$kw$on_DASH_change,on_change,cljs.core.cst$kw$style,style,cljs.core.cst$kw$id_DASH_fn,id_fn,cljs.core.cst$kw$label_DASH_fn,label_fn,cljs.core.cst$kw$vertical_QMARK_,true], 0));
});

re_com.tabs.vertical_pill_tabs.cljs$lang$maxFixedArity = (0);

re_com.tabs.vertical_pill_tabs.cljs$lang$applyTo = (function (seq35182){
return re_com.tabs.vertical_pill_tabs.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq35182));
});


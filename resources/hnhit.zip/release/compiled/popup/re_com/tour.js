// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('re_com.tour');
goog.require('cljs.core');
goog.require('reagent.core');
goog.require('re_com.box');
goog.require('re_com.buttons');
/**
 * Returns a map containing
 *   - A reagent atom for each tour step controlling popover show/hide (boolean)
 *   - A standard atom holding the current step (integer)
 *   - A copy of the steps parameter passed in, to determine the order for prev/next functions
 *   It sets the first step atom to true so that it will be initially shown
 *   Sample return value:
 *   {:steps [:step1 :step2 :step3]
 *   :current-step (atom 0)
 *   :step1 (reagent/atom true)
 *   :step2 (reagent/atom false)
 *   :step3 (reagent/atom false)}
 */
re_com.tour.make_tour = (function re_com$tour$make_tour(tour_spec){
var tour_map = new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$current_DASH_step,(cljs.core.atom.cljs$core$IFn$_invoke$arity$1 ? cljs.core.atom.cljs$core$IFn$_invoke$arity$1((0)) : cljs.core.atom.call(null,(0))),cljs.core.cst$kw$steps,tour_spec], null);
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3(((function (tour_map){
return (function (p1__36016_SHARP_,p2__36017_SHARP_){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__36016_SHARP_,p2__36017_SHARP_,reagent.core.atom.cljs$core$IFn$_invoke$arity$1(false));
});})(tour_map))
,tour_map,tour_spec);
});
/**
 * Resets all poover atoms to false
 */
re_com.tour.initialise_tour = (function re_com$tour$initialise_tour(tour){
return cljs.core.doall.cljs$core$IFn$_invoke$arity$1((function (){var iter__7793__auto__ = (function re_com$tour$initialise_tour_$_iter__36032(s__36033){
return (new cljs.core.LazySeq(null,(function (){
var s__36033__$1 = s__36033;
while(true){
var temp__6728__auto__ = cljs.core.seq(s__36033__$1);
if(temp__6728__auto__){
var s__36033__$2 = temp__6728__auto__;
if(cljs.core.chunked_seq_QMARK_(s__36033__$2)){
var c__7791__auto__ = cljs.core.chunk_first(s__36033__$2);
var size__7792__auto__ = cljs.core.count(c__7791__auto__);
var b__36035 = cljs.core.chunk_buffer(size__7792__auto__);
if((function (){var i__36034 = (0);
while(true){
if((i__36034 < size__7792__auto__)){
var step = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(c__7791__auto__,i__36034);
cljs.core.chunk_append(b__36035,(function (){var G__36042 = (step.cljs$core$IFn$_invoke$arity$1 ? step.cljs$core$IFn$_invoke$arity$1(tour) : step.call(null,tour));
var G__36043 = false;
return (cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__36042,G__36043) : cljs.core.reset_BANG_.call(null,G__36042,G__36043));
})());

var G__36046 = (i__36034 + (1));
i__36034 = G__36046;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__36035),re_com$tour$initialise_tour_$_iter__36032(cljs.core.chunk_rest(s__36033__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__36035),null);
}
} else {
var step = cljs.core.first(s__36033__$2);
return cljs.core.cons((function (){var G__36044 = (step.cljs$core$IFn$_invoke$arity$1 ? step.cljs$core$IFn$_invoke$arity$1(tour) : step.call(null,tour));
var G__36045 = false;
return (cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__36044,G__36045) : cljs.core.reset_BANG_.call(null,G__36044,G__36045));
})(),re_com$tour$initialise_tour_$_iter__36032(cljs.core.rest(s__36033__$2)));
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__7793__auto__(cljs.core.cst$kw$steps.cljs$core$IFn$_invoke$arity$1(tour));
})());
});
/**
 * Sets the first popover atom in the tour to true
 */
re_com.tour.start_tour = (function re_com$tour$start_tour(tour){
re_com.tour.initialise_tour(tour);

var G__36051_36055 = cljs.core.cst$kw$current_DASH_step.cljs$core$IFn$_invoke$arity$1(tour);
var G__36052_36056 = (0);
(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__36051_36055,G__36052_36056) : cljs.core.reset_BANG_.call(null,G__36051_36055,G__36052_36056));

var G__36053 = cljs.core.first(cljs.core.cst$kw$steps.cljs$core$IFn$_invoke$arity$1(tour)).call(null,tour);
var G__36054 = true;
return (cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__36053,G__36054) : cljs.core.reset_BANG_.call(null,G__36053,G__36054));
});
/**
 * Closes all tour popovers
 */
re_com.tour.finish_tour = (function re_com$tour$finish_tour(tour){
return re_com.tour.initialise_tour(tour);
});
re_com.tour.next_tour_step = (function re_com$tour$next_tour_step(tour){
var steps = cljs.core.cst$kw$steps.cljs$core$IFn$_invoke$arity$1(tour);
var old_step = (function (){var G__36064 = cljs.core.cst$kw$current_DASH_step.cljs$core$IFn$_invoke$arity$1(tour);
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(G__36064) : cljs.core.deref.call(null,G__36064));
})();
var new_step = (old_step + (1));
if((new_step < cljs.core.count(cljs.core.cst$kw$steps.cljs$core$IFn$_invoke$arity$1(tour)))){
var G__36065_36071 = cljs.core.cst$kw$current_DASH_step.cljs$core$IFn$_invoke$arity$1(tour);
var G__36066_36072 = new_step;
(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__36065_36071,G__36066_36072) : cljs.core.reset_BANG_.call(null,G__36065_36071,G__36066_36072));

var G__36067_36073 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(steps,old_step).call(null,tour);
var G__36068_36074 = false;
(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__36067_36073,G__36068_36074) : cljs.core.reset_BANG_.call(null,G__36067_36073,G__36068_36074));

var G__36069 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(steps,new_step).call(null,tour);
var G__36070 = true;
return (cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__36069,G__36070) : cljs.core.reset_BANG_.call(null,G__36069,G__36070));
} else {
return null;
}
});
re_com.tour.prev_tour_step = (function re_com$tour$prev_tour_step(tour){
var steps = cljs.core.cst$kw$steps.cljs$core$IFn$_invoke$arity$1(tour);
var old_step = (function (){var G__36082 = cljs.core.cst$kw$current_DASH_step.cljs$core$IFn$_invoke$arity$1(tour);
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(G__36082) : cljs.core.deref.call(null,G__36082));
})();
var new_step = (old_step - (1));
if((new_step >= (0))){
var G__36083_36089 = cljs.core.cst$kw$current_DASH_step.cljs$core$IFn$_invoke$arity$1(tour);
var G__36084_36090 = new_step;
(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__36083_36089,G__36084_36090) : cljs.core.reset_BANG_.call(null,G__36083_36089,G__36084_36090));

var G__36085_36091 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(steps,old_step).call(null,tour);
var G__36086_36092 = false;
(cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__36085_36091,G__36086_36092) : cljs.core.reset_BANG_.call(null,G__36085_36091,G__36086_36092));

var G__36087 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(steps,new_step).call(null,tour);
var G__36088 = true;
return (cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2 ? cljs.core.reset_BANG_.cljs$core$IFn$_invoke$arity$2(G__36087,G__36088) : cljs.core.reset_BANG_.call(null,G__36087,G__36088));
} else {
return null;
}
});
/**
 * Generate the hr and previous/next buttons markup.
 *   If first button in tour, don't generate a Previous button.
 *   If last button in tour, change Next button to a Finish button
 */
re_com.tour.make_tour_nav = (function re_com$tour$make_tour_nav(tour){
var on_first_button = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((function (){var G__36095 = cljs.core.cst$kw$current_DASH_step.cljs$core$IFn$_invoke$arity$1(tour);
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(G__36095) : cljs.core.deref.call(null,G__36095));
})(),(0));
var on_last_button = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((function (){var G__36096 = cljs.core.cst$kw$current_DASH_step.cljs$core$IFn$_invoke$arity$1(tour);
return (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(G__36096) : cljs.core.deref.call(null,G__36096));
})(),(cljs.core.count(cljs.core.cst$kw$steps.cljs$core$IFn$_invoke$arity$1(tour)) - (1)));
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$hr,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$style,cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.array_seq([re_com.box.flex_child_style("none"),new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$margin,"10px 0px 10px"], null)], 0))], null)], null),((on_first_button)?null:new cljs.core.PersistentVector(null, 9, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.buttons.button,cljs.core.cst$kw$label,"Previous",cljs.core.cst$kw$on_DASH_click,((function (on_first_button,on_last_button){
return (function (event){
re_com.tour.prev_tour_step(tour);

return null;
});})(on_first_button,on_last_button))
,cljs.core.cst$kw$style,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$margin_DASH_right,"15px"], null),cljs.core.cst$kw$class,"btn-default"], null)),new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.buttons.button,cljs.core.cst$kw$label,((on_last_button)?"Finish":"Next"),cljs.core.cst$kw$on_DASH_click,((function (on_first_button,on_last_button){
return (function (event){
if(on_last_button){
re_com.tour.finish_tour(tour);
} else {
re_com.tour.next_tour_step(tour);
}

return null;
});})(on_first_button,on_last_button))
,cljs.core.cst$kw$class,"btn-default"], null)], null);
});

// Compiled by ClojureScript 1.9.229 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('re_com.typeahead');
goog.require('cljs.core');
goog.require('cljs.core.async');
goog.require('re_com.misc');
goog.require('re_com.util');
goog.require('re_com.popover');
goog.require('re_com.box');
goog.require('re_com.validate');
goog.require('reagent.core');
goog.require('goog.events.KeyCodes');
re_com.typeahead.typeahead_args_desc = new cljs.core.PersistentVector(null, 18, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$data_DASH_source,cljs.core.cst$kw$required,true,cljs.core.cst$kw$type,"fn",cljs.core.cst$kw$validate_DASH_fn,cljs.core.fn_QMARK_,cljs.core.cst$kw$description,new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$span,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":data-source"], null)," supplies suggestion objects. This can either accept a single string argument (the search term), or a string and a callback. For the first case, the fn should return a collection of suggestion objects (which can be anything). For the second case, the fn should return ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,"nil"], null),", and eventually result in a call to the callback with a collection of suggestion objects."], null)], null),new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$name,cljs.core.cst$kw$on_DASH_change,cljs.core.cst$kw$required,false,cljs.core.cst$kw$default,null,cljs.core.cst$kw$type,"string -> nil",cljs.core.cst$kw$validate_DASH_fn,cljs.core.fn_QMARK_,cljs.core.cst$kw$description,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$span,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":change-on-blur?"], null)," controls when it is called. It is passed a suggestion object."], null)], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$change_DASH_on_DASH_blur_QMARK_,cljs.core.cst$kw$required,false,cljs.core.cst$kw$default,true,cljs.core.cst$kw$type,"boolean | atom",cljs.core.cst$kw$description,new cljs.core.PersistentVector(null, 8, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$span,"when true, invoke ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":on-change"], null)," when the use chooses a suggestion, otherwise invoke it on every change (navigating through suggestions with the mouse or keyboard, or if ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,"rigid?"], null)," is also ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,"false"], null),", invoke it on every character typed.)"], null)], null),cljs.core.PersistentArrayMap.fromArray([cljs.core.cst$kw$name,cljs.core.cst$kw$model,cljs.core.cst$kw$required,false,cljs.core.cst$kw$default,null,cljs.core.cst$kw$type,"object | atom",cljs.core.cst$kw$description,"The initial value of the typeahead (should match the suggestion objects returned by ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":data-source"], null),")."], true, false),new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$name,cljs.core.cst$kw$debounce_DASH_delay,cljs.core.cst$kw$required,false,cljs.core.cst$kw$default,(250),cljs.core.cst$kw$type,"integer",cljs.core.cst$kw$validate_DASH_fn,cljs.core.integer_QMARK_,cljs.core.cst$kw$description,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$span,"After receiving input, the typeahead will wait this many milliseconds without receiving new input before calling ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":data-source"], null),"."], null)], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$render_DASH_suggestion,cljs.core.cst$kw$required,false,cljs.core.cst$kw$type,"render fn",cljs.core.cst$kw$validate_DASH_fn,cljs.core.fn_QMARK_,cljs.core.cst$kw$description,"override the rendering of the suggestion items by passing a fn that returns hiccup forms. The fn will receive two arguments: the search term, and the suggestion object."], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$suggestion_DASH_to_DASH_string,cljs.core.cst$kw$required,false,cljs.core.cst$kw$type,"suggestion -> string",cljs.core.cst$kw$validate_DASH_fn,cljs.core.fn_QMARK_,cljs.core.cst$kw$description,"When a suggestion is chosen, the input-text value will be set to the result of calling this fn with the suggestion object."], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$rigid_QMARK_,cljs.core.cst$kw$required,false,cljs.core.cst$kw$default,true,cljs.core.cst$kw$type,"boolean | atom",cljs.core.cst$kw$description,new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$span,"If ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,"false"], null)," the user will be allowed to choose arbitrary text input rather than a suggestion from ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":data-source"], null),". In this case, a string will be supplied in lieu of a suggestion object."], null)], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$status,cljs.core.cst$kw$required,false,cljs.core.cst$kw$type,"keyword",cljs.core.cst$kw$validate_DASH_fn,re_com.validate.input_status_type_QMARK_,cljs.core.cst$kw$description,new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$span,"validation status. ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,"nil/omitted"], null)," for normal status or one of: ",re_com.validate.input_status_types_list], null)], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$status_DASH_icon_QMARK_,cljs.core.cst$kw$required,false,cljs.core.cst$kw$default,false,cljs.core.cst$kw$type,"boolean",cljs.core.cst$kw$description,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$span,"when true, display an icon to match ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":status"], null)," (no icon for nil)"], null)], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$status_DASH_tooltip,cljs.core.cst$kw$required,false,cljs.core.cst$kw$type,"string",cljs.core.cst$kw$validate_DASH_fn,cljs.core.string_QMARK_,cljs.core.cst$kw$description,"displayed in status icon's tooltip"], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$placeholder,cljs.core.cst$kw$required,false,cljs.core.cst$kw$type,"string",cljs.core.cst$kw$validate_DASH_fn,cljs.core.string_QMARK_,cljs.core.cst$kw$description,"background text shown when empty"], null),new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$name,cljs.core.cst$kw$width,cljs.core.cst$kw$required,false,cljs.core.cst$kw$default,"250px",cljs.core.cst$kw$type,"string",cljs.core.cst$kw$validate_DASH_fn,cljs.core.string_QMARK_,cljs.core.cst$kw$description,"standard CSS width setting for this input"], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$height,cljs.core.cst$kw$required,false,cljs.core.cst$kw$type,"string",cljs.core.cst$kw$validate_DASH_fn,cljs.core.string_QMARK_,cljs.core.cst$kw$description,"standard CSS height setting for this input"], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$disabled_QMARK_,cljs.core.cst$kw$required,false,cljs.core.cst$kw$default,false,cljs.core.cst$kw$type,"boolean | atom",cljs.core.cst$kw$description,"if true, the user can't interact (input anything)"], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$class,cljs.core.cst$kw$required,false,cljs.core.cst$kw$type,"string",cljs.core.cst$kw$validate_DASH_fn,cljs.core.string_QMARK_,cljs.core.cst$kw$description,"CSS class names, space separated"], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$style,cljs.core.cst$kw$required,false,cljs.core.cst$kw$type,"CSS style map",cljs.core.cst$kw$validate_DASH_fn,re_com.validate.css_style_QMARK_,cljs.core.cst$kw$description,"CSS styles to add or override"], null),new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$name,cljs.core.cst$kw$attr,cljs.core.cst$kw$required,false,cljs.core.cst$kw$type,"HTML attr map",cljs.core.cst$kw$validate_DASH_fn,re_com.validate.html_attr_QMARK_,cljs.core.cst$kw$description,new cljs.core.PersistentVector(null, 9, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$span,"HTML attributes, like ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":on-mouse-move"], null),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$br], null),"No ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":class"], null)," or ",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$code,":style"], null),"allowed"], null)], null)], null);

/**
 * Return an initial value for the typeahead state, given `args`.
 */
re_com.typeahead.make_typeahead_state = (function re_com$typeahead$make_typeahead_state(p__34721){
var map__34725 = p__34721;
var map__34725__$1 = ((((!((map__34725 == null)))?((((map__34725.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34725.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34725):map__34725);
var args = map__34725__$1;
var on_change = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34725__$1,cljs.core.cst$kw$on_DASH_change);
var rigid_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34725__$1,cljs.core.cst$kw$rigid_QMARK_);
var change_on_blur_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34725__$1,cljs.core.cst$kw$change_DASH_on_DASH_blur_QMARK_);
var data_source = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34725__$1,cljs.core.cst$kw$data_DASH_source);
var suggestion_to_string = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34725__$1,cljs.core.cst$kw$suggestion_DASH_to_DASH_string);
var debounce_delay = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34725__$1,cljs.core.cst$kw$debounce_DASH_delay);
var model = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34725__$1,cljs.core.cst$kw$model);
var external_model_value = re_com.util.deref_or_value(model);
var G__34727 = (function (){var c_input = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
return cljs.core.PersistentHashMap.fromArrays([cljs.core.cst$kw$waiting_QMARK_,cljs.core.cst$kw$suggestion_DASH_to_DASH_string,cljs.core.cst$kw$displaying_DASH_suggestion_QMARK_,cljs.core.cst$kw$input_DASH_text,cljs.core.cst$kw$rigid_QMARK_,cljs.core.cst$kw$data_DASH_source,cljs.core.cst$kw$c_DASH_search,cljs.core.cst$kw$change_DASH_on_DASH_blur_QMARK_,cljs.core.cst$kw$suggestions,cljs.core.cst$kw$c_DASH_input,cljs.core.cst$kw$on_DASH_change,cljs.core.cst$kw$external_DASH_model,cljs.core.cst$kw$model],[false,(function (){var or__6939__auto__ = suggestion_to_string;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return cljs.core.str;
}
})(),false,"",rigid_QMARK_,data_source,(re_com.typeahead.debounce.cljs$core$IFn$_invoke$arity$2 ? re_com.typeahead.debounce.cljs$core$IFn$_invoke$arity$2(c_input,debounce_delay) : re_com.typeahead.debounce.call(null,c_input,debounce_delay)),change_on_blur_QMARK_,cljs.core.PersistentVector.EMPTY,c_input,on_change,re_com.util.deref_or_value(model),re_com.util.deref_or_value(model)]);
})();
if(cljs.core.truth_(external_model_value)){
return (re_com.typeahead.display_suggestion.cljs$core$IFn$_invoke$arity$2 ? re_com.typeahead.display_suggestion.cljs$core$IFn$_invoke$arity$2(G__34727,external_model_value) : re_com.typeahead.display_suggestion.call(null,G__34727,external_model_value));
} else {
return G__34727;
}
});
/**
 * Should `event` update the `typeahead` `model`?
 */
re_com.typeahead.event_updates_model_QMARK_ = (function re_com$typeahead$event_updates_model_QMARK_(p__34728,event){
var map__34732 = p__34728;
var map__34732__$1 = ((((!((map__34732 == null)))?((((map__34732.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34732.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34732):map__34732);
var state = map__34732__$1;
var change_on_blur_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34732__$1,cljs.core.cst$kw$change_DASH_on_DASH_blur_QMARK_);
var rigid_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34732__$1,cljs.core.cst$kw$rigid_QMARK_);
var change_on_blur_QMARK___$1 = re_com.util.deref_or_value(change_on_blur_QMARK_);
var rigid_QMARK___$1 = re_com.util.deref_or_value(rigid_QMARK_);
var G__34734 = (((event instanceof cljs.core.Keyword))?event.fqn:null);
switch (G__34734) {
case "input-text-blurred":
var and__6927__auto__ = change_on_blur_QMARK___$1;
if(cljs.core.truth_(and__6927__auto__)){
return cljs.core.not(rigid_QMARK___$1);
} else {
return and__6927__auto__;
}

break;
case "suggestion-activated":
return cljs.core.not(change_on_blur_QMARK___$1);

break;
case "input-text-changed":
return cljs.core.not((function (){var or__6939__auto__ = change_on_blur_QMARK___$1;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return rigid_QMARK___$1;
}
})());

break;
default:
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(event)].join('')));

}
});
/**
 * Should `event` cause the `input-text` value to be used to show the active suggestion?
 */
re_com.typeahead.event_displays_suggestion_QMARK_ = (function re_com$typeahead$event_displays_suggestion_QMARK_(p__34736,event){
var map__34740 = p__34736;
var map__34740__$1 = ((((!((map__34740 == null)))?((((map__34740.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34740.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34740):map__34740);
var state = map__34740__$1;
var change_on_blur_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34740__$1,cljs.core.cst$kw$change_DASH_on_DASH_blur_QMARK_);
var change_on_blur_QMARK___$1 = re_com.util.deref_or_value(change_on_blur_QMARK_);
var G__34742 = (((event instanceof cljs.core.Keyword))?event.fqn:null);
switch (G__34742) {
case "suggestion-activated":
return cljs.core.not(change_on_blur_QMARK___$1);

break;
default:
return false;

}
});
/**
 * Change the `typeahead` `model` value to `new-value`
 */
re_com.typeahead.update_model = (function re_com$typeahead$update_model(p__34744,new_value){
var map__34747 = p__34744;
var map__34747__$1 = ((((!((map__34747 == null)))?((((map__34747.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34747.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34747):map__34747);
var state = map__34747__$1;
var on_change = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34747__$1,cljs.core.cst$kw$on_DASH_change);
if(cljs.core.truth_(on_change)){
(on_change.cljs$core$IFn$_invoke$arity$1 ? on_change.cljs$core$IFn$_invoke$arity$1(new_value) : on_change.call(null,new_value));
} else {
}

return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(state,cljs.core.cst$kw$model,new_value);
});
/**
 * Change the `input-text` `model` to the string representation of `suggestion`
 */
re_com.typeahead.display_suggestion = (function re_com$typeahead$display_suggestion(p__34749,suggestion){
var map__34753 = p__34749;
var map__34753__$1 = ((((!((map__34753 == null)))?((((map__34753.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34753.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34753):map__34753);
var state = map__34753__$1;
var suggestion_to_string = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34753__$1,cljs.core.cst$kw$suggestion_DASH_to_DASH_string);
var suggestion_string = (suggestion_to_string.cljs$core$IFn$_invoke$arity$1 ? suggestion_to_string.cljs$core$IFn$_invoke$arity$1(suggestion) : suggestion_to_string.call(null,suggestion));
var G__34755 = state;
if(cljs.core.truth_(suggestion_string)){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$variadic(G__34755,cljs.core.cst$kw$input_DASH_text,suggestion_string,cljs.core.array_seq([cljs.core.cst$kw$displaying_DASH_suggestion_QMARK_,true], 0));
} else {
return G__34755;
}
});
re_com.typeahead.clear_suggestions = (function re_com$typeahead$clear_suggestions(state){
return cljs.core.dissoc.cljs$core$IFn$_invoke$arity$variadic(state,cljs.core.cst$kw$suggestions,cljs.core.array_seq([cljs.core.cst$kw$suggestion_DASH_active_DASH_index], 0));
});
/**
 * Make the suggestion at `index` the active suggestion
 */
re_com.typeahead.activate_suggestion_by_index = (function re_com$typeahead$activate_suggestion_by_index(p__34756,index){
var map__34760 = p__34756;
var map__34760__$1 = ((((!((map__34760 == null)))?((((map__34760.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34760.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34760):map__34760);
var state = map__34760__$1;
var suggestions = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34760__$1,cljs.core.cst$kw$suggestions);
var suggestion = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(suggestions,index);
var G__34762 = state;
var G__34762__$1 = cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__34762,cljs.core.cst$kw$suggestion_DASH_active_DASH_index,index)
;
var G__34762__$2 = (cljs.core.truth_(re_com.typeahead.event_updates_model_QMARK_(state,cljs.core.cst$kw$suggestion_DASH_activated))?re_com.typeahead.update_model(G__34762__$1,suggestion):G__34762__$1);
if(cljs.core.truth_(re_com.typeahead.event_displays_suggestion_QMARK_(state,cljs.core.cst$kw$suggestion_DASH_activated))){
return re_com.typeahead.display_suggestion(G__34762__$2,suggestion);
} else {
return G__34762__$2;
}
});
/**
 * Choose the suggestion at `index`
 */
re_com.typeahead.choose_suggestion_by_index = (function re_com$typeahead$choose_suggestion_by_index(p__34763,index){
var map__34766 = p__34763;
var map__34766__$1 = ((((!((map__34766 == null)))?((((map__34766.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34766.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34766):map__34766);
var state = map__34766__$1;
var suggestions = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34766__$1,cljs.core.cst$kw$suggestions);
var suggestion = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(suggestions,index);
return re_com.typeahead.clear_suggestions(re_com.typeahead.display_suggestion(re_com.typeahead.update_model(re_com.typeahead.activate_suggestion_by_index(state,index),suggestion),suggestion));
});
re_com.typeahead.choose_suggestion_active = (function re_com$typeahead$choose_suggestion_active(p__34768){
var map__34772 = p__34768;
var map__34772__$1 = ((((!((map__34772 == null)))?((((map__34772.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34772.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34772):map__34772);
var state = map__34772__$1;
var suggestion_active_index = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34772__$1,cljs.core.cst$kw$suggestion_DASH_active_DASH_index);
var G__34774 = state;
if(cljs.core.truth_(suggestion_active_index)){
return re_com.typeahead.choose_suggestion_by_index(G__34774,suggestion_active_index);
} else {
return G__34774;
}
});
re_com.typeahead.wrap = (function re_com$typeahead$wrap(index,count){
return cljs.core.mod((count + index),count);
});
re_com.typeahead.activate_suggestion_next = (function re_com$typeahead$activate_suggestion_next(p__34775){
var map__34779 = p__34775;
var map__34779__$1 = ((((!((map__34779 == null)))?((((map__34779.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34779.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34779):map__34779);
var state = map__34779__$1;
var suggestions = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34779__$1,cljs.core.cst$kw$suggestions);
var suggestion_active_index = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34779__$1,cljs.core.cst$kw$suggestion_DASH_active_DASH_index);
var G__34781 = state;
if(cljs.core.truth_(suggestions)){
return re_com.typeahead.activate_suggestion_by_index(G__34781,re_com.typeahead.wrap(((function (){var or__6939__auto__ = suggestion_active_index;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return (-1);
}
})() + (1)),cljs.core.count(suggestions)));
} else {
return G__34781;
}
});
re_com.typeahead.activate_suggestion_prev = (function re_com$typeahead$activate_suggestion_prev(p__34782){
var map__34786 = p__34782;
var map__34786__$1 = ((((!((map__34786 == null)))?((((map__34786.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34786.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34786):map__34786);
var state = map__34786__$1;
var suggestions = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34786__$1,cljs.core.cst$kw$suggestions);
var suggestion_active_index = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34786__$1,cljs.core.cst$kw$suggestion_DASH_active_DASH_index);
var G__34788 = state;
if(cljs.core.truth_(suggestions)){
return re_com.typeahead.activate_suggestion_by_index(G__34788,re_com.typeahead.wrap(((function (){var or__6939__auto__ = suggestion_active_index;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return (0);
}
})() - (1)),cljs.core.count(suggestions)));
} else {
return G__34788;
}
});
re_com.typeahead.reset_typeahead = (function re_com$typeahead$reset_typeahead(state){
var G__34790 = state;
var G__34790__$1 = re_com.typeahead.clear_suggestions(G__34790)
;
var G__34790__$2 = cljs.core.assoc.cljs$core$IFn$_invoke$arity$variadic(G__34790__$1,cljs.core.cst$kw$waiting_QMARK_,false,cljs.core.array_seq([cljs.core.cst$kw$input_DASH_text,"",cljs.core.cst$kw$displaying_DASH_suggestion_QMARK_,false], 0))
;
if(cljs.core.truth_(re_com.typeahead.event_updates_model_QMARK_(state,cljs.core.cst$kw$input_DASH_text_DASH_changed))){
return re_com.typeahead.update_model(G__34790__$2,null);
} else {
return G__34790__$2;
}
});
/**
 * Update state when new suggestions are available
 */
re_com.typeahead.got_suggestions = (function re_com$typeahead$got_suggestions(state,suggestions){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$variadic(state,cljs.core.cst$kw$suggestions,suggestions,cljs.core.array_seq([cljs.core.cst$kw$waiting_QMARK_,false,cljs.core.cst$kw$suggestion_DASH_active_DASH_index,null], 0));
});
/**
 * Update state when the `input-text` is about to lose focus.
 */
re_com.typeahead.input_text_will_blur = (function re_com$typeahead$input_text_will_blur(p__34791){
var map__34795 = p__34791;
var map__34795__$1 = ((((!((map__34795 == null)))?((((map__34795.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34795.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34795):map__34795);
var state = map__34795__$1;
var input_text = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34795__$1,cljs.core.cst$kw$input_DASH_text);
var displaying_suggestion_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34795__$1,cljs.core.cst$kw$displaying_DASH_suggestion_QMARK_);
var G__34797 = state;
if(cljs.core.truth_((function (){var and__6927__auto__ = cljs.core.not(displaying_suggestion_QMARK_);
if(and__6927__auto__){
return re_com.typeahead.event_updates_model_QMARK_(state,cljs.core.cst$kw$input_DASH_text_DASH_blurred);
} else {
return and__6927__auto__;
}
})())){
return re_com.typeahead.update_model(G__34797,input_text);
} else {
return G__34797;
}
});
/**
 * Update `state` given a new `data-source`. Resets the typeahead since any existing suggestions
 *   came from the old `data-source`.
 */
re_com.typeahead.change_data_source = (function re_com$typeahead$change_data_source(state,data_source){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(re_com.typeahead.reset_typeahead(state),cljs.core.cst$kw$data_DASH_source,data_source);
});
/**
 * Update state when the external model value has changed.
 */
re_com.typeahead.external_model_changed = (function re_com$typeahead$external_model_changed(state,new_value){
return re_com.typeahead.clear_suggestions(re_com.typeahead.display_suggestion(re_com.typeahead.update_model(state,new_value),new_value));
});
/**
 * Call the `data-source` fn with `text`, and then call `got-suggestions` with the result
 *   (asynchronously, if `data-source` does not return a truthy value).
 */
re_com.typeahead.search_data_source_BANG_ = (function re_com$typeahead$search_data_source_BANG_(data_source,state_atom,text){
var temp__6726__auto__ = (function (){var G__34801 = text;
var G__34802 = ((function (G__34801){
return (function (p1__34798_SHARP_){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(state_atom,re_com.typeahead.got_suggestions,p1__34798_SHARP_);
});})(G__34801))
;
return (data_source.cljs$core$IFn$_invoke$arity$2 ? data_source.cljs$core$IFn$_invoke$arity$2(G__34801,G__34802) : data_source.call(null,G__34801,G__34802));
})();
if(cljs.core.truth_(temp__6726__auto__)){
var return_value = temp__6726__auto__;
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(state_atom,re_com.typeahead.got_suggestions,return_value);
} else {
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(state_atom,cljs.core.assoc,cljs.core.cst$kw$waiting_QMARK_,true);
}
});
/**
 * For every value arriving on the `c-search` channel, call `search-data-source!`.
 */
re_com.typeahead.search_data_source_loop_BANG_ = (function re_com$typeahead$search_data_source_loop_BANG_(state_atom,c_search){
var c__15224__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto__){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto__){
return (function (state_34852){
var state_val_34853 = (state_34852[(1)]);
if((state_val_34853 === (1))){
var state_34852__$1 = state_34852;
var statearr_34854_34869 = state_34852__$1;
(statearr_34854_34869[(2)] = null);

(statearr_34854_34869[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_34853 === (2))){
var state_34852__$1 = state_34852;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_34852__$1,(4),c_search);
} else {
if((state_val_34853 === (3))){
var inst_34850 = (state_34852[(2)]);
var state_34852__$1 = state_34852;
return cljs.core.async.impl.ioc_helpers.return_chan(state_34852__$1,inst_34850);
} else {
if((state_val_34853 === (4))){
var inst_34838 = (state_34852[(7)]);
var inst_34838__$1 = (state_34852[(2)]);
var inst_34839 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(state_atom) : cljs.core.deref.call(null,state_atom));
var inst_34840 = cljs.core.cst$kw$data_DASH_source.cljs$core$IFn$_invoke$arity$1(inst_34839);
var inst_34841 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("",inst_34838__$1);
var state_34852__$1 = (function (){var statearr_34855 = state_34852;
(statearr_34855[(8)] = inst_34840);

(statearr_34855[(7)] = inst_34838__$1);

return statearr_34855;
})();
if(inst_34841){
var statearr_34856_34870 = state_34852__$1;
(statearr_34856_34870[(1)] = (5));

} else {
var statearr_34857_34871 = state_34852__$1;
(statearr_34857_34871[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_34853 === (5))){
var inst_34843 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(state_atom,re_com.typeahead.reset_typeahead);
var state_34852__$1 = state_34852;
var statearr_34858_34872 = state_34852__$1;
(statearr_34858_34872[(2)] = inst_34843);

(statearr_34858_34872[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_34853 === (6))){
var inst_34840 = (state_34852[(8)]);
var inst_34838 = (state_34852[(7)]);
var inst_34845 = re_com.typeahead.search_data_source_BANG_(inst_34840,state_atom,inst_34838);
var state_34852__$1 = state_34852;
var statearr_34859_34873 = state_34852__$1;
(statearr_34859_34873[(2)] = inst_34845);

(statearr_34859_34873[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_34853 === (7))){
var inst_34847 = (state_34852[(2)]);
var state_34852__$1 = (function (){var statearr_34860 = state_34852;
(statearr_34860[(9)] = inst_34847);

return statearr_34860;
})();
var statearr_34861_34874 = state_34852__$1;
(statearr_34861_34874[(2)] = null);

(statearr_34861_34874[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__15224__auto__))
;
return ((function (switch__15098__auto__,c__15224__auto__){
return (function() {
var re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto__ = null;
var re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto____0 = (function (){
var statearr_34865 = [null,null,null,null,null,null,null,null,null,null];
(statearr_34865[(0)] = re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto__);

(statearr_34865[(1)] = (1));

return statearr_34865;
});
var re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto____1 = (function (state_34852){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_34852);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e34866){if((e34866 instanceof Object)){
var ex__15102__auto__ = e34866;
var statearr_34867_34875 = state_34852;
(statearr_34867_34875[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_34852);

return cljs.core.cst$kw$recur;
} else {
throw e34866;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__34876 = state_34852;
state_34852 = G__34876;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto__ = function(state_34852){
switch(arguments.length){
case 0:
return re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto____0.call(this);
case 1:
return re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto____1.call(this,state_34852);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto____0;
re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto____1;
return re_com$typeahead$search_data_source_loop_BANG__$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto__))
})();
var state__15226__auto__ = (function (){var statearr_34868 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_34868[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto__);

return statearr_34868;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto__))
);

return c__15224__auto__;
});
/**
 * Update state in response to `input-text` `on-change`, and put text on the `c-input` channel
 */
re_com.typeahead.input_text_on_change_BANG_ = (function re_com$typeahead$input_text_on_change_BANG_(state_atom,new_text){
var map__34881 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(state_atom) : cljs.core.deref.call(null,state_atom));
var map__34881__$1 = ((((!((map__34881 == null)))?((((map__34881.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34881.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34881):map__34881);
var state = map__34881__$1;
var input_text = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34881__$1,cljs.core.cst$kw$input_DASH_text);
var c_input = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34881__$1,cljs.core.cst$kw$c_DASH_input);
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(new_text,input_text)){
return state;
} else {
if(clojure.string.blank_QMARK_(new_text)){
} else {
cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(c_input,new_text);
}

return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(state_atom,((function (map__34881,map__34881__$1,state,input_text,c_input){
return (function (p1__34877_SHARP_){
var G__34883 = p1__34877_SHARP_;
var G__34883__$1 = cljs.core.assoc.cljs$core$IFn$_invoke$arity$variadic(G__34883,cljs.core.cst$kw$input_DASH_text,new_text,cljs.core.array_seq([cljs.core.cst$kw$displaying_DASH_suggestion_QMARK_,false], 0))
;
if(cljs.core.truth_(re_com.typeahead.event_updates_model_QMARK_(state,cljs.core.cst$kw$input_DASH_text_DASH_changed))){
return re_com.typeahead.update_model(G__34883__$1,new_text);
} else {
return G__34883__$1;
}
});})(map__34881,map__34881__$1,state,input_text,c_input))
);
}
});
re_com.typeahead.input_text_on_key_down_BANG_ = (function re_com$typeahead$input_text_on_key_down_BANG_(state_atom,event){
var pred__34887 = cljs.core._EQ_;
var expr__34888 = event.which;
if(cljs.core.truth_((pred__34887.cljs$core$IFn$_invoke$arity$2 ? pred__34887.cljs$core$IFn$_invoke$arity$2(goog.events.KeyCodes.UP,expr__34888) : pred__34887.call(null,goog.events.KeyCodes.UP,expr__34888)))){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(state_atom,re_com.typeahead.activate_suggestion_prev);
} else {
if(cljs.core.truth_((pred__34887.cljs$core$IFn$_invoke$arity$2 ? pred__34887.cljs$core$IFn$_invoke$arity$2(goog.events.KeyCodes.DOWN,expr__34888) : pred__34887.call(null,goog.events.KeyCodes.DOWN,expr__34888)))){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(state_atom,re_com.typeahead.activate_suggestion_next);
} else {
if(cljs.core.truth_((pred__34887.cljs$core$IFn$_invoke$arity$2 ? pred__34887.cljs$core$IFn$_invoke$arity$2(goog.events.KeyCodes.ENTER,expr__34888) : pred__34887.call(null,goog.events.KeyCodes.ENTER,expr__34888)))){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(state_atom,re_com.typeahead.choose_suggestion_active);
} else {
if(cljs.core.truth_((pred__34887.cljs$core$IFn$_invoke$arity$2 ? pred__34887.cljs$core$IFn$_invoke$arity$2(goog.events.KeyCodes.ESC,expr__34888) : pred__34887.call(null,goog.events.KeyCodes.ESC,expr__34888)))){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(state_atom,re_com.typeahead.reset_typeahead);
} else {
if(cljs.core.truth_((pred__34887.cljs$core$IFn$_invoke$arity$2 ? pred__34887.cljs$core$IFn$_invoke$arity$2(goog.events.KeyCodes.TAB,expr__34888) : pred__34887.call(null,goog.events.KeyCodes.TAB,expr__34888)))){
if(cljs.core.truth_(cljs.core.not_empty(cljs.core.cst$kw$suggestions.cljs$core$IFn$_invoke$arity$1((cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(state_atom) : cljs.core.deref.call(null,state_atom)))))){
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(state_atom,re_com.typeahead.activate_suggestion_next);

return event.preventDefault();
} else {
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(state_atom,re_com.typeahead.input_text_will_blur);
}
} else {
return true;
}
}
}
}
}
});
/**
 * typeahead reagent component
 */
re_com.typeahead.typeahead = (function re_com$typeahead$typeahead(var_args){
var args__8125__auto__ = [];
var len__8118__auto___34920 = arguments.length;
var i__8119__auto___34921 = (0);
while(true){
if((i__8119__auto___34921 < len__8118__auto___34920)){
args__8125__auto__.push((arguments[i__8119__auto___34921]));

var G__34922 = (i__8119__auto___34921 + (1));
i__8119__auto___34921 = G__34922;
continue;
} else {
}
break;
}

var argseq__8126__auto__ = ((((0) < args__8125__auto__.length))?(new cljs.core.IndexedSeq(args__8125__auto__.slice((0)),(0),null)):null);
return re_com.typeahead.typeahead.cljs$core$IFn$_invoke$arity$variadic(argseq__8126__auto__);
});

re_com.typeahead.typeahead.cljs$core$IFn$_invoke$arity$variadic = (function (p__34892){
var map__34893 = p__34892;
var map__34893__$1 = ((((!((map__34893 == null)))?((((map__34893.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34893.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34893):map__34893);
var args = map__34893__$1;
var data_source = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34893__$1,cljs.core.cst$kw$data_DASH_source);
var on_change = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34893__$1,cljs.core.cst$kw$on_DASH_change);
var rigid_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34893__$1,cljs.core.cst$kw$rigid_QMARK_);
var change_on_blur_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34893__$1,cljs.core.cst$kw$change_DASH_on_DASH_blur_QMARK_);

var map__34895 = re_com.typeahead.make_typeahead_state(args);
var map__34895__$1 = ((((!((map__34895 == null)))?((((map__34895.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34895.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34895):map__34895);
var state = map__34895__$1;
var c_search = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34895__$1,cljs.core.cst$kw$c_DASH_search);
var c_input = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34895__$1,cljs.core.cst$kw$c_DASH_input);
var state_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(state);
var input_text_model = reagent.core.cursor(state_atom,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$input_DASH_text], null));
re_com.typeahead.search_data_source_loop_BANG_(state_atom,c_search);

return ((function (map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_){
return (function() { 
var G__34923__delegate = function (p__34897){
var map__34898 = p__34897;
var map__34898__$1 = ((((!((map__34898 == null)))?((((map__34898.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34898.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34898):map__34898);
var args__$1 = map__34898__$1;
var disabled_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$disabled_QMARK_);
var status_icon_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$status_DASH_icon_QMARK_);
var height = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$height);
var status_tooltip = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$status_DASH_tooltip);
var model = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$model);
var suggestion_to_string = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$suggestion_DASH_to_DASH_string);
var placeholder = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$placeholder);
var render_suggestion = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$render_DASH_suggestion);
var rigid_QMARK___$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$rigid_QMARK_);
var width = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$width);
var data_source__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$data_DASH_source);
var style = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$style);
var status = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$status);
var class$ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34898__$1,cljs.core.cst$kw$class);

var map__34900 = (cljs.core.deref.cljs$core$IFn$_invoke$arity$1 ? cljs.core.deref.cljs$core$IFn$_invoke$arity$1(state_atom) : cljs.core.deref.call(null,state_atom));
var map__34900__$1 = ((((!((map__34900 == null)))?((((map__34900.cljs$lang$protocol_mask$partition0$ & (64))) || (map__34900.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__34900):map__34900);
var state__$1 = map__34900__$1;
var suggestions = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34900__$1,cljs.core.cst$kw$suggestions);
var waiting_QMARK_ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34900__$1,cljs.core.cst$kw$waiting_QMARK_);
var suggestion_active_index = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34900__$1,cljs.core.cst$kw$suggestion_DASH_active_DASH_index);
var external_model = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34900__$1,cljs.core.cst$kw$external_DASH_model);
var last_data_source = cljs.core.cst$kw$data_DASH_source.cljs$core$IFn$_invoke$arity$1(state__$1);
var latest_external_model = re_com.util.deref_or_value(model);
var width__$1 = (function (){var or__6939__auto__ = width;
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return "250px";
}
})();
if(cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(last_data_source,data_source__$1)){
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(state_atom,re_com.typeahead.change_data_source,data_source__$1);
} else {
}

if(cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(latest_external_model,external_model)){
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(state_atom,re_com.typeahead.external_model_changed,latest_external_model);
} else {
}

return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.box.v_box,cljs.core.cst$kw$width,width__$1,cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 27, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.misc.input_text,cljs.core.cst$kw$model,input_text_model,cljs.core.cst$kw$class,class$,cljs.core.cst$kw$style,style,cljs.core.cst$kw$disabled_QMARK_,disabled_QMARK_,cljs.core.cst$kw$status_DASH_icon_QMARK_,status_icon_QMARK_,cljs.core.cst$kw$status,status,cljs.core.cst$kw$status_DASH_tooltip,status_tooltip,cljs.core.cst$kw$width,width__$1,cljs.core.cst$kw$height,height,cljs.core.cst$kw$placeholder,placeholder,cljs.core.cst$kw$on_DASH_change,cljs.core.partial.cljs$core$IFn$_invoke$arity$2(re_com.typeahead.input_text_on_change_BANG_,state_atom),cljs.core.cst$kw$change_DASH_on_DASH_blur_QMARK_,false,cljs.core.cst$kw$attr,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$on_DASH_key_DASH_down,cljs.core.partial.cljs$core$IFn$_invoke$arity$2(re_com.typeahead.input_text_on_key_down_BANG_,state_atom)], null)], null),(cljs.core.truth_((function (){var or__6939__auto__ = cljs.core.not_empty(suggestions);
if(cljs.core.truth_(or__6939__auto__)){
return or__6939__auto__;
} else {
return waiting_QMARK_;
}
})())?new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.box.v_box,cljs.core.cst$kw$class,"rc-typeahead-suggestions-container",cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(cljs.core.truth_(waiting_QMARK_)?new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.box.box,cljs.core.cst$kw$align,cljs.core.cst$kw$center,cljs.core.cst$kw$child,new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.misc.throbber,cljs.core.cst$kw$size,cljs.core.cst$kw$small,cljs.core.cst$kw$class,"rc-typeahead-throbber"], null)], null):null),(function (){var iter__7793__auto__ = ((function (map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_){
return (function re_com$typeahead$iter__34902(s__34903){
return (new cljs.core.LazySeq(null,((function (map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_){
return (function (){
var s__34903__$1 = s__34903;
while(true){
var temp__6728__auto__ = cljs.core.seq(s__34903__$1);
if(temp__6728__auto__){
var s__34903__$2 = temp__6728__auto__;
if(cljs.core.chunked_seq_QMARK_(s__34903__$2)){
var c__7791__auto__ = cljs.core.chunk_first(s__34903__$2);
var size__7792__auto__ = cljs.core.count(c__7791__auto__);
var b__34905 = cljs.core.chunk_buffer(size__7792__auto__);
if((function (){var i__34904 = (0);
while(true){
if((i__34904 < size__7792__auto__)){
var vec__34914 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(c__7791__auto__,i__34904);
var i = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__34914,(0),null);
var s = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__34914,(1),null);
var selected_QMARK_ = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(suggestion_active_index,i);
cljs.core.chunk_append(b__34905,cljs.core.with_meta(new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.box.box,cljs.core.cst$kw$child,(cljs.core.truth_(render_suggestion)?(render_suggestion.cljs$core$IFn$_invoke$arity$1 ? render_suggestion.cljs$core$IFn$_invoke$arity$1(s) : render_suggestion.call(null,s)):s),cljs.core.cst$kw$class,[cljs.core.str("rc-typeahead-suggestion"),cljs.core.str(((selected_QMARK_)?" active":null))].join(''),cljs.core.cst$kw$attr,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$on_DASH_mouse_DASH_over,((function (i__34904,selected_QMARK_,vec__34914,i,s,c__7791__auto__,size__7792__auto__,b__34905,s__34903__$2,temp__6728__auto__,map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_){
return (function (){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(state_atom,re_com.typeahead.activate_suggestion_by_index,i);
});})(i__34904,selected_QMARK_,vec__34914,i,s,c__7791__auto__,size__7792__auto__,b__34905,s__34903__$2,temp__6728__auto__,map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_))
,cljs.core.cst$kw$on_DASH_mouse_DASH_down,((function (i__34904,selected_QMARK_,vec__34914,i,s,c__7791__auto__,size__7792__auto__,b__34905,s__34903__$2,temp__6728__auto__,map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_){
return (function (p1__34890_SHARP_){
p1__34890_SHARP_.preventDefault();

return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(state_atom,re_com.typeahead.choose_suggestion_by_index,i);
});})(i__34904,selected_QMARK_,vec__34914,i,s,c__7791__auto__,size__7792__auto__,b__34905,s__34903__$2,temp__6728__auto__,map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_))
], null)], null),new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$key,i], null)));

var G__34924 = (i__34904 + (1));
i__34904 = G__34924;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__34905),re_com$typeahead$iter__34902(cljs.core.chunk_rest(s__34903__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__34905),null);
}
} else {
var vec__34917 = cljs.core.first(s__34903__$2);
var i = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__34917,(0),null);
var s = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__34917,(1),null);
var selected_QMARK_ = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(suggestion_active_index,i);
return cljs.core.cons(cljs.core.with_meta(new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.box.box,cljs.core.cst$kw$child,(cljs.core.truth_(render_suggestion)?(render_suggestion.cljs$core$IFn$_invoke$arity$1 ? render_suggestion.cljs$core$IFn$_invoke$arity$1(s) : render_suggestion.call(null,s)):s),cljs.core.cst$kw$class,[cljs.core.str("rc-typeahead-suggestion"),cljs.core.str(((selected_QMARK_)?" active":null))].join(''),cljs.core.cst$kw$attr,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$on_DASH_mouse_DASH_over,((function (selected_QMARK_,vec__34917,i,s,s__34903__$2,temp__6728__auto__,map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_){
return (function (){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(state_atom,re_com.typeahead.activate_suggestion_by_index,i);
});})(selected_QMARK_,vec__34917,i,s,s__34903__$2,temp__6728__auto__,map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_))
,cljs.core.cst$kw$on_DASH_mouse_DASH_down,((function (selected_QMARK_,vec__34917,i,s,s__34903__$2,temp__6728__auto__,map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_){
return (function (p1__34890_SHARP_){
p1__34890_SHARP_.preventDefault();

return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(state_atom,re_com.typeahead.choose_suggestion_by_index,i);
});})(selected_QMARK_,vec__34917,i,s,s__34903__$2,temp__6728__auto__,map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_))
], null)], null),new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$key,i], null)),re_com$typeahead$iter__34902(cljs.core.rest(s__34903__$2)));
}
} else {
return null;
}
break;
}
});})(map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_))
,null,null));
});})(map__34900,map__34900__$1,state__$1,suggestions,waiting_QMARK_,suggestion_active_index,external_model,last_data_source,latest_external_model,width__$1,map__34898,map__34898__$1,args__$1,disabled_QMARK_,status_icon_QMARK_,height,status_tooltip,model,suggestion_to_string,placeholder,render_suggestion,rigid_QMARK___$1,width,data_source__$1,style,status,class$,map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_))
;
return iter__7793__auto__(cljs.core.map.cljs$core$IFn$_invoke$arity$3(cljs.core.vector,cljs.core.range.cljs$core$IFn$_invoke$arity$0(),suggestions));
})()], null)], null):null)], null)], null);
};
var G__34923 = function (var_args){
var p__34897 = null;
if (arguments.length > 0) {
var G__34925__i = 0, G__34925__a = new Array(arguments.length -  0);
while (G__34925__i < G__34925__a.length) {G__34925__a[G__34925__i] = arguments[G__34925__i + 0]; ++G__34925__i;}
  p__34897 = new cljs.core.IndexedSeq(G__34925__a,0);
} 
return G__34923__delegate.call(this,p__34897);};
G__34923.cljs$lang$maxFixedArity = 0;
G__34923.cljs$lang$applyTo = (function (arglist__34926){
var p__34897 = cljs.core.seq(arglist__34926);
return G__34923__delegate(p__34897);
});
G__34923.cljs$core$IFn$_invoke$arity$variadic = G__34923__delegate;
return G__34923;
})()
;
;})(map__34895,map__34895__$1,state,c_search,c_input,state_atom,input_text_model,map__34893,map__34893__$1,args,data_source,on_change,rigid_QMARK_,change_on_blur_QMARK_))
});

re_com.typeahead.typeahead.cljs$lang$maxFixedArity = (0);

re_com.typeahead.typeahead.cljs$lang$applyTo = (function (seq34891){
return re_com.typeahead.typeahead.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq34891));
});

/**
 * Return a channel which will receive a value from the `in` channel only
 *   if no further value is received on the `in` channel in the next `ms` milliseconds.
 */
re_com.typeahead.debounce = (function re_com$typeahead$debounce(in$,ms){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__15224__auto___35093 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__15224__auto___35093,out){
return (function (){
var f__15225__auto__ = (function (){var switch__15098__auto__ = ((function (c__15224__auto___35093,out){
return (function (state_35060){
var state_val_35061 = (state_35060[(1)]);
if((state_val_35061 === (7))){
var inst_35015 = (state_35060[(2)]);
var state_35060__$1 = state_35060;
var statearr_35062_35094 = state_35060__$1;
(statearr_35062_35094[(2)] = inst_35015);

(statearr_35062_35094[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (1))){
var inst_35010 = null;
var state_35060__$1 = (function (){var statearr_35063 = state_35060;
(statearr_35063[(7)] = inst_35010);

return statearr_35063;
})();
var statearr_35064_35095 = state_35060__$1;
(statearr_35064_35095[(2)] = null);

(statearr_35064_35095[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (4))){
var state_35060__$1 = state_35060;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_35060__$1,(7),in$);
} else {
if((state_val_35061 === (15))){
var inst_35045 = (state_35060[(2)]);
var state_35060__$1 = (function (){var statearr_35065 = state_35060;
(statearr_35065[(8)] = inst_35045);

return statearr_35065;
})();
var statearr_35066_35096 = state_35060__$1;
(statearr_35066_35096[(2)] = null);

(statearr_35066_35096[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (13))){
var inst_35033 = (state_35060[(9)]);
var inst_35047 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_35033,cljs.core.cst$kw$default);
var state_35060__$1 = state_35060;
if(inst_35047){
var statearr_35067_35097 = state_35060__$1;
(statearr_35067_35097[(1)] = (16));

} else {
var statearr_35068_35098 = state_35060__$1;
(statearr_35068_35098[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (6))){
var inst_35019 = (state_35060[(10)]);
var inst_35018 = (state_35060[(2)]);
var inst_35019__$1 = cljs.core.async.timeout(ms);
var inst_35027 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_35028 = [in$,inst_35019__$1];
var inst_35029 = (new cljs.core.PersistentVector(null,2,(5),inst_35027,inst_35028,null));
var state_35060__$1 = (function (){var statearr_35069 = state_35060;
(statearr_35069[(11)] = inst_35018);

(statearr_35069[(10)] = inst_35019__$1);

return statearr_35069;
})();
return cljs.core.async.ioc_alts_BANG_(state_35060__$1,(8),inst_35029);
} else {
if((state_val_35061 === (17))){
var state_35060__$1 = state_35060;
var statearr_35070_35099 = state_35060__$1;
(statearr_35070_35099[(2)] = null);

(statearr_35070_35099[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (3))){
var inst_35058 = (state_35060[(2)]);
var state_35060__$1 = state_35060;
return cljs.core.async.impl.ioc_helpers.return_chan(state_35060__$1,inst_35058);
} else {
if((state_val_35061 === (12))){
var inst_35018 = (state_35060[(11)]);
var state_35060__$1 = state_35060;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_35060__$1,(15),out,inst_35018);
} else {
if((state_val_35061 === (2))){
var inst_35010 = (state_35060[(7)]);
var inst_35012 = (inst_35010 == null);
var state_35060__$1 = state_35060;
if(cljs.core.truth_(inst_35012)){
var statearr_35071_35100 = state_35060__$1;
(statearr_35071_35100[(1)] = (4));

} else {
var statearr_35072_35101 = state_35060__$1;
(statearr_35072_35101[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (11))){
var inst_35055 = (state_35060[(2)]);
var inst_35010 = inst_35055;
var state_35060__$1 = (function (){var statearr_35073 = state_35060;
(statearr_35073[(7)] = inst_35010);

return statearr_35073;
})();
var statearr_35074_35102 = state_35060__$1;
(statearr_35074_35102[(2)] = null);

(statearr_35074_35102[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (9))){
var inst_35031 = (state_35060[(12)]);
var inst_35039 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_35031,(0),null);
var inst_35040 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_35031,(1),null);
var state_35060__$1 = (function (){var statearr_35075 = state_35060;
(statearr_35075[(13)] = inst_35040);

return statearr_35075;
})();
var statearr_35076_35103 = state_35060__$1;
(statearr_35076_35103[(2)] = inst_35039);

(statearr_35076_35103[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (5))){
var inst_35010 = (state_35060[(7)]);
var state_35060__$1 = state_35060;
var statearr_35077_35104 = state_35060__$1;
(statearr_35077_35104[(2)] = inst_35010);

(statearr_35077_35104[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (14))){
var inst_35053 = (state_35060[(2)]);
var state_35060__$1 = state_35060;
var statearr_35078_35105 = state_35060__$1;
(statearr_35078_35105[(2)] = inst_35053);

(statearr_35078_35105[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (16))){
var inst_35032 = (state_35060[(14)]);
var state_35060__$1 = state_35060;
var statearr_35079_35106 = state_35060__$1;
(statearr_35079_35106[(2)] = inst_35032);

(statearr_35079_35106[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (10))){
var inst_35033 = (state_35060[(9)]);
var inst_35019 = (state_35060[(10)]);
var inst_35042 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_35033,inst_35019);
var state_35060__$1 = state_35060;
if(inst_35042){
var statearr_35080_35107 = state_35060__$1;
(statearr_35080_35107[(1)] = (12));

} else {
var statearr_35081_35108 = state_35060__$1;
(statearr_35081_35108[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (18))){
var inst_35051 = (state_35060[(2)]);
var state_35060__$1 = state_35060;
var statearr_35082_35109 = state_35060__$1;
(statearr_35082_35109[(2)] = inst_35051);

(statearr_35082_35109[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_35061 === (8))){
var inst_35033 = (state_35060[(9)]);
var inst_35031 = (state_35060[(12)]);
var inst_35031__$1 = (state_35060[(2)]);
var inst_35032 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_35031__$1,(0),null);
var inst_35033__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_35031__$1,(1),null);
var inst_35034 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_35033__$1,in$);
var state_35060__$1 = (function (){var statearr_35083 = state_35060;
(statearr_35083[(9)] = inst_35033__$1);

(statearr_35083[(14)] = inst_35032);

(statearr_35083[(12)] = inst_35031__$1);

return statearr_35083;
})();
if(inst_35034){
var statearr_35084_35110 = state_35060__$1;
(statearr_35084_35110[(1)] = (9));

} else {
var statearr_35085_35111 = state_35060__$1;
(statearr_35085_35111[(1)] = (10));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__15224__auto___35093,out))
;
return ((function (switch__15098__auto__,c__15224__auto___35093,out){
return (function() {
var re_com$typeahead$debounce_$_state_machine__15099__auto__ = null;
var re_com$typeahead$debounce_$_state_machine__15099__auto____0 = (function (){
var statearr_35089 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_35089[(0)] = re_com$typeahead$debounce_$_state_machine__15099__auto__);

(statearr_35089[(1)] = (1));

return statearr_35089;
});
var re_com$typeahead$debounce_$_state_machine__15099__auto____1 = (function (state_35060){
while(true){
var ret_value__15100__auto__ = (function (){try{while(true){
var result__15101__auto__ = switch__15098__auto__(state_35060);
if(cljs.core.keyword_identical_QMARK_(result__15101__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__15101__auto__;
}
break;
}
}catch (e35090){if((e35090 instanceof Object)){
var ex__15102__auto__ = e35090;
var statearr_35091_35112 = state_35060;
(statearr_35091_35112[(5)] = ex__15102__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_35060);

return cljs.core.cst$kw$recur;
} else {
throw e35090;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__15100__auto__,cljs.core.cst$kw$recur)){
var G__35113 = state_35060;
state_35060 = G__35113;
continue;
} else {
return ret_value__15100__auto__;
}
break;
}
});
re_com$typeahead$debounce_$_state_machine__15099__auto__ = function(state_35060){
switch(arguments.length){
case 0:
return re_com$typeahead$debounce_$_state_machine__15099__auto____0.call(this);
case 1:
return re_com$typeahead$debounce_$_state_machine__15099__auto____1.call(this,state_35060);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
re_com$typeahead$debounce_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$0 = re_com$typeahead$debounce_$_state_machine__15099__auto____0;
re_com$typeahead$debounce_$_state_machine__15099__auto__.cljs$core$IFn$_invoke$arity$1 = re_com$typeahead$debounce_$_state_machine__15099__auto____1;
return re_com$typeahead$debounce_$_state_machine__15099__auto__;
})()
;})(switch__15098__auto__,c__15224__auto___35093,out))
})();
var state__15226__auto__ = (function (){var statearr_35092 = (f__15225__auto__.cljs$core$IFn$_invoke$arity$0 ? f__15225__auto__.cljs$core$IFn$_invoke$arity$0() : f__15225__auto__.call(null));
(statearr_35092[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__15224__auto___35093);

return statearr_35092;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__15226__auto__);
});})(c__15224__auto___35093,out))
);


return out;
});
